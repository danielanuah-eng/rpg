// O Peso do Céu — Ficha do Colosso — versão 3.8.0
// Guarda tudo na primeira visita. Depois disso a rede é opcional.
const CACHE = 'peso-ficha-v3.8.0';
const ARQUIVOS = [
  './', './manifest.webmanifest',
  './icone-192.png', './icone-512.png',
  './icone-192-mascara.png', './icone-512-mascara.png',
  './apple-touch-icon.png', './favicon.png'
];

// versão nova: baixa tudo direto da rede (sem cache do navegador no meio)
self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE)
      .then(c => c.addAll(ARQUIVOS.map(u => new Request(u, {cache: 'reload'}))))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys()
      .then(ks => Promise.all(
        ks.filter(k => k.startsWith('peso-ficha-') && k !== CACHE)
          .map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

// Cache primeiro: a mesa costuma ser num porão sem sinal.
// A rede roda por fora, sem segurar a tela, só para atualizar.
// Qualquer abertura do app (com ?instalar, index.html...) é a mesma página.
self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  if (new URL(req.url).origin !== self.location.origin) return;
  const chave = req.mode === 'navigate' ? './' : req;
  const rede = fetch(req).then(r => {
    if (r && r.ok && r.type === 'basic' && !r.redirected) {
      const copia = r.clone();
      caches.open(CACHE).then(c => c.put(chave, copia));
    }
    return r;
  });
  e.waitUntil(rede.then(() => {}, () => {}));
  e.respondWith(
    caches.match(chave, {cacheName: CACHE})
      .then(achou => achou || rede)
      .catch(() => rede)
  );
});
