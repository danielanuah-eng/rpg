---
tipo: Regras
categoria: Sistema
tags:
  - regras
  - sistema
pdf_page: 8
---


# Reclamações Divinas

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=8|Consultar Texto Original no PDF (Página 8) — Políticas dos Deuses e Gatilhos]]**

A reclamação divina é a cena mais importante que cada jogador vai ter neste livro, e é a única que não dá para forçar. Ela existe para o Mestre nunca precisar improvisar nenhuma delas.

---

## A Regra de Ouro

**Deus não reclama por calendário. Deus reclama quando é conveniente para ele** — e cada um destes cinco deuses tem um motivo diferente. Por isso as reclamações acontecem espalhadas, uma por vez, em capítulos diferentes, e duas delas podem não acontecer no Livro 1.

- **[[Kira Andros|Kira]]** já foi reclamada meses antes do início da campanha. Ela já mora no [[Chalé 5 - Ares|Chalé 5]] e serve como o exemplo vivo para a mesa de como a dinâmica funciona.
- **[[Barak Armstrong|Barak]]** é o único com data agendada por Zeus.
- **[[Hadesson Neto|Hadesson]]** NÃO é reclamado no Livro 1 por desígnio deliberado de Hades.

---

## Políticas dos Deuses

| Deus | A política dele | O que isso faz na mesa |
| :--- | :--- | :--- |
| **Ares** | Não vê problema nenhum. No instante em que repara num feito de bravura, ele assume. Gosta de ser reconhecido por gente que briga bem; não tem paciência para discrição. | [[Daniel Storis|Daniel]] é o primeiro a ser reclamado depois de Barak, provavelmente já no [[Capítulo 3 - O Pega-Bandeira|Capítulo 3]]. |
| **Zeus** | Calculista e político. Sabe da existência do filho desde antes do museu e escolheu o local exato: no acampamento, perante todo mundo. Não é carinho — é anúncio de poder. | [[Barak Armstrong|Barak]] tem data marcada: [[Capítulo 2 - A Chegada|Capítulo 2]], na fogueira. É a única reclamação agendada. |
| **Atena** | Não vê problema, mas não age por impulso. Ela assume quando o filho faz algo que a honra publicamente — e ela mesma julga o que é isso. | [[Igorovsky Baranyeisky|Igorovsky]] é reclamado no primeiro momento em que sua mente salva alguém em público. |
| **Apolo** | Festeiro, assume alto com luz e som. Quer exibição e arte ou compaixão brilhante. | [[Ícaro Lyra|Ícaro]] é reclamado quando cuida de alguém a ponto de esquecer de si mesmo. |
| **Hades** | Esconde. Filho dos Três Grandes atrai perigo e atritos cósmicos. O último pacto ainda dói; esconder o filho é a única proteção que ele pode oferecer. | [[Hadesson Neto|Hadesson]] **NÃO** é reclamado no Livro 1. Trate o silêncio do pai como ferida aberta. |

---

## As Cinco Reclamações, Uma a Uma

### 1. BARAK · ZEUS (Agendado, Capítulo 2)
- **Quando:** Na fogueira, no encerramento do [[Capítulo 2 - A Chegada]], com o acampamento inteiro em volta.
- **O sinal:** Um raio azul-branco suspenso no ar acima de sua cabeça, girando lentamente, com um estalo seco que reverbera no peito — o trovão chega antes da luz, na ordem invertida.
- **O que muda:** Silêncio sepulcral de trezentas pessoas, seguido por murmúrios eternos. Barak ganha plateia permanente — o que ele desejava e o que lhe custará caro.
  > [!IMPORTANT]
  > Se a mesa não chegar à fogueira, Zeus reclama onde estiverem no final da sessão, com menos plateia, ficando visivelmente irritado com isso.

### 2. DANIEL · ARES (Gatilho, a partir do Capítulo 3)
- **O gatilho:** Encarar algo muito maior que ele e não recuar. Não precisa vencer; precisa ficar de pé.
- **Onde é provável:**
  - Cap. 3: Aceitar o duelo declarado de [[Augusto]] (ganhando ou perdendo).
  - Cap. 4: Ficar entre um monstro e um campista menor.
  - Cap. 6: Falar diretamente com uma cabeça de Cila em vez de se esconder.
  - Cap. 9: Voltar para buscar alguém na fuga.
- **O sinal:** Uma lança cruzada com um javali rubro, girando devagar, com cheiro de ferro quente e mato pisado.
- **O que muda:** O [[Chalé 5 - Ares]] explode em gritos e celebração. Augusto o observa com seriedade. Daniel herda uma família que luta por ele e uma fama que não escolheu.

### 3. IGOROVSKY · ATENA (Gatilho, a partir do Capítulo 3)
- **O gatilho:** Resolver com lógica um problema caro, perante testemunhas (adultos ou meio acampamento). Atena não assume em segredo.
- **Onde é provável:**
  - Cap. 3: Descobrir sozinho a bandeira falsa de [[Fausto]] ou surpreendê-lo taticamente.
  - Cap. 4: Descobrir a mecânica para derrubar o Ogro Ensombrado em dupla.
  - Cap. 6: Associar os seis espantalhos às seis cabeças de Cila antes dos outros.
  - Cap. 8: Cronometrar a troca de turno dos guardas Cebrenos.
- **O sinal:** Uma coruja cinza milimetricamente desenhada sobre sua cabeça, que hesita um segundo extra e olha nos olhos dele antes de sumir.
- **O que muda:** O [[Chalé 6 - Atena]] aplaude educadamente e Demyra anota seu nome. Começam a cobrar respostas impossíveis dele.

### 4. ÍCARO · APOLO (Gatilho, a partir do Capítulo 4)
- **O gatilho:** Cuidar de outrem a ponto de se esquecer de si mesmo, ou praticar um ato artístico memorável em público.
- **Onde é provável:**
  - Cap. 4: Atender na enfermaria superlotada até a exaustão.
  - Cap. 5: Tratar o braço ferido de [[Dave]] na estação de metrô.
  - Cap. 7: Rezar no olho do funil de Caríbdis.
  - Cap. 8: Cantar e acalmar os pégasos nos currais da ilha.
- **O sinal:** Um sol e uma lira dourados. Toda música tocando ao redor desafina por um segundo e volta cristalina e perfeita.
- **O que muda:** Tom Belff dá um assobio vibrante. O [[Chalé 7 - Apolo]] passa a procurá-lo para curas constantes, sem nunca perguntar se ele próprio está bem.

---

## HADESSON · HADES (O Único que Depende do Mestre)

Hades não quer reclamar. Ele protege escondendo. Contudo, quanto mais o garoto manifesta poderes das trevas diante de testemunhas, mais insustentável fica o segredo.

### A Contagem do Silêncio (6 Segredos)
*Contador oculto do Mestre. Não desenhe na mesa. Começa em 0 no Capítulo 2.*
- **Avança 1 quando Hadesson:**
  - Usa poder de morte, sombras ou frio na frente de terceiros.
  - É reconhecido por uma besta ancestral, morto ou monstro sem se apresentar.
  - Dá uma ordem em situação de crise que salva vidas e é prontamente obedecido.
  - Encara sozinho algo letal e sobrevive.
- **Avança 2 quando:**
  - Faz qualquer um dos atos acima na presença direta de um deus, oráculo ou monstro falante.

### Desfecho no Fim do Livro 1:
- **0 a 3 segmentos:** Hades permanece calado. É o padrão da campanha: termina com uma ferida aberta a ser cobrada no Livro 2.
- **4 a 5 segmentos:** Hades não reclama, mas cede uma bênção discreta: no Cap. 9, Cérbero para na boca da caverna e encara Hadesson nos olhos por três segundos antes de partir.
- **6 segmentos (Cheio):** A Reclamação Sombria se manifesta no Cap. 9:
  > *"Não tem luz. Ninguém aponta, ninguém grita, e você não sente nada. O que acontece é que as sombras param. As das árvores, as das pessoas, a do fogo — todas param ao mesmo tempo. E aí a sua sombra, só a sua, fica de pé quando você está sentado. Ela tem a forma de um elmo. Fica assim por cinco segundos... e Quíron diz em voz solene: 'Bem-vindo, filho de Hades.'"*

---

## Como Conduzir Qualquer Reclamação
1. **Pare a mesa**: Nunca faça no calor de um turno de combate. Deixe a poeira baixar e descreva o silêncio.
2. **Descreva de fora**: Não diga ao jogador o que ele sente internamente; descreva a reação boquiaberta da plateia.
3. **Máximo de uma por sessão**: Se dois dispararem o gatilho na mesma noite, guarde o segundo para um momento mais épico.
4. **Pergunte, não narre o fim**: *"Trezentas pessoas estão olhando para você. O que você faz com as mãos?"*
5. **Se ninguém for reclamado, sem problemas**: Apenas Barak é mandatório. Dois personagens não reclamados tornam o drama muito mais potente.

---

## Links Relacionados
- [[Barak Armstrong]]
- [[Hadesson Neto]]
- [[Daniel Storis]]
- [[Igorovsky Baranyeisky]]
- [[Ícaro Lyra]]
- [[Kira Andros]]
- [[🏠 Início]]
