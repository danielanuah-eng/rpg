---
tipo: Regras
categoria: Sistema
tags:
  - regras
  - sistema
pdf_page: 15
---


# Quando a Mesa Faz Besteira

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=15|Consultar Texto Original no PDF (Página 15) — Regras de Condução e Tabela de Consequências]]**

*A seção mais usada do livro.*

Seus jogadores não conhecem este mundo. Cinco deles descobriram que são semideuses na terça-feira passada, e a mesa inteira está aprendendo as regras sociais de um lugar onde monstro se disfarça de curador e deus se disfarça de tédio. Eles vão bater em quem não deviam, abrir o que não deviam e falar o que não deviam.

Isso não é sabotagem. É falta de mapa. E a resposta certa quase nunca é castigo.

---

## As Três Regras de Ouro

1. **Nunca puna ignorância. Puna teimosia.**
   - A primeira vez que alguém faz besteira por não entender o mundo, a consequência ensina.
   - Da segunda vez, sabendo, a consequência cobra. São coisas diferentes e a mesa sente a diferença na hora.
2. **A consequência é a aula.**
   - Não explique a regra do mundo em voz de narrador. Mostre o que acontece e deixe eles deduzirem.
   - Bater num guarda de museu não vira lição de moral: vira um guarda caído no chão, assustado, olhando pra eles — e essa imagem ensina mais que qualquer fala.
3. **Deixe a besteira funcionar de vez em quando.**
   - Um plano burro que dá certo é a melhor coisa que pode acontecer numa mesa, e é o que faz os jogadores confiarem em você para tentar coisas. Uma em cada três.

---

## O que Fazer com Cada Tipo de Besteira

| A besteira | Não faça | Faça |
| :--- | :--- | :--- |
| **Atacar um NPC inofensivo** *(guarda, funcionário, campista)* | Combate. Nunca vire combate. | A pessoa cai sentada, assustada, e não revida. O silêncio na sala é a consequência. Alguém vai pedir desculpa e alguém não vai, e isso define os dois. |
| **Atacar um NPC que não pode ser vencido** *(Polifemo, Cila, Lélape)* | Matar o personagem para provar um ponto. | O golpe acerta e não faz nada. Descreva o bronze celestial escorregando, a criatura nem olhando. Dê a informação rápido — um round, não três. |
| **Quebrar, roubar, incendiar** | Bronca de NPC. | Funciona. E alguém viu. A consequência chega três cenas depois, pela porta errada. |
| **Falar a verdade para quem não devia** | Fazer o NPC não acreditar. | Deixe acreditar. Informação vazando é melhor gancho que informação guardada. |
| **Separar-se do grupo sem motivo** | Matar quem se separou. | Isso é exatamente o que a [[Como a Noite Trabalha|Noite]] quer. Dê a essa pessoa uma cena boa e sozinha, e depois cobre. |
| **Insistir num plano que não vai dar certo** | Deixar falhar em silêncio. | Faça um NPC dizer, uma vez, em voz alta e curta, por que não vai dar. Se insistirem, deixe acontecer e não sabote. |
| **Ignorar a pista que você achou óbvia** | Repetir a pista igual. | Mude o mensageiro, não a mensagem. A mesma informação na boca de outra pessoa, num tom diferente. |
| **Perguntar uma coisa que o personagem saberia** *(mitologia, acampamento)* | "Seu personagem sabe isso" e seguir. | Responda. Jogador que não conhece mitologia não pode ser penalizado por isso. Responda como o personagem responderia, curto, e siga. |
| **Fazer a coisa mais absurda possível** | Consequência fatal. | Consequência absurda. Engraçada, cara, não letal, e que volta depois — o absurdo que rende é o que tem sequela. |
| **Duas pessoas brigando na mesa** *(personagens, não jogadores)* | Resolver por você. | Deixe rolar até alguém ter que escolher um lado. Depois entre com um NPC que interrompe. |

---

## O Aviso de Três Camadas

Antes de qualquer coisa irreversível, avise três vezes, de três jeitos. Se avisou três vezes e eles foram mesmo assim, a consequência é justa e ninguém reclama:
1. **O ambiente avisa**: Cheiro errado, silêncio repentino, marca de garra no chão, uma porta já arrombada.
2. **Um NPC avisa**: Curto, sem explicar. *"Eu não ia por aí."*
3. **Você avisa, fora da ficção**: Uma frase, na sua voz de mestre: *"Só pra deixar claro: isso aqui pode acabar mal de verdade."*

> [!NOTE]
> A terceira camada não quebra imersão. Quebra menos do que um personagem morto por mal-entendido.

---

## A Régua do Irreversível

| Sempre Reversível | Reversível com Custo | Irreversível |
| :--- | :--- | :--- |
| Apanhar, cair, ser derrubado | Ser preso, capturado, separado | O preço de [[Kyla Nestor (Cila)|Cila]] (Cap. 6) |
| Quebrar coisa, ser expulso de um lugar | Perder um item, perder um aliado | Quem fica na porta (Cap. 9 - [[Breno]]) |
| Falar besteira, brigar, ofender | Perder a confiança de um NPC | Morte de personagem jogador |
| Errar o caminho, perder tempo | Deixar a [[A Brasa da Casa]] apagar | — |

> [!IMPORTANT]
> Só cobre a coluna da direita (**Irreversível**) depois das três camadas de aviso. As outras duas colunas você pode cobrar à vontade, o tempo todo, sem dó — é delas que a campanha vive.

---

## Feito Para Esta Mesa (Os Jogadores)

- **[[Daniel Storis|Daniel (LG)]]**: Vai fazer a coisa mais burra disponível toda sessão. Tenha uma consequência absurda pronta em cada cena. Ele não quer vencer: quer que aconteça alguma coisa.
- **[[Barak Armstrong|Barak (Caio)]]**: Foge quando a maré vira, e não gosta de ser afrontado na frente dos outros. *Nunca humilhe Barak em público.* Se precisar cobrar dele, cobre em particular, com um NPC, em voz baixa.
- **[[Hadesson Neto|Hadesson (Wilson/Soneto)]]**: Abandona o barco se estiver em desvantagem, e isso é do personagem. Não moralize. Dê a ele uma vez em que abandonar era a jogada certa, e ele passa a ficar por escolha.
- **[[Igorovsky Baranyeisky|Igorovsky (Filipe)]]**: Não conhece a mitologia. Toda vez que a resposta depender disso, entregue a informação sem cobrar teste e sem condescender. Ele resolve com lógica, não com repertório — dê a ele o repertório e assista.
- **[[Ícaro Lyra|Ícaro (Lucas)]]**: Vai querer conversar com o monstro antes de bater. Metade dos adversários deste livro tem conversa; a outra metade tem os olhos pretos. Deixe ele descobrir qual é qual pagando barato.
- **[[Kira Andros|Kira (Alessa)]]**: É a que sabe das coisas e vai liderar. Quando ela liderar para o lugar errado, não corrija pela boca de um adulto — deixe outro jogador discordar.

---

## Links Relacionados
- [[Sistema de Rolagem]]
- [[Como a Noite Trabalha]]
- [[Reclamações Divinas]]
- [[Capítulo 1 - O Museu das Maravilhas]]
- [[🏠 Início]]
