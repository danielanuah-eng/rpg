---
tipo: Hub
categoria: Sistema
tags:
  - regras
  - sistema
  - hub
pdf_page: 6
---

# 🔷 Guia de Regras & Sistema de Jogo

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=6|Consultar Texto Original no PDF (Página 6) — Guia do Mestre]]**

Regras de condução, gestão de dados, economia de medo e mecânicas adaptadas de Daggerheart.

---

## Seções de Regras
- **[[Sistema de Rolagem]]:** Leitura de dados de Esperança e Medo, acertos críticos e atributos.
- **[[Quando a Mesa Faz Besteira]]:** As três regras de condução, consequências pedagógicas e a régua do irreversível.
- **[[Como a Noite Trabalha]]:** A manipulação pela verdade, os Pseudologoi e a regra inquebrável de Dave.
- **[[Cheiro Névoa e Disfarce]]:** Faro de monstros, distorções da Névoa e tiques de disfarces.
- **[[Reclamações Divinas]]:** Requisitos de aclamação, as cinco revelações e a Contagem do Silêncio de Hades.

---
[[🏠 Início|⬅ Retornar ao Início]]
