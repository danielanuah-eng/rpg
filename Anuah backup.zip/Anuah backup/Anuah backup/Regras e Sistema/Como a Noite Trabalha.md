---
tipo: Regras
categoria: Sistema
tags:
  - regras
  - sistema
pdf_page: 20
---


# Como a Noite Trabalha

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=20|Consultar Texto Original no PDF (Página 20) — Corrupção, Pseudologoi e Regra do Dave]]**

Nyx nunca aparece. Ela não ataca, não ameaça e não fala. O que ela faz é três coisas, e todo capítulo deste livro tem pelo menos uma delas acontecendo em segundo plano.

---

## 1. Ela corrompe pelo argumento, não pela magia

A corte de Nyx não possui ninguém. Convence. 
- [[Dave]] não foi enfeitiçado: concordou.
- Os infiltrados da [[A Ordem da Família das Máscaras|Ordem]] passaram pelo rito de purificação de coração limpo e mudaram de ideia depois, conversando.

**Na mesa isso vira:**
Todo agente da Noite diz coisas verdadeiras. Que missões de deuses são abusivas. Que semideuses morrem por causas que não escolheram. Que ninguém reclamou aquele garoto. Você nunca precisa fazer o vilão mentir — e é isso que assusta.

> [!TIP]
> **Sinal de mesa:** Quando um NPC disser algo que deixe um jogador em silêncio por dois segundos, você acertou. Marque a frase e repita-a mais tarde, na boca de outra pessoa.

---

## 2. Ela engana pelo que a pessoa já queria ouvir

Os **Pseudologoi** — os irmãos falsos — não inventam. Escolhem uma verdade e dizem do jeito mais cruel possível, no pior momento possível, para quem já estava sozinho.

**Mecânica do Sussurro (Custa 3 Medo):**
Você fala só com um jogador, em voz baixa, olhando só para ele. Uma frase. Verdadeira. Ele escolhe:
- Marcar **2 Estresse** para aguentar, OU
- Entregar **1 Esperança** para não ouvir — e se entregar a Esperança, você fala mesmo assim, mas só ele sabe o que foi dito.

### Frases prontas por personagem:
- **[[Barak Armstrong|Barak]]:** *"Seu pai viu você chegar. Não fez nada. Ele só viu."*
- **[[Kira Andros|Kira]]:** *"Você não foi embora de casa. Você foi mandada."*
- **[[Igorovsky Baranyeisky|Igorovsky]]:** *"Nenhuma das suas contas explica por que você gosta deles."*
- **[[Daniel Storis|Daniel]]:** *"Todo mundo ri. Ninguém chama você quando é sério."*
- **[[Ícaro Lyra|Ícaro]]:** *"Você sabe consertar gente. Não sabe consertar isso."*
- **[[Hadesson Neto|Hadesson]]:** *"Você já esteve num lugar assim antes. Você só não lembra de ter voltado."*

---

## 3. Ela dá medo tirando a explicação

Nada do [[O Criadouro|Ensombrado]] tem explicação disponível:
- Monstro sem rastro.
- Corpo que não vira pó ao morrer.
- Sombra que faz o gesto errado.
- Grilos que param todos ao mesmo tempo.
- **Nunca explique nenhum desses no Livro 1.**

### Os Quatro Tiques da Noite (Espalhe um por sessão):
1. **A luz cai um degrau** num ponto só do mapa, e ninguém mexeu em interruptor nenhum.
2. **Os bichos param**: Grilo, pássaro, cachorro de vizinho. Todo mundo percebe; ninguém sabe dizer o que mudou.
3. **A sombra não corresponde**: A sombra de alguém conhecido faz um gesto que a pessoa não fez.
4. **A noite chega cedo ali**: Escurece num quarteirão antes do resto da rua.

> [!WARNING]
> **A Regra de Ouro da Noite:** Se os jogadores virem Nyx, ela morre como ameaça. Ela não tem forma neste livro. Ela tem *ausência de explicação*, e a ausência de explicação é a coisa mais assustadora que existe numa mesa de doze anos de idade.

---

## 4. A Regra do Dave

[[Dave]] não pode ser descoberto no Livro 1. Não é difícil: **é impossível**.

Isso não é proteção de enredo do Mestre — é o poder dele. Filho de Afrodite treinado pela corte de Nyx, ele acredita em tudo que diz na hora em que diz, e por isso não existe nada para pegar: nem hesitação, nem contradição, nem cheiro de mentira.

**Mecanicamente:** Todo teste a respeito de Dave sai a favor dele.

| Se a mesa tentar... | O que acontece |
| :--- | :--- |
| **Ler Dave com a [[A Meia-Máscara de Pavão|Meia-Máscara]]** | *"Nada. Como olhar pra água parada."* A máscara não tem o que ler. |
| **Detectar mentira, intenção, nervosismo** | Ele está dizendo a verdade. Sempre está — só não a verdade inteira. |
| **Seguir Dave** | Ele está exatamente onde disse que estaria, fazendo exatamente o que disse. Ele já tinha feito a outra parte antes de sair. |
| **Revistar as coisas dele** | Não tem nada. O que importa ele não carrega no corpo. |
| **Mentir para Dave** | Ele sabe (graças ao [[O Espelho de Atena]]), e não confronta: arquiva, e muda o plano dele em silêncio. |
| **Acusá-lo na cara, sem prova** | Ele não nega, não se ofende e não se defende. Ele pergunta, com preocupação real, o que aconteceu para a pessoa pensar isso. E a mesa inteira fica constrangida. |

> [!NOTE]
> **Como narrar Dave:** Nunca diga *"você não descobre nada"*. Diga o que eles descobriram, e que tudo confere perfeitamente. A sensação que fica não é de parede — é de alívio. É pior.

---

## Links Relacionados
- [[A Noite e Nyx]]
- [[Dave]]
- [[O Espelho de Atena]]
- [[O Criadouro]]
- [[Quando a Mesa Faz Besteira]]
- [[🏠 Início]]
