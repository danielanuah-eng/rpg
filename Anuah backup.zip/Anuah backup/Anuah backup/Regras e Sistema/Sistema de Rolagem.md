---
tipo: Regras
categoria: Sistema
tags:
  - regras
  - sistema
pdf_page: 6
---


# Sistema de Rolagem

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=6|Consultar Texto Original no PDF (Página 6) — Leitura de Rolagem e Atributos]]**

Em *A Noite Mais Densa*, a mecânica de jogo utiliza o sistema de dados duplos de **Daggerheart** (Dado de Esperança vs. Dado de Medo), além de atributos específicos adaptados para a mitologia greco-romana moderna.

---

## 1. Atributos da Ficha

O livro utiliza **Estresse** (não "Fadiga") e seis atributos fundamentais:
- **Agilidade**: Movimento rápido, corrida, esquiva física e perseguição veloz.
- **Força**: Força física bruta, agarrões, empurrões, arremessos e armas pesadas.
- **Finesse**: Precisão cirúrgica, furtividade, esconder-se, consertar mecanismos e manobras delicadas.
  > [!NOTE]
  > Esconder-se, manobrar e consertar são **Finesse**, não Agilidade. Este é o erro mais comum em mesas novas.
- **Instinto**: Percepção sensorial apurada, intuição, sentir cheiro sobrenatural ou notar ameaças ocultas.
- **Presença**: Carisma, liderança, intimidar, convencer, atuação e autoridade.
- **Conhecimento**: Sabedoria teórica, história antiga, deduções lógicas, leitura de escrituras e análise tática.

---

## 2. Leitura dos Dados e Resultados

Toda rolagem de ação envolve o lançamento de **2d12** (um dado representando a **Esperança** e outro o **Medo**). O valor final é somado ao modificador do atributo contra a Dificuldade (Dif.) estipulada pelo Mestre.

| Resultado | O que é | O que o Mestre faz |
| :--- | :--- | :--- |
| **Sucesso Crítico** | Dados iguais que superam a Dificuldade. | O jogador consegue o que quer e mais: **+1 Esperança**, **-1 Estresse**. Descreva o feito muito melhor do que o jogador descreveu. *Crítico nunca vem com Medo: o dado de Esperança é sempre o que manda nele.* |
| **Sucesso com Esperança** | Passa na Dif. e o dado de Esperança é estritamente maior. | Consegue o que quer sem complicações. **+1 Esperança**. O jogo segue em frente limpo. |
| **Sucesso com Medo** | Passa na Dif., mas o dado de Medo é estritamente maior. | Consegue o que quer e o mundo cobra a fatura. O Mestre ganha **+1 Medo** e o holofote. *Nunca desfaça o sucesso!* Cobre em outro lugar: tempo, barulho, atenção indesejada ou alguém vendo. |
| **Falha com Esperança** | Não atinge a Dif., mas o dado de Esperança é maior. | Não consegue o que queria, mas ganha **+1 Esperança**. Abra uma porta nova ou oportunidade alternativa, não um beco sem saída. |
| **Falha com Medo** | Não atinge a Dif. e o dado de Medo é maior. | Não consegue. O Mestre ganha **+1 Medo** e o holofote. É exatamente aqui que a [[A Noite e Nyx|Noite]] avança. |

> [!WARNING]
> **O erro mais comum:** Tratar *Sucesso com Medo* como meio-sucesso. Não é. O jogador conseguiu. O Mestre é quem ganhou uma moeda para gastar — e vai gastar daqui a três minutos, quando ninguém estiver esperando.

---

## 3. Gestão dos Recursos

- **Esperança (Jogadores)**: Moeda dos semideuses. Usada para ajudar aliados fora de turno, ativar habilidades de domínio divino, amortecer impactos severos ou mitigar estresse.
- **Medo (Mestre)**: Moeda do destino e dos monstros. Usada para disparar Ações de Medo exclusivas dos inimigos, apagar lâmpadas, separar o grupo, acelerar relógios e sussurros de [[A Noite e Nyx|Nyx]].
- **Estresse**: Medidor de desgaste físico e emocional. Quando a trilha de Estresse enche, o personagem fica Vulnerável.

---

## Links Relacionados
- [[Quando a Mesa Faz Besteira]]
- [[Como a Noite Trabalha]]
- [[Reclamações Divinas]]
- [[Cheiro Névoa e Disfarce]]
- [[🏠 Início]]
