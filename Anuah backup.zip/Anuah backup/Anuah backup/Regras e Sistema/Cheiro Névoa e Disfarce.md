---
tipo: Regras
categoria: Sistema
tags:
  - regras
  - sistema
pdf_page: 24
---


# Cheiro, Névoa e Disfarce

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=24|Consultar Texto Original no PDF (Página 24) — Regras de Cheiro, Névoa e Tiques de Monstros]]**

Três regras de mundo fundamentais que valem do primeiro capítulo ao último. Explique-as sempre pela ficção, nunca pela regra bruta.

---

## 1. Cheiro

Semideus cheira. Quanto mais forte o pai divino, quanto mais velho o filho, quanto mais poder usado, mais longe o cheiro chega. Monstro não enxerga melhor que ninguém — **ele fareja**.

### Na mesa:
- **Crianças juntas cheiram mais**: Seis crianças juntas cheiram muito mais do que seis separadas. Isso é motivo mecânico para se dividirem, e motivo emocional para não se dividirem.
- **Uso de poder divino acende o cheiro**: Toda vez que um jogador fizer algo abertamente sobrenatural em público, você ganha **1 Medo**. Não avise antes; avise depois, uma vez, para a regra ficar conhecida.
- **O que corta o cheiro**: [[A Brasa da Casa]] e **água corrente** cortam cheiro (banho, chuva forte, fumaça de fogueira, riacho). É uma saída criativa constante esperando ser descoberta pelos jogadores.
- **[[Barak Armstrong|Barak]] cheira mais que todos**: Filho de um dos Três Grandes (Zeus). Se você quiser justificar por que o museu virou armadilha no [[Capítulo 1 - O Museu das Maravilhas|Capítulo 1]], a resposta é o cheiro dele — e ele nunca precisa saber disso no Livro 1.

---

## 2. A Névoa

A Névoa cobre o sobrenatural com uma explicação mundana, e o mortal sempre escolhe a explicação mais comum:
- Um dragão vira um caminhão desgovernado.
- Uma espada de bronze vira um taco de beisebol.
- Um centauro vira um homem numa cadeira de rodas.

**Na mesa:** Toda vez que algo impossível acontecer na frente de mortais, descreva o que os mortais viram, não o que realmente aconteceu. É cômico, canônico do universo de Percy Jackson e ensina o funcionamento do mundo sem dar aula formal.

---

## 3. Disfarce dos Monstros

Monstro inteligente se disfarça de coisa cotidiana e chata: funcionário público, professor substituto, gerente de atendimento, curador de museu, guarda. 
**O disfarce nunca falha por aparência — falha por comportamento.**

Cada monstro disfarçado deste livro tem um **tique característico que o entrega**, percebível sem rolagem se o jogador estiver prestando atenção na coisa certa:

| Monstro | Disfarce | O Tique Revelador |
| :--- | :--- | :--- |
| **[[Mormo]]** | [[Sr. Morelo (Mormo)|Sr. Morelo]], curador do museu | Conta as crianças apontando com o dedo — e conta de novo, e o número dá diferente. |
| **[[Lélape]]** | Estátua de cão numa vitrine | A poeira nunca assenta nele. |
| **[[Crocotta]]** | Voz no escuro do túnel de metrô | Fala frases inteiras sem respirar no meio. |
| **[[Kyla Nestor (Cila)|Cila]]** | Kyla Nestor, gerente do parque aquático Nostos | Nunca vira as costas para ninguém (anda de lado, contorna portas). |
| **[[Cebrenos]]** | Guardas burocratas de uniforme | Explicam em voz alta o procedimento antes de executá-lo. Sempre. |

> [!TIP]
> Se um jogador achar o tique sem rolar dados, dê a resposta de graça e elogie. Achar o tique é a recompensa de prestar atenção, e prestar atenção é o que você quer ensinar nesta campanha inteira.

---

## Links Relacionados
- [[Sistema de Rolagem]]
- [[Quando a Mesa Faz Besteira]]
- [[Como a Noite Trabalha]]
- [[Capítulo 1 - O Museu das Maravilhas]]
- [[Capítulo 6 - O Parque Aquático Nostos]]
- [[🏠 Início]]
