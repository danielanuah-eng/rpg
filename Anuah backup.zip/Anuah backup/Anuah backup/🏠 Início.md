---
tipo: Hub
categoria: Início
tags:
  - moc
  - inicio
  - hub
pdf_page: 1
---

# 🏠 A Noite Mais Densa — Livro 1
### Campanha de RPG: Percy Jackson × Daggerheart

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=1|Consultar Texto Original no PDF (Página 1) — Sumário e Guia Geral]]**

Bem-vindo à Wiki oficial de **A Noite Mais Densa (Livro 1)**. Use os hubs setoriais abaixo para explorar as regras, personagens, chalés, feras e sessões da campanha:

---

## 🧭 Navegação Setorial (Os Oito Grandes Hubs)

- 🔷 **[[Regras e Sistema]]:** Dados de Esperança e Medo, regras pedagógicas e economia da mesa.
- 🟣 **[[Capítulos]]:** As nove sessões cronológicas do Museu de NY ao clímax na Ilha de Ninguém.
- 🔵 **[[Protagonistas]]:** A Mesa dos Seis (Barak, Kira, Daniel, Igorovsky, Ícaro e Hadesson).
- 🟢 **[[NPCs do Acampamento]]:** Mestres, diretores e campistas de Long Island ([[Quíron]], [[Kellen (Diretor K)|Kellen]], [[Augusto]], etc.).
- 🟡 **[[NPCs do Mundo]]:** Deuses olimpos e figuras mundanas ([[Professor Fujiho]], [[Sr. Morelo (Mormo)|Sr. Morelo]], [[Kyla Nestor (Cila)|Cila]], [[Polifemo]]).
- 🟠 **[[Acampamento Meio-Sangue]]:** O refúgio seguro e os **[[Chalés do Acampamento]]** (Cabanas 1 a 13).
- 🔴 **[[Bestiário e Ameaças]]:** As 18 feras, demônios e perigos mitológicos calibrados em Daggerheart.
- 🪙 **[[Itens e Relíquias]]:** Armas sagradas de bronze celestial e artefatos de poder.
- 🌸 **[[Lore e Profecias]]:** [[A Grande Profecia]], [[A Profecia da Missão]], [[O Caso Édea]], [[O Criadouro]] e [[A Noite e Nyx]].

---

## ⚡ Guia Rápido de Regras em Jogo
- [[Sistema de Rolagem]] · [[Quando a Mesa Faz Besteira]] · [[Como a Noite Trabalha]] · [[Cheiro Névoa e Disfarce]] · [[Reclamações Divinas]]

---

## 🛰️ Outra campanha neste vault

- **[[🛰️ O Peso do Céu]]** — RPG de mechas (Daggerheart × Lancer), segunda edição. Oito fábricas, 120 Peças, 104 adversários e combate no teatro da mente. Wiki completa em `O Peso do Céu/`.
