---
tipo: Bestiário
categoria: Ameaça
tags:
  - bestiario
  - ameaca
  - monstro
pdf_page: 165
---


# As Sereias

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=165|Consultar Texto Original no PDF (Página 165) — Encontro e Canto das Sereias]]**

Criaturas mitológicas ancestrais empoleiradas num recife de pedras no meio do Mar de Monstros ([[Capítulo 7 - O Mar]]).

---

## O Método de Caça
- Não aparentam beleza juvenil nem cantam árias encantadas: são criaturas idosas, magras e pálidas.
- **O Engodo da Conversa:** Falam com a voz exata da pessoa que o semideus mais ama no mundo, dizendo exatamente a frase de consolo ou validação que a pessoa mais desejava ouvir na vida.

---

## Resoluções e Testes
- **Ouvir e Resistir:** Presença Dif. 15 (falha faz o personagem caminhar fascinado até a amurada; uma segunda falha Dif. 17 o faz mergulhar no mar).
- **Medidas Clássicas:** Tapar os ouvidos com cera ou amarrar o companheiro ao mastro do navio (Finesse Dif. 13).
- **Música de Ícaro:** [[Ícaro Lyra|Ícaro]] pode cantar com fervor (Presença Dif. 15 com Vantagem) para sobrepujar o chamado das sereias por duas rodadas.

---

## Links Relacionados
- [[Capítulo 7 - O Mar]]
- [[Ícaro Lyra]]
- [[🏠 Início]]
