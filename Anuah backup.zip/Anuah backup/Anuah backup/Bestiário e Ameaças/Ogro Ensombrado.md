---
tipo: Bestiário
categoria: Ameaça
tags:
  - bestiario
  - ameaca
  - monstro
pdf_page: 104
---


# Ogro Ensombrado

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=104|Consultar Texto Original no PDF (Página 104) — Ficha do Ogro Ensombrado]]**

*Tier 1 · Brutamonte*  
Gigante grotesco e musculoso armado com uma marreta descomunal, saído da floresta leste no [[Capítulo 4 - A Noite Mais Densa]].

---

## Estatísticas de Combate
- **Dificuldade:** 13 | **Limiares:** 9/16 | **PV:** 8 | **Estresse:** 3
- **Ataque:** +2 · Marreta colossal · Corpo a corpo · 1d12+3 físico
- **AÇÃO — Marreta:** Quem for atingido escolhe: marcar 4 Estresse ou queimar 2 Esperanças para receber metade do dano.

---

## Passivas e Ações de Medo
- **PASSIVA — Peso esmagador:** Quem encerra a rodada adjacente ao Ogro realiza Agilidade Dif. 13 ou cai perdendo a próxima ação.
- **AÇÃO DE MEDO (1) — Arremesso:** Agarra um campista pela roupa, gira lentamente e o arremessa na zona mais distante do mapa (2 Estresse e larga um item empunhado).
- **AÇÃO DE MEDO (3) — A Pisada:** Desce o calcanhar com impacto sísmico: todos na zona rolam Agilidade Dif. 13 ou tombam no chão. Quem estiver ajoelhado cuidando de um ferido falha automaticamente.
- **FRAQUEZA — Derrubá-lo em Dupla:** Duas pessoas agindo em conjunto gastando 1 Esperança cada realizam Força Dif. 18: o colosso desaba e leva duas rodadas inteiras para se erguer.

---

## Links Relacionados
- [[O Criadouro]]
- [[Capítulo 4 - A Noite Mais Densa]]
- [[Igorovsky Baranyeisky]]
- [[🏠 Início]]
