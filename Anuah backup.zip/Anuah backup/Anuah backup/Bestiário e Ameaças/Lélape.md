---
tipo: Bestiário
categoria: Ameaça
tags:
  - bestiario
  - ameaca
  - monstro
pdf_page: 47
---


# Lélape

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=47|Consultar Texto Original no PDF (Página 47) — Ficha e Perseguição de Lélape]]**

*Tier 1 · Solo*  
O lendário cão da mitologia grega fadado a nunca perder uma caçada.

---

## Estatísticas de Combate
- **Dificuldade:** 14 | **Limiares:** 8/15 | **PV:** 8 | **Estresse:** 4
- **Ataque:** +2 · Bote · Muito Próximo · 1d10+3 físico
- **Experiência:** *"Nunca perdi uma caça"* +3
- **Impulso:** Achar. Pegar. Entregar. Ele não deseja devorar crianças; deseja recuperar a [[A Lâmina-Chave]].

---

## Passivas e Habilidades
- **PASSIVA — Nunca perde:** Nenhum teste para se esconder funciona duas vezes seguidas contra ele. Distância não o desanima. A **única** coisa que atrapalha seu faro é água corrente (chafarizes, rios, bueiros).
- **PASSIVA — Só quer a faca:** Ignora semideuses desarmados, a menos que alguém se interponha entre ele e o portador da lâmina ([[Barak Armstrong|Barak]]).
- **PASSIVA — Implacável (2):** Pode receber o holofote até duas vezes por turno do Mestre gastando Medo.
- **AÇÃO — Cheirar:** Levanta a cabeça e fareja. O Mestre pronuncia o nome do alvo, que marca 1 Estresse imediatamente (sem defesa).
- **AÇÃO DE MEDO (1) — Atalho:** Desaparece na vegetação e ressurge à frente do grupo (avança seu contador de perseguição em +1).
- **AÇÃO DE MEDO (2) — A pata no peito:** Derruba o alvo e pressiona o peito com a pata dianteira, revistando com o focinho. Exige duas pessoas para removê-lo.
- **SE FOR FERIDO DE VERDADE:** Olha fixamente para quem o golpeou, grava seu cheiro e recua temporariamente. Lélape não morre no Livro 1.

---

## Links Relacionados
- [[A Lâmina-Chave]]
- [[Professor Fujiho]]
- [[Capítulo 1 - O Museu das Maravilhas]]
- [[🏠 Início]]
