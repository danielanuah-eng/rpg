---
tipo: Bestiário
categoria: Ameaça
tags:
  - bestiario
  - ameaca
  - monstro
pdf_page: 136
---


# Empusa

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=136|Consultar Texto Original no PDF (Página 136) — Ficha da Empusa Disfarçada]]**

*Tier 1 · Oportunista (2 Pontos de Batalha)*  
Serva metamorfa de Hécate disfarçada de colegial em um banco da plataforma de metrô.

---

## Estatísticas de Combate
- **Dificuldade:** 13 | **Limiares:** 5/10 | **PV:** 4 | **Estresse:** 5
- **Ataque:** +1 · Garras afiadas · Corpo a corpo · 1d8+3 físico
- **Experiência:** *"Ninguém olha duas vezes pra mim"* +3

---

## Habilidades e Peculiaridades
- **PASSIVA — Perna de bronze, perna de burro:** Seu disfarce corporal esconde uma perna feita de bronze celestial e outra de jumenta sob as calças compridas (Instinto Dif. 13 para notar).
- **PASSIVA — Vulnerabilidade ao Fogo:** Qualquer dano ígneo conta **DOBRADO** contra ela e a força a recuar uma zona.
- **AÇÃO — Convite:** Chama a vítima mais isolada pelo nome verdadeiro (Presença Dif. 14 para não ser seduzido para o túnel).
- **AÇÃO DE MEDO (2) — Cabelo em chamas:** Desfaz o disfarce mortal revelando sua face demoníaca, infligindo 1 de Estresse em todos ao redor.

---

## Links Relacionados
- [[Capítulo 5 - A Estrada e o Pub]]
- [[Cão do Inferno]]
- [[🏠 Início]]
