---
tipo: Bestiário
categoria: Ameaça
tags:
  - bestiario
  - ameaca
  - monstro
pdf_page: 35
---


# Mormo

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=35|Consultar Texto Original no PDF (Página 35) — Ficha e Tique de Mormo]]**

O bicho-papão mitológico grego que se alimenta de crianças extraviadas.

---

## O Disfarce: [[Sr. Morelo (Mormo)|Sr. Morelo]]
Atua como o afável curador do turno da noite no Museu das Maravilhas de Nova York. Usa terno de tweed com cotoveleiras de couro e gira um chaveiro metálico no dedo.
- **Filosofia de Caça:** Não persegue suas presas; basta ser o adulto simpático que indica o caminho do banheiro ou oferece guloseimas.
- **O Tique:** Conta as crianças apontando com o dedo indicador e, ao recontar, o número resulta diferente.
- **Anatomia Oculta:** Mão gélida com uma junta a mais em cada dedo.

---

## Comportamento na Sessão
- Nunca entra em combate direto no [[Capítulo 1 - O Museu das Maravilhas]].
- Se uma criança for levada por ele, o objetivo torna-se um resgate emergencial imediato antes da fuga.

---

## Links Relacionados
- [[Sr. Morelo (Mormo)]]
- [[Cheiro Névoa e Disfarce]]
- [[Capítulo 1 - O Museu das Maravilhas]]
- [[🏠 Início]]
