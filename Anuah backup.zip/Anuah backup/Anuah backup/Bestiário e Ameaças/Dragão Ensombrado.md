---
tipo: Bestiário
categoria: Ameaça
tags:
  - bestiario
  - ameaca
  - monstro
pdf_page: 104
---


# Dragão Ensombrado

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=104|Consultar Texto Original no PDF (Página 104) — Ficha do Dragão do Breu]]**

*Tier 1 · Brutamonte (Dois deles na Infiltração)*  
Feras reptilianas do tamanho de cavalos de guerra, alteradas pelas energias de Nyx no [[O Criadouro]].

---

## Estatísticas de Combate
- **Dificuldade:** 14 | **Limiares:** 8/15 | **PV:** 7 | **Estresse:** 3
- **Ataque:** +2 · Garras e sopro de breu · Muito Próximo · 1d10+3 mágico
- **Experiência:** *"Instrução recebida"* +2
- **Aparência:** Olhos totalmente negros sem íris nem brilho, babando um fluido viscoso escuro que faz a grama fumegar e apodrecer.

---

## Habilidades Especiais
- **PASSIVA — Olhos escuros:** Imunidade total a charme, persuasão, engodo ou intimidação.
- **PASSIVA — Baba cáustica:** Terminar o turno na mesma zona do monstro impõe 1 de Estresse.
- **AÇÃO — Sopro de Breu:** Rajada em cone (Agilidade Dif. 15 ou 1d10+3 mágico e ganha a condição *Marcado pelo Breu*).
- **CONDIÇÃO — Marcado pelo Breu:** Toda rolagem de Esperança do semideus passa a contar como Medo até que ele lave a marca em água corrente pura.
- **AÇÃO DE MEDO (2) — O alvo certo:** Foca exclusivamente no semideus mais ferido por ordens pré-estabelecidas de seus criadores.

---

## Links Relacionados
- [[O Criadouro]]
- [[Capítulo 4 - A Noite Mais Densa]]
- [[A Noite e Nyx]]
- [[🏠 Início]]
