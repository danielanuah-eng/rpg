---
tipo: Bestiário
categoria: Ameaça
tags:
  - bestiario
  - ameaca
  - monstro
pdf_page: 72
---


# Campistas do Chalé 5

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=72|Consultar Texto Original no PDF (Página 72) — Ficha da Horda de Ares]]**

*Tier 1 · Horda (3 por PV — 2 Pontos de Batalha)*  
Adolescentes veteranos filhos de Ares que treinam combate corpo a corpo desde os nove anos de idade.

---

## Estatísticas de Combate
- **Dificuldade:** 10 | **Limiares:** 5/9 | **PV:** 4 | **Estresse:** 2
- **Ataque:** -1 · Bronze embotado · Corpo a corpo · 1d6+2 contundente
- **Impulsos:** Derrubar, rir da cara do novato, ajudar a levantar e derrubar de novo.

---

## Regras da Arena e do Jogo
- **PASSIVA — Não é pra matar:** Golpes desferidos por eles nunca causam morte. A 0 PV, a vítima cai atordoada na areia e deve contar até vinte antes de se levantar.
- **AÇÃO — Cercar:** Vítima cercada sofre Desvantagem para sair da zona até derrubar ao menos dois deles.
- **AÇÃO DE MEDO (1) — Grito coordenado:** Apontam e berram em uníssono a posição de um jogador no vale, atraindo [[Augusto]] ou [[Breno]] na rodada seguinte.

---

## Links Relacionados
- [[Chalé 5 - Ares]]
- [[Augusto]]
- [[Capítulo 2 - A Chegada]]
- [[Capítulo 3 - O Pega-Bandeira]]
- [[🏠 Início]]
