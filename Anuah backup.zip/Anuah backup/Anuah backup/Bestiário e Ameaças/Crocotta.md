---
tipo: Bestiário
categoria: Ameaça
tags:
  - bestiario
  - ameaca
  - monstro
pdf_page: 127
---

# Crocotta

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=127|Consultar Texto Original no PDF (Página 127) — Ficha e Emboscada da Crocotta]]**

*Tier 1 · Oportunista*  
Come do escuro e chama pelo nome. Nunca aparece inteiro: só um pedaço de cara, na altura errada, longe demais pra ter certeza.

---

## Estatísticas de Combate
- **Dificuldade:** 12 | **Limiares:** 5/10 | **PV:** 4 | **Estresse:** 4
- **Ataque:** +1 · Mordida · Muito Próximo · 1d8+2 físico
- **Experiência:** *"A voz certa"* +3
- **Impulsos:** Separar um do grupo. Só um. Sempre só um.

---

## Passivas e Habilidades
- **PASSIVA — Voz roubada:** Fala com a voz de alguém que o alvo ama. Pergunte ao jogador como era essa voz e use a descrição dele.
- **PASSIVA — Não respira entre as palavras:** Instinto Dif. 15 para perceber que a frase inteira saiu sem uma pausa de ar. Quem perceber avisa os outros de graça.
- **AÇÃO — Chamar:** O alvo que for atrás marca 2 Estresse e chega a uma plataforma vazia. A voz agora vem de trás.
- **AÇÃO DE MEDO (2) — O segundo nome:** Chama outra pessoa do grupo, e dessa vez acerta um detalhe que ninguém contou a ninguém nesta mesa.
- **FRAQUEZA — Chamado de volta:** Se outro personagem gritar o nome verdadeiro de quem foi atrás, em voz alta, na frente de todos (Presença Dif. 15), a imitação quebra e o bicho foge. **ELE NÃO LUTA QUANDO É VISTO.**

---

## Saídas da Cena
- **Perceber que a voz não respira:** Instinto Dif. 15 (sabe que é armadilha antes de se mover).
- **Saída Criativa:** Qualquer coisa que ilumine o túnel (lanterna de celular, faísca, [[A Brasa da Casa]]). O Crocotta não suporta ser visto inteiro: ele foge e some.
- **O Resgate de Dave:** Quando a fera finalmente avança, é [[Dave]] quem salva a vítima, levando um corte feio no antebraço que sela a confiança da mesa.

---

## Links Relacionados
- [[Cão do Inferno]]
- [[Empusa]]
- [[Dave]]
- [[Capítulo 5 - A Estrada e o Pub]]
- [[Cheiro Névoa e Disfarce]]
- [[🏠 Início]]
