---
tipo: Bestiário
categoria: Ameaça
tags:
  - bestiario
  - ameaca
  - monstro
pdf_page: 105
---


# Cão de Baba

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=105|Consultar Texto Original no PDF (Página 105) — Ficha dos Cães do Brejo]]**

*Tier 1 · Lacaio*  
Matilha de cães monstruosos corrompidos pela saliva negra de Nyx que emergem das águas estagnadas do brejo no [[Capítulo 4 - A Noite Mais Densa]].

---

## Estatísticas de Combate
- **Dificuldade:** 10 | **PV:** 1 | **Ataque:** +1 · Mordida · Corpo a corpo · 1d6+1
- **Impulsos:** O isolado. Perseguem obstinadamente quem estiver afastado dos demais companheiros.

---

## Mecânicas de Horda
- **PASSIVA — Lacaio (3):** Qualquer acerto derruba o cão. Um único ataque com dano elevado pode derrotar até 3 deles se estiverem agrupados.
- **PASSIVA — Quem está só:** Se atacar um alvo desacompanhado na zona, seu dano salta para **1d6+4**.
- **AÇÃO DE MEDO (1) — Mais um:** Um novo cão emerge sorrateiramente do lodo sem fazer ruído, avançando na direção do alvo mais isolado.

---

## Links Relacionados
- [[Capítulo 4 - A Noite Mais Densa]]
- [[O Criadouro]]
- [[🏠 Início]]
