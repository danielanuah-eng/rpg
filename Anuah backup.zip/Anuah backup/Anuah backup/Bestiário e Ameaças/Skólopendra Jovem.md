---
tipo: Bestiário
categoria: Ameaça
tags:
  - bestiario
  - ameaca
  - monstro
pdf_page: 167
---


# Skólopendra Jovem

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=167|Consultar Texto Original no PDF (Página 167) — Ficha da Skólopendra Jovem]]**

*Tier 2 · Brutamonte (4 Pontos de Batalha)*  
Um filhote colossal de centopeia marinha gigante que cruza as águas do Mar de Monstros no [[Capítulo 7 - O Mar]].

---

## Estatísticas
- **Dificuldade:** 14 | **Limiares:** 10/20 | **PV:** 8 | **Estresse:** 3
- **Ataque:** +1 · Esbarrão · Muito Próximo · 2d6+2 físico (nunca intencional)
- **Natureza:** É um filhote afetuoso e desajeitado do tamanho de um ônibus urbano. Não deseja devorar o navio: apenas quer coçar sua carapaça no casco de madeira.

---

## O Risco Mecânico
- **AÇÃO DE MEDO (2) — Ela sobe:** Repousa as costas contra o barco, fazendo o casco estalar perigosamente e iniciando a **Contagem de Avaria (4)**. Cada segmento eleva em +1 a dificuldade para escapar de Caríbdis mais tarde.
- **Como Lidar:** Atirar rações no mar para que ela siga o aroma, ou bater panelas no lado oposto (Presença Dif. 12).
- **Perigo Mortal:** Se os jogadores a matarem, o sangue espalhado atrai espécimes adultos gigantescos na cena seguinte.

---

## Links Relacionados
- [[Capítulo 7 - O Mar]]
- [[Caríbdis]]
- [[🏠 Início]]
