---
tipo: Bestiário
categoria: Ameaça
tags:
  - bestiario
  - ameaca
  - monstro
pdf_page: 171
---


# Cebrenos

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=171|Consultar Texto Original no PDF (Página 171) — Ficha dos Guardas Caninos]]**

Os guardas e carcereiros caninos que realizam a patrulha e o controle burocrático na Ilha de Ninguém ([[Capítulo 7 - O Mar]], [[Capítulo 8 - A Ilha de Ninguém]]).

---

## Perfil dos Guardas (Tier 1 · Horda / Tier 2 · Líder)
- Humanoides de cabeça de cão trajando uniformes cinzentos impecáveis, coleiras de bronze numeradas e pranchetas de controle.
- **Procedimento Estrito:** Não são monstros sanguinários descontrolados. Explicam calmamente em voz alta o regulamento antes de agir. Nunca usam força letal: se o alvo parar de resistir, eles interrompem o golpe no ar e apenas aplicam algemas.
- **A Lista de Prisioneiros:** Carregam uma lista com os nomes dos semideuses anotados antes mesmo de eles chegarem à ilha, com um sétimo nome riscado.

---

## A Piada Cruel da Captura
Ser capturado e algemado pelos Cebrenos é o meio de transporte mais rápido e direto até o cativeiro de [[Cérbero]] no pátio dos fundos da pousada.

---

## Links Relacionados
- [[Capítulo 7 - O Mar]]
- [[Capítulo 8 - A Ilha de Ninguém]]
- [[Cérbero]]
- [[Polifemo]]
- [[🏠 Início]]
