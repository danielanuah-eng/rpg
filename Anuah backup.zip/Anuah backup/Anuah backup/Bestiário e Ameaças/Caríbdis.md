---
tipo: Bestiário
categoria: Ameaça
tags:
  - bestiario
  - ameaca
  - monstro
pdf_page: 169
---


# Caríbdis

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=169|Consultar Texto Original no PDF (Página 169) — Ambiente e Contagem de Caríbdis]]**

*Tier 2 · Ambiente de Evento*  
O voraz vórtice marinho ancestral que devora oceanos inteiros na garganta de acesso à Ilha de Ninguém.

---

## Características
- Não possui rosto, olhos ou forma carnal: é o próprio mar escoando em espiral para as profundezas abissais.
- O redemoinho tem o diâmetro de um quarteirão urbano, com paredes d'água lisas como espelho girando em velocidade assustadora.

---

## Estrutura da Cena: Contagem em Oposição
A travessia de Caríbdis não é um combate convencional: é uma disputa entre a **Contagem de Progresso (6)** e a **Contagem de Naufrágio (6)**.
- **Dificuldade Base:** 14 (+1 para cada marca de avaria sofrida nos capítulos anteriores).
- Sucessos dos heróis avançam o Progresso; Falhas ou **rolagens com Medo** avançam o Naufrágio.
- **Seis Tarefas Simultâneas:** O leme, as velas, os remos de suporte, alívio de carga, corte de cabos presos e preces aos deuses ([[Ícaro Lyra|Ícaro]] ou [[Barak Armstrong|Barak]]).

---

## Desfecho Canônico
O naufrágio ocorre inevitavelmente, quebrando a embarcação e separando os seis semideuses em dois grupos ao atingirem a costa ([[Capítulo 7 - O Mar]]).

---

## Links Relacionados
- [[Capítulo 7 - O Mar]]
- [[Pingente de Éolo]]
- [[A Profecia da Missão]]
- [[🏠 Início]]
