---
tipo: Bestiário
categoria: Ameaça
tags:
  - bestiario
  - ameaca
  - monstro
pdf_page: 50
---


# Strix e Ninhada

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=50|Consultar Texto Original no PDF (Página 50) — Ficha de Combate da Strix]]**

Aves monstruosas de rapina noturna consagradas a [[A Noite e Nyx|Nyx]].

---

## Strix (Tier 1 · Líder — 3 Pontos de Batalha)
Uma coruja empalhada gigante com olhos de vidro negro fosco que desperta ao retirarem o manto da lâmina.
- **Dificuldade:** 14 | **Limiares:** 7/13 | **PV:** 6 | **Estresse:** 4
- **Ataque:** +3 · Garras em mergulho · Muito Próximo · 1d10+2 físico
- **Experiência:** *"Eu vejo no escuro"* +3
- **PASSIVA — Fora de alcance:** Após atacar, alça voo até o teto da sala. Só pode ser atingida por projéteis, arremessos ou quem subir sobre vitrines ou pedestais.
- **PASSIVA — Olho preto:** Imune a lábia, persuasão, intimidação ou choro.
- **AÇÃO — A voz:** Chora emitindo a voz exata de uma criança conhecida pelos personagens (Presença Dif. 13 ou avança hipnotizado em direção ao som).
- **AÇÃO DE MEDO (2) — Mergulho duplo:** Rasante rápido atacando dois alvos distintos em linha reta.
- **AÇÃO DE MEDO (3) — O manto:** Mergulha para abocanhar o manto negro de veludo e fugir pela claraboia.

---

## Ninhada de Strix (Tier 1 · Horda — 2 Pontos de Batalha)
Três corujas menores, do tamanho de felinos, que emergem de trás das estantes.
- **Dificuldade:** 11 | **Limiares:** 5/9 | **PV:** 4 | **Estresse:** 2
- **Ataque:** -1 · Bicadas rápidas · Muito Próximo · 1d6+2 físico
- **AÇÃO — Cegar:** Bate as asas contra a face de um herói, aplicando Desvantagem na próxima ação.
- **AÇÃO DE MEDO (1) — Vidro:** Arremessam uma vítima contra uma vitrine de vidro (Agilidade Dif. 13 ou sofre 1d6 e aumenta a atenção do museu).

---

## Formas Criativas de Vitória
- Usar a **lâmpada de luz negra** da Sala de Restauro afugenta as criaturas aos berros pela claraboia.
- Abrir a manivela da claraboia inundando a sala com luz exterior dispersa as aves.

---

## Links Relacionados
- [[Capítulo 1 - O Museu das Maravilhas]]
- [[A Lâmina-Chave]]
- [[A Noite e Nyx]]
- [[🏠 Início]]
