---
tipo: Bestiário
categoria: Ameaça
tags:
  - bestiario
  - ameaca
  - monstro
pdf_page: 135
---


# Cão do Inferno

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=135|Consultar Texto Original no PDF (Página 135) — Ficha da Matilha do Metrô]]**

*Tier 1 · Horda (3 por PV — 2 Pontos de Batalha por bando)*  
Mastins infernais de pelagem negra fosca e olhos vermelhos como brasas que emboscam o grupo nos túneis escuros do metrô de Manhattan ([[Capítulo 5 - A Estrada e o Pub]]).

---

## Estatísticas de Combate
- **Dificuldade:** 12 | **Limiares:** 6/11 | **PV:** 4 | **Estresse:** 2
- **Ataque:** +1 · Mordida flamejante · Muito Próximo · 1d8+2 físico

---

## Táticas e Fraquezas
- **PASSIVA — Do escuro:** Recebem Vantagem dentro dos túneis sem iluminação, mas sofrem **Desvantagem** se atraídos para a escadaria da saída da rua ou sob luz forte.
- **Medo do Fogo:** Recuam perante a chama da [[A Brasa da Casa]] ou faíscas elétricas.
- **O Terceiro Trilho:** Podem ser empurrados contra o trilho energizado do metrô (Força/Agilidade Dif. 15), sendo vaporizados instantaneamente.

---

## Links Relacionados
- [[Capítulo 5 - A Estrada e o Pub]]
- [[Empusa]]
- [[A Brasa da Casa]]
- [[🏠 Início]]
