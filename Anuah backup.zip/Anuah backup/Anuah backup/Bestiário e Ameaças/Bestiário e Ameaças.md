---
tipo: Hub
categoria: Ameaça
tags:
  - bestiario
  - ameaca
  - monstro
  - hub
pdf_page: 25
---

# 🔴 Bestiário & Ameaças

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=25|Consultar Texto Original no PDF (Página 25) — Monstros e Ameaças]]**

Compêndio completo de criaturas, adversários e ameaças ambientais calibrados no sistema Daggerheart.

---

## 1. O Museu & O Mundo Mortal (Capítulo 1)
- **[[Mormo]]:** O bicho-papão ancestral disfarçado de curador.
- **[[Lélape]]:** O cão inabalável que nunca perde uma caça.
- **[[Strix e Ninhada]]:** Aves de mau agouro consagradas a Nyx.

## 2. O Acampamento & A Infiltração (Capítulos 2, 3 e 4)
- **[[Autômato de Treino]]:** Mecanismo de bronze rebelado pelas vibrações do Criadouro.
- **[[Campistas do Chalé 5]]:** A horda de veteranos de combate na arena e no vale.
- **[[Dragão Ensombrado]]:** Fera reptiliana do Breu com sopro cáustico.
- **[[Ogro Ensombrado]]:** Brutamonte colossal com marreta sísmica.
- **[[Cão de Baba]]:** Rastreador predatório que emerge do lodo do brejo.

## 3. A Cidade & O Metrô (Capítulo 5)
- **[[Crocotta]]:** A besta das sombras que rouba a voz dos entes queridos.
- **[[Cão do Inferno]]:** Mastins das trevas com olhos de brasa.
- **[[Empusa]]:** Metamorfa sedutora com perna de bronze e de burro.

## 4. O Mar de Monstros & A Ilha (Capítulos 6, 7, 8 e 9)
- **[[Télquines do Turno da Noite]]:** Demônios ferreiros do porão das bombas.
- **[[Piratas de Anteu]]:** Mercenários semideuses armados com ganchos e arpões.
- **[[Skólopendra Jovem]]:** Centopeia marinha do tamanho de um ônibus.
- **[[As Sereias]]:** Vozes hipnóticas que cantam o consolo proibido.
- **[[Caríbdis]]:** O vórtice oceânico que devora embarcações inteiras.
- **[[Cebrenos]]:** Carcereiros caninos metódicos de prancheta e uniforme.
- **[[Cérbero]]:** O guardião tricéfalo aprisionado em agonia.

---
[[🏠 Início|⬅ Retornar ao Início]]
