---
tipo: Bestiário
categoria: Ameaça
tags:
  - bestiario
  - ameaca
  - monstro
pdf_page: 187
---


# Cérbero

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=187|Consultar Texto Original no PDF (Página 187) — Ficha e Libertação de Cérbero]]**

*Tier 2 · Solo (5 Pontos de Batalha se acuado)*  
O cão tricéfalo guardião dos portões do Submundo, capturado e acorrentado na Ilha de Ninguém.

---

## Condição no Encontro
- Cérbero está preso por uma argola e correntes maciças de bronze celestial cravadas na rocha viva do pátio.
- Ele não rosna por agressividade: geme de dor e angústia por estar desconectado das energias vitais do Submundo.
- **Não pode ser libertado por força bruta nem arrombamento.**

---

## Os Três Avisos de Cérbero
Se alguém se aproximar de arma em punho ou tentar romper as correntes, ele reage:
1. Uma das cabeças se ergue com olhar vago.
2. As três cabeças se levantam juntas e o gemido cessa (o silêncio da fera).
3. A cabeça central abaixa o focinho e mostra presas afiadas. No passo seguinte, ataca em fúria acuada.

---

## O Resgate de Hadesson
A única forma de libertar Cérbero sem derramamento de sangue é a intervenção de [[Hadesson Neto|Hadesson]]:
- O filho de Hades se aproxima desarmado, chama o guardião pelo nome com respeito e lhe oferece uma tigela de **biscoitos com leite** (item obtido na despensa de Polifemo).
- As três cabeças calam-se em paz. A cabeça do meio cheira a mão do garoto, reconhecendo imediatamente a linhagem de seu verdadeiro senhor.

---

## Links Relacionados
- [[Hadesson Neto]]
- [[Polifemo]]
- [[Capítulo 8 - A Ilha de Ninguém]]
- [[Capítulo 9 - A Fuga e o Preço]]
- [[🏠 Início]]
