---
tipo: Bestiário
categoria: Ameaça
tags:
  - bestiario
  - ameaca
  - monstro
pdf_page: 154
---


# Télquines do Turno da Noite

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=154|Consultar Texto Original no PDF (Página 154) — Ficha dos Télquines das Bombas]]**

Demônios metalúrgicos de Rhodes com cabeça de cão, nadadeiras no lugar de pés e mãos humanas habilidosas, encarregados da manutenção das bombas submersas do parque Nostos ([[Capítulo 6 - O Parque Aquático Nostos]]).

---

## O Télquine Comum (Tier 2 · Comum — 2 Pontos cada)
- **Dificuldade:** 14 | **Limiares:** 8/16 | **PV:** 5 | **Estresse:** 4
- **Ataque:** +2 · Chave de grifo pesada e mordida · Corpo a corpo · 2d6+2 físico
- **PASSIVA — Mão de ferreiro:** Qualquer arma metálica que os atinja esquenta em brasa (marcando 1 Estresse por rodada segurada).
- **AÇÃO — Sabotar:** Acionam válvulas que elevam o nível da água inundada no porão.

---

## O Encarregado (Tier 2 · Líder — 3 Pontos)
O mestre de obras grisalho com crachá de supervisão.
- **Dificuldade:** 15 | **Limiares:** 10/20 | **PV:** 6 | **Estresse:** 4
- **Ataque:** +2 · Marreta de precisão · Próximo · 2d6+3 físico
- **PASSIVA — Educado até o fim:** Sempre avisa formalmente o que vai fazer antes de desferir o golpe.
- **AÇÃO DE MEDO (3) — O disjuntor:** Corta a iluminação de emergência, deixando a sala inundada em trevas absolutas onde apenas eles enxergam.

---

## Links Relacionados
- [[Capítulo 6 - O Parque Aquático Nostos]]
- [[Kyla Nestor (Cila)]]
- [[🏠 Início]]
