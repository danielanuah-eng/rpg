---
tipo: Bestiário
categoria: Ameaça
tags:
  - bestiario
  - ameaca
  - monstro
pdf_page: 73
---


# Autômato de Treino

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=73|Consultar Texto Original no PDF (Página 73) — Ficha do Autômato da Arena]]**

*Tier 1 · Brutamonte (4 Pontos de Batalha)*  
Manequim mecanizado construído por [[Outros Campistas|Chris Forgjer]] para treinos marciais no [[Acampamento Meio-Sangue]].

---

## Estatísticas de Combate
- **Dificuldade:** 13 | **Limiares:** 9/16 | **PV:** 8 | **Estresse:** 3
- **Ataque:** +2 · Braço de madeira maciça · Corpo a corpo · 1d12+2 contundente
- **Experiência:** *"Já apanhou de todo mundo"* +2

---

## Passivas e Mecânicas
- **PASSIVA — Muito resistente:** Reduz em 3 qualquer dano físico sofrido.
- **PASSIVA — Inanimado:** Não sente dor, não recua e não é afetado por intimidação ou ilusões.
- **FRAQUEZA — A Chave nas Costas:** Há uma chave mecânica de desligamento em sua espinha dorsal (Instinto Dif. 13 para notar). Alcançar a retaguarda e girá-la (Finesse Dif. 15 com auxílio) desativa o autômato imediatamente.
- **AÇÃO — Varrer:** Rotação que derruba todos os alvos adjacentes (Agilidade Dif. 13).
- **AÇÃO DE MEDO (2) — Ele escolhe:** Persegue obstinadamente o semideus que utilizou poder divino mais recentemente.

---

## Conexão com o Criadouro
O autômato enlouquece e desobedece aos comandos de desligar devido às ressonâncias profanas de bronze emanadas do [[O Criadouro]] na floresta leste.

---

## Links Relacionados
- [[Acampamento Meio-Sangue]]
- [[O Criadouro]]
- [[Capítulo 2 - A Chegada]]
- [[Outros Campistas]]
- [[🏠 Início]]
