---
tipo: Bestiário
categoria: Ameaça
tags:
  - bestiario
  - ameaca
  - monstro
pdf_page: 164
---


# Piratas de Anteu

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=164|Consultar Texto Original no PDF (Página 164) — Ficha dos Piratas do Mar]]**

Semideuses adultos renegados e mercenários profissionais que patrulham as rotas do Mar de Monstros em botes infláveis velozes ([[Capítulo 7 - O Mar]]).

---

## O Pirata Comum (Tier 1 · Comum — 2 Pontos de Batalha)
- **Dificuldade:** 13 | **Limiares:** 7/13 | **PV:** 5 | **Estresse:** 3
- **Ataque:** +2 · Gancho de abordagem e faca · Próximo · 1d10+2 físico
- **PASSIVA — Profissionais:** Não lutam até a morte por contrato de pilhagem. Se dois companheiros caírem, os outros recuam imediatamente.
- **AÇÃO — Abordar:** Lança ganchos para puxar o barco dos novatos (Finesse Dif. 13 para cortar cabos).

---

## A Capitã (Tier 2 · Líder — 3 Pontos de Batalha)
Uma veterana de quarenta anos com tatuagem de âncora e voz serena que nunca grita.
- **Dificuldade:** 15 | **Limiares:** 9/18 | **PV:** 6 | **Estresse:** 4
- **Ataque:** +2 · Arpão de bronze · Distante · 2d6+3 físico
- **Experiência:** *"Vinte anos nesta água"* +4
- **AÇÃO DE MEDO (2) — Arpão na vela:** Perfura a vela dos semideuses de fora a fora, reduzindo sua capacidade de manobra contra Caríbdis.

---

## Como Superar sem Lutar
- **Negociação / Pagamento:** Aceitam dracmas de ouro ou informações de navegação.
- **Intimidação Divina:** Não entram em confronto aberto com filhos reconhecidos dos Três Grandes se [[Barak Armstrong|Barak]] exibir o poder do raio.
- **Mencionar Anteu (Conhecimento Dif. 15):** Citar o patrono dos mercenários compra hesitação respeitosa.

---

## Links Relacionados
- [[Capítulo 7 - O Mar]]
- [[Barak Armstrong]]
- [[Caríbdis]]
- [[🏠 Início]]
