---
tipo: Item
categoria: Relíquia
tags:
  - item
  - reliquia
pdf_page: 146
---


# A Meia-Máscara de Pavão

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=146|Consultar Texto Original no PDF (Página 146) — Regras e Poderes da Máscara]]**

- **Origem:** Encontrada trancada no terceiro armário do vestiário de funcionários do parque aquático Nostos ([[Capítulo 6 - O Parque Aquático Nostos]]).
- **Aparência:** Meia máscara esculpida em bronze celestial, leve como pena, ostentando o desenho delicado de uma pena de pavão gravado na fronte.

---

## Regras e Poderes
- **Vestir:** 1 ação; marque 1 Estresse. Dura uma cena.
- **Não Ser Lembrado:** Concede Vantagem em testes para passar despercebido, apagar rastros e fazer com que testemunhas esqueçam sua fisionomia (não funciona contra quem já o vigia de perto).
- **Ler o Coração:** Uma vez por cena, gaste 1 Esperança, encare um alvo e pergunte ao Mestre o que a pessoa está sentindo no momento. O Mestre deve responder a verdade em uma única palavra ou frase objetiva.
- **Tirar a Máscara:** Marque 1 Estresse. Por um segundo aterrorizante, o usuário esquece o próprio nome.
- **O Preço Oculto:** Cada leitura dá **1 Medo** ao Mestre e aproxima a [[A Ordem da Família das Máscaras|Ordem das Máscaras]] de localizar o portador.

> [!WARNING]
> **A Armadilha com Dave:** A máscara **não lê mentiras de quem acredita no que diz**. Ao tentar ler [[Dave]], o resultado é invariavelmente: *"Nada. Como olhar pra água parada."* O mesmo silêncio ocorre ao tentar ler Sebastian ou Kellen.

---

## Links Relacionados
- [[Capítulo 6 - O Parque Aquático Nostos]]
- [[A Ordem da Família das Máscaras]]
- [[Dave]]
- [[🏠 Início]]
