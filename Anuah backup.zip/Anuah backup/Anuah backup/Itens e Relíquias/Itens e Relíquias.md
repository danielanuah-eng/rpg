---
tipo: Hub
categoria: Relíquia
tags:
  - item
  - reliquia
  - hub
pdf_page: 56
---

# 🪙 Itens & Relíquias da Campanha

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=56|Consultar Texto Original no PDF (Página 56) — Armas e Relíquias]]**

Tesouros, artefatos divinos e instrumentos chave da jornada dos semideuses.

---

## Relíquias Centrais
- **[[A Lâmina-Chave]]:** A adaga gélida que escolhe o filho do trovão no museu.
- **[[A Brasa da Casa]]:** O fogo inextinguível entregue por Héstia na fogueira.
- **[[A Meia-Máscara de Pavão]]:** Máscara de bronze da Ordem que revela sentimentos e apaga memórias.
- **[[O Espelho de Atena]]:** O espelho secreto de Dave que denuncia falsidades.
- **[[Espantalhos de Palha]]:** Os seis foliões portáteis de Dionísio que aplacam Cila.
- **[[Pingente de Éolo]]:** Navegação encantada que protege contra as ondas de Poseidon.
- **[[A Lâmina de Nyx]]:** A arma sem reflexo que extingue almas da existência.
- **[[Itens Menores e Bugigangas]]:** Lista completa de achados, armas e moedas da campanha.

---
[[🏠 Início|⬅ Retornar ao Início]]
