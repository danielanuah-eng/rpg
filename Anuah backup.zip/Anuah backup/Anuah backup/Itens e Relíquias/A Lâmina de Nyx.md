---
tipo: Item
categoria: Relíquia
tags:
  - item
  - reliquia
pdf_page: 188
---


# A Lâmina de Nyx

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=188|Consultar Texto Original no PDF (Página 188) — A Lâmina Negra da Noite]]**

- **Origem:** Entregue em segredo a [[Dave]] por um semideus renegado na Ilha de Ninguém ([[Capítulo 8 - A Ilha de Ninguém]]).
- **Aparência:** Adaga forjada em metal negro fosco que absorve a luz ao redor, sem produzir reflexo algum em sua superfície.

---

## A Maldição do Apagamento
Qualquer criatura, mortal ou semideus que for morto por esta lâmina **deixa de existir**:
- A alma não vai para o Submundo (nem Elísio, nem Campos de Asfódelos, nem Punição).
- Não desce para o Tártaro e monstros não viram pó para renascer.
- Com o passar dos dias, até mesmo a memória das pessoas sobre quem foi atingido começa a se esvanecer no mundo mortal.

> [!WARNING]
> Nenhum teste ou rolagem dos jogadores revela esse efeito no Livro 1. O único indício é que Dave para completamente de empunhar sua espada de bronze comum em situações reservadas.

---

## Links Relacionados
- [[Dave]]
- [[A Noite e Nyx]]
- [[Capítulo 8 - A Ilha de Ninguém]]
- [[A Grande Profecia]]
- [[🏠 Início]]
