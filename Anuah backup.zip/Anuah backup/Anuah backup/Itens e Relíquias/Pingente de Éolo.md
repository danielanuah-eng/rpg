---
tipo: Item
categoria: Relíquia
tags:
  - item
  - reliquia
pdf_page: 178
---


# Pingente de Éolo

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=178|Consultar Texto Original no PDF (Página 178) — Regras do Pingente de Navegação]]**

- **Portador:** [[Barak Armstrong|Barak]].
- **Aparência:** Pingente de prata contendo uma brisa rodopiante aprisionada em vidro encantado.
- **Estado:** Apresenta uma rachadura fina no cristal.

---

## Funcionamento e Danos
- **Propriedade Principal:** Permite que embarcações naveguem pelas águas perigosas do Mar de Monstros sem atrair a fúria direta de Poseidon.
- **Degradação:** Se for forçado além do limite ou sofrer Ações de Medo na tormenta de [[Caríbdis]] ([[Capítulo 7 - O Mar]]), racha mais profundamente e passa a funcionar para proteger apenas uma pessoa no naufrágio.

---

## Links Relacionados
- [[Barak Armstrong]]
- [[Caríbdis]]
- [[Capítulo 7 - O Mar]]
- [[🏠 Início]]
