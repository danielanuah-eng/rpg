---
tipo: Item
categoria: Relíquia
tags:
  - item
  - reliquia
pdf_page: 133
---


# Espantalhos de Palha

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=133|Consultar Texto Original no PDF (Página 133) — Entrega dos Espantalhos por Dionísio]]**

- **Origem:** Entregues por [[Deuses Presentes|Dionísio]] no pub *A Vinha Tardia* ([[Capítulo 5 - A Estrada e o Pub]]).
- **Quantidade:** Exatamente 6 bonecos de palha trançada, do tamanho de um antebraço.

---

## Propriedades Mágicas
- **Parceiros de Festa:** Ao serem acesos com fogo, ardem com labaredas coloridas sem consumir a palha, emitindo sons estridentes de música de taberna, gargalhadas e o eco vibrante de uma multidão em êxtase.
- **O Encaixe na Odisseia:** Cada espantalho foi desenhado sob medida para entreter uma das seis cabeças carnívoras de [[Kyla Nestor (Cila)|Cila]]. Jogar um espantalho aceso ocupa uma cabeça por uma rodada inteira com um banquete imaginário.
- **Solução Limpa do Capítulo 6:** Acender os seis espantalhos simultaneamente garante passagem pacífica pelo canal da criatura sem que nenhum semideus precise sacrificar memórias ou pertences queridos.

---

## Links Relacionados
- [[Deuses Presentes]]
- [[Kyla Nestor (Cila)]]
- [[Capítulo 5 - A Estrada e o Pub]]
- [[Capítulo 6 - O Parque Aquático Nostos]]
- [[🏠 Início]]
