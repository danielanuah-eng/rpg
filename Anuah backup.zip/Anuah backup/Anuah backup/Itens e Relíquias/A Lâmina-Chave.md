---
tipo: Item
categoria: Relíquia
tags:
  - item
  - reliquia
pdf_page: 42
---


# A Lâmina-Chave

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=42|Consultar Texto Original no PDF (Página 42) — Encontro da Lâmina no Museu]]**

- **Origem:** Encontrada sob o manto de veludo negro no Gabinete de História Natural do Museu das Maravilhas ([[Capítulo 1 - O Museu das Maravilhas]]).
- **Aparência:** Faca de bronze com lâmina larga e rústica; o cabo é envolvido por tiras de couro preto ressecado. Não reluz e não é ornamentada.
- **Propriedade Térmica Única:** É muito mais gélida do que metal comum e continua fria mesmo após minutos presa numa mão quente.

---

## A Escolha da Lâmina
A faca escolhe seu portador — e escolhe o filho do trovão, [[Barak Armstrong|Barak]]. Se outro personagem tentar guardá-la, a empunhadura esfria até doer nos ossos, forçando-o a passá-la para Barak.

---

## Propriedades no Livro 1
- **Mecanicamente:** No Livro 1, não possui propriedades mágicas ativáveis em combate — corta como uma excelente lâmina de bronze celestial e fere monstros imortais.
- **O Enigma Cósmico:** Ninguém no acampamento (nem Quíron, nem o Oráculo) sabe o que ela abre (Mundo §3). Nyx soltou [[Lélape]] no museu especificamente para recuperar esta relíquia antes que os semideuses a resgatassem.

---

## Links Relacionados
- [[Barak Armstrong]]
- [[Lélape]]
- [[Capítulo 1 - O Museu das Maravilhas]]
- [[A Noite e Nyx]]
- [[🏠 Início]]
