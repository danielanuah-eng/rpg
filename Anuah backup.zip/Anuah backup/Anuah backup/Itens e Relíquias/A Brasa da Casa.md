---
tipo: Item
categoria: Relíquia
tags:
  - item
  - reliquia
pdf_page: 110
---


# A Brasa da Casa

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=110|Consultar Texto Original no PDF (Página 110) — Entrega e Regras da Brasa]]**

- **Origem:** Presente de [[Deuses Presentes|Héstia (A Menina da Fogueira)]] concedido no encerramento do [[Capítulo 4 - A Noite Mais Densa]].
- **Aparência:** Um pequeno vaso de barro rústico do tamanho de uma xícara de café, contendo uma brasa viva que nunca se extingue e emite um calor reconfortante no peito.

---

## Propriedades e Regras Mecânicas
- **Acender:** Custa 1 ação e marcar 1 Estresse (ou gastar 1 Esperança). O fogo brilha por uma cena inteira.
- **A Luz Certa:** Enquanto a brasa arde, nada do Breu ou das criaturas ensombradas consegue se camuflar ou emboscar o grupo. Testes para resistir a pavor ou achar caminhos no escuro ganham Vantagem.
- **Aquecer Outro:** Uma vez por descanso, gaste 1 Esperança para limpar 2 de Estresse de **outra pessoa**. *A brasa nunca aquece a própria mão de quem a carrega.*
- **Zelar:** Durante um descanso curto ou longo, se um semideus dedicar seu tempo cuidando da brasa em vez de descansar, o grupo todo limpa +1 de Estresse e quem zelou ganha +1 de Esperança.
- **O que NÃO faz:** Não causa dano de combate, não queima cordas de propósito e não funciona como tocha para acelerar marcha. É um lar portátil, não uma arma.
- **O Preço:** Em qualquer cena em que arder após o anoitecer, o Mestre ganha **+1 Medo** (a luz é visível de longe e atrai caçadores da Noite).
- **Perda Definitiva:** Se o portador abandonar um companheiro para se salvar, a brasa apaga-se instantaneamente. Só reacende quando o grupo abrigar e proteger alguém de fora com risco e comida reais.

---

## Links Relacionados
- [[Deuses Presentes]]
- [[Capítulo 4 - A Noite Mais Densa]]
- [[Cheiro Névoa e Disfarce]]
- [[🏠 Início]]
