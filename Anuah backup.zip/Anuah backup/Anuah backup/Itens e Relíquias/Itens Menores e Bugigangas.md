---
tipo: Item
categoria: Relíquia
tags:
  - item
  - reliquia
pdf_page: 56
---


# Itens Menores e Bugigangas

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=56|Consultar Texto Original no PDF (Página 56) — Tabela de Itens e Achados]]**

Lista de relíquias menores, peças utilitárias e itens mundanos que cruzam a campanha.

---

## 1. Bronze Celestial do Acervo (Capítulo 1)
Três peças autênticas de bronze celestial disfarçadas como "cobre antigo" na Sala de Armaduras do museu: uma lâmina curta, uma ponta de lança e um disco de escudo. Permitem que os semideuses causem dano em monstros desde a primeira sessão.

## 2. Réplicas do Cesto de Manuseio (Capítulo 1)
Armas de metal barato e sucata. Se um jogador tentar usá-las contra um monstro, a lâmina entorta e quebra no primeiro golpe, ensinando a diferença entre sucata mortal e bronze celestial.

## 3. Lâmpada de Luz Negra (Capítulo 1)
Encontrada na Sala de Restauro do museu. Revela marcas secretas da Noite e afasta instantaneamente criaturas de mau agouro como a [[Strix e Ninhada|Strix]].

## 4. Folha Dourada da Árvore (Capítulo 2)
Folha caída da árvore mística da colina. Permanece morna por sete dias na mão de quem a carrega. Não tem efeito bélico, mas serve como lembrança afetuosa com peso de moeda emocional no Capítulo 6.

## 5. Bandagens do Chalé 7 (Capítulo 2)
Faixas e unguentos preparados por Tom Belff e Ícaro. Permitem limpar 1 de Estresse de outra pessoa uma vez por dia até se esgotarem.

## 6. Lupa de Romeo (Capítulo 2)
Lente de aumento tática emprestada por Romeo do Chalé 6. Revela pistas ocultas e intenções veladas ao analisar pergaminhos ou engrenagens.

## 7. Bip, o Pássaro Mecânico (Capítulo 5)
Pássaro autômato entregue por Elle no portão. Leva e traz mensagens do acampamento, demorando uma sessão inteira para cada viagem.

## 8. Guardanapo de Margaux (Capítulo 5)
Bilhete escrito pela dona do Hotel Ambrósia contendo o horário exato da maré em Asbury Park e alertas sobre os perigos do parque Nostos.

## 9. Pelúcia de Três Cabeças (Capítulo 6)
Cachorrinho de pelúcia ganho na máquina de garra do parque Nostos. Pode ser lançado como isca de distração no clímax da fuga na ilha.

## 10. Vinho Ninguém (Capítulo 8)
Pequeno barril de vinho forte artesanal produzido por Polifemo. Serve como presente de suborno, moeda valiosa ou combustível inflamável.

## 11. Elo da Coleira de Cérbero (Capítulo 8)
Um pesado anel de bronze celestial que se desprende das correntes de Cérbero. Enquanto estiver nas mãos de um semideus, feras e caninos infernais recusam-se a atacar primeiro.

---

## Links Relacionados
- [[A Lâmina-Chave]]
- [[A Brasa da Casa]]
- [[A Meia-Máscara de Pavão]]
- [[🏠 Início]]
