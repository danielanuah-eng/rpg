---
tipo: Item
categoria: Relíquia
tags:
  - item
  - reliquia
pdf_page: 132
---


# O Espelho de Atena

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=132|Consultar Texto Original no PDF (Página 132) — Segredo do Espelho de Dave]]**

- **Portador Oculto:** [[Dave]] (carregado secretamente no bolso da jaqueta).
- **Aparência:** Espelho de mão polido, perfeitamente liso, com a silhueta de uma coruja gravada no verso de metal.
- **Origem:** Artefato lendário concedido pela deusa Atena.

---

## Poder do Espelho
Quem se olha no espelho enquanto outra pessoa fala vê o próprio reflexo distorcer-se grotescamente se a pessoa estiver mentindo.
- Dave utiliza o espelho de forma discreta o tempo todo, simulando um gesto vaidoso de ajeitar o cabelo.
- **Consequência Mecânica:** **Mentir para Dave nunca funciona.** Ele não confronta quem mente para ele: apenas arquiva a informação, sorri e altera seus planos silenciosamente.

---

## Links Relacionados
- [[Dave]]
- [[Como a Noite Trabalha]]
- [[Capítulo 5 - A Estrada e o Pub]]
- [[🏠 Início]]
