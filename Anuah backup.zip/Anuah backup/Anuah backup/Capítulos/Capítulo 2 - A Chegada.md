---
tipo: Sessão
categoria: Capítulo
tags:
  - capitulo
  - sessao
pdf_page: 58
---


# Capítulo 2 - A Chegada

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=58|Consultar Texto Original no PDF (Página 58) — Capítulo 2 Completo]]**

*Conhecer o lugar e as pessoas que serão defendidas ou perdidas depois. Nenhum combate mortal. É a sessão em que ninguém sangra.*

---

## Painel do Capítulo
- **Onde:** [[Acampamento Meio-Sangue]] (Mundo §20).
- **Quando:** Madrugada chuvosa de chegada, seguida por um dia inteiro de exploração, encerrando na grande fogueira noturna.
- **Quem está em cena:** [[Kira Andros|Kira]] (entra na história aqui) · [[Quíron]] · [[Kellen (Diretor K)|Kellen]] · [[Fujiro]] · [[Augusto]], [[Bryan]] e [[Breno]] · [[Dave]] · [[Kenny, Elle e Edgar]] · conselheiros dos chalés · [[Sebastian (Oráculo)|Sebastian]] (observando ao longe) · a menina da fogueira ([[Deuses Presentes|Héstia]]).
- **O que os jogadores sabem:** Que são semideuses e foram resgatados para um vale protegido.
- **O que só o Mestre sabe:** Que a fogueira central está baixa porque há medo no ar; que Kellen não dorme há uma semana; que o cheiro metálico a leste vem do [[O Criadouro]]; que Zeus vai reclamar Barak na fogueira na frente de trezentos campistas; que os outros quatro não serão reclamados hoje (e Hadesson não será no Livro 1).
- **Começa quando:** A chuva cessa abruptamente na linha da cerca mágica da colina.
- **Termina quando:** O raio azul-branco desce sobre a cabeça de Barak e o acampamento inteiro se ajoelha em silêncio.
- **Nível:** 1
- **Contadores:** Nenhum. Único capítulo sem relógio correndo contra os heróis.
- **Marco:** Marco I — Sementes de Experiência anotadas, primeiro descanso longo.

---

## Cena 1 — A Colina e a Garota na Cerca
A árvore de folhas douradas no topo da colina. Sentada na cerca com sua espada de bronze no colo, [[Kira Andros|Kira]] aguarda os novatos:
> *"Vocês demoraram. Eu tô aqui desde a meia-noite. Eu sou a Kira. Vem, eu mostro tudo. E não pisa fora do caminho que tem cobra."*

---

## Cena 2 — O Acampamento, Cabana por Cabana
Kira apresenta o semicírculo em 'U' dos doze chalés e os heróis visitam suas instalações:
- A arena de areia onde [[Augusto]] treina obstinado.
- A forja esfumaçada de [[Outros Campistas|Victor e Chris]].
- A misteriosa construção de pedra preta fora do U ([[Chalé 13 - A Cabana Preta (Hades)]]).

---

## Cena 3 — Quem Recebe Quem
Roda social com os principais NPCs:
- **Kellen:** Brincalhão, servindo morangos frescos, mas com olhar de exaustão profunda (Instinto Dif. 14).
- **Kenny, Elle e Edgar:** Kenny puxa conversa acolhedora; Elle adota o grupo como amigos incondicionais; Edgar observa em silêncio.
- **Bryan e Breno:** Bryan faz provocações ácidas medindo as fraquezas dos novatos; Breno observa impassível.
- **Dave:** Cumprimenta com elegância, oferece um lanche e desaparece com discrição.
- **Sebastian:** Passa ao longe à noite e, se abordado, diz uma verdade crua e desconfortável para cada semideus.

---

## Cena 4 — Oito Lugares para Explorar
Os jogadores se dividem em duplas para explorar:
1. **A Arena:** Oportunidade de testar forças com Augusto.
2. **A Fogueira Central:** Menininha de oito anos mexendo cinzas ([[Deuses Presentes|Héstia]]). Sentar e descansar ali limpa 1d4 de Estresse.
3. **O Lago:** Conversar com náiades para obter boatos valiosos.
4. **A Forja:** Victor afia armas de bronze de graça para quem souber o nome do próprio armamento.
5. **A Floresta Leste:** Cheiro de fundição quente e clareiras com vegetação necrosada.
6. **O Mural de Recordes:** Placa histórica com feitos do acampamento.
7. **O Escritório de Kellen:** Mapas com seis anomalias assinaladas em Nova York.
8. **Os Campos de Morango:** Tarde pacífica de trabalho manual que limpa 1 de Estresse.

---

## Cena 5 — A Arena e o Autômato Descontrolado
Durante um treino amistoso com os veteranos do Chalé 5, um dos manequins mecanizados construídos por Chris ([[Autômato de Treino]]) desperta sozinho, atraído pela ressonância profana da floresta leste, ignorando os comandos de desligamento.
- **Resolução:** Girar a chave de corte na espinha dorsal ou empurrá-lo no barril d'água.

---

## Cena 6 — A Fogueira e a Reclamação
No fim da noite, com trezentos semideuses reunidos:

> **LEIA EM VOZ ALTA:**  
> *"A conversa morre de repente, porque alguém apontou. E aí trezentas cabeças viram ao mesmo tempo — e não pra vocês. Pra um de vocês. Em cima da cabeça do Barak tem um raio. Parado no ar. Azul e branco, do tamanho de um braço, girando muito devagar. E o estalo chega antes da luz, o que é a ordem errada, e ninguém comenta isso. Dá pra sentir no esterno. O Chalé 7 para de tocar no meio de um acorde."*

Quíron ajoelha seu corpo de centauro; ninguém aplaude; inicia-se o murmúrio temeroso da profecia dos Três Grandes. Os outros quatro protagonistas observam sem sinal celestial sobre suas cabeças.

---

## A Cabana Preta e Kellen
Após a fogueira, Kellen chama [[Hadesson Neto|Hadesson]] em particular e entrega as chaves da Cabana 13 desocupada.

---

## Fechamento do Capítulo 2
- [ ] Kira assumiu a liderança das explicações iniciais.
- [ ] A mesa notou as chamas baixas da fogueira três vezes.
- [ ] Barak foi solenemente reclamado por Zeus.
- [ ] Hadesson recebeu permissão para dormir na Cabana Preta.
- [ ] Primeiro Descanso Longo realizado (o Mestre ganha 1d4 + 1 por jogador de Medo).

---

## Links Relacionados
- [[Acampamento Meio-Sangue]]
- [[Barak Armstrong]]
- [[Augusto]]
- [[Chalé 13 - A Cabana Preta (Hades)]]
- [[Capítulo 3 - O Pega-Bandeira]]
- [[🏠 Início]]

---
**Navegação da Campanha:** [[Capítulo 1 - O Museu das Maravilhas|⬅ Capítulo 1 - O Museu das Maravilhas]] · [[Capítulos|Índice das Sessões]] · [[Capítulo 3 - O Pega-Bandeira|Próxima Sessão: Capítulo 3 - O Pega-Bandeira ➔]]
