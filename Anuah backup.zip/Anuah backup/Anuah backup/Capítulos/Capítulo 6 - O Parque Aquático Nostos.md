---
tipo: Sessão
categoria: Capítulo
tags:
  - capitulo
  - sessao
pdf_page: 143
---


# Capítulo 6 - O Parque Aquático Nostos

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=143|Consultar Texto Original no PDF (Página 143) — Capítulo 6 Completo]]**

*Um parque aquático decadente e colorido que funciona como a boca de um monstro ancestral. O capítulo em que a mesa paga pela primeira vez — e o único em que a ameaça não pode ser derrotada, apenas atravessada.*

---

## Painel do Capítulo
- **Onde:** Asbury Park, Nova Jersey (Mundo §23).
- **Quando:** Chegada durante a tarde de sol; clímax noturno após o fechamento dos portões.
- **Quem está em cena:** [[Kyla Nestor (Cila)|Kyla Nestor (Cila)]] · Sandro (atendente do turno da tarde) · funcionários noturnos · [[Télquines do Turno da Noite]] na casa de máquinas · a presença colossal de Cila.
- **O que os jogadores sabem:** Que a passagem para o Mar de Monstros fica ali; que três funcionários sumiram misteriosamente em dois meses.
- **O que só o Mestre sabe:** Que Kyla é Cila; que os seis tobogãs d'água são suas cabeças metamorfoseadas; que um dos sumidos pertencia à [[A Ordem da Família das Máscaras|Ordem]]; que a criatura não possui pontos de vida para combate.
- **Começa quando:** Os heróis avistam o letreiro de plástico desbotado: *NOSTOS — O CAMINHO PRA CASA*.
- **Termina quando:** O pequeno barco de fibra cruza o portal e emerge em mar aberto.
- **Nível:** 1
- **Contadores:** *Contagem da Maré (6)* · *Contagem de Avaria (4)* se houver colisões.

---

## Cena 1 — O Tour do Parque
O parque cheira a cloro, fritura e protetor solar.
- Kyla Nestor recebe as crianças com entusiasmo corporativo e prancheta em mãos.
- **O Tique de Cila:** Ela **nunca vira as costas** para ninguém, movimentando-se sempre de perfil ou de lado.
- Sandro entrega o mapa e o cronograma se os personagens forem amigáveis.

---

## Cena 2 — O Vestiário e a Máscara
No subsolo, três armários lacrados com fita contêm os pertences dos funcionários desaparecidos.
- No terceiro armário, encontram a [[A Meia-Máscara de Pavão]] e um caderno de anotações indicando que o ralo da piscina drena diretamente para o covil da fera.

---

## Cena 3 — A Noite e o Confronto nas Máquinas
Quando os portões fecham e as luzes baixam para tons verde-esmeralda:
- Se descerem ao porão das bombas, enfrentam os [[Télquines do Turno da Noite]] com água até os joelhos.
- **Solução:** Acionar as bombas para sugar os demônios pelo ralo ou usar a luz da [[A Brasa da Casa]].

---

## Cena 4 — A Viagem do Retorno (O Túnel)
Os heróis embarcam no barquinho de fibra que corre sobre trilhos submersos da atração desativada.
> **LEIA EM VOZ ALTA:**  
> *"O barquinho entra pelo portal de isopor e o portão desce atrás de vocês com um clonk de metal. Fica escuro. A voz gravada começa: 'BEM-VINDOS… À VIAGEM… DO RETORNO' — estourada, com chiado, alto demais... E aí vocês passam por um trecho onde o cheiro muda. Não é mais cloro. É maresia. E o teto, que era de concreto, some — e vocês não conseguem ver onde ele foi."*

---

## Cena 5 — O Encontro com Cila
Seis pescoços escuros descem do teto cavernoso.
- **Ataques são Inúteis:** Bronze celestial escorrega sem feri-la.
- **A Solução Limpa (Saída A):** Lançar os seis [[Espantalhos de Palha]] acesos. Cada cabeça morde um espantalho e fica entretida com uma festa ilusória em sua garganta, liberando o barco com **+2 Esperança** para cada um.
- **O Preço Cruel (Saída B):** Se não tiverem espantalhos, Cila exige seis coisas amadas e insubstituíveis trazidas de casa. A perda é irreversível.
- **Ação em Grupo (Saída C):** Manobra desesperada de remo e navegação (Dif. 17).

---

## Cena 6 — A Saída e a Marca do Tártaro
O barco emerge sob o céu estrelado do mar aberto.
Na falésia ao lado da saída, há uma segunda abertura de rocha enegrecida exalando ar tóxico e quente, com marcas colossais de garras saindo de dentro para fora (a entrada do Tártaro para o Livro 3).

---

## Fechamento do Capítulo 6
- [ ] A Meia-Máscara de Pavão foi encontrada.
- [ ] O grupo atravessou o túnel sem letalidade.
- [ ] Cila foi saciada por espantalhos, memórias ou fuga coordenada.
- [ ] Avistaram a fenda de ar quente na rocha.

---

## Links Relacionados
- [[Kyla Nestor (Cila)]]
- [[Espantalhos de Palha]]
- [[A Meia-Máscara de Pavão]]
- [[Télquines do Turno da Noite]]
- [[Capítulo 7 - O Mar]]
- [[🏠 Início]]

---
**Navegação da Campanha:** [[Capítulo 5 - A Estrada e o Pub|⬅ Capítulo 5 - A Estrada e o Pub]] · [[Capítulos|Índice das Sessões]] · [[Capítulo 7 - O Mar|Próxima Sessão: Capítulo 7 - O Mar ➔]]
