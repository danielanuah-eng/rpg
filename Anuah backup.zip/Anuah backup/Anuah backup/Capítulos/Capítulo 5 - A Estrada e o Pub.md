---
tipo: Sessão
categoria: Capítulo
tags:
  - capitulo
  - sessao
pdf_page: 119
---


# Capítulo 5 - A Estrada e o Pub

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=119|Consultar Texto Original no PDF (Página 119) — Capítulo 5 Completo]]**

*A missão começa, o acampamento fica para trás e o segundo grupo de apoio acompanha os heróis até a porta do pub. Depois disso, cada um tem a sua parte.*

---

## Painel do Capítulo
- **Onde:** Casa Grande -> estrada -> Manhattan -> Hotel Ambrósia -> pub A Vinha Tardia -> Hotel Ambrósia.
- **Quando:** Dois dias após o ataque da Infiltração.
- **Quem está em cena:** Os seis protagonistas · [[Dave]], [[Bryan]] e [[Breno]] (o segundo grupo de apoio) · [[Quíron]] e [[Kellen (Diretor K)|Kellen]] · [[Kenny, Elle e Edgar]] · [[Crocotta]] no túnel · [[Cão do Inferno]] e [[Empusa]] no metrô · [[Deuses Presentes|Dionísio]] · [[Margaux Vine]].
- **O que os jogadores sabem:** Que o Submundo está vazando porque algo sagrado foi retirado de lá; que a profecia ordena buscar o guardião acorrentado; que devem seguir para oeste até o mar.
- **O que só o Mestre sabe:** Que o guardião é [[Cérbero]] e quem o capturou foi Dave aliado a Nyx (Mundo §5); que Dave carrega o [[O Espelho de Atena]] para detectar mentiras; que o segundo grupo se separa na porta do pub porque Dave precisa operar nas sombras.
- **Começa quando:** O mapa é aberto na mesa de pingue-pongue e Kellen permanece em silêncio.
- **Termina quando:** A senha da passagem marítima está na mão e o grupo percebe que quase não conseguiu sair do conforto do hotel.
- **Nível:** 1
- **Contadores:** *Contagem do Conforto (6)*.

---

## Cena 1 — O Briefing
Quíron reúne os semideuses na Casa Grande:
> *"O Submundo está vazando... Vocês não vão matar nada. Vocês vão devolver uma coisa. Guardem essa diferença."*

### A Trilha do Guardião (Como a Mesa Descobre Cérbero):
- **Pista 1 (No trem):** Noticiário mortal sobre cães desaparecidos na região.
- **Pista 2 (Na Vinha Tardia):** Dionísio comenta: *"Cachorro grande. Três cabeças. Come biscoito com leite."*

---

## Cena 2 — A Despedida no Portão
Debaixo da árvore dourada:
- Kenny aperta a mão de cada um e repete: *"Volta."*
- Elle entrega [[Itens Menores e Bugigangas|Bip]], seu pássaro de mensagens de bronze.
- Edgar entrega suprimentos úteis de última hora.
- Augusto treina na arena e diz sem olhar: *"Você volta com todo mundo ou não volta. Não tem terceira opção que preste."*

---

## Cena 3 — A Estrada e a Confissão de Breno
No vagão do trem, Breno senta-se perto dos jogadores e abre o coração pela única vez:
> *"O Bryan fala muito... Ele fala pra pessoa não chegar perto — quanto mais ele gosta, pior ele fala. Falaram pra vocês que a gente matou ela? ... Ela entrou na frente. Foi isso. Vocês são novos. Vão querer provar alguma coisa lá na frente. Não precisa. Eu já precisei. Não compensa."*

---

## Cena 4 — A Cidade e a Emboscada do Metrô
Numa estação decadente do metrô de Manhattan, o [[Crocotta]] ecoa do fundo dos trilhos imitando a voz de alguém amado pelos semideuses para atraí-los para o escuro:
- Dave pula heroicamente na frente do ataque, ferindo o antebraço feio para salvar um personagem.
- Quando o Crocotta foge, bandos de [[Cão do Inferno]] e a [[Empusa]] atacam na plataforma isolada.
- **Soluções:** Empurrar criaturas contra o terceiro trilho energizado ou acender [[A Brasa da Casa]].

---

## Cena 5 — O Hotel Ambrósia e a Tentação
Um hotel suntuoso onde nada ataca os heróis: lareira quente, camas perfeitas, cheiro de pão caseiro.
- **A Armadilha do Conforto:** Cada luxo aceito (banho quente, comidas da infância) marca a *Contagem do Conforto (6)*.
- **Breno procura Kira:** No lobby à noite, Breno pede a Kira: *"Se eu não voltar de alguma coisa, ele não tem ninguém. Não tô pedindo pra você gostar dele. Tô pedindo pra você não deixar ele sozinho."*

---

## Cena 6 — A Porta do Pub e a Separação
No Upper West Side, o grupo se despede de Dave, Bryan e Breno na porta de serviço:
> *"A gente para por aqui. Vocês pegam a senha, a gente resolve a nossa parte, e a gente se encontra do outro lado da água."*

---

## Cena 7 — A Vinha Tardia e Dionísio
Pub com placas alertando *"NÃO SERVIMOS ÁLCOOL"*. Dionísio cumpre pena servindo suco de uva.
- Entrega os seis [[Espantalhos de Palha]]: *"Parceiros de festa portáteis. Acende, queima, não consome. São seis. Vocês são seis. Faz a conta quando precisar."*

---

## Cena 8 — A Manhã e a Senha
Margaux entrega a senha do mar e o guardanapo de advertência sobre o parque aquático Nostos.

---

## Fechamento do Capítulo 5
- [ ] Bip foi entregue ao grupo.
- [ ] A conversa de Breno sobre Édea aconteceu no trem.
- [ ] Dave salvou a vida de alguém e ganhou a lealdade da mesa.
- [ ] O segundo grupo se separou na porta do pub.
- [ ] Os seis espantalhos de palha estão no inventário.

---

## Links Relacionados
- [[Dave]]
- [[Breno]]
- [[Deuses Presentes]]
- [[Margaux Vine]]
- [[Espantalhos de Palha]]
- [[Capítulo 6 - O Parque Aquático Nostos]]
- [[🏠 Início]]

---
**Navegação da Campanha:** [[Capítulo 4 - A Noite Mais Densa|⬅ Capítulo 4 - A Noite Mais Densa]] · [[Capítulos|Índice das Sessões]] · [[Capítulo 6 - O Parque Aquático Nostos|Próxima Sessão: Capítulo 6 - O Parque Aquático Nostos ➔]]
