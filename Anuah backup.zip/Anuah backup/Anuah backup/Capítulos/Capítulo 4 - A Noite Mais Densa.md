---
tipo: Sessão
categoria: Capítulo
tags:
  - capitulo
  - sessao
pdf_page: 102
---


# Capítulo 4 - A Noite Mais Densa

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=102|Consultar Texto Original no PDF (Página 102) — Capítulo 4 Completo]]**

*A sessão em que o acampamento deixa de ser seguro e onde as profecias são proclamadas sobre os mortos.*

---

## Painel do Capítulo
- **Onde:** O mesmo vale do riacho, sem corte de cena após o fim do Capítulo 3.
- **Quando:** Crepúsculo acelerado virando noite total.
- **Quem está em cena:** Dois [[Dragão Ensombrado|Dragões Ensombrados]] · um [[Ogro Ensombrado]] · matilha de [[Cão de Baba|Cães de Baba]] · cento e poucos campistas em pânico · [[Augusto]], [[Bryan]] e [[Breno]] · [[Quíron]] e [[Kellen (Diretor K)|Kellen]] · [[Sebastian (Oráculo)|Sebastian]] · a menina da fogueira ([[Deuses Presentes|Héstia]]).
- **O que os jogadores sabem:** Os monstros romperam as defesas mágicas da colina.
- **O que só o Mestre sabe:** As feras foram produzidas e despachadas sob encomenda do [[O Criadouro]] (Mundo §10); os monstros atacam preferencialmente os semideuses novos; seus corpos não se dissolverão em pó dourado.
- **Começa quando:** Dois segundos inteiros de silêncio absoluto após o sumiço do som dos grilos.
- **Termina quando:** Sebastian recita a profecia no pátio e ninguém consegue dormir.
- **Nível:** 1 (Evolui para Meio-Nível no encerramento).
- **Contadores:** *Sobrevivência (4 Rodadas)*.
- **Marco:** Marco III — Meio-nível e a [[A Brasa da Casa]].

---

## Cena 1 — A Infiltração (4 Rodadas de Pavor)
> **LEIA EM VOZ ALTA:**  
> *"A mata do lado oeste se abre, e o que sai dela não faz barulho nenhum: dois dragões do tamanho de cavalos, com os olhos pretos por inteiro — sem íris, sem brilho, sem nada — e um ogro atrás deles, encostando nos troncos. Da boca dos três escorre um líquido preto e grosso, e onde ele pinga na grama a grama fumega e morre. Eles não rugem. Não ameaçam. Eles olham em volta, escolhem, e vêm."*

Esta cena **não é para derrotar todos os inimigos**: é um teste de resistência por quatro rodadas até o socorro dos líderes:
1. **Rodada 1:** O primeiro Dragão e o Ogro avançam. Crianças fogem desordenadas. A meta é entender que as feras não negociam.
2. **Rodada 2:** O segundo Dragão ataca pela retaguarda. Os aliados do Chalé 5 tomam posição para cobrir as crianças.
3. **Rodada 3:** Cães de Baba emergem do brejo lodozo buscando alvos isolados.
4. **Rodada 4:** Exaustão máxima. Quíron e Kellen chegam ao vale.

---

## Cena 2 — O Fim do Ataque e os Cadáveres
Quíron dispara flechas com precisão cirúrgica e Kellen atua com letalidade mágica silenciosa.
Quando os monstros caem, **os corpos não viram pó**. Ficam estirados na relva morta, cheirando a ar estagnado de armário antigo.
> *"Eles não sumiram."*

---

## Cena 3 — O Rescaldo
Investigação dos cadáveres:
- **Examinar os Corpos (Conhecimento Dif. 15):** Jovens e bem alimentados demais para serem bestas selvagens da floresta; alguém os cultivou.
- **A Queimadura da Grama (Instinto Dif. 14):** A trilha de baba tóxica aponta diretamente para a floresta leste ([[O Criadouro]]).

---

## Cena 4 — A Fogueira e a Brasa da Casa
Na noite seguinte, a fogueira central está quase apagada. [[Deuses Presentes|Héstia]] aproxima-se do semideus que se arriscou para proteger um companheiro e lhe entrega [[A Brasa da Casa]]:
> *"Tá baixa porque tem gente demais com medo de ir dormir. Segura pra mim. Sou quem fica."*

---

## Cena 5 — As Profecias
Sebastian desce do sótão e cruza o pátio:
1. **[[A Grande Profecia]]:** Pronunciada perante o acampamento sobre os corpos sem pó.
2. **[[A Profecia da Missão]]:** Dita na manhã seguinte para Barak na Casa Grande, designando a jornada rumo ao Mar de Monstros para resgatar o guardião aprisionado.

---

## Fichas dos Adversários
- [[Dragão Ensombrado]]
- [[Ogro Ensombrado]]
- [[Cão de Baba]]

---

## Fechamento do Capítulo 4
- [ ] A mesa resistiu às quatro rodadas de infiltração.
- [ ] Os corpos não viraram pó perante as testemunhas.
- [ ] Kellen foi visto lutando para matar.
- [ ] A Brasa da Casa foi entregue ao protetor da noite.
- [ ] As duas profecias foram recitadas.
- [ ] Marco III: Escolha do Meio-Nível 2.

---

## Links Relacionados
- [[A Grande Profecia]]
- [[A Profecia da Missão]]
- [[A Brasa da Casa]]
- [[O Criadouro]]
- [[Capítulo 5 - A Estrada e o Pub]]
- [[🏠 Início]]

---
**Navegação da Campanha:** [[Capítulo 3 - O Pega-Bandeira|⬅ Capítulo 3 - O Pega-Bandeira]] · [[Capítulos|Índice das Sessões]] · [[Capítulo 5 - A Estrada e o Pub|Próxima Sessão: Capítulo 5 - A Estrada e o Pub ➔]]
