---
tipo: Sessão
categoria: Capítulo
tags:
  - capitulo
  - sessao
pdf_page: 161
---


# Capítulo 7 - O Mar

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=161|Consultar Texto Original no PDF (Página 161) — Capítulo 7 Completo]]**

*A profecia disse que a estrada se divide em duas. É aqui que os semideuses sobem de nível — encharcados, separados e sem ninguém para comemorar com eles.*

---

## Painel do Capítulo
- **Onde:** O misterioso Mar de Monstros (Mundo §24).
- **Quando:** Um dia e uma noite de navegação marítima.
- **Quem está em cena:** Apenas os seis protagonistas e, no desfecho, os carcereiros [[Cebrenos]].
- **O que os jogadores sabem:** Devem atravessar até a ilha do guardião utilizando o [[Pingente de Éolo]].
- **O que só o Mestre sabe:** Que os Cebrenos são os guardas da Ilha de Ninguém; que ser capturado é o transporte mais veloz até Cérbero; que existe uma lista com seus nomes e um sétimo riscado.
- **Começa quando:** O sol brilha na água cristalina e a primeira hora a bordo é a mais leve e pacífica da missão inteira.
- **Termina quando:** Metade do grupo está algemada numa barca e a outra metade acorda do lado de dentro dos muros da ilha.
- **Nível:** 1 -> **Nível 2** no fechamento!
- **Contadores:** *Progresso (6)* vs. *Naufrágio (6)* · *Avaria (4)* herdada.
- **Marco:** Marco IV — Nível 2 alcançado.

---

## Cena 1 — A Travessia e os Três Encontros
Role ou selecione três encontros na tabela de perigos do mar:
1. **O Navio Encalhado:** Cargueiro mortal com luzes acesas sem gerador.
2. **[[Piratas de Anteu]]:** Mercenários adultos em botes que podem ser subornados ou intimidados pelo raio de Barak.
3. **[[As Sereias]]:** Vozes idênticas às pessoas mais queridas chamando os personagens para a água.
4. **[[Skólopendra Jovem]]:** Filhote de centopeia colossal que se esfrega no casco para coçar as costas.
5. **O Bote Salva-Vidas:** Criança misteriosa de sete anos dormindo ilesa à deriva.
6. **A Tempestade que Escolhe:** Nuvem negra de Nyx que segue a embarcação sem vento nem raios.

---

## Cena 2 — A Calmaria Prévia
Três avisos sucessivos:
1. Todos os animais marinhos somem da água.
2. O vento cessa completamente e a vela desaba.
3. O som do mar desaparece no ar (onda sem barulho, espuma sem estalo).

---

## Cena 3 — O Vórtice de Caríbdis
> **LEIA EM VOZ ALTA:**  
> *"Não tem forma. Não tem rosto. Não tem boca. É o mar indo embora para baixo — um funil de água do tamanho de um quarteirão, girando devagar demais para o tamanho que tem, com a borda lisa como vidro e o fundo que ninguém vê. O barulho volta de uma vez e é um barulho de ralo, grave, que se sente no esterno."*

- **Disputa:** Progresso (6) vs Naufrágio (6).
- Os heróis dividem tarefas: manobrar o leme, ajustar velas, remar, aliviar carga, cortar amarras e rezar aos deuses.
- **O Desfecho:** O barco despedaça-se, cumprindo a profecia de cisão da comitiva.

---

## Cena 4 — A Separação
- **Grupo A (Barak e quem segurou o [[Pingente de Éolo]]):** Arremessados diretamente para dentro do pátio interno murado da hospedaria na Ilha de Ninguém.
- **Grupo B:** Naufragam numa praia de pedras cinzentas na costa exterior da ilha, onde são abordados pelos guardas [[Cebrenos]] de prancheta.

---

## Cena 5 — A Patrulha do Pátio e as Algemas
- No Grupo A: Enfrentam discretamente dois Cebrenos e um hóspede aliado de Nyx que saiu para fumar.
- No Grupo B: A rendição aos Cebrenos rende a viagem de barca diretamente para as celas de segurança máxima.

---

## Fechamento do Capítulo 7 (Subida de Nível)
- [ ] O mar calmo deu lugar a Caríbdis.
- [ ] A comitiva foi dividida em dois grupos separados.
- [ ] Ser capturado provou ser a rota para os fundos da ilha.
- [ ] **Marco IV — NÍVEL 2:** Cada jogador ganha Proficiência +1, nova carta de domínio e nova Experiência a +2 baseada no que fez na primeira hora pós-naufrágio.

---

## Links Relacionados
- [[Caríbdis]]
- [[Piratas de Anteu]]
- [[Cebrenos]]
- [[Pingente de Éolo]]
- [[Capítulo 8 - A Ilha de Ninguém]]
- [[🏠 Início]]

---
**Navegação da Campanha:** [[Capítulo 6 - O Parque Aquático Nostos|⬅ Capítulo 6 - O Parque Aquático Nostos]] · [[Capítulos|Índice das Sessões]] · [[Capítulo 8 - A Ilha de Ninguém|Próxima Sessão: Capítulo 8 - A Ilha de Ninguém ➔]]
