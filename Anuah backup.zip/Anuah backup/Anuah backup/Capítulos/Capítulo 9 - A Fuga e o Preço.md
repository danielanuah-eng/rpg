---
tipo: Sessão
categoria: Capítulo
tags:
  - capitulo
  - sessao
pdf_page: 199
---


# Capítulo 9 - A Fuga e o Preço

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=199|Consultar Texto Original no PDF (Página 199) — Capítulo 9 Completo]]**

*A sessão em que alguém fica para trás. O clímax trágico do Livro 1.*

---

## Painel do Capítulo
- **Onde:** Ilha de Ninguém -> mar -> litoral -> [[Acampamento Meio-Sangue]].
- **Quando:** Começa no estrondo do alarme geral na ilha e termina na vigília fúnebre da noite.
- **Quem está em cena:** Todos os semideuses · [[Cérbero]] liberto · [[Polifemo]] furioso · aliados de Nyx · [[Cebrenos]] · [[Bryan]] e [[Breno]].
- **O que os jogadores sabem:** Devem evacuar a ilha em fuga acelerada protegendo o cão tricéfalo.
- **O que só o Mestre sabe:** Que Breno ficará do lado de fora da caverna para fechar a laje e não retornará; que Dave já possui a [[A Lâmina de Nyx]]; que o Olimpo silenciará sobre a perda; que o abraço acolhedor de Dave em Bryan foi milimetricamente calculado.
- **Começa quando:** A corrente de bronze de Cérbero despenca na rocha com um eco ensurdecedor.
- **Termina quando:** O Chalé 5 permanece a noite inteira em pé ao redor da fogueira, e Bryan golpeia um tronco na floresta até sangrar as mãos.
- **Nível:** 2
- **Contadores:** *Fuga (8)* vs. *Ilha Desperta (6)*.
- **Marco:** Marco V — Sem evolução de ficha. Apenas história e legado.

---

## Cena 1 — A Fuga Desesperada
Perseguição caótica pelo armazém e pátio rumo aos barcos:
- Cérbero avança atropelando obstáculos (avança a Fuga, mas atrai barulho).
- Barris de vinho rolam pelo chão; cabritos berram soltos; fardos de lã pegam fogo.
- No cais, Polifemo barra o caminho:
  > *"Eu fiz alguma coisa com vocês? ... VOCÊS NEM PAGARAM O QUARTO!"*
- Polifemo derruba e quebra barcos, mas **nunca desfere golpes letais contra crianças**.

---

## Cena 2 — A Caverna e o Preço
O único caminho seguro até os botes de fuga é um túnel rochoso na maré cuja boca só pode ser fechada por fora por uma laje de pedra colossal.
- **O Sacrifício de Breno:** Breno permanece do lado de fora empunhando sua maça de guerra.
> **LEIA EM VOZ ALTA:**  
> *Breno, com a laje já pela metade, olhando para quem conversou com ele no trem:  
> "Eu falei pra você não precisar provar nada. Eu preciso."  
> E a pedra encaixa.  
> E aí, de dentro, no escuro, eles ouvem o primeiro baque da maça. Depois mais dois. Depois um intervalo longo demais. Depois nada.*

- **O Desespero de Bryan:** Bryan esmurra a pedra até sangrar os nós dos dedos, implorando aos berros para o irmão abrir. Dave o abraça por trás e o contém com falsa ternura, consolidando o controle psicológico sobre ele para o Livro 2.

---

## Cena 3 — A Devolução de Cérbero e a Volta
Os semideuses cruzam o mar montados nos pégasos fugitivos.
- Cérbero é devolvido a uma fenda abissal nas rochas; Hades não agradece nem diz uma palavra, mas a opressão no ar se alivia.

---

## Cena 4 — O Acampamento e o Luto Mal Distribuído
Ao chegarem ao acampamento, o Olimpo não se manifesta e o acampamento não realiza um luto justo:
- No refeitório, sussurram sobre Édea (*"Sobrou um"*).
- No [[Chalé 5 - Ares]], as portas abrem-se em vigília solene. Augusto lidera a queima da mortalha vazia sem derramar uma única lágrima em público.
- Bryan isola-se na borda da mata esmurrando árvores, onde apenas Dave o acompanha nas sombras.

---

## Fechamento do Livro 1
- [ ] Cérbero foi devolvido ao Submundo com sucesso.
- [ ] Breno se sacrificou pela sobrevivência da mesa.
- [ ] O Chalé 5 permaneceu unido em dor e lealdade inabalável.
- [ ] A desconfiança sobre quem vazou as informações permanece no ar.
- [ ] **Marco V:** Sem nível na ficha — o reconhecimento vem na forma de respeito dos veteranos, Quíron chamando cada um pelo nome e a revelação de que o mundo se tornou muito mais sombrio.

---

## Links Relacionados
- [[Breno]]
- [[Bryan]]
- [[Augusto]]
- [[Dave]]
- [[Chalé 5 - Ares]]
- [[A Lâmina de Nyx]]
- [[🏠 Início]]

---
**Navegação da Campanha:** [[Capítulo 8 - A Ilha de Ninguém|⬅ Capítulo 8 - A Ilha de Ninguém]] · [[Capítulos|Índice das Sessões]]
