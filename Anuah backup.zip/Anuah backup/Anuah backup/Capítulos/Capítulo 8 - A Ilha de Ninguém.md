---
tipo: Sessão
categoria: Capítulo
tags:
  - capitulo
  - sessao
pdf_page: 180
---


# Capítulo 8 - A Ilha de Ninguém

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=180|Consultar Texto Original no PDF (Página 180) — Capítulo 8 Completo]]**

*O lugar mais cordial e mais perigoso do Livro 1. E a grande cena do filho de Hades.*

---

## Painel do Capítulo
- **Onde:** Ilha de Ninguém (Mundo §25).
- **Quando:** Manhã ensolarada seguinte ao naufrágio marítimo.
- **Quem está em cena:** [[Polifemo]] · três semideuses aliados de Nyx · guardas [[Cebrenos]] · [[Cérbero]] acorrentado · pégasos confinados · Édipo e Belerofonte · [[Dave]], [[Bryan]] e [[Breno]] (que chegam pelo cais como se nada houvesse ocorrido).
- **O que os jogadores sabem:** Estão buscando o guardião sequestrado no pátio dos fundos.
- **O que só o Mestre sabe:** Que os hóspedes foram previamente avisados por Dave da chegada do grupo; que há uma mancha no pátio que não reflete luz; que Dave recebe a nefasta [[A Lâmina de Nyx]] nesta sessão.
- **Começa quando:** No cais de madeira tratada, um ciclope imenso de avental sorri calorosamente dizendo: *"Sejam bem-vindos! Quarto pra quantos?"*
- **Termina quando:** Ocorre o primeiro silêncio bom e reconfortante da missão inteira.
- **Nível:** 2
- **Contadores:** *Suspeita da Pousada (6)* · *Resgate (4)* se necessário.

---

## Cena 1 — A Pousada do Ninguém
Polifemo transformou sua propriedade num comércio próspero: salão aconchegante com lareira, comida saborosa que limpa 1d4 de Estresse e retratos carinhosos de seus carneiros favoritos na parede.
- **Suspeita da Pousada (6):** Avança se os heróis fizerem perguntas intrusivas sobre os fundos ou usarem magia na frente dos hóspedes.
- **A Chave sem Número:** Guardada atrás do balcão, abre o portão dos fundos.

---

## Cena 2 — Os Fundos e os Currais
Três rotas de acesso aos fundos:
1. Roubar a chave sem número da recepção (Finesse Dif. 17).
2. Forçar o alçapão da adega sob os fardos de lã (Força Dif. 15).
3. Aguardar a troca de turno dos Cebrenos às 21h (janela de quatro minutos livres).
- **O que há nos fundos:** Seis celas de bronze, quatro pégasos confinados e o pátio de pedra do guardião.

---

## Cena 3 — Cérbero e a Redenção de Hadesson
Cérbero repousa amarrado por correntes de bronze celestial, gemendo dolorosamente pela ruptura com o mundo inferior.
- Tentar cortar a corrente resulta em ataque feroz de três mordidas.
- **A Cena de Hadesson:** [[Hadesson Neto|Hadesson]] ajoelha-se desarmado perante a besta, chama Cérbero pelo nome e oferece uma tigela com biscoitos e leite fresco.
> *As três cabeças calam-se ao mesmo tempo. O gemido cessa. A cabeça do meio fareja a mão do semideus: o Submundo já conhecia seu nome antes dele nascer.*

---

## Cena 4 — O Reencontro e a Traição nas Sombras
Dave, Bryan e Breno atracam tranquilamente no cais trazendo mantimentos e reforços.
- Enquanto todos celebram o sucesso do resgate, Dave retira-se discretamente e recebe [[A Lâmina de Nyx]] das mãos de um semideus conspirador.

---

## Fichas dos Adversários
- [[Polifemo]]
- [[Cérbero]]
- [[Cebrenos]]

---

## Fechamento do Capítulo 8
- [ ] A mesa apreciou a acolhida sincera de Polifemo.
- [ ] Hadesson teve seu momento solo estelar libertando Cérbero.
- [ ] O segundo grupo reuniu-se com a comitiva.
- [ ] Dave obteve a lâmina negra sem ser flagrado.

---

## Links Relacionados
- [[Hadesson Neto]]
- [[Cérbero]]
- [[Polifemo]]
- [[A Lâmina de Nyx]]
- [[Capítulo 9 - A Fuga e o Preço]]
- [[🏠 Início]]

---
**Navegação da Campanha:** [[Capítulo 7 - O Mar|⬅ Capítulo 7 - O Mar]] · [[Capítulos|Índice das Sessões]] · [[Capítulo 9 - A Fuga e o Preço|Próxima Sessão: Capítulo 9 - A Fuga e o Preço ➔]]
