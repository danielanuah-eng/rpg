---
tipo: Sessão
categoria: Capítulo
tags:
  - capitulo
  - sessao
pdf_page: 80
---


# Capítulo 3 - O Pega-Bandeira

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=80|Consultar Texto Original no PDF (Página 80) — Capítulo 3 Completo]]**

*Uma festa tradicional até deixar de ser. É aqui que a mesa mede forças táticas com o Chalé 5 — e é aqui que o relógio da Noite termina de encher.*

---

## Painel do Capítulo
- **Onde:** Vale do Riacho Partido (Mundo §21).
- **Quando:** Sexta-feira ao entardecer. Sol baixo avermelhado e sombras longas.
- **Quem está em cena:** [[Augusto]], [[Bryan]] e [[Breno]] (adversários no comando do Chalé 5) · [[Fausto]] (capitão do time dos jogadores) · [[Quíron]] (árbitro) · [[Kellen (Diretor K)|Kellen]] e [[Sebastian (Oráculo)|Sebastian]] (assistindo do topo do rochedo) · [[Dave]] (elogiando os combatentes na margem) · todo o acampamento.
- **O que os jogadores sabem:** É um jogo esportivo tradicional sem letalidade, onde o Chalé 5 não aceita perder.
- **O que só o Mestre sabe:** Que a *Contagem de Sombra (8)* vai encher antes do final da partida; que a invasão do [[Capítulo 4 - A Noite Mais Densa]] começa no segundo exato em que a contagem terminar; que Augusto escalou Kira e Daniel no time oposto de propósito para medir sua fibra moral.
- **Começa quando:** Quíron sopra a concha marinha duas vezes e as equipes descem a colina em disparada.
- **Termina quando:** Os grilos emudecem simultaneamente por todo o vale.
- **Nível:** 1
- **Contadores:** *Bandeira Oeste (6)* · *Bandeira Leste (6)* · *Contagem de Sombra (8)*.
- **Marco:** Marco II — Recompensa social no fim.

---

## Cena 1 — A Escolha dos Times
Augusto separa propositalmente [[Kira Andros|Kira]] e [[Daniel Storis|Daniel]] para jogarem contra sua própria cabana:
> *"Vocês dois vão pra lá. Eu não sei o que vocês são ainda. E não dá pra saber jogando do mesmo lado."*

Em seguida, Augusto convoca [[Barak Armstrong|Barak]]:
> *"Armstrong. Vem pro cinco. Não é favor. É que eu vi o que caiu em cima da tua cabeça ontem, e eu prefiro isso comigo do que contra mim. Tu decide."*

---

## Cena 2 — O Terreno e os Acidentes
O Riacho Partido corta o vale:
- **Terreno Neutro:** Ninguém pode ser atacado com os pés dentro da água corrente. Lavar o rosto ali limpa 1 de Estresse.
- **Oeste (Bosque das Amoreiras):** Mata densa, frutas caídas. Vantagem para se esconder. Abriga a *Cova do Carvalho*, onde Augusto enterrou a bandeira à altura da grama.
- **Leste (Pinheiros Queimados):** Clareira aberta. Visibilidade ampla. Fausto fincou a bandeira real na *Laje de Granito* e uma bandeira falsa nas *Ruínas do Celeiro*.

---

## Cena 3 — A Dinâmica do Jogo
As equipes disputam as seis etapas para capturar o estandarte adversário: Localizar -> Alcançar -> Neutralizar o Defensor -> Soltar do Suporte -> Atravessar o Riacho -> Cruzar a Linha de Casa.
- **A Regra de Ouro da Mesa:** Informação de um lado não vaza para o outro fora da ficção.
- Se alguém chegar a 0 PV, tomba na relva e deve contar até vinte antes de voltar ao combate.

---

## Cena 4 — O Confronto com os Líderes de Ares
- **[[Augusto]]**: Desafia para o *Duelo Declarado* quem demonstrar mais poder.
- **[[Bryan]]**: Desestabiliza com ataques psicológicos corrosivos (*"Fala primeiro"*).
- **[[Breno]]**: Intervém para proteger o irmão com sua maça colossal.

---

## Cena 5 — A Interrupção Repentina
A partida não chega a ter um vencedor pacífico. Quando a *Contagem de Sombra (8)* enche (impulsionada por rolagens com Medo):
> **LEIA EM VOZ ALTA:**  
> *"Os grilos param. Não um por um — todos, ao mesmo tempo, no vale inteiro, como se alguém tivesse desligado uma chave. Por dois segundos vocês escutam a própria respiração e mais nada. E aí a mata do lado oeste se abre..."*

Quíron leva a concha aos lábios, mas não sopra. O [[Capítulo 4 - A Noite Mais Densa]] começa imediatamente nesse silêncio absoluto.

---

## Gatilhos de Reclamação Divina no Capítulo 3
- **[[Daniel Storis|Daniel (Ares)]]:** Se aceitar o duelo declarado de Augusto ou resistir de pé a um golpe de Breno, a lança e o javali vermelho acendem no campo aberto.
- **[[Igorovsky Baranyeisky|Igorovsky (Atena)]]:** Se decifrar sozinho o ardil da bandeira falsa de Fausto, a coruja cinza se materializa.
- **[[Ícaro Lyra|Ícaro (Apolo)]]:** Se abandonar a disputa de jogo para socorrer um campista atolado no brejo, o sol e a lira dourados acendem.

---

## Fechamento do Capítulo 3
- [ ] Augusto e Fausto traçaram suas jogadas táticas.
- [ ] Cada jogador teve ao menos um embate com Augusto, Bryan ou Breno.
- [ ] A Contagem de Sombra atingiu 8 segmentos.
- [ ] Os grilos pararam de cantar simultaneamente.

---

## Links Relacionados
- [[Chalé 5 - Ares]]
- [[Augusto]]
- [[Fausto]]
- [[Capítulo 4 - A Noite Mais Densa]]
- [[🏠 Início]]

---
**Navegação da Campanha:** [[Capítulo 2 - A Chegada|⬅ Capítulo 2 - A Chegada]] · [[Capítulos|Índice das Sessões]] · [[Capítulo 4 - A Noite Mais Densa|Próxima Sessão: Capítulo 4 - A Noite Mais Densa ➔]]
