---
tipo: Hub
categoria: Capítulo
tags:
  - capitulo
  - sessao
  - hub
pdf_page: 27
---

# 🟣 As Nove Sessões da Campanha

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=27|Consultar Texto Original no PDF (Página 27) — Estrutura das Sessões]]**

Hub central de navegação cronológica das nove sessões de *A Noite Mais Densa*.

---

## Trilha dos Capítulos

1. **[[Capítulo 1 - O Museu das Maravilhas]]** ➔ O chamado e o despertar dos poderes.
2. **[[Capítulo 2 - A Chegada]]** ➔ Acolhimento em Long Island e a revelação de Zeus.
3. **[[Capítulo 3 - O Pega-Bandeira]]** ➔ O teste marcial contra o Chalé 5.
4. **[[Capítulo 4 - A Noite Mais Densa]]** ➔ A invasão ensombrada e as profecias.
5. **[[Capítulo 5 - A Estrada e o Pub]]** ➔ A jornada a Manhattan e o pub de Dionísio.
6. **[[Capítulo 6 - O Parque Aquático Nostos]]** ➔ A travessia da garganta de Cila.
7. **[[Capítulo 7 - O Mar]]** ➔ O Mar de Monstros e o vórtice de Caríbdis.
8. **[[Capítulo 8 - A Ilha de Ninguém]]** ➔ A pousada de Polifemo e o resgate de Cérbero.
9. **[[Capítulo 9 - A Fuga e o Preço]]** ➔ O sacrifício na caverna e a volta para casa.

---
[[🏠 Início|⬅ Retornar ao Início]]
