---
tipo: Sessão
categoria: Capítulo
tags:
  - capitulo
  - sessao
pdf_page: 30
---


# Capítulo 1 - O Museu das Maravilhas

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=30|Consultar Texto Original no PDF (Página 30) — Capítulo 1 Completo]]**

*A sessão em que cinco crianças de doze anos descobrem, todas de uma vez, que o mundo mentiu para elas a vida inteira.*

---

## Painel do Capítulo
- **Onde:** Excursão escolar ao Museu das Maravilhas, Nova York. Começa no ônibus amarelo, termina correndo num parque no escuro.
- **Quando:** Uma quinta-feira de outono. Saída às 14h, retorno previsto para as 19h (que não vai acontecer).
- **Quem está em cena:** [[Barak Armstrong|Barak]], [[Igorovsky Baranyeisky|Igorovsky]], [[Daniel Storis|Daniel]], [[Ícaro Lyra|Ícaro]], [[Hadesson Neto|Hadesson]] · [[Quíron]] (o motorista) · [[Professor Fujiho]] (História) · [[Fujiro]] (o monitor sátiro) · [[Sr. Morelo (Mormo)|Sr. Morelo]] (curador da noite / Mormo) · dois guardas mortais · Darrim e Amaê (colegas de turma) · [[Lélape]] e a [[Strix e Ninhada|Strix]].
- **O que os jogadores sabem:** Passeio comum de escola pública. Ônibus velho, professor chato com cheiro de incenso.
- **O que só o Mestre sabe:** Que os cinco são semideuses e nenhum sabe; que [[A Noite e Nyx|Nyx]] plantou a carta e soltou Lélape atrás da [[A Lâmina-Chave]]; que o Sr. Morelo é [[Mormo]]; que o Professor Fujiho é um elemental protetor de Barak e Fujiro é um sátiro; que observadores da [[A Ordem da Família das Máscaras|Ordem]] assistem de fora (Mundo §8).
- **Começa quando:** O ônibus range ao passar numa lombada e todo mundo sobe dez centímetros do banco.
- **Termina quando:** O ônibus arranca com as portas ainda abertas e Quíron diz a frase de revelação.
- **Nível:** 1
- **Contadores:** *Atenção do Museu (6)* · depois, *Perseguição (6)*.
- **Marco:** Fim do capítulo: cada jogador escreve a sua semente de Experiência.

> [!TIP]
> A sessão tem três terços: 1 hora de escola comum e tédio, 1 hora de exploração livre e mistério, e 40 minutos de terror e perseguição veloz.

---

## Cena 1 — O Ônibus Escolar
Um ônibus amarelo com quinze anos a mais do que deveria. Bancos de vinil verde rasgados com fita crepe prateada, cheiro de borracha quente e lanche esmagado.

> **LEIA EM VOZ ALTA:**  
> *"O ônibus pega uma lombada e todo mundo sobe dez centímetros do banco ao mesmo tempo, e a turma inteira faz 'ÔÔÔÔ' junto, porque é a lei. O ar-condicionado morreu em algum momento do governo passado. Faz calor. O professor de História está sentado na primeira fileira, sozinho, abanando um leque de papel, e vocês não sabem dizer qual a idade dele: setenta? Noventa? Ele tem o tipo de cara que parece esculpida em raiz de árvore. Lá na frente, o motorista olha pelo espelho. Não pra rua. Pro corredor. E quando o olhar dele passa por você — por você especificamente — ele dá um aceno de cabeça bem pequeno, como se estivesse conferindo uma lista."*

### O que pode acontecer no Ônibus:
- **Conversar com Quíron:** Ele pergunta de bom humor: *"Teus pais são os dois?"* e presta atenção cirúrgica na resposta.
- **Reparar no Professor Fujiho (Instinto Dif. 10):** Não está suando, apesar dos 34°C.
- **Reparar no Monitor Fujiro (Instinto Dif. 15):** Cheira o ar a cada dez minutos e aperta as muletas em pânico contido.
- **Mexer na pasta do professor (Finesse Dif. 15):** Papel de arroz, tinta e um mapa de NY com um círculo a lápis em volta do museu.

---

## Cena 2 — A Chegada e o Sr. Morelo
O Museu das Maravilhas era um antigo banco de pedra cinza. Na fachada lê-se com letras caídas: *MVSEV DAS MARA ILHAS*. Há uma placa de latão: *ACERVO CEDIDO PELA FUNDAÇÃO NOSTOS*.

> **LEIA EM VOZ ALTA:**  
> *"O Sr. Morelo bate palmas duas vezes e a turma inteira para, mais por susto do que por respeito. Ele tem uns sessenta anos, um paletó com remendo no cotovelo e um molho de chaves que ele gira no dedo sem parar. 'Regras', ele diz. 'Primeira: não corram. Segunda: não toquem. Terceira' — e aqui ele abre um sorriso — 'se vocês forem tocar em alguma coisa mesmo assim, não toquem no que tem corda de veludo na frente, porque essas eu tenho que explicar pro seguro.' E aí ele solta vocês. Uma hora livre. Ele fala 'uma hora livre' do jeito que um adulto fala quando já desistiu de ser obedecido."*

---

## Cena 3 — Uma Hora Livre (As Salas)
Enquanto a *Atenção do Museu (6)* não encher, nada ataca diretamente.
1. **Sala das Ânforas:** Vasos com cenas de uma mulher sem rosto entregando uma faca a um jovem. Inscrição grega traduzida pelo áudio-guia: *"O que ela toma, ninguém procura."* Vitrine vazia com marca em formato de lâmina.
2. **Sala de Armaduras:** Peças autênticas de bronze celestial disfarçadas como "liga de cobre não identificada" (Finesse Dif. 14 para pegar sem ser visto).
3. **Ala do Oriente:** Sala do Professor Fujiho. Os sinos de vento tocam sem vento, acompanhando a respiração dele.
4. **Gabinete de História Natural (A Sala Central):** Vitrines com animais empalhados. No centro, a estátua de cão negro sem poeira ([[Lélape]]). No fundo, a coruja empalhada ([[Strix e Ninhada|Strix]]) guardando um manto de veludo negro cobrindo a [[A Lâmina-Chave]] e uma carta misteriosa.
5. **Sala de Restauro:** Lâmpada de luz negra que revela marcas de garras e manchas profanas.
6. **Copa e Depósito:** Ficha do catálogo da coruja marcada como *"Strix. Sem procedência. Não exibir"* com anotação a lápis *"ordem de cima"*.

---

## Cena 4 — A Vitrine, a Coruja e a Carta
Dispara quando a Atenção enche ou alguém força a vitrine trancada da coruja.

> **LEIA EM VOZ ALTA:**  
> *"A coruja empalhada da vitrine do fundo pisca. Não mexe a cabeça, não abre a asa: pisca, com aquele olho de vidro preto até a borda. E aí o vidro da vitrine racha do lado de dentro, sozinho, de baixo pra cima, com um barulho de gelo. Ela abre as asas — e as asas são grandes demais pra caixa onde ela estava, grandes demais pra sala — e o que sai da boca dela não é pio. É choro de criança. Vindo do teto. E de trás das outras vitrines, mais três pares de olhos pretos abrem ao mesmo tempo."*

- **Combate I:** A [[Strix e Ninhada|Strix e sua Ninhada]] despertam.
- **A Lâmina-Chave:** Revelada sob o veludo. Ela esfria dolorosamente na mão de qualquer outro até ser entregue a [[Barak Armstrong|Barak]].

---

## Cena 5 — O Sr. Morelo Conta as Crianças e Lélape Racha
Os guardas tentam separar o grupo. O Sr. Morelo surge para levar as crianças sozinhas. E então a estátua de pedra racha em placas revelando o pelo negro de [[Lélape]], o cão que nunca perde uma caça.

---

## Cena 6 — O Professor de História
O Professor Fujiho intervém empunhando o leque de papel, controlando rajadas ciclônicas de vento para segurar o cão:
> *"Corram, por favor. Pela porta dos fundos. Eu conheço esse cachorro."*

---

## Cena 7 — A Perseguição no Parque
Disputa entre dois contadores: **Fuga (6)** vs. **Lélape (6)**.
- Correr não resolve porque Lélape nunca desiste.
- **A Solução do Capítulo:** Água corrente! Entrar no chafariz do parque ou canaletas de água corta o rastro e avança a Fuga em +3.

---

## Cena 8 — O Ônibus e a Revelação
Na rua deserta, Quíron aguarda erguido em suas quatro patas de centauro, empunhando um arco longo de bronze:
> *"Entra. Todo mundo. Agora."*

Na viagem de fuga rumo a Long Island, Quíron explica a existência dos deuses, a herança divina dos cinco garotos e o perigo do cheiro que agora atrai os monstros.

---

## Fichas dos Adversários
- [[Strix e Ninhada]]
- [[Lélape]]
- [[Professor Fujiho]] (Aliado)

---

## Gatilhos da Sessão 1 (Tabela de Custos)
- Quebrar vitrine: +2 na Atenção e +1 Medo.
- Tocar em Lélape com a mão nua: A pele brilha; o cão foca essa pessoa na perseguição.
- Falar o próprio nome perto de Morelo: +1 Medo. Morelo repete o nome baixinho.
- Atacar com réplica de manuseio: A réplica entorta; ensina a diferença entre bronze e sucata.

---

## Fechamento do Capítulo
- [ ] Exploraram ao menos três salas do museu.
- [ ] A Lâmina-Chave está com Barak.
- [ ] A perseguição foi resolvida por água corrente.
- [ ] Quíron revelou sua forma de centauro.
- [ ] Cada jogador registrou uma semente de Experiência.

---

## Links Relacionados
- [[Barak Armstrong]]
- [[Lélape]]
- [[Strix e Ninhada]]
- [[A Lâmina-Chave]]
- [[Capítulo 2 - A Chegada]]
- [[🏠 Início]]

---
**Navegação da Campanha:** [[Capítulos|Índice das Sessões]] · [[Capítulo 2 - A Chegada|Próxima Sessão: Capítulo 2 - A Chegada ➔]]
