---
tipo: Lore
categoria: Profecia e Lore
tags:
  - lore
  - profecia
pdf_page: 69
---


# O Caso Édea

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=69|Consultar Texto Original no PDF (Página 69) — A Memória e a Culpa do Chalé 5]]**

O grande fantasma emocional que assombra o [[Chalé 5 - Ares]] e divide as opiniões de todo o [[Acampamento Meio-Sangue]].

---

## A Tragédia de Dois Anos Atrás
- **Quem era Édea:** A antiga e lendária conselheira/líder do Chalé 5, extremamente respeitada e admirada por sua garra e honra em combate.
- **A Morte:** Dois anos antes do início da campanha, durante uma missão perigosa, Édea morreu em combate. Os irmãos de sangue [[Bryan]] e [[Breno]] estavam presentes com ela.
- **A Suspeita:** Metade do acampamento sussurra secretamente que Bryan e Breno foram responsáveis ou a abandonaram covardemente para morrer. Ninguém nunca formalizou a acusação em voz alta perante [[Quíron]] ou [[Kellen (Diretor K)|Kellen]], mas o estigma nunca foi apagado.
- **O Reflexo no Chalé:** A foto de Édea foi retirada da parede do chalé (deixando apenas uma mancha escura na tinta). Augusto assumiu a liderança aos oito anos de idade para blindar seus irmãos contra o ódio velado dos outros chalés.

---

## A Verdade Revelada por Breno
No [[Capítulo 5 - A Estrada e o Pub]], na viagem de trem, Breno senta longe do irmão e confessa pela única vez na campanha inteira aos semideuses:
> *"Falaram pra vocês que a gente matou ela? ... Ela entrou na frente. Foi isso."*

Édea não foi traída; ela se sacrificou para proteger os dois irmãos mais jovens. A crueldade sarcástica de Bryan é sua máscara para afastar qualquer um de sua dor, e o silêncio de Breno é o peso de carregar uma culpa injusta.

---

## O Desfecho no Funeral do Livro 1
Quando Breno se sacrifica no [[Capítulo 9 - A Fuga e o Preço]], o acampamento não realiza um luto digno — espalham-se boatos de alívio e fofocas veladas (*"Sobrou um"*, dizem no refeitório). Apenas o Chalé 5 passa a noite inteira em vigília na fogueira, provando sua lealdade inquebrantável.

---

## Links Relacionados
- [[Chalé 5 - Ares]]
- [[Bryan]]
- [[Breno]]
- [[Augusto]]
- [[Capítulo 5 - A Estrada e o Pub]]
- [[Capítulo 9 - A Fuga e o Preço]]
- [[🏠 Início]]
