---
tipo: Lore
categoria: Profecia e Lore
tags:
  - lore
  - profecia
pdf_page: 146
---


# A Ordem da Família das Máscaras

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=146|Consultar Texto Original no PDF (Página 146) — Sentinelas e Rituais da Ordem]]**

Uma seita enigmática e influente que atua nas fronteiras entre o mundo mortal, as cortes divinas e os domínios da Noite.

---

## Operação e Crenças
- A Ordem venera rituais de despersonalização e máscaras como símbolos de desprendimento da tirania do destino imposto pelos deuses olímpicos.
- Mantêm sentinelas infiltrados em pontos estratégicos pelo país: museus, portos, parques aquáticos e até mesmo nas cercanias do Acampamento Meio-Sangue.
- Seus membros utilizam relíquias como a [[A Meia-Máscara de Pavão]] e o misterioso *Olho de Bronze* (Mundo §8), capaz de apagar e reescrever memórias recentes.

---

## Envolvimento na Campanha
1. **O Museu ([[Capítulo 1 - O Museu das Maravilhas|Capítulo 1]]):** Observadores mascarados assistiram de fora ao despertar de [[Lélape]] e à fuga do ônibus, sem intervir.
2. **A Infiltração ([[Capítulo 4 - A Noite Mais Densa|Capítulo 4]]):** A razão pela qual os monstros ensombrados penetraram o vale sem que as defesas mágicas soassem alarme envolve o uso do *Olho de Bronze* para alterar a memória dos vigias.
3. **O Parque Nostos ([[Capítulo 6 - O Parque Aquático Nostos|Capítulo 6]]):** Um dos três funcionários sumidos do parque aquático era, na verdade, um sentinela da Ordem que investigava [[Kyla Nestor (Cila)|Cila]], tendo deixado para trás a [[A Meia-Máscara de Pavão]] e anotações cruciais.
4. **Aliança com Nyx:** A Ordem não foi enfeitiçada: eles acreditam na tese filosófica da Noite de que os deuses olímpicos são exploradores crueis de semideuses descartáveis.

---

## Links Relacionados
- [[A Meia-Máscara de Pavão]]
- [[A Noite e Nyx]]
- [[Capítulo 6 - O Parque Aquático Nostos]]
- [[🏠 Início]]
