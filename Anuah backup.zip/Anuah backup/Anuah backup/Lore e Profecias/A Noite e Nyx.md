---
tipo: Lore
categoria: Profecia e Lore
tags:
  - lore
  - profecia
pdf_page: 20
---


# A Noite e Nyx

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=20|Consultar Texto Original no PDF (Página 20) — Filosofia e Ações de Nyx]]**

Nyx, a deusa primordial da Noite, é a grande força antagônica que se move sob o tabuleiro do Livro 1.

---

## Filosofia de Atuação
Nyx opera sem manifestação física direta. Ela não grita, não comanda exércitos trovejantes e não aparece em glória aterrorizante.
- **A Ausência de Explicação:** Seu poder é a remoção da certeza. Monstros que não viram pó, sombras que desobedecem aos corpos, luzes que esmaecem gradualmente, animais que emudecem no vale.
- **A Tentação da Verdade:** A corte de Nyx não utiliza feitiços de controle mental. Eles utilizam a verdade crua: a indiferença arrogante dos deuses olimpianos, os jovens sacrificados em missões inúteis e a dor do abandono.
- **Agentes Ocultos:** [[Dave]], filho de Afrodite, opera como seu infiltrado mais perfeito, acreditando piamente na causa de poupar semideuses das garras dos olímpicos.

---

## A Presença na Campanha
1. **O Museu:** Plantou a carta misteriosa e atiçou [[Lélape]] para caçar a [[A Lâmina-Chave]].
2. **O Vale:** Soltou os monstros ensombrados do [[O Criadouro]] para testar os novatos e forçar o Oráculo a falar.
3. **O Mar:** Fez seu olho vigiar a embarcação sob a forma de uma tempestade sem raios ([[Capítulo 7 - O Mar]]).
4. **A Ilha de Ninguém:** Entregou a [[A Lâmina de Nyx]] a Dave para que as futuras vítimas desapareçam da existência sem deixar rastro no Submundo.

---

## Links Relacionados
- [[Como a Noite Trabalha]]
- [[Dave]]
- [[A Grande Profecia]]
- [[O Criadouro]]
- [[A Lâmina de Nyx]]
- [[🏠 Início]]
