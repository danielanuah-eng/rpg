---
tipo: Lore
categoria: Profecia e Lore
tags:
  - lore
  - profecia
pdf_page: 102
---


# O Criadouro

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=102|Consultar Texto Original no PDF (Página 102) — Origem dos Monstros Ensombrados]]**

Localizado nas profundezas da floresta leste (Mundo §10), além dos limites seguros do acampamento. É a forja profana e o laboratório biológico onde feras antigas são alteradas pela essência do Breu.

---

## Características e Manifestações
- **Cheiro de metal quente:** Um odor metálico e asfixiante de fundição em brasa emana da floresta leste, mesmo onde não existe forja visível.
- **Ressonância de bronze:** As vibrações do Criadouro afetam qualquer engrenagem ou artefato de bronze celestial num raio de dois quilômetros — razão pela qual os autômatos de treino construídos por [[Outros Campistas|Chris Forgjer]] acordam sozinhos ([[Capítulo 2 - A Chegada|Capítulo 2]]) e [[Outros Campistas|Victor Goldffêch]] tranca o galpão do Chalé 9 no [[Capítulo 4 - A Noite Mais Densa|Capítulo 4]].
- **Grama morta em arco:** As criaturas criadas no local expelem uma baba escura e viscosa que queima o solo em círculos pretos e lisos onde a vegetação nunca mais renasce.

---

## Criaturas Geradas
- [[Dragão Ensombrado]]
- [[Ogro Ensombrado]]
- [[Cão de Baba]]

> [!IMPORTANT]
> Corpos de criaturas ensombradas **não viram pó** dourado quando mortas. Ficam caídas na matéria física, demonstrando que foram geradas ou modificadas artificialmente em solo terreno sob encomenda de forças ancestrais.

---

## Links Relacionados
- [[Capítulo 4 - A Noite Mais Densa]]
- [[A Noite e Nyx]]
- [[Autômato de Treino]]
- [[🏠 Início]]
