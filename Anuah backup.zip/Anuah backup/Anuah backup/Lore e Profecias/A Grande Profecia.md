---
tipo: Lore
categoria: Profecia e Lore
tags:
  - lore
  - profecia
pdf_page: 111
---


# A Grande Profecia

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=111|Consultar Texto Original no PDF (Página 111) — Texto da Grande Profecia]]**

Recitada por [[Sebastian (Oráculo)|Sebastian]], o Oráculo do acampamento, na mesma noite da invasão dos monstros ensombrados no vale ([[Capítulo 4 - A Noite Mais Densa|Capítulo 4]]). O próprio fato de Sebastian ter descido do sótão por vontade própria foi o que aterrorizou o acampamento.

---

## O Texto da Grande Profecia

> *Sete nascidos do fogo partido*  
> *descerão ao abismo sem fundo e sem ruído.*  
> *A que não pôde querer escondeu o último elo,*  
> *e o elo traz o nome de um filho sem desvelo.*  
> *Quando o trovão emudecer e o abismo secar,*  
> *a noite não terá de subir: já vai estar.*  
> *Um dos sete abrirá o que os outros seis fecharam,*  
> *e a lâmina sem reflexo dirá quem todos amaram.*  

*(Referência ao Mundo §27. Não explique na mesa durante o jogo).*

---

## Análise Oculta dos Versos (Só para o Mestre)

- **"Sete nascidos do fogo partido"**: Os seis semideuses da mesa ([[Barak Armstrong|Barak]], [[Kira Andros|Kira]], [[Daniel Storis|Daniel]], [[Igorovsky Baranyeisky|Igorovsky]], [[Ícaro Lyra|Ícaro]], [[Hadesson Neto|Hadesson]]) somados ao sétimo escolhido ausente (filho de Poseidon).
- **"descerão ao abismo sem fundo e sem ruído"**: A futura descida aos domínios esquecidos do Tártaro / abismo primordial nos livros subsequentes.
- **"A que não pôde querer escondeu o último elo"**: Héstia ([[Deuses Presentes|Héstia / A Menina da Fogueira]]) e o segredo guardado da chama.
- **"e o elo traz o nome de um filho sem desvelo"**: A linhagem negligenciada de Hades ([[Hadesson Neto|Hadesson]]).
- **"Quando o trovão emudecer e o abismo secar / a noite não terá de subir: já vai estar"**: O plano de Nyx ([[A Noite e Nyx]]) para suplantar o domínio olímpico sem batalha aberta, corrompendo a base.
- **"Um dos sete abrirá o que os outros seis fecharam"**: O papel decisivo da [[A Lâmina-Chave]].
- **"e a lâmina sem reflexo dirá quem todos amaram"**: A misteriosa [[A Lâmina de Nyx]] entregue a [[Dave]].

---

## Links Relacionados
- [[A Profecia da Missão]]
- [[Sebastian (Oráculo)]]
- [[Capítulo 4 - A Noite Mais Densa]]
- [[A Noite e Nyx]]
- [[🏠 Início]]
