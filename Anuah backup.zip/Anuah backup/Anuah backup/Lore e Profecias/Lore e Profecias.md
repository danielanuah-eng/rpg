---
tipo: Hub
categoria: Profecia e Lore
tags:
  - lore
  - profecia
  - hub
pdf_page: 111
---

# 🌸 Lore, Profecias & Conspirações

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=111|Consultar Texto Original no PDF (Página 111) — As Profecias]]**

Os mistérios ocultos, profecias do Oráculo e tramas subterrâneas que definem o destino dos heróis.

---

## As Revelações do Destino
- **[[A Grande Profecia]]:** Os versos proferidos por Sebastian sobre os cadáveres que não viram pó.
- **[[A Profecia da Missão]]:** As linhas que antecipam as escolhas e tragédias do Livro 1.
- **[[A Noite e Nyx]]:** A doutrina filosófica e a corrosão invisível da Noite Primordial.
- **[[O Caso Édea]]:** A culpa enterrada e a nobreza secreta dos irmãos do Chalé 5.
- **[[O Criadouro]]:** A forja profana na floresta leste onde feras ensombradas são concebidas.
- **[[A Ordem da Família das Máscaras]]:** A conspiração de semideuses dissidentes.

---
[[🏠 Início|⬅ Retornar ao Início]]
