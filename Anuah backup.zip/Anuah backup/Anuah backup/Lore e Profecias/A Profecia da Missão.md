---
tipo: Lore
categoria: Profecia e Lore
tags:
  - lore
  - profecia
pdf_page: 111
---


# A Profecia da Missão

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=111|Consultar Texto Original no PDF (Página 111) — Texto da Profecia da Missão]]**

Entregue por [[Sebastian (Oráculo)|Sebastian]] exclusivamente para [[Barak Armstrong|Barak]] na manhã seguinte à invasão, dentro da Casa Grande. Nenhum outro semideus foi nomeado pelo Oráculo — o que significou que os outros cinco viajaram por escolha voluntária, não por destino.

---

## O Texto da Profecia da Missão

> *A estrada se abre em duas antes de o mar acabar,*  
> *e uma das metades chega sem saber da outra.*  
> *O riso e o trovão não pisam a mesma areia.*  
> *Haverá vinho onde não há vinho, e um presente que ninguém vai querer.*  
> *A garganta que canta cobra o que se ama — e aceita ser enganada por seis.*  
> *O acorrentado só se solta pela mão que ninguém nomeou.*  
> *E quem fechar a última porta, fecha do lado de fora.*  
>  
> *— e só o chalé vermelho vai saber chorar o nome.*  

---

## O que Cada Verso Significa (Só para o Mestre)

| Verso | O que é de verdade | Quando cai a ficha |
| :--- | :--- | :--- |
| *A estrada se abre em duas antes de o mar acabar* | O naufrágio provocado por [[Caríbdis]] e a separação inevitável do grupo. | [[Capítulo 7 - O Mar]] |
| *e uma das metades chega sem saber da outra* | O Grupo A cai dentro do muro da pousada enquanto o Grupo B é algemado na praia. | [[Capítulo 7 - O Mar]] |
| *O riso e o trovão não pisam a mesma areia* | [[Dave]] (Afrodite/riso) e [[Barak Armstrong|Barak]] (Zeus/trovão) vão para grupos distintos — permitindo a Dave operar nas sombras. | [[Capítulo 7 - O Mar]], e ninguém repara. |
| *Haverá vinho onde não há vinho* | [[Capítulo 5 - A Estrada e o Pub|A Vinha Tardia]], o pub nova-iorquino de [[Deuses Presentes|Dionísio]], onde todas as garrafas contêm apenas suco. | [[Capítulo 5 - A Estrada e o Pub]] |
| *e um presente que ninguém vai querer* | Os [[Espantalhos de Palha]] descartados por Dionísio entregues com má vontade. | [[Capítulo 5 - A Estrada e o Pub]] |
| *A garganta que canta cobra o que se ama* | [[Kyla Nestor (Cila)|Cila]], e o seu tributo cruel de lembranças e âncoras pessoais. | [[Capítulo 6 - O Parque Aquático Nostos]] |
| *e aceita ser enganada por seis* | Os seis [[Espantalhos de Palha]], um para cada uma das seis cabeças de Cila. Estava na profecia o tempo todo! | [[Capítulo 6 - O Parque Aquático Nostos]] |
| *O acorrentado só se solta pela mão que ninguém nomeou* | [[Cérbero]], o guardião aprisionado, que só atende ao chamado de [[Hadesson Neto|Hadesson]] (o único não reclamado). | [[Capítulo 8 - A Ilha de Ninguém]] |
| *E quem fechar a última porta, fecha do lado de fora* | A laje da caverna de fuga na ilha, onde [[Breno]] se sacrifica sozinho. | [[Capítulo 9 - A Fuga e o Preço]] |
| *— e só o chalé vermelho vai saber chorar o nome* | O [[Chalé 5 - Ares]], que fica de luto em pé a noite toda na fogueira, enquanto os outros chalés fofocam. | [[Capítulo 9 - A Fuga e o Preço]] |

> [!TIP]
> A profecia não decreta sentenças nem promete mortes: ela apenas desenha o formato do destino. Reler a profecia ao fim do Livro 1 revela que tudo estava nas entrelinhas.

---

## Links Relacionados
- [[A Grande Profecia]]
- [[Sebastian (Oráculo)]]
- [[Breno]]
- [[Dave]]
- [[Cérbero]]
- [[🏠 Início]]
