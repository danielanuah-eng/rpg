---
tipo: Local
categoria: Acampamento e Chalés
tags:
  - acampamento
  - chale
pdf_page: 62
---


# Chalé 8 - Ártemis

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=62|Consultar Texto Original no PDF (Página 62) — Estrutura do Chalé de Ártemis]]**

O chalé prateado reservado exclusivamente para a Deusa da Caça e suas Caçadoras imortais.

---

## Características
- **Exterior:** Cabana baixa, feita de pedra prateada que reflete o luar com fulgor gélido.
- **Status:** Permanentemente fechado e vazio na maior parte do tempo, a menos que as Caçadoras de Ártemis façam uma visita temporária a Long Island. Ninguém do acampamento ousa invadir ou violar sua entrada.

---

## Links Relacionados
- [[Acampamento Meio-Sangue]]
- [[Rivalidades Divinas]]
- [[🏠 Início]]

---
**Alinhamento das Cabanas:** [[Chalé 7 - Apolo]] · [[Chalés do Acampamento|Todos os Chalés]] · [[Acampamento Meio-Sangue]] · [[Chalé 9 - Hefesto]]
