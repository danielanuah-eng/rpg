---
tipo: Local
categoria: Acampamento e Chalés
tags:
  - acampamento
  - chale
pdf_page: 62
---


# Chalé 9 - Hefesto

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=62|Consultar Texto Original no PDF (Página 62) — Estrutura do Chalé de Hefesto]]**

A oficina viva dos artífices divinos e ferreiros do acampamento.

---

## Características
- **Exterior:** Paredes maciças de tijolo aparente e vigas de ferro reforçadas, chaminé industrial que expele fumaça ininterruptamente dia e noite, e portas pesadas de correr de metal escovado.
- **Conselheiros:**
  - [[Outros Campistas|Victor Goldffêch]] (Líder ferreiro mestre, não ergue os óculos de proteção).
  - [[Outros Campistas|Chris Forgjer]] (Vice inventor impulsivo, criador de autômatos).
- **Curiosidades:** O galpão abriga *Zé*, um bode mecânico que mastiga pregos e ferramentas.
- **Segurança Tática:** Victor tranca o galpão no [[Capítulo 4 - A Noite Mais Densa]] após o ataque do Criadouro, avisando que *"coisa que não apodrece não devia ficar perto de ferramenta"*.

---

## Links Relacionados
- [[Autômato de Treino]]
- [[Outros Campistas]]
- [[Acampamento Meio-Sangue]]
- [[O Criadouro]]
- [[🏠 Início]]

---
**Alinhamento das Cabanas:** [[Chalé 8 - Ártemis]] · [[Chalés do Acampamento|Todos os Chalés]] · [[Acampamento Meio-Sangue]] · [[Chalé 10 - Afrodite]]
