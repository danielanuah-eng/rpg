---
tipo: Local
categoria: Acampamento e Chalés
tags:
  - acampamento
  - chale
pdf_page: 60
---


# Chalé 2 - Hera

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=60|Consultar Texto Original no PDF (Página 60) — Estrutura do Chalé de Hera]]**

O santuário honorário dedicado à Rainha dos Céus e deusa do casamento.

---

## Características
- **Exterior:** Semelhante em elegância ao Chalé de Zeus, porém mais contido e simétrico. Esculturas de pavões e romãs adornam o friso superior.
- **Interior:** Impecavelmente limpo, perfumado, organizado e estritamente vazio.
- **A Regra Inviolável:** Não existem semideuses filhos de Hera. O chalé permanece vazio o ano inteiro. Ninguém entra, ninguém mora e ninguém comenta sobre sua existência além de observar seu vazio opressivo.

---

## Links Relacionados
- [[Acampamento Meio-Sangue]]
- [[Rivalidades Divinas]]
- [[🏠 Início]]

---
**Alinhamento das Cabanas:** [[Chalé 1 - Zeus]] · [[Chalés do Acampamento|Todos os Chalés]] · [[Acampamento Meio-Sangue]] · [[Chalé 3 - Poseidon]]
