---
tipo: Local
categoria: Acampamento e Chalés
tags:
  - acampamento
  - chale
pdf_page: 62
---


# Chalé 11 - Hermes

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=62|Consultar Texto Original no PDF (Página 62) — Estrutura do Chalé de Hermes]]**

O maior, mais barulhento e mais apinhado chalé do acampamento.

---

## Características e Rotina
- **Exterior:** Cabana rústica com caduceu talhado sobre a porta, desgastada pelo uso constante de centenas de hóspedes.
- **Interior:** Caos acolhedor. Colchões espalhados pelo chão, mochilas empilhadas, jogos de dados e cartas rolando clandestinamente nos cantos a qualquer hora da madrugada.
- **Acomodação dos Indeterminados:** Todo semideus que ainda não foi reclamado por seus pais divinos reside no Chalé 11. Há campistas veteranos que vivem ali há mais de quatro anos sem saber de quem são filhos.
- **Liderança:** [[Kenny, Elle e Edgar|Kenny]] atua como vice-líder acolhedor, garantindo que ninguém se sinta completamente abandonado.

---

## Links Relacionados
- [[Kenny, Elle e Edgar]]
- [[Hadesson Neto]]
- [[Reclamações Divinas]]
- [[Acampamento Meio-Sangue]]
- [[🏠 Início]]

---
**Alinhamento das Cabanas:** [[Chalé 10 - Afrodite]] · [[Chalés do Acampamento|Todos os Chalés]] · [[Acampamento Meio-Sangue]] · [[Chalé 12 - Dionísio]]
