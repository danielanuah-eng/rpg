---
tipo: Local
categoria: Acampamento e Chalés
tags:
  - acampamento
  - chale
pdf_page: 63
---


# Chalé 13 - A Cabana Preta (Hades)

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=63|Consultar Texto Original no PDF (Página 63) — A Décima Terceira Cabana]]**

A misteriosa e velada cabana erguida fora do semicírculo em 'U' das doze cabanas olímpicas.

---

## Características e Isolamento
- **Localização:** Fica atrás da linha das cabanas regulares, parcialmente encoberta pela sombra densa de dois pinheiros antigos.
- **Aparência:** Construção baixa de rocha de obsidiana negra sem janelas, portas sem entalhes nem adornos, sem brasão visível.
- **O Tabu do Acampamento:** Ninguém no acampamento fala abertamente sobre ela. Quando os novatos perguntam a respeito, veteranos dão de ombros e mudam de assunto com destreza.

---

## A Abertura para Hadesson
No encerramento do [[Capítulo 2 - A Chegada]], após o espetáculo da reclamação triunfal de Zeus sobre Barak, [[Kellen (Diretor K)|Kellen]] procura [[Hadesson Neto|Hadesson]] em particular e faz o impensável: manda abrir a cabana preta:
> *"Vou mandar arejar aquela ali de fora do U. Não é tua, ninguém disse que é tua. Mas hoje ela tá aberta, e eu prefiro que alguém durma dentro dela do que ela ficar aberta sozinha."*

Oficialmente Hadesson permanece registrado no Chalé 11 como não-reclamado, mas passa a dormir dentro das paredes silenciosas da Cabana Preta.

---

## Links Relacionados
- [[Hadesson Neto]]
- [[Kellen (Diretor K)]]
- [[Deuses Presentes]]
- [[Acampamento Meio-Sangue]]
- [[Capítulo 2 - A Chegada]]
- [[🏠 Início]]

---
**Alinhamento das Cabanas:** [[Chalé 12 - Dionísio]] · [[Chalés do Acampamento|Todos os Chalés]] · [[Acampamento Meio-Sangue]]
