---
tipo: Local
categoria: Acampamento e Chalés
tags:
  - acampamento
  - chale
pdf_page: 61
---


# Chalé 5 - Ares

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=61|Consultar Texto Original no PDF (Página 61) — Estrutura do Chalé de Ares]]**

O temido chalé vermelho dos filhos do Deus da Guerra.

---

## Características e Aparência
- **Exterior:** Tinta vermelha áspera descascando de propósito, arame farpado decorativo correndo pelas calhas e uma cabeça de javali de bronze celestial empalhada sobre o batente da porta.
- **Interior:** Surpreendentemente, é o chalé **mais limpo e organizado** do acampamento. Beliches alinhados com precisão militar, armas engraxadas em suportes, chão varrido e um quadro minucioso de escalas de tarefas escrito à mão com caligrafia milimétrica.
- **A Marca na Parede:** Um espaço desbotado onde outrora ficava pendurada a foto da antiga líder [[O Caso Édea|Édea]]. Ninguém toca no assunto na presença de estranhos.

---

## Hierarquia e Membros
- **Líder:** [[Augusto]] (10 anos, implacável no comando).
- **Vice-Líderes:** [[Bryan]] (ruidoso, agressivo verbalmente) e [[Breno]] (forte, protetor silencioso).
- **Membros Jogadores:** [[Kira Andros]] (veterana) e [[Daniel Storis]] (recruta recém-reclamado).

---

## O Estigma e a Lealdade
O Chalé 5 carrega a pior reputação do acampamento — metade dos campistas desconfia que Bryan e Breno causaram a morte de Édea. Em contrapartida, possuem o senso de fraternidade interna mais inquebrantável de Long Island: se alguém atacar um filho de Ares, comprou briga com o chalé inteiro.

---

## Links Relacionados
- [[Augusto]]
- [[Bryan]]
- [[Breno]]
- [[Kira Andros]]
- [[Daniel Storis]]
- [[O Caso Édea]]
- [[Capítulo 3 - O Pega-Bandeira]]
- [[Capítulo 9 - A Fuga e o Preço]]
- [[🏠 Início]]

---
**Alinhamento das Cabanas:** [[Chalé 4 - Deméter]] · [[Chalés do Acampamento|Todos os Chalés]] · [[Acampamento Meio-Sangue]] · [[Chalé 6 - Atena]]
