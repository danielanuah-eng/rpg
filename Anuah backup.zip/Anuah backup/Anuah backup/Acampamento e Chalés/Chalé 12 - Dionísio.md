---
tipo: Local
categoria: Acampamento e Chalés
tags:
  - acampamento
  - chale
pdf_page: 62
---


# Chalé 12 - Dionísio

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=62|Consultar Texto Original no PDF (Página 62) — Estrutura do Chalé de Dionísio]]**

A cabana descontraída dedicada ao Deus do Vinho, das Festas e da Loucura Ritual.

---

## Características
- **Exterior:** Pérgola totalmente recoberta por parreiras carregadas de uvas, alpendre aconchegante com sofás de almofadas macias e luzinhas festivas penduradas acesas o ano inteiro.
- **Liderança:** [[Outros Campistas|Cristine]] (líder sarcástica) e [[Outros Campistas|Myrthes]] (vice atenta).
- **Curiosidade:** Embora o deus Dionísio esteja proibido por Zeus de beber vinho (cumprindo pena como anfitrião no pub *A Vinha Tardia* em NY), o chalé mantém o clima festivo e descontraído, servindo os melhores sucos de uva e doces do acampamento.

---

## Links Relacionados
- [[Outros Campistas]]
- [[Deuses Presentes]]
- [[Capítulo 5 - A Estrada e o Pub]]
- [[Acampamento Meio-Sangue]]
- [[🏠 Início]]

---
**Alinhamento das Cabanas:** [[Chalé 11 - Hermes]] · [[Chalés do Acampamento|Todos os Chalés]] · [[Acampamento Meio-Sangue]] · [[Chalé 13 - A Cabana Preta (Hades)]]
