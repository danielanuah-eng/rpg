---
tipo: Local
categoria: Acampamento e Chalés
tags:
  - acampamento
  - chale
pdf_page: 22
---


# Rivalidades Divinas

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=22|Consultar Texto Original no PDF (Página 22) — Tabela de Rivalidades dos Deuses]]**

O Olimpo permanece de pé e os deuses são os mesmos de milênios atrás. Suas rivalidades ancestrais não explodem em batalhas cósmicas a todo momento: manifestam-se como fofoca de família rica com raios — e no acampamento, isso se traduz em quem senta com quem no refeitório.

---

## As Rivalidades que Importam no Livro 1

| Deuses Rivais         | Natureza da Rixa                                                                  | Como se Manifesta no Acampamento                                                                                                                                          |
| :-------------------- | :-------------------------------------------------------------------------------- | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| **Atena × Poseidon**  | Antiga, mal resolvida, e nenhum dos dois admite que ainda liga.                   | O [[Chalé 6 - Atena]] recusa-se a emprestar qualquer material ou livro ao [[Chalé 3 - Poseidon]]. Ninguém vivo lembra o porquê; a regra é mais velha que os campistas.    |
| **Ares × Atena**      | Guerra bruta contra guerra planejada.                                             | Piada constante entre os dois lados (*"Chalé 5 pensa com o cotovelo"* vs *"Chalé 6 desenha a estratégia e apanha no meio dela"*). Igorovsky ouve isso na primeira semana. |
| **Zeus × Hades**      | Zeus não gosta de lembrar que possui um irmão no Submundo.                        | Filho de Hades é tratado com respeito cuidadoso e cauteloso demais. Ninguém é abertamente hostil, mas ninguém encosta ou senta perto de Hadesson.                         |
| **Zeus × Poseidon**   | Dois orgulhos colossais do mesmo tamanho.                                         | Qualquer tempestade súbita em dia ensolarado vira motivo de piada ácida e sarcasmo nas mesas do refeitório.                                                               |
| **Apolo × Ares**      | Apolo nunca perdoou um ultraje antigo e faz questão de compor versos zombeteiros. | O [[Chalé 7 - Apolo]] cura os feridos do [[Chalé 5 - Ares]] sempre, e invariavelmente comenta com deboche.                                                                |
| **Hera × Todo Mundo** | Deusa do matrimônio e do lar num acampamento repleto de filhos bastardos.         | O [[Chalé 2 - Hera]] permanece impecavelmente limpo, luxuoso e vazio o ano inteiro.                                                                                       |

---

## O Tratamento Social Chalé por Chalé

- **Filho de Zeus ([[Barak Armstrong|Barak]]):** Tratado como artigo frágil e caríssimo. Adultos adotam formalidade desconcertante; os campistas esperam feitos inacreditáveis e comentam baixinho se ele vacilar. Ganha uma plateia em toda cena pública.
- **Filhos de Ares ([[Kira Andros|Kira]] e [[Daniel Storis|Daniel]]):** Herdam a pior reputação de Long Island e a maior lealdade de sangue. Metade do acampamento sussurra sobre a morte de Édea, mas eles recebem Augusto, Bryan e Breno como protetores incondicionais.
- **Filho de Atena ([[Igorovsky Baranyeisky|Igorovsky]]):** Todos esperam que ele saiba absolutamente tudo. Pelo menos uma vez por sessão, um NPC lhe faz uma pergunta impossível e aguarda seriamente pela resposta.
- **Filho de Apolo ([[Ícaro Lyra|Ícaro]]):** Todos o procuram para fechar cortes e aliviar estresse, mas ninguém pergunta se ele está bem. É a válvula de escape emocional da mesa.
- **Filho de Hades ([[Hadesson Neto|Hadesson]]):** O respeito supersticioso do vazio. Quando senta à mesa do refeitório ou na fogueira, sobra espaço vago nos dois lados do banco.

---

## Links Relacionados
- [[Acampamento Meio-Sangue]]
- [[Reclamações Divinas]]
- [[O Caso Édea]]
- [[🏠 Início]]
