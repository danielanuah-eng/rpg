---
tipo: Local
categoria: Acampamento e Chalés
tags:
  - acampamento
  - chale
pdf_page: 61
---


# Chalé 4 - Deméter

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=61|Consultar Texto Original no PDF (Página 61) — Estrutura do Chalé de Deméter]]**

O chalé da fertilidade, agricultura e colheita.

---

## Características
- **Exterior:** Telhado coberto de grama viva e flores silvestres, janelas repletas de vasos de cerâmica com temperos aromáticos e fachada tomada por videiras viçosas.
- **Conselheiros:** [[Outros Campistas|Daemon Hernandez]] (líder rigoroso e prático) e [[Outros Campistas|Thiago]] (vice que carrega o jackalope Herbert).
- **Função no Acampamento:** Administram as estufas e os extensos campos de morango que sustentam a economia do acampamento e servem como retiro de descompressão emocional para os campistas estressados.

---

## Links Relacionados
- [[Acampamento Meio-Sangue]]
- [[Outros Campistas]]
- [[🏠 Início]]

---
**Alinhamento das Cabanas:** [[Chalé 3 - Poseidon]] · [[Chalés do Acampamento|Todos os Chalés]] · [[Acampamento Meio-Sangue]] · [[Chalé 5 - Ares]]
