---
tipo: Local
categoria: Acampamento e Chalés
tags:
  - acampamento
  - chale
pdf_page: 61
---


# Chalé 7 - Apolo

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=61|Consultar Texto Original no PDF (Página 61) — Estrutura do Chalé de Apolo]]**

O chalé solar dedicado à cura, à música, ao tiro com arco e à poesia.

---

## Características
- **Exterior:** Feito de pedra clara que reluz dourada ao sol e brilha com tom de mel aconchegante durante a noite. Varanda ampla com rede pendurada e violões encostados nos cantos.
- **Conselheiro:** [[Outros Campistas|Tom Belff]] (Líder esportivo e acolhedor).
- **Membro Jogador:** [[Ícaro Lyra]].

---

## Função e o Preço do Chalé
- O Chalé 7 opera como o hospital de campanha e a válvula de alívio de Estresse do acampamento.
- **O Preço Amargo:** Todos no acampamento correm até os filhos de Apolo quando estão sangrando ou em pânico, mas quase ninguém para para perguntar como os próprios curandeiros estão se sentindo.

---

## Links Relacionados
- [[Ícaro Lyra]]
- [[Outros Campistas]]
- [[Acampamento Meio-Sangue]]
- [[Capítulo 4 - A Noite Mais Densa]]
- [[🏠 Início]]

---
**Alinhamento das Cabanas:** [[Chalé 6 - Atena]] · [[Chalés do Acampamento|Todos os Chalés]] · [[Acampamento Meio-Sangue]] · [[Chalé 8 - Ártemis]]
