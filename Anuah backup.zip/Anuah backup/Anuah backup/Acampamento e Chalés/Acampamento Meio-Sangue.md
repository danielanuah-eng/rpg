---
tipo: Local
categoria: Acampamento e Chalés
tags:
  - acampamento
  - chale
pdf_page: 58
---


# Acampamento Meio-Sangue

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=58|Consultar Texto Original no PDF (Página 58) — Descrição do Vale e Instalações]]**

O refúgio seguro dos semideuses na costa norte de Long Island (Mundo §20). Protegido pela fronteira mágica ancorada na árvore de folhas douradas no cume da colina.

---

## Estrutura e Principais Locais

### 1. A Colina e a Árvore Protetora
- Uma única árvore colossal de casca rachada cujas folhas douradas emitem calor suave e luz própria cor de mel.
- A fronteira mágica corta o clima: chuva forte do lado de fora cessa imediatamente ao cruzar a cerca de madeira.

### 2. O Layout em 'U' dos Chalés
Doze cabanas principais dispostas em formato de ferradura ao redor da fogueira central de pedra, mais a décima terceira cabana oculta fora do alinhamento.
- Cada chalé reflete a personalidade, os poderes e as idiossincrasias do deus patrono.
- Veja a lista detalhada em:
  - [[Chalé 1 - Zeus]]
  - [[Chalé 2 - Hera]]
  - [[Chalé 3 - Poseidon]]
  - [[Chalé 4 - Deméter]]
  - [[Chalé 5 - Ares]]
  - [[Chalé 6 - Atena]]
  - [[Chalé 7 - Apolo]]
  - [[Chalé 8 - Ártemis]]
  - [[Chalé 9 - Hefesto]]
  - [[Chalé 10 - Afrodite]]
  - [[Chalé 11 - Hermes]]
  - [[Chalé 12 - Dionísio]]
  - [[Chalé 13 - A Cabana Preta (Hades)]]

### 3. A Fogueira Central
Círculo de pedras do tamanho de uma sala. Durante os acontecimentos do Livro 1, as chamas estão anormalmente baixas (na altura dos tornozelos), pois há campistas demais receosos de dormir. [[Deuses Presentes|Héstia]] permanece ali silenciosa. Sentar e descansar na fogueira limpa 1d4 de Estresse.

### 4. A Casa Grande
Casarão de três andares com ampla varanda de onde [[Quíron]] e [[Kellen (Diretor K)|Kellen]] gerenciam as operações. No sótão reside [[Sebastian (Oráculo)|Sebastian, o Oráculo]], e no segundo andar fica o escritório de Kellen com mapas estratégicos marcados com seis pontos misteriosos.

### 5. A Arena de Combate
Chão de areia batida, arquibancada rústica de três degraus e bonecos de treino danificados. É o domínio de [[Augusto]], onde o treino é pesado e ninguém morre, mas o orgulho é testado diariamente.

### 6. A Forja e Oficinas de Hefesto
Calor sufocante, fumaça, bigornas e engenhocas excêntricas sob os cuidados de [[Outros Campistas|Victor Goldffêch e Chris Forgjer]].

### 7. Os Campos de Morango e o Lago
Fileiras intermináveis de cultivo mortal de morango usadas como fachada comercial e sustento do acampamento. O lago escuro abriga náiades fofoqueiras.

### 8. A Floresta Leste
Floresta densa proibida. Abriga clareiras com manchas de vegetação morta e o cheiro metálico sufocante do [[O Criadouro]].

---

## Links Relacionados
- [[Rivalidades Divinas]]
- [[Capítulo 2 - A Chegada]]
- [[Capítulo 3 - O Pega-Bandeira]]
- [[Capítulo 4 - A Noite Mais Densa]]
- [[🏠 Início]]
