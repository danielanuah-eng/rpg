---
tipo: Local
categoria: Acampamento e Chalés
tags:
  - acampamento
  - chale
pdf_page: 62
---


# Chalé 10 - Afrodite

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=62|Consultar Texto Original no PDF (Página 62) — Estrutura do Chalé de Afrodite]]**

O chalé dedicado à Deusa do Amor, da Beleza e do Desejo.

---

## Características
- **Exterior:** Pintado em tons de rosa desbotado elegante, sacada de madeira entalhada, cortinas finas e um perfume agradável e caro que atinge os transeuntes muito antes de alcançarem a porta.
- **Interior:** Camas com dossel de seda, espelhos ornamentados e guarda-roupas luxuosos.
- **Membro Chave:** [[Dave]] dorme aqui — quando dorme. Usa seu charme natural de filho de Afrodite para mascarar suas maquinações secretas a serviço da Noite.

---

## Links Relacionados
- [[Dave]]
- [[O Espelho de Atena]]
- [[Acampamento Meio-Sangue]]
- [[🏠 Início]]

---
**Alinhamento das Cabanas:** [[Chalé 9 - Hefesto]] · [[Chalés do Acampamento|Todos os Chalés]] · [[Acampamento Meio-Sangue]] · [[Chalé 11 - Hermes]]
