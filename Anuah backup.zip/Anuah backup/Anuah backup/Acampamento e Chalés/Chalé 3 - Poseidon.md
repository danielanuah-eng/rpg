---
tipo: Local
categoria: Acampamento e Chalés
tags:
  - acampamento
  - chale
pdf_page: 61
---


# Chalé 3 - Poseidon

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=61|Consultar Texto Original no PDF (Página 61) — Estrutura do Chalé de Poseidon]]**

A cabana marítima do Senhor dos Oceanos.

---

## Características
- **Exterior:** Construído com rochas acinzentadas entrelaçadas com conchas marinhas fossilizadas e pedras de coral. Emite um cheiro permanente de maresia fresca e ozônio marítimo.
- **Interior:** Vazio no início da campanha. Janelas amplas com vista para o estreito de Long Island.
- **Lore na Campanha:** O sétimo semideus escolhido na [[A Grande Profecia]] é filho de Poseidon, mas não está presente nesta mesa no Livro 1.
- **Rivalidade Histórica:** Os campistas do [[Chalé 6 - Atena]] recusam-se a emprestar livros ou ferramentas ao Chalé 3 desde tempos imemoriais por conta da rivalidade milenar entre seus patronos.

---

## Links Relacionados
- [[Acampamento Meio-Sangue]]
- [[Rivalidades Divinas]]
- [[Capítulo 7 - O Mar]]
- [[🏠 Início]]

---
**Alinhamento das Cabanas:** [[Chalé 2 - Hera]] · [[Chalés do Acampamento|Todos os Chalés]] · [[Acampamento Meio-Sangue]] · [[Chalé 4 - Deméter]]
