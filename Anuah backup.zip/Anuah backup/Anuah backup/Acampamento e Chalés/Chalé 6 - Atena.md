---
tipo: Local
categoria: Acampamento e Chalés
tags:
  - acampamento
  - chale
pdf_page: 61
---


# Chalé 6 - Atena

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=61|Consultar Texto Original no PDF (Página 61) — Estrutura do Chalé de Atena]]**

O centro intelectual e tático do acampamento, dedicado à Deusa da Sabedoria e da Estratégia de Batalha.

---

## Características
- **Exterior:** Paredes cinza-claras, coruja de bronze gravada sobre a porta e cortinas azuis milimetricamente alinhadas em todas as janelas.
- **Interior:** Mapas táticos, estantes repletas de tratados militares antigos, maquetes em miniatura do relevo de Long Island e mesas de estudo.
- **Conselheiros e Membros:**
  - [[Outros Campistas|Romeo]] (Líder leitor e calmo).
  - [[Outros Campistas|Demyra]] (Vice metódica, com sua prancheta de prontuários e alergias).
  - [[Fausto]] (Estrategista veterano e capitão do Pega-Bandeira).
  - [[Igorovsky Baranyeisky]] (Protagonista).

---

## Dinâmica com Outros Chalés
- Mantêm uma rixa permanente com o [[Chalé 5 - Ares]] (*"O Chalé 5 pensa com o cotovelo; o Chalé 6 desenha o plano e apanha no meio dele"*).
- Não compartilham materiais com o [[Chalé 3 - Poseidon]].

---

## Links Relacionados
- [[Igorovsky Baranyeisky]]
- [[Fausto]]
- [[Outros Campistas]]
- [[Acampamento Meio-Sangue]]
- [[Rivalidades Divinas]]
- [[🏠 Início]]

---
**Alinhamento das Cabanas:** [[Chalé 5 - Ares]] · [[Chalés do Acampamento|Todos os Chalés]] · [[Acampamento Meio-Sangue]] · [[Chalé 7 - Apolo]]
