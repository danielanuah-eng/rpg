---
tipo: Hub
categoria: Acampamento e Chalés
tags:
  - acampamento
  - chale
  - hub
pdf_page: 60
---

# 🟠 Os 13 Chalés do Acampamento Meio-Sangue

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=60|Consultar Texto Original no PDF (Página 60) — Os Chalés do Acampamento]]**

As doze cabanas dispostas em 'U' ao redor da fogueira, mais o décimo terceiro chalé das sombras.

---

## O Semicírculo em 'U'

- **[[Chalé 1 - Zeus]]:** Mármore branco, colunas dóricas e vazio solene.
- **[[Chalé 2 - Hera]]:** O santuário honorário permanentemente impecável e vazio.
- **[[Chalé 3 - Poseidon]]:** Rochas marítimas e conchas fossilizadas com aroma de maresia.
- **[[Chalé 4 - Deméter]]:** Telhado de grama viva, flores e cultivo de morangos.
- **[[Chalé 5 - Ares]]:** Arame farpado, javali de bronze e lealdade militar inquebrantável.
- **[[Chalé 6 - Atena]]:** Coruja de bronze, biblioteca tática e mapas estratégicos.
- **[[Chalé 7 - Apolo]]:** Pedra dourada, instrumentos musicais e a enfermaria do vale.
- **[[Chalé 8 - Ártemis]]:** Prata lunar preservada para as Caçadoras.
- **[[Chalé 9 - Hefesto]]:** Tijolos aparentes, chaminé viva e forjas em atividade.
- **[[Chalé 10 - Afrodite]]:** Seda, fragrâncias refinadas e beleza estonteante.
- **[[Chalé 11 - Hermes]]:** O chalé lotado dos indeterminados e recém-chegados.
- **[[Chalé 12 - Dionísio]]:** Pérgola coberta de parreiras e clima festivo perene.

## Fora do Alinhamento
- **[[Chalé 13 - A Cabana Preta (Hades)]]:** Obsidiana gélida aberta secretamente por Kellen para Hadesson.

---
[[Acampamento Meio-Sangue]] · [[Rivalidades Divinas]] · [[🏠 Início]]
