---
tipo: Personagem
categoria: NPC Acampamento
tags:
  - npc
  - acampamento
pdf_page: 92
---


# Augusto

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=92|Consultar Texto Original no PDF (Página 92) — Ficha e Condução de Augusto]]**

Líder supremo do [[Chalé 5 - Ares]], com apenas dez anos de idade. A figura mais respeitada, perigosa e complexa do acampamento jovem.

---

## Estatísticas de Combate (Tier 1 · Líder)
- **Dificuldade:** 14 | **Limiares:** 7/13 | **PV:** 6 | **Estresse:** 3
- **Ataque:** +3 · Mangual de bronze celestial · Muito Próximo · 1d10+2 físico
- **Experiência:** *"Leitura de campo"* +3
- **Passivas:**
  - *Ele se posiciona:* Augusto nunca corre atrás de ninguém; ele já se coloca onde o alvo ia passar.
  - *Mangual contorna escudo:* Escudos e coberturas não oferecem benefício contra seus golpes.
  - *A mão estendida:* Nunca bate em quem já caiu. Estende a mão para levantar o oponente sem sarcasmo.
- **Ações Especiais:** *Duelo declarado*, *Escudo de braço*, e Ação de Medo *O cavalinho* (invoca um trenó de reconhecimento tático).

---

## Dinâmica Psicológica e Lore
- Assumiu a responsabilidade brutal de proteger o Chalé 5 após a tragédia de [[O Caso Édea|Édea]].
- Não expressa sentimentos e masca chiclete sem parar. Protege ferozmente seus subordinados.
- **A Brecha de Augusto:** Não sabe reagir a demonstrações genuínas de cuidado ou compaixão (Presença Dif. 15). Se alguém demonstrar carinho desinteressado, sua couraça se quebra por um instante valioso.

---

## Falas Marcantes
- *"Você é do cinco agora. Isso não é prêmio. Isso é que se alguém mexer com você, mexeu comigo, e eu tenho pouca paciência e muito tempo livre."*
- *"Eu não sei o que vocês são ainda. E não dá pra saber jogando do mesmo lado."*
- *"Você volta com todo mundo ou não volta. Não tem terceira opção que preste."*

---

## Links Relacionados
- [[Chalé 5 - Ares]]
- [[Bryan]]
- [[Breno]]
- [[Kira Andros]]
- [[O Caso Édea]]
- [[Capítulo 3 - O Pega-Bandeira]]
- [[🏠 Início]]
