---
tipo: Personagem
categoria: NPC Acampamento
tags:
  - npc
  - acampamento
pdf_page: 33
---


# Quíron

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=33|Consultar Texto Original no PDF (Página 33) — Perfil e Falas de Quíron]]**

O diretor de atividades do [[Acampamento Meio-Sangue]] e lendário mentor dos maiores heróis da antiguidade.

---

## Aparência e Papel
- **Disfarçado no Mundo Mortal:** Atua como o motorista paciente e cordial do ônibus escolar no [[Capítulo 1 - O Museu das Maravilhas]], usando cadeira de rodas com pedais manuais e um retrovisor côncavo voltado para os alunos.
- **Forma Verdadeira:** Um majestoso centauro de pelagem castanha, barba farta e olhar experiente que já testemunhou mil gerações de semideuses partirem.

---

## Postura Narrativa
- Quíron sabe exatamente a linhagem dos recém-chegados, mas nunca a antecipa: respeita a soberania dos deuses para reclamarem seus filhos.
- No pega-bandeira ([[Capítulo 3 - O Pega-Bandeira]]), atua como árbitro estrito, proibindo danos letais e prezando pelo aprendizado prático.
- Na hora do perigo real, sua velocidade e precisão com o arco de bronze são implacáveis.

---

## Falas Marcantes
- *"Cinto, chefe. Eu sei que não tem cinto. Segura em alguma coisa então."*
- *"Doze anos. É a idade em que começa, e ninguém escolhe. Sinto muito."*
- *"Vocês não vão matar nada. Vocês vão devolver uma coisa. Guardem essa diferença."*

---

## Links Relacionados
- [[Acampamento Meio-Sangue]]
- [[Capítulo 1 - O Museu das Maravilhas]]
- [[Capítulo 2 - A Chegada]]
- [[Capítulo 5 - A Estrada e o Pub]]
- [[🏠 Início]]
