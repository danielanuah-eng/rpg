---
tipo: Personagem
categoria: NPC Acampamento
tags:
  - npc
  - acampamento
pdf_page: 94
---


# Fausto

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=94|Consultar Texto Original no PDF (Página 94) — Ficha de Apoio e Tática]]**

Conselheiro experiente do [[Chalé 6 - Atena]] e capitão do time dos novatos no [[Capítulo 3 - O Pega-Bandeira]].

---

## Perfil e Função (Tier 1 · Aliado de Apoio)
- **Dificuldade para convencimento:** 14
- Olhos cansados, voz arrastada, absolutamente desinteressado por clichês militares. Já viu o final de todas as partidas de pega-bandeira convencionais.
- **Ação Aliada - O Furo:** Quando os jogadores descrevem um plano, Fausto analisa e aponta a falha tática crítica. O plano corrigido recebe Vantagem.
- **Gatilho - Surpreendê-lo (Dif. 17):** Se um jogador apresentar uma estratégia genuinamente inovadora e imprevisível, Fausto sorri pela primeira vez em meses e torna-se um mentor leal permanente.

---

## Falas Marcantes
- *"Eu vou explicar três vezes. Não é porque vocês são burros. É porque na terceira vez alguém sempre acha o erro."*
- *"Você. Você é o meu plano B. Não faz essa cara, é elogio."*
- *"Vocês estão prontos pra uma conversa de verdade."* (Ao fim do Livro 1).

---

## Links Relacionados
- [[Chalé 6 - Atena]]
- [[Capítulo 3 - O Pega-Bandeira]]
- [[Igorovsky Baranyeisky]]
- [[🏠 Início]]
