---
tipo: Personagem
categoria: NPC Acampamento
tags:
  - npc
  - acampamento
pdf_page: 63
---


# Kellen (Diretor K)

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=63|Consultar Texto Original no PDF (Página 63) — Perfil e Acolhimento]]**

O codiretor executivo do [[Acampamento Meio-Sangue]].

---

## Perfil e Personalidade
- Um gnomo diminuto e carismático, mago habilidoso, que conhece o nome de cada campista antes mesmo de eles se apresentarem.
- Todos no acampamento gostam de Kellen genuinamente. Ele senta no chão para conversar com os campistas de sete anos e vive oferecendo morangos frescos.
- **A Tensão Oculta:** Carrega uma exaustão acumulada que tenta disfarçar com piadas leves. Não dorme direito há semanas devido às anomalias da Noite.

---

## Em Combate e Crise
No [[Capítulo 4 - A Noite Mais Densa]], quando o vale é atacado, a máscara de diretor bem-humorado desaparece em frações de segundo: transforma-se em um guerreiro veloz, letal e sem qualquer hesitação.

---

## Falas Marcantes
- *"Come morango, vai. A gente tem morango sobrando e eu não sei mais o que fazer com aquilo."*
- *"Vou mandar arejar aquela ali de fora do U. Não é tua, ninguém disse que é tua. Mas hoje ela tá aberta, e eu prefiro que alguém durma dentro dela do que ela ficar aberta sozinha."* (Ao abrir a cabana preta para Hadesson).
- *"Se der errado, volta. Não conserta. Volta. Eu prefiro explicar um fracasso do que enterrar um sucesso."*

---

## Links Relacionados
- [[Acampamento Meio-Sangue]]
- [[Chalé 13 - A Cabana Preta (Hades)]]
- [[Hadesson Neto]]
- [[Capítulo 4 - A Noite Mais Densa]]
- [[🏠 Início]]
