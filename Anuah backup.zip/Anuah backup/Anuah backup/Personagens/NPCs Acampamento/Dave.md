---
tipo: Personagem
categoria: NPC Acampamento
tags:
  - npc
  - acampamento
pdf_page: 21
---


# Dave

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=21|Consultar Texto Original no PDF (Página 21) — A Regra do Dave e Ficha Secreta]]**

Filho de [[Chalé 10 - Afrodite|Afrodite]], membro honorário do Time Arrisco e o infiltrado mais perigoso da campanha.

---

## Ficha do Mestre (Tier 1 · Aliado Social)
*(Os jogadores enxergam apenas um aliado encantador e solícito).*
- **Dificuldade:** 14 | **PV:** 5 | **Estresse:** 5
- **Ações Aliadas:** *Carisma* (abre portas sociais fechadas), *Glamour* (faz mortais ignorarem o grupo), *Ilusão Pequena*.
- **Passiva:** Flerta e cativa a todos com simpatia genuína.
- **Segredo 1 - O Espelho de Atena:** Carrega oculto o [[O Espelho de Atena]], que denuncia qualquer mentira proferida na sua presença. Mentir para Dave nunca funciona.
- **Segredo 2 - Imune a Leituras:** A [[A Meia-Máscara de Pavão]] não consegue ler intenções de Dave, pois ele acredita piamente no que profere na hora em que fala.

---

## A Traição Perfeita
Dave não é um monstro maligno; é um converso da causa de [[A Noite e Nyx|Nyx]]. Ele acredita genuinamente que libertar os semideuses da manipulação dos deuses do Olimpo é um ato de misericórdia.
- No [[Capítulo 5 - A Estrada e o Pub]], salva heroicamente a vida de um jogador contra o [[Crocotta]], consolidando a confiança inabalável da mesa.
- No [[Capítulo 8 - A Ilha de Ninguém]], recebe em segredo a nefasta [[A Lâmina de Nyx]].
- No [[Capítulo 9 - A Fuga e o Preço]], acolhe o destroçado Bryan, manipulando o vácuo emocional deixado por Breno para garantir um peão cego para o Livro 2.

---

## Links Relacionados
- [[Chalé 10 - Afrodite]]
- [[O Espelho de Atena]]
- [[A Lâmina de Nyx]]
- [[Como a Noite Trabalha]]
- [[A Noite e Nyx]]
- [[🏠 Início]]
