---
tipo: Personagem
categoria: NPC Acampamento
tags:
  - npc
  - acampamento
pdf_page: 111
---


# Sebastian (Oráculo)

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=111|Consultar Texto Original no PDF (Página 111) — Aparição e Revelação do Oráculo]]**

O hospedeiro mortal do espírito do Oráculo de Delfos residente no sótão da Casa Grande.

---

## Características
- Ao contrário dos mitos tradicionais de múmias inertes, Sebastian é um homem mais velho, vivo, calmo e ligeiramente sarcástico.
- Desce do sótão sem avisar apenas quando os eventos atingem proporções catastróficas.
- Recita suas profecias com o mesmo tom informal de quem lê a previsão meteorológica no jornal matinal, apreciando o choque nas expressões dos campistas.

---

## As Profecias Proferidas no Livro 1
1. **[[A Grande Profecia]]:** Pronunciada sobre os cadáveres ensombrados que não viraram pó no pátio do acampamento.
2. **[[A Profecia da Missão]]:** Dita diretamente para Barak Armstrong na manhã da partida.

---

## Falas Marcantes
- *"Porque ficou interessante. Faz anos que não fica interessante."*
- *"Quem é o traidor? Alguém que chama vocês de amigo. Isso reduz bastante, não reduz?"*
- *"Eu vou morrer? Não hoje. Boa pergunta, aliás. Ninguém pergunta essa."*

---

## Links Relacionados
- [[A Grande Profecia]]
- [[A Profecia da Missão]]
- [[Barak Armstrong]]
- [[Capítulo 4 - A Noite Mais Densa]]
- [[🏠 Início]]
