---
tipo: Personagem
categoria: NPC Acampamento
tags:
  - npc
  - acampamento
pdf_page: 93
---


# Breno

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=93|Consultar Texto Original no PDF (Página 93) — Ficha, Confissão e Sacrifício]]**

O colosso silencioso do [[Chalé 5 - Ares]], irmão inseparável de [[Bryan]].

---

## Estatísticas de Combate (Tier 1 · Brutamonte)
- **Dificuldade:** 13 | **Limiares:** 9/16 | **PV:** 8 | **Estresse:** 3
- **Ataque:** +2 · Maça grande de bronze celestial · Corpo a corpo · 1d12+3 físico
- **Experiência:** *"Não sinto ainda"* +2
- **Passivas:** Reduz 3 de todo dano físico sofrido. Nunca ataca quem está caído.
- **Reação:** *Vai junto* — se Bryan for ferido ou insultado gravemente, Breno larga qualquer objetivo para intervir pelo irmão.

---

## O Coração do Personagem
- Fala muito pouco, mas com peso esmagador.
- Carrega o fardo do sacrifício de Édea em silêncio absoluto para poupar Bryan.
- No trem do [[Capítulo 5 - A Estrada e o Pub]], ele senta perto dos jogadores e avisa: *"Vocês são novos. Vão querer provar alguma coisa lá na frente. Não precisa. Eu já precisei. Não compensa."*

---

## O Sacrifício na Caverna (Capítulo 9)
No clímax da fuga na Ilha de Ninguém, Breno permanece do lado de fora da caverna para encaixar a laje de pedra e conter as hostes inimigas:
> *"Eu falei pra você não precisar provar nada. Eu preciso."*  
*(A pedra se fecha. A maça ressoa três vezes. Depois, o silêncio definitivo).*

---

## Links Relacionados
- [[Bryan]]
- [[Augusto]]
- [[Chalé 5 - Ares]]
- [[O Caso Édea]]
- [[Capítulo 5 - A Estrada e o Pub]]
- [[Capítulo 9 - A Fuga e o Preço]]
- [[🏠 Início]]
