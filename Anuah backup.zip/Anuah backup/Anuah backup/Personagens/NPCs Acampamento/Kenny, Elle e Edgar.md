---
tipo: Personagem
categoria: NPC Acampamento
tags:
  - npc
  - acampamento
pdf_page: 63
---


# Kenny, Elle e Edgar

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=63|Consultar Texto Original no PDF (Página 63) — Recepção e Despedida no Portão]]**

O trio inseparável do [[Acampamento Meio-Sangue]] que atua como âncora emocional dos personagens e símbolo do que precisa ser protegido.

---

## Kenny (Chalé 11 - Hermes)
- Vice-líder do Chalé 11. Alegre e expansivo até demais. Arrasta novatos para jogos bobos de bola no pátio (limpando Estresse).
- Recusa-se terminantemente a deixar o acampamento enquanto Elle permanecer lá dentro.
- Ao se despedir no portão, aperta a mão de cada um e diz uma única palavra solene: *"Volta."*

## Elle
- Amiga decidida e obstinada. Adota os recém-chegados instantaneamente: *"Tá decidido, vocês são meus amigos. Não precisa responder, eu já decidi."*
- Entrega [[Itens Menores e Bugigangas|Bip]], seu pássaro mecânico transmissor de recados, exigindo notícias da jornada.

## Edgar
- Observador silencioso que acompanha Kenny em todos os cantos.
- Percebe ferimentos e pavores antes de qualquer outro campista, oferecendo itens úteis de última hora sem esperar por agradecimentos.

> [!NOTE]
> Nenhum dos três participa de combates de campo fora do acampamento no Livro 1. Eles são a razão de os semideuses desejarem retornar com vida.

---

## Links Relacionados
- [[Chalé 11 - Hermes]]
- [[Capítulo 2 - A Chegada]]
- [[Capítulo 5 - A Estrada e o Pub]]
- [[Capítulo 9 - A Fuga e o Preço]]
- [[🏠 Início]]
