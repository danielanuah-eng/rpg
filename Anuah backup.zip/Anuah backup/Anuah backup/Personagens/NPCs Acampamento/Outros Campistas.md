---
tipo: Personagem
categoria: NPC Acampamento
tags:
  - npc
  - acampamento
pdf_page: 61
---


# Outros Campistas do Acampamento

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=61|Consultar Texto Original no PDF (Página 61) — Líderes e Vices dos Chalés]]**

Conselheiros e campistas de destaque que dão vida à rotina e aos serviços do acampamento.

---

## Tom Belff (Chalé 7 - Apolo)
- Líder atlético e vibrante do [[Chalé 7 - Apolo]]. Transita o dia inteiro entre as quadras esportivas e a enfermaria.
- Sempre convida os recém-chegados para jogar qualquer modalidade e comanda os cuidados médicos de emergência.

## Romeo e Demyra (Chalé 6 - Atena)
- **Romeo (Líder):** Passa as tardes sob o toldo externo, lendo tomos antigos. Empresta sua lupa mágica para investigações audaciosas.
- **Demyra (Vice):** Prancheta constante em punho no almoxarifado. Cadastra alergias, chalés e dados táticos de todos os campistas para futura utilização prática.

## Victor Goldffêch e Chris Forgjer (Chalé 9 - Hefesto)
- **Victor (Líder):** Nunca ergue os óculos de solda na forja. Afia bronze celestial gratuitamente para quem demonstrar que respeita a própria arma sabendo seu nome.
- **Chris (Vice):** Fala rápido demais e vive inventando engenhocas excêntricas, como [[Autômato de Treino|autômatos de treino]] e o bode mecânico Zé (que come pregos da oficina).

## Cristine e Myrthes (Chalé 12 - Dionísio)
- **Cristine (Líder):** Relaxa no alpendre coberto de parreiras do chalé, analisando os novatos com sagacidade debochada.
- **Myrthes (Vice):** Acompanha Cristine controlando os horários e tarefas dos companheiros de chalé.

## Daemon Hernandez e Thiago (Chalé 4 - Deméter)
- **Daemon (Líder):** Encontrado cuidando da horta medicinal atrás do refeitório. Rígido e prático nas orientações de sobrevivência natural.
- **Thiago (Vice):** Carrega no ombro um jackalope (coelho de chifres) de estimação chamado Herbert.

---

## Links Relacionados
- [[Acampamento Meio-Sangue]]
- [[Chalé 6 - Atena]]
- [[Chalé 7 - Apolo]]
- [[Chalé 9 - Hefesto]]
- [[Chalé 4 - Deméter]]
- [[Chalé 12 - Dionísio]]
- [[🏠 Início]]
