---
tipo: Hub
categoria: NPC Acampamento
tags:
  - npc
  - acampamento
  - hub
pdf_page: 63
---

# 🟢 NPCs do Acampamento Meio-Sangue

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=63|Consultar Texto Original no PDF (Página 63) — Figuras do Acampamento]]**

Os mentores, líderes de chalé e companheiros veteranos que vivem no vale de Long Island.

---

## Direção & Mentoria
- **[[Quíron]]:** Diretor de atividades, centauro e instrutor milenar.
- **[[Kellen (Diretor K)]]:** Codiretor gnomo e mago de imenso poder protetor.
- **[[Sebastian (Oráculo)]]:** Hospedeiro do Oráculo de Delfos residente no sótão.

## Liderança do Chalé 5 (Ares)
- **[[Augusto]]:** Líder de 10 anos, implacável no combate com mangual.
- **[[Bryan]]:** Vice-líder de língua afiada que afasta os outros com sarcasmo.
- **[[Breno]]:** Colosso protetor que carrega a dor do sacrifício em silêncio.

## O Aliado das Sombras
- **[[Dave]]:** Filho de Afrodite, sedutor carismático e infiltrado de Nyx.

## Estrategistas & Aliados
- **[[Fausto]]:** Mestre tático do Chalé de Atena e mentor dos novatos.
- **[[Kenny, Elle e Edgar]]:** Trio acolhedor do Chalé de Hermes e sustentação moral.
- **[[Outros Campistas]]:** Tom Belff (Apolo), Romeo e Demyra (Atena), Victor e Chris (Hefesto), Cristine e Myrthes (Dionísio), Daemon e Thiago (Deméter).

---
[[Acampamento Meio-Sangue]] · [[🏠 Início]]
