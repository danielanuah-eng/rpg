---
tipo: Personagem
categoria: NPC Acampamento
tags:
  - npc
  - acampamento
pdf_page: 92
---


# Bryan

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=92|Consultar Texto Original no PDF (Página 92) — Ficha e Condução de Bryan]]**

Vice-líder do [[Chalé 5 - Ares]] e irmão de sangue de [[Breno]].

---

## Estatísticas de Combate (Tier 1 · Oportunista)
- **Dificuldade:** 13 | **Limiares:** 5/10 | **PV:** 4 | **Estresse:** 5
- **Ataque:** +1 · Espada média · Corpo a corpo · 1d8+2 físico
- **Experiência:** *"Sei onde dói"* +3
- **Habilidade Chave:** *Fala primeiro* — ataca verbalmente a maior insegurança emocional do alvo (Presença/Conhecimento Dif. 15 para não hesitar e tomar 2 Estresse).
- **Passiva:** *Não é o irmão* — ao atingir metade dos PV, recua imediatamente chamando por Breno.

---

## Personalidade e Condução
- Usa sua agressividade verbal ruidosa e provocações ácidas como um escudo impenetrável para não deixar ninguém se aproximar.
- Vive sob a suspeita coletiva do acampamento de ter causado a morte de [[O Caso Édea|Édea]].
- **A Brecha de Bryan:** Cai por terra se alguém mencionar o nome de Édea com respeito sincero em vez de acusação. Ele se cala e abandona a cena.

---

## O Luto no Capítulo 9
No [[Capítulo 9 - A Fuga e o Preço]], após o sacrifício de Breno, Bryan entra em desespero catatônico, esmurrando árvores até que [[Dave]] o acolhe em um abraço frio e calculado.

---

## Links Relacionados
- [[Breno]]
- [[Augusto]]
- [[Chalé 5 - Ares]]
- [[O Caso Édea]]
- [[Dave]]
- [[Capítulo 9 - A Fuga e o Preço]]
- [[🏠 Início]]
