---
tipo: Personagem
categoria: Protagonista
tags:
  - protagonista
  - semideus
  - jogador
pdf_page: 4
---


# Hadesson Neto

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=4|Consultar Texto Original no PDF (Página 4) — Perfil do Personagem e Contagem do Silêncio]]**

- **Jogador:** Wilson (Soneto)
- **Parente Divino:** [[Chalé 13 - A Cabana Preta (Hades)|Hades]] *(Informação exclusiva do Mestre no início)*
- **Arma e Marca:** Adaga de bronze celestial, pingente de ampulheta.
- **Idade / Porte:** 12 anos, cerca de 1,40 m.

---

## O que o Jogador Quer da Mesa
Controle de combate, eficiência implacável, humor seco, sobrevivência prática. Entedia-se se ficar ocioso ou sem função tática.

---

## Condução pelo Mestre
- **Dê Comando:** Hadesson precisa de tarefas práticas na mesa: cronometrar o tempo, guardar a retaguarda, coordenar posições.
- **Não Reclamado no Livro 1:** Hades deliberadamente recusa-se a reivindicá-lo publicamente para protegê-lo do destino trágico dos Três Grandes. Isso deve ser trabalhado como uma ferida aberta durante toda a narrativa.
- **O Resgate de Cérbero:** No [[Capítulo 8 - A Ilha de Ninguém]], Hadesson tem a cena mais emocionante do livro: [[Cérbero]] recusa-se a ser libertado por força ou magia, cedendo apenas quando o filho de Hades oferece biscoitos com leite e o chama pelo nome.

---

## Citações e Interações Notáveis
- **Frase de Sebastian:** *"Repare em como sobra espaço no banco quando você senta. Já era assim antes daqui."*
- **Sussurro da Noite (Pseudologoi):** *"Você já esteve num lugar assim antes. Você só não lembra de ter voltado."*
- **Reação do Acampamento:** Os campistas o tratam com respeito excessivo e um distanciamento cauteloso. Quando ele senta, sobra espaço dos dois lados.

---

## Links Relacionados
- [[Chalé 13 - A Cabana Preta (Hades)]]
- [[Cérbero]]
- [[Reclamações Divinas]]
- [[Capítulo 2 - A Chegada]]
- [[Capítulo 8 - A Ilha de Ninguém]]
- [[🏠 Início]][[Protagonistas|Hub da Equipe]] · [[Barak Armstrong]] · [[Kira Andros]] · [[Daniel Storis]] · [[Igorovsky Baranyeisky]] · [[Ícaro Lyra]]

---
### Companheiros da Mesa dos Seis
[[Protagonistas|Hub da Equipe]] · [[Barak Armstrong]] · [[Kira Andros]] · [[Daniel Storis]] · [[Igorovsky Baranyeisky]] · [[Ícaro Lyra]]
