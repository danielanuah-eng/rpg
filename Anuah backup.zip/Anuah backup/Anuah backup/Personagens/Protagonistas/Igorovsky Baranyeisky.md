---
tipo: Personagem
categoria: Protagonista
tags:
  - protagonista
  - semideus
  - jogador
pdf_page: 4
---


# Igorovsky Baranyeisky

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=4|Consultar Texto Original no PDF (Página 4) — Perfil do Personagem e Reclamação]]**

- **Jogador:** Filipe
- **Parente Divino:** [[Chalé 6 - Atena|Atena]] *(Informação exclusiva do Mestre no início)*
- **Arma e Marca:** Alabarda, arco e flecha, fidget toys no bolso, caderno e lápis.
- **Idade / Porte:** 12 anos, cerca de 1,40 m.

---

## O que o Jogador Quer da Mesa
Puzzles lógicos, cálculos meticulosos, combate tático e cooperação em equipe. Não conhece mitologia grega na vida real.

---

## Condução pelo Mestre
- **Entrega de Informação:** Nunca penalize nem condescenda com a falta de repertório mitológico do jogador. Entregue os fatos mitológicos como conhecimento natural do semideus e deixe Igorovsky brilhar resolvendo os enigmas com lógica e estratégia.
- **Saídas Limpas vs. Sujas:** Todo enigma do livro tem uma solução lógica elegante e saídas improvisadas sujas. Deixe Igorovsky encontrar a solução limpa ou resmungar com charme caso os outros prefiram a força bruta.
- **Gatilho de Reclamação:** Solucionar publicamente uma armadilha perigosa (como descobrir o chamariz de [[Fausto]] no Cap. 3 ou decifrar o enigma dos espantalhos no Cap. 6). Atena se manifesta com uma coruja cinza perfeita desenhada no ar.

---

## Citações e Interações Notáveis
- **Frase de Sebastian:** *"Você conta as coisas em voz baixa. Nem sempre são coisas que dá pra contar."*
- **Sussurro da Noite (Pseudologoi):** *"Nenhuma das suas contas explica por que você gosta deles."*

---

## Links Relacionados
- [[Chalé 6 - Atena]]
- [[Fausto]]
- [[Reclamações Divinas]]
- [[Capítulo 3 - O Pega-Bandeira]]
- [[Capítulo 6 - O Parque Aquático Nostos]]
- [[🏠 Início]][[Protagonistas|Hub da Equipe]] · [[Barak Armstrong]] · [[Kira Andros]] · [[Daniel Storis]] · [[Ícaro Lyra]] · [[Hadesson Neto]]

---
### Companheiros da Mesa dos Seis
[[Protagonistas|Hub da Equipe]] · [[Barak Armstrong]] · [[Kira Andros]] · [[Daniel Storis]] · [[Ícaro Lyra]] · [[Hadesson Neto]]
