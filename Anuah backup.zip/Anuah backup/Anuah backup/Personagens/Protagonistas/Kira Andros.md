---
tipo: Personagem
categoria: Protagonista
tags:
  - protagonista
  - semideus
  - jogador
pdf_page: 3
---


# Kira Andros

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=3|Consultar Texto Original no PDF (Página 3) — Perfil da Personagem e Liderança]]**

- **Jogadora:** Alessa
- **Parente Divino:** [[Chalé 5 - Ares|Ares]]
- **Arma e Marca:** Espada de bronze celestial, pulseira-escudo que se regenera.
- **Idade / Porte:** 12 anos, cerca de 1,40 m. Já é campista veterana há alguns meses.

---

## O que a Jogadora Quer da Mesa
Liderar a equipe, desvendar mistérios, confrontar monstros diretamente, demonstrar força e determinação. Cabeça quente, porém com juízo e disciplina tática.

---

## Condução pelo Mestre
- **A Veterana da Turma:** Entra formalmente no [[Capítulo 2 - A Chegada]] já sabendo de tudo o que os novatos desconhecem. Ela é a única que já foi reclamada por seu pai. Durante uma sessão inteira, ela assume o papel de explicar o mundo.
  > [!TIP]
  > Deixe Kira explicar algo errado ao menos uma vez para reforçar que o acampamento é antigo demais para qualquer recruta dominar totalmente.
- **A Porta Aberta para Augusto:** Kira é a única que pode construir uma ponte genuína com [[Augusto]]. Se Alessa investir na relação fraterna, Augusto deixará de tratá-la como simples recruta para vê-la como uma irmã mais velha confiável.
- **O Fio Longo com os Irmãos:** No [[Capítulo 5 - A Estrada e o Pub]], [[Breno]] procura Kira em segredo no hotel para pedir que ela cuide de [[Bryan]], um pacto que ganha peso avassalador no [[Capítulo 9 - A Fuga e o Preço]].

---

## Citações e Interações Notáveis
- **Frase de Sebastian:** *"Te mandaram esperar na cerca porque é a única tarefa em que você não pode bater em ninguém."*
- **Sussurro da Noite (Pseudologoi):** *"Você não foi embora de casa. Você foi mandada."*

---

## Links Relacionados
- [[Chalé 5 - Ares]]
- [[Augusto]]
- [[Bryan]]
- [[Breno]]
- [[O Caso Édea]]
- [[Capítulo 2 - A Chegada]]
- [[🏠 Início]][[Protagonistas|Hub da Equipe]] · [[Barak Armstrong]] · [[Daniel Storis]] · [[Igorovsky Baranyeisky]] · [[Ícaro Lyra]] · [[Hadesson Neto]]

---
### Companheiros da Mesa dos Seis
[[Protagonistas|Hub da Equipe]] · [[Barak Armstrong]] · [[Daniel Storis]] · [[Igorovsky Baranyeisky]] · [[Ícaro Lyra]] · [[Hadesson Neto]]
