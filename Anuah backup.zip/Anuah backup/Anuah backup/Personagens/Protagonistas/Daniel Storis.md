---
tipo: Personagem
categoria: Protagonista
tags:
  - protagonista
  - semideus
  - jogador
pdf_page: 4
---


# Daniel Storis

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=4|Consultar Texto Original no PDF (Página 4) — Perfil do Personagem e Reclamação]]**

- **Jogador:** LG
- **Parente Divino:** [[Chalé 5 - Ares|Ares]] *(Informação exclusiva do Mestre no início)*
- **Arma e Marca:** Lança de combate, pistola de airsoft na mochila.
- **Idade / Porte:** 12 anos, cerca de 1,40 m.

---

## O que o Jogador Quer da Mesa
Comédia física, caos, soluções absurdas, chamar atenção o tempo todo. Covarde na atitude cotidiana, porém suicida nas ações da ficha mecânica.

---

## Condução pelo Mestre
- **Consequências Engraçadas:** Em toda cena, tenha engatilhada uma consequência cômica, cara e não letal para as ideias absurdas de Daniel.
- **O Arco do Livro 1:** Descobrir que medo genuíno e coragem indomável coexistem no mesmo peito.
- **Gatilho de Reclamação:** Encarar algo colossal de frente e se recusar a correr. Se aceitar o duelo contra [[Augusto]] no [[Capítulo 3 - O Pega-Bandeira]] ou proteger um campista no [[Capítulo 4 - A Noite Mais Densa]], uma lança e um javali vermelho acendem sobre sua cabeça.

---

## Citações e Interações Notáveis
- **Frase de Sebastian:** *"Você fala alto no lugar errado pra ninguém reparar quando você fica quieto."*
- **Sussurro da Noite (Pseudologoi):** *"Todo mundo ri. Ninguém chama você quando é sério."*
- **Fuga do Capítulo 9:** No clímax da caverna, a perda de Breno atinge Daniel com força crua. Se fizer piada nesse momento, não permita risadas na mesa: é seu mecanismo de defesa contra o pavor.

---

## Links Relacionados
- [[Chalé 5 - Ares]]
- [[Augusto]]
- [[Reclamações Divinas]]
- [[Capítulo 3 - O Pega-Bandeira]]
- [[Capítulo 4 - A Noite Mais Densa]]
- [[🏠 Início]][[Protagonistas|Hub da Equipe]] · [[Barak Armstrong]] · [[Kira Andros]] · [[Igorovsky Baranyeisky]] · [[Ícaro Lyra]] · [[Hadesson Neto]]

---
### Companheiros da Mesa dos Seis
[[Protagonistas|Hub da Equipe]] · [[Barak Armstrong]] · [[Kira Andros]] · [[Igorovsky Baranyeisky]] · [[Ícaro Lyra]] · [[Hadesson Neto]]
