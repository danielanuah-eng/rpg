---
tipo: Personagem
categoria: Protagonista
tags:
  - protagonista
  - semideus
  - jogador
pdf_page: 4
---


# Ícaro Lyra

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=4|Consultar Texto Original no PDF (Página 4) — Perfil do Personagem e Reclamação]]**

- **Jogador:** Lucas
- **Parente Divino:** [[Chalé 7 - Apolo|Apolo]] *(Informação exclusiva do Mestre no início)*
- **Arma e Marca:** Arco de bronze celestial, skate debaixo do braço, Prisma de Asclépio.
- **Idade / Porte:** 12 anos, cerca de 1,40 m.

---

## O que o Jogador Quer da Mesa
Enigmas poéticos, referências mitológicas, dialogar com adversários e NPCs antes de puxar armas, descobrir o lado oculto de cada criatura. Detesta receber ordens autoritárias.

---

## Condução pelo Mestre
- **Diálogo com Monstros:** Deixe Ícaro tentar conversar. Metade dos monstros do livro tem brechas para negociação cordial; a outra metade pertence aos olhos pretos do Breu.
- **A Válvula de Cura:** Ícaro é naturalmente atraído a aliviar a dor alheia, carregando ataduras e bálsamos para todos.
- **Gatilho de Reclamação:** Ocorre quando ele cuida de um ferido esquecendo-se da própria segurança (como na enfermaria no Cap. 4 ou com [[Dave]] no Cap. 5). O sol e a lira acendem e todas as melodias próximas se afinam num uníssono sublime.

---

## Citações e Interações Notáveis
- **Frase de Sebastian:** *"Você carrega bandagem pra todo mundo e nenhuma do seu tamanho."*
- **Sussurro da Noite (Pseudologoi):** *"Você sabe consertar gente. Não sabe consertar isso."*

---

## Links Relacionados
- [[Chalé 7 - Apolo]]
- [[Reclamações Divinas]]
- [[Capítulo 4 - A Noite Mais Densa]]
- [[Capítulo 5 - A Estrada e o Pub]]
- [[🏠 Início]][[Protagonistas|Hub da Equipe]] · [[Barak Armstrong]] · [[Kira Andros]] · [[Daniel Storis]] · [[Igorovsky Baranyeisky]] · [[Hadesson Neto]]

---
### Companheiros da Mesa dos Seis
[[Protagonistas|Hub da Equipe]] · [[Barak Armstrong]] · [[Kira Andros]] · [[Daniel Storis]] · [[Igorovsky Baranyeisky]] · [[Hadesson Neto]]
