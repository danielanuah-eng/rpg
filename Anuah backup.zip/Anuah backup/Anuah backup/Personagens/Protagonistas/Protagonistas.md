---
tipo: Hub
categoria: Protagonista
tags:
  - protagonista
  - semideus
  - hub
pdf_page: 3
---

# 🔵 A Mesa dos Seis (Protagonistas)

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=3|Consultar Texto Original no PDF (Página 3) — Os Seis Semideuses]]**

Os seis semideuses de 12 anos que protagonizam a campanha *A Noite Mais Densa*.

---

## Os Heróis da Mesa

- **[[Barak Armstrong]]:** Filho de Zeus · O Escolhido e dono do holofote.
- **[[Kira Andros]]:** Filha de Ares · A veterana e líder do grupo.
- **[[Daniel Storis]]:** Filho de Ares · O caos e a descoberta da coragem.
- **[[Igorovsky Baranyeisky]]:** Filho de Atena · A mente analítica e tática.
- **[[Ícaro Lyra]]:** Filho de Apolo · O curandeiro, artista e diplomata.
- **[[Hadesson Neto]]:** Filho de Hades · O silêncio do submundo e o resgate de Cérbero.

---
[[🏠 Início|⬅ Retornar ao Início]]
