---
tipo: Personagem
categoria: Protagonista
tags:
  - protagonista
  - semideus
  - jogador
pdf_page: 3
---


# Barak Armstrong

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=3|Consultar Texto Original no PDF (Página 3) — Perfil do Personagem e Reclamação]]**

- **Jogador:** Caio
- **Parente Divino:** [[Chalé 1 - Zeus|Zeus]] *(Informação exclusiva do Mestre no início)*
- **Arma e Marca:** Arma que alterna de forma, canivete no bolso, baralho de bar.
- **Idade / Porte:** 12 anos, cerca de 1,40 m.

---

## O que o Jogador Quer da Mesa
Holofote, frases épicas, narrativa de escolhido, provar o seu valor perante todos. Não tolera ser afrontado. Foge estrategicamente quando a maré vira desfavorável.

---

## Condução pelo Mestre
- **A Lâmina-Chave:** No [[Capítulo 1 - O Museu das Maravilhas]], a [[A Lâmina-Chave]] vai parar na mão dele. Ser o portador do item mais perigoso do museu é um holofote que traz consigo uma fatura alta.
- **Fuga:** Quando Barak fugir de uma situação de perigo, não o puna. Deixe funcionar, e faça alguém do acampamento reparar em silêncio. A mesa constrói o personagem muito melhor do que o castigo direto.
- **O Cheiro Divino:** Por ser filho de um dos Três Grandes, Barak emite o cheiro mais forte do grupo, atraindo feras ancestrais como [[Lélape]].
- **A Reclamação:** É o único semideus com data marcada: Zeus o reclama no encerramento do [[Capítulo 2 - A Chegada]], perante trezentos campistas na fogueira central, com um raio azul-branco cujo trovão chega antes do relâmpago.

---

## Citações e Interações Notáveis
- **Frase de Sebastian:** *"Você embaralha com uma mão só porque a outra fica livre pra ir embora."*
- **Sussurro da Noite (Pseudologoi):** *"Seu pai viu você chegar. Não fez nada. Ele só viu."*
- **Relação com Augusto:** No [[Capítulo 3 - O Pega-Bandeira]], [[Augusto]] respeita o raio de Barak como um general respeita artilharia e o convida pessoalmente para o time do Chalé 5.

---

## Links Relacionados
- [[Chalé 1 - Zeus]]
- [[A Lâmina-Chave]]
- [[Reclamações Divinas]]
- [[Capítulo 1 - O Museu das Maravilhas]]
- [[Capítulo 2 - A Chegada]]
- [[Capítulo 3 - O Pega-Bandeira]]
- [[🏠 Início]][[Protagonistas|Hub da Equipe]] · [[Kira Andros]] · [[Daniel Storis]] · [[Igorovsky Baranyeisky]] · [[Ícaro Lyra]] · [[Hadesson Neto]]

---
### Companheiros da Mesa dos Seis
[[Protagonistas|Hub da Equipe]] · [[Kira Andros]] · [[Daniel Storis]] · [[Igorovsky Baranyeisky]] · [[Ícaro Lyra]] · [[Hadesson Neto]]
