---
tipo: Personagem
categoria: NPC do Mundo
tags:
  - npc
  - mundo
pdf_page: 128
---


# Margaux Vine

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=128|Consultar Texto Original no PDF (Página 128) — Hotel Ambrósia e Negociação]]**

Filha de Dionísio e gerente do lendário **Hotel Ambrósia** em Manhattan.

---

## Perfil e Função
- Veste roupas impecáveis e exibe a expressão clássica de tédio aristocrático herdada de seu pai divino.
- Atende no balcão do lobby do hotel. Cordial, inabalável e estritamente comercial: só entrega a senha da passagem marítima para quem pernoitar no hotel a cinco dracmas de ouro por cabeça.
- **O Guardanapo de Margaux:** Se os semideuses resistirem às tentações da [[Capítulo 5 - A Estrada e o Pub|Contagem do Conforto]] e saírem no horário, ela admira a disciplina do grupo e lhes entrega um guardanapo com dicas cruciais sobre a maré e o parque Nostos:
  > *"NOSTOS — Asbury Park. Procure o rapaz do turno da tarde, não o da noite. A maré vira 23h40. Não desçam de tobogã. — M."*

---

## Falas Marcantes
- *"Cinco dracmas por cabeça, uma noite, e a senha é de vocês. Não é armadilha. É preço."*
- *"Todo mundo acha que vai embora de manhã. Eu trabalho aqui há seis anos."*
- *"Vocês são chatos. Eu gosto."*

---

## Links Relacionados
- [[Capítulo 5 - A Estrada e o Pub]]
- [[Deuses Presentes]]
- [[Itens Menores e Bugigangas]]
- [[🏠 Início]]
