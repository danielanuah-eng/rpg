---
tipo: Hub
categoria: NPC do Mundo
tags:
  - npc
  - mundo
  - hub
pdf_page: 22
---

# 🟡 NPCs do Mundo Mortal & Forças Divinas

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=22|Consultar Texto Original no PDF (Página 22) — Encontros Fora do Acampamento]]**

Mestres disfarçados, anfitriões de além-mar e deuses imortais que cruzam a jornada dos semideuses.

---

## No Mundo Mortal (Nova York)
- **[[Professor Fujiho]]:** Professor de História e elemental de vento protetor de Barak.
- **[[Fujiro]]:** Monitor sátiro com muletas e faro aguçado.
- **[[Sr. Morelo (Mormo)]]:** Curador do museu que conta as crianças com juntas extras.
- **[[Margaux Vine]]:** Gerente do Hotel Ambrósia e negociante de senhas marítimas.

## No Mar de Monstros & Além
- **[[Kyla Nestor (Cila)]]:** Gerente do parque Nostos e serpente marinha de seis cabeças.
- **[[Polifemo]]:** Ciclope hospedeiro da Pousada do Ninguém e pastor de carneiros.

## As Divindades Supremas
- **[[Deuses Presentes]]:** Héstia (a menina da fogueira), Dionísio (o atendente do pub), Atena, Hades, Zeus, Hera e Poseidon.

---
[[🏠 Início|⬅ Retornar ao Início]]
