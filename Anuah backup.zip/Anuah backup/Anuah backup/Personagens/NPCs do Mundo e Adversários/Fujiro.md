---
tipo: Personagem
categoria: NPC do Mundo
tags:
  - npc
  - mundo
pdf_page: 33
---


# Fujiro

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=33|Consultar Texto Original no PDF (Página 33) — Perfil do Monitor Sátiro]]**

- **Ocupação Mortal:** Monitor do ônibus escolar no passeio ao museu.
- **Natureza Sobrenatural:** Sátiro farejador de semideuses disfarçado de jovem com muletas, boné e calças largas.
- **Comportamento:** Passa a viagem inteira farejando o ar discretamente a cada dez minutos, suando frio ao notar cinco cheiros poderosos concentrados no mesmo veículo.
- Ao fim do [[Capítulo 1 - O Museu das Maravilhas]], retira o boné acanhado perante Quíron e entrega um número de telefone anotado num papel de bala (que ele mesmo avisa que não funciona).

---

## Links Relacionados
- [[Quíron]]
- [[Cheiro Névoa e Disfarce]]
- [[Capítulo 1 - O Museu das Maravilhas]]
- [[🏠 Início]]
