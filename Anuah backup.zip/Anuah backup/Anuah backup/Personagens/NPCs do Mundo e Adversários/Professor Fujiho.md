---
tipo: Personagem
categoria: NPC do Mundo
tags:
  - npc
  - mundo
pdf_page: 33
---


# Professor Fujiho

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=33|Consultar Texto Original no PDF (Página 33) — Ficha e Papel de Fujiho]]**

- **Ocupação Mortal:** Professor de História do colégio dos semideuses.
- **Natureza Sobrenatural:** Elemental de Vento (Aliado Tier 1) enviado para vigiar e proteger [[Barak Armstrong|Barak]].
- **Aparência:** Idoso chinês de traços esculpidos como pedra castigada pelo vento. Monótono, sereno, sempre com um leque de papel e uma pasta de couro. Não sua nem sob calor escaldante de 34 graus.

---

## Atuação no Capítulo 1
- Se Barak sumir de seu campo de visão por mais de um minuto, Fujiho muda de lugar sem emitir um único ruído.
- Quando [[Lélape]] acorda no museu, o professor intervém empunhando o leque de papel: abre rajadas tempestuosas que retêm a fera por três rodadas e permite a fuga das crianças pela porta dos fundos.
- **Desfecho:** Permanece no museu para segurar a retaguarda. Na semana seguinte, a escola mortal apenas informa que ele se aposentou sem deixar telefone de contato.

---

## Links Relacionados
- [[Barak Armstrong]]
- [[Lélape]]
- [[Capítulo 1 - O Museu das Maravilhas]]
- [[🏠 Início]]
