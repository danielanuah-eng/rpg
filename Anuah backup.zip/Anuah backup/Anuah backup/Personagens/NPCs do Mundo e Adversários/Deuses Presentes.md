---
tipo: Personagem
categoria: NPC do Mundo
tags:
  - npc
  - mundo
pdf_page: 22
---


# Deuses Presentes

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=22|Consultar Texto Original no PDF (Página 22) — Rivalidades e Manifestações Divinas]]**

A chave riordana da narrativa: **nenhum deus explica, nenhum agradece e nenhum chega a tempo**. Eles surgem como um parente rico excêntrico: de repente, sem aviso prévio, deixando um presente bizarro e uma dívida emocional pesada.

---

## 1. Héstia (A Menina da Fogueira)
- **Onde aparece:** Na fogueira central do acampamento ([[Capítulo 2 - A Chegada|Cap. 2]], [[Capítulo 4 - A Noite Mais Densa|Cap. 4]]).
- **Como se manifesta:** Uma garotinha de cerca de oito anos mexendo cinzas baixas com um graveto de madeira.
- **O que deixa:** A relíquia [[A Brasa da Casa]], entregue a quem demonstrou bravura para proteger os outros sem se gabar. Ninguém no acampamento consegue se lembrar dela após sair da fogueira.

## 2. Dionísio (Sr. D)
- **Onde aparece:** Atrás do balcão do pub subterrâneo *A Vinha Tardia* em Nova York ([[Capítulo 5 - A Estrada e o Pub|Cap. 5]]).
- **Como se manifesta:** Camisa havaiana berrante, servindo apenas suco de uva e reclamando da pena de serviço comunitário imposta por Zeus.
- **O que deixa:** Os seis [[Espantalhos de Palha]], entregues com má vontade e sarcasmo como descarte de estoque.

## 3. Atena
- **Onde aparece:** Nunca em pessoa física; manifesta-se através do olhar calculista da coruja de bronze, em sonhos e na mente de seus filhos.
- **O que deixa:** A dúvida inquietante se o acampamento está verdadeiramente seguro e a concessão de lampejos de dedução lógica.

## 4. Hades
- **Onde aparece:** Nunca diretamente. Mantém silêncio absoluto.
- **O que deixa:** A autorização oculta para abertura da Cabana Preta para [[Hadesson Neto|Hadesson]] e o fato chocante de que [[Cérbero]] já conhecia o nome do semideus antes de qualquer palavra ser dita.

## 5. Hera
- **Onde aparece:** Nunca.
- **O que deixa:** O Chalé 2 permanentemente impecável, limpo, luxuoso e vazio.

## 6. Zeus
- **Onde aparece:** Nunca em pessoa física.
- **Como se manifesta:** Noticiários sobre tempestades elétricas anormais e o canal oficial de notícias dele em todas as TVs de bar. Manifesta-se no raio imponente sobre a cabeça de [[Barak Armstrong|Barak]].

## 7. Poseidon
- **Onde aparece:** Nunca.
- **O que deixa:** O mar calmo demais no [[Capítulo 7 - O Mar]], que subitamente se rebela na bocarra de [[Caríbdis]].

---

## Links Relacionados
- [[Reclamações Divinas]]
- [[Rivalidades Divinas]]
- [[A Brasa da Casa]]
- [[Espantalhos de Palha]]
- [[🏠 Início]]
