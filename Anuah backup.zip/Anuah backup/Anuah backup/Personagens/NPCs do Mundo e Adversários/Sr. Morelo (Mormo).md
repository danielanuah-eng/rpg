---
tipo: Personagem
categoria: NPC do Mundo
tags:
  - npc
  - mundo
pdf_page: 35
---


# Sr. Morelo (Mormo)

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=35|Consultar Texto Original no PDF (Página 35) — Cena e Tique do Bicho-Papão]]**

O curador do turno da noite do Museu das Maravilhas de Nova York e um dos predadores gregos mais astutos e antigos em atividade.

---

## Disfarce Mortal
Um senhor idoso e afável de terno de tweed com cotoveleiras de couro, chaveiro giratório no dedo e piadas ruins inofensivas. Sabe o nome de cada estudante e oferece doces de coração aberto.

---

## Identidade Verdadeira: Mormo (O Bicho-Papão)
Mormo descobriu há séculos que não precisa caçar ou assustar crianças: basta ser o adulto amigável e atencioso que sabe onde fica o banheiro e a saída.
- **O Tique Revelador:** Conta as crianças apontando o indicador em voz baixa e, ao terminar, reconta novamente obtendo um número diferente.
- **A Junta Extra:** Estende a mão para guiar crianças isoladas; sua mão é gélida e possui uma articulação óssea a mais em cada dedo.
- **Objetivo no Museu:** Isolar uma criança do grupo para levá-la aos fundos sem derramamento de sangue público.

---

## Falas Marcantes
- *"Regras: Primeira, não corram. Segunda, não toquem. Terceira: se forem tocar mesmo assim, não toquem no que tem corda de veludo na frente."*
- *"Já veio turma aqui com professor que não contava as crianças na saída. Eu conto."*
- *"Cê tá sozinho? Criança sozinha me dá aflição, sério."*

---

## Links Relacionados
- [[Mormo]]
- [[Cheiro Névoa e Disfarce]]
- [[Capítulo 1 - O Museu das Maravilhas]]
- [[🏠 Início]]
