---
tipo: Personagem
categoria: NPC do Mundo
tags:
  - npc
  - mundo
pdf_page: 183
---


# Polifemo

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=183|Consultar Texto Original no PDF (Página 183) — Pousada e Ficha do Ciclope]]**

O lendário ciclope pastor da Odisseia, agora dono e anfitrião da **Pousada do Ninguém** na Ilha de Ninguém ([[Capítulo 8 - A Ilha de Ninguém]]).

---

## Perfil (Tier 2 · Solo)
- **Dificuldade:** 16 | **Limiares:** 12/24 | **PV:** 10 | **Estresse:** 6
- **Aparência:** Um ciclope colossal do tamanho de dois cavalos usando um avental de cozinha encardido, limpando as mãos num pano de prato e exibindo um sorriso sincero e hospitaleiro.
- **Personalidade:** Polifemo leva o comércio de hotelaria e a hospitalidade extremamente a sério. Ele genuinamente adora receber hóspedes, cozinhar ensopados deliciosos e servir seu queijo artesanal e o famoso "Vinho Ninguém".
- **O Ponto Cego:** Por possuir um único olho, tem um ponto cego real explorável em movimentação furtiva (Instinto Dif. 15).

---

## O Conflito Trágico
- Polifemo não é contratado por crueldade; ele apenas alugou a cela dos fundos para os aliados de Nyx e alimenta o prisioneiro ([[Cérbero]]) com leite fresco diariamente.
- **A Regra de Polifemo:** Ele nunca mata crianças. Mesmo durante o confronto no cais com o armazém em chamas, ele apenas derruba, bloqueia e lamenta a ingratidão dos jovens:
  > *"VOCÊS NEM PAGARAM O QUARTO!"*

---

## Links Relacionados
- [[Cérbero]]
- [[Capítulo 8 - A Ilha de Ninguém]]
- [[Capítulo 9 - A Fuga e o Preço]]
- [[🏠 Início]]
