---
tipo: Personagem
categoria: NPC do Mundo
tags:
  - npc
  - mundo
pdf_page: 144
---


# Kyla Nestor (Cila)

> [!INFO] Fonte no PDF Original
> 📖 **[[A-Noite-Mais-Densa-Livro-1.pdf#page=144|Consultar Texto Original no PDF (Página 144) — Cila no Parque Aquático Nostos]]**

A gerente de atendimento ao cliente do decrépito parque aquático **Nostos** em Asbury Park.

---

## Identidade e Comportamento
- Uma funcionária de uniforme polo com sorriso corporativo congelado, prancheta e crachá.
- **A Verdade Monstruosa:** Kyla é **Cila**, o monstro marinho de seis cabeças da Odisseia, estabelecida na foz do canal de acesso ao Mar de Monstros.
- **O Tique Revelador:** Kyla **nunca se vira de costas** para ninguém; anda de lado e contorna portas de perfil.
- **Os Seis Tobogãs:** Os seis grandes tobogãs d'água da atração principal do parque são suas próprias cabeças adormecidas sob a ilusão da Névoa.

---

## O Encontro na Garganta
No túnel submerso (*A Viagem do Retorno*), Cila exige seu tributo histórico de seis itens/sacrifícios de valor emocional para permitir a passagem:
- Ela não pode ser morta ou ferida por armas normais.
- Aceita ser distraída se cada uma das seis cabeças receber um [[Espantalhos de Palha|espantalho mágico]] aceso doado por Dionísio.
- Se cobrarem o preço em âncoras pessoais, a perda é irreversível para a campanha inteira.

---

## Links Relacionados
- [[Caríbdis]]
- [[Espantalhos de Palha]]
- [[Capítulo 6 - O Parque Aquático Nostos]]
- [[🏠 Início]]
