---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/fixa
  - fabrica/catedral
nivel: 1
fabrica: Fundição Catedral
custo_estresse: 0
pdf_page: 38
jogo: O Peso do Céu
---

# Brasão

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=38|Consultar Texto Original no PDF (Página 38) — Peça Brasão (Fundição Catedral)]]**

*Nível 1 · Fixa · sempre ligada · [[Fundição Catedral]]*

---

Enquanto você estiver de pé e visível, todo aliado em Perto tem **+1** de Evasão.

---

## Links Relacionados
- [[Fundição Catedral]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
