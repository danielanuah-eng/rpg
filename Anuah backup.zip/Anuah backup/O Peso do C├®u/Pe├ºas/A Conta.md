---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/tensa
  - fabrica/carvao
nivel: 9
fabrica: Carvão
custo_estresse: 6
pdf_page: 47
jogo: O Peso do Céu
---

# A Conta

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=47|Consultar Texto Original no PDF (Página 47) — Peça A Conta (Carvão)]]**

*Nível 9 · Tensa · liga com 6+ de Medo na mesa · [[Carvão]]*

---

Enquanto ligada, uma vez por cena, um adversário de Escalão inferior ao seu descobre que te deve alguma coisa e passa a agir do seu lado até o fim da cena.

> [!WARNING] Peça Tensa
> Não custa nada, mas só funciona enquanto o Mestre tiver **6 ou mais de Medo**. Ele não pode gastar Medo só para desligar a Peça — mas se o gasto tem efeito na ficção, ela apaga junto. Ver [[O Medo]].

---

## Links Relacionados
- [[Carvão]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
