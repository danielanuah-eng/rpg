---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/selo
nivel: 6
fabrica: Selo Civil
custo_estresse: 1
pdf_page: 45
jogo: O Peso do Céu
---

# Triangulação

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=45|Consultar Texto Original no PDF (Página 45) — Peça Triangulação (Selo Civil)]]**

*Nível 6 · Ativa · 1 Estresse · [[Selo Civil]]*

---

Marque um alvo pelo satélite. Você sabe onde ele está pelo resto da sessão, em qualquer lugar do mapa, e ele não consegue se esconder de você numa cena.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **1 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Selo Civil]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
