---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/carvao
nivel: 1
fabrica: Carvão
custo_estresse: 1
pdf_page: 46
jogo: O Peso do Céu
---

# Carga de Fenda

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=46|Consultar Texto Original no PDF (Página 46) — Peça Carga de Fenda (Carvão)]]**

*Nível 1 · Ativa · 1 Estresse · [[Carvão]]*

---

Plante uma carga em um alvo em Corpo a corpo. Ela estoura na sua próxima ação: `4d10`, ignorando Blindagem. Duas por sortida.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **1 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Carvão]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
