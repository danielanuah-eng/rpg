---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/fixa
  - fabrica/brasa
nivel: 3
fabrica: Companhia Brasa e Filhos
custo_estresse: 0
pdf_page: 35
jogo: O Peso do Céu
---

# Braço de Carga

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=35|Consultar Texto Original no PDF (Página 35) — Peça Braço de Carga (Companhia Brasa e Filhos)]]**

*Nível 3 · Fixa · sempre ligada · [[Companhia Brasa e Filhos]]*

---

Você carrega o que quiser: um colosso inerte, um vagão, um pedaço de parede. Nada disso atrapalha o seu movimento.

---

## Links Relacionados
- [[Companhia Brasa e Filhos]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
