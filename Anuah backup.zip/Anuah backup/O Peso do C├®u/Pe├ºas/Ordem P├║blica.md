---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/fixa
  - fabrica/selo
nivel: 7
fabrica: Selo Civil
custo_estresse: 0
pdf_page: 45
jogo: O Peso do Céu
---

# Ordem Pública

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=45|Consultar Texto Original no PDF (Página 45) — Peça Ordem Pública (Selo Civil)]]**

*Nível 7 · Fixa · sempre ligada · [[Selo Civil]]*

---

Enquanto você estiver de pé e visível, o Mestre paga **+1 Medo** para fazer um adversário agir fora da vez dele.

---

## Links Relacionados
- [[Selo Civil]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
