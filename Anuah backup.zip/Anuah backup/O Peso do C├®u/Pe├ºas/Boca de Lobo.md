---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/carvao
nivel: 5
fabrica: Carvão
custo_estresse: 2
pdf_page: 46
jogo: O Peso do Céu
---

# Boca de Lobo

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=46|Consultar Texto Original no PDF (Página 46) — Peça Boca de Lobo (Carvão)]]**

*Nível 5 · Ativa · 2 Estresse · [[Carvão]]*

---

Prepare uma armadilha num lugar. O primeiro adversário que entrar nele sofre `4d10` e fica **Restrito**.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **2 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Carvão]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
