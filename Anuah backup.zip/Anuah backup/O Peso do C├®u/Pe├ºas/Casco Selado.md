---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/fixa
  - fabrica/arco
nivel: 1
fabrica: Estaleiros do Arco
custo_estresse: 0
pdf_page: 40
jogo: O Peso do Céu
---

# Casco Selado

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=40|Consultar Texto Original no PDF (Página 40) — Peça Casco Selado (Estaleiros do Arco)]]**

*Nível 1 · Fixa · sempre ligada · [[Estaleiros do Arco]]*

---

Água, pressão, vácuo, gás e fumaça não te afetam, em nenhuma profundidade e por tempo nenhum.

---

## Links Relacionados
- [[Estaleiros do Arco]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
