---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/fixa
  - fabrica/arco
nivel: 2
fabrica: Estaleiros do Arco
custo_estresse: 0
pdf_page: 22
jogo: O Peso do Céu
---

# Sonar

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=22|Consultar Texto Original no PDF (Página 22) — Peça Sonar (Estaleiros do Arco)]]**

*Nível 2 · Fixa · sempre ligada · [[Estaleiros do Arco]]*

---

Você sabe o que existe em cada direção até Muito Longe, mesmo sem ver — e tudo que tiver ouvido também sabe que você está olhando.

---

## Links Relacionados
- [[Estaleiros do Arco]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
