---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/gralha
nivel: 5
fabrica: Oficinas Gralha
custo_estresse: 1
pdf_page: 43
jogo: O Peso do Céu
---

# Areia no Motor

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=43|Consultar Texto Original no PDF (Página 43) — Peça Areia no Motor (Oficinas Gralha)]]**

*Nível 5 · Ativa · 1 Estresse · [[Oficinas Gralha]]*

---

Role **Conhecimento** contra a Evasão de um alvo. Se acertar, uma Peça instalada dele desliga até o fim da cena.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **1 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Oficinas Gralha]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
