---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/fixa
  - fabrica/carvao
nivel: 2
fabrica: Carvão
custo_estresse: 0
pdf_page: 46
jogo: O Peso do Céu
---

# Gancho Sujo

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=46|Consultar Texto Original no PDF (Página 46) — Peça Gancho Sujo (Carvão)]]**

*Nível 2 · Fixa · sempre ligada · [[Carvão]]*

---

Seus ataques contra alvos **Vulneráveis**, **Restritos** ou distraídos somam **+2 por Proficiência** ao dano.

---

## Links Relacionados
- [[Carvão]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
