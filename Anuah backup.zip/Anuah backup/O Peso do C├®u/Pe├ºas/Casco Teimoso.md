---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/fixa
  - fabrica/brasa
nivel: 4
fabrica: Companhia Brasa e Filhos
custo_estresse: 0
pdf_page: 35
jogo: O Peso do Céu
---

# Casco Teimoso

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=35|Consultar Texto Original no PDF (Página 35) — Peça Casco Teimoso (Companhia Brasa e Filhos)]]**

*Nível 4 · Fixa · sempre ligada · [[Companhia Brasa e Filhos]]*

---

A primeira vez em cada cena que você marcaria 3 Estrutura de um golpe só, marque 1.

---

## Links Relacionados
- [[Companhia Brasa e Filhos]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
