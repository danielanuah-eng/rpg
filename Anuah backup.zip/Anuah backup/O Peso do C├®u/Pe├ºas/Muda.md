---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/ossatura
nivel: 5
fabrica: Ossatura
custo_estresse: 2
pdf_page: 48
jogo: O Peso do Céu
---

# Muda

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=48|Consultar Texto Original no PDF (Página 48) — Peça Muda (Ossatura)]]**

*Nível 5 · Ativa · 2 Estresse · [[Ossatura]]*

---

Limpe todas as Avarias e **4 Estrutura**. Marque 2 Estresse e fique **Vulnerável** até a sua próxima ação. O casco está molhado.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **2 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Ossatura]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
