---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/tensa
  - fabrica/selo
nivel: 5
fabrica: Selo Civil
custo_estresse: 4
pdf_page: 45
jogo: O Peso do Céu
---

# Mandado

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=45|Consultar Texto Original no PDF (Página 45) — Peça Mandado (Selo Civil)]]**

*Nível 5 · Tensa · liga com 4+ de Medo na mesa · [[Selo Civil]]*

---

Nomeie um alvo. Enquanto ligada, os seus ataques contra ele têm vantagem e os ataques dele contra qualquer outra pessoa têm desvantagem.

> [!WARNING] Peça Tensa
> Não custa nada, mas só funciona enquanto o Mestre tiver **4 ou mais de Medo**. Ele não pode gastar Medo só para desligar a Peça — mas se o gasto tem efeito na ficção, ela apaga junto. Ver [[O Medo]].

---

## Links Relacionados
- [[Selo Civil]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
