---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/catedral
nivel: 7
fabrica: Fundição Catedral
custo_estresse: 2
pdf_page: 39
jogo: O Peso do Céu
---

# Julgamento

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=39|Consultar Texto Original no PDF (Página 39) — Peça Julgamento (Fundição Catedral)]]**

*Nível 7 · Ativa · 2 Estresse · [[Fundição Catedral]]*

---

Nomeie um alvo em voz alta. Todos os ataques aliados contra ele somam **+2 por Proficiência**, e ele não pode ficar **Oculto** de você.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **2 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Fundição Catedral]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
