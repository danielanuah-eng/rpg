---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/gralha
nivel: 8
fabrica: Oficinas Gralha
custo_estresse: 2
pdf_page: 43
jogo: O Peso do Céu
---

# Tudo Que Tem

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=43|Consultar Texto Original no PDF (Página 43) — Peça Tudo Que Tem (Oficinas Gralha)]]**

*Nível 8 · Ativa · 2 Estresse · [[Oficinas Gralha]]*

---

Dispare ou use todas as armas e Peças Ativas instaladas de uma vez. Depois disso, marque 3 Estresse e uma Peça à sua escolha desliga até a próxima Parada.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **2 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Oficinas Gralha]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
