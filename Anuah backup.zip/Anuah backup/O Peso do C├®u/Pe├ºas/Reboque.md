---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/selo
nivel: 8
fabrica: Selo Civil
custo_estresse: 1
pdf_page: 45
jogo: O Peso do Céu
---

# Reboque

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=45|Consultar Texto Original no PDF (Página 45) — Peça Reboque (Selo Civil)]]**

*Nível 8 · Ativa · 1 Estresse · [[Selo Civil]]*

---

Engate um colosso **Inerte** ou **Restrito** e arraste-o com você, inclusive para fora da cena.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **1 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Selo Civil]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
