---
tipo: Hub
categoria: MOC
tags:
  - peso-do-ceu
  - moc
  - hub
jogo: O Peso do Céu
---

# 🔩 As 120 Peças

Quinze Peças por fábrica. **Fixa** está sempre ligada; **Ativa** custa [[Estresse]] e uma ação; **Tensa** não custa nada mas só funciona enquanto o Mestre tiver Medo guardado — ver [[O Medo]].

Uma Peça por encaixe do chassi. Troca-se numa doca ou numa Parada Longa.

---

## Companhia Brasa e Filhos

- [[Chapa Sobreposta]] — Nível 1 · Fixa · sempre ligada
- [[Pé de Chumbo]] — Nível 1 · Fixa · sempre ligada
- [[Guincho de Doca]] — Nível 1 · Ativa · 1 Estresse
- [[Solda de Campo]] — Nível 2 · Ativa · 1 Estresse
- [[Fornalha Aberta]] — Nível 2 · Tensa · liga com 4+ de Medo na mesa
- [[Marreta de Fundição]] — Nível 3 · Ativa · 1 Estresse
- [[Braço de Carga]] — Nível 3 · Fixa · sempre ligada
- [[Purga de Vapor]] — Nível 4 · Ativa · 2 Estresse
- [[Casco Teimoso]] — Nível 4 · Fixa · sempre ligada
- [[Motor de Teimosia]] — Nível 5 · Tensa · liga com 6+ de Medo na mesa
- [[Bigorna (peça)]] — Nível 6 · Fixa · sempre ligada
- [[Chaminé Dupla]] — Nível 7 · Ativa · 1 Estresse
- [[Prensa]] — Nível 8 · Ativa · 2 Estresse
- [[Placa de Sacrifício]] — Nível 9 · Tensa · liga com 4+ de Medo na mesa
- [[A Última Brasa]] — Nível 10 · Ativa · 2 Estresse

## Vespertina Mecânica Fina

- [[Patim de Competição]] — Nível 1 · Fixa · sempre ligada
- [[Passo de Lado]] — Nível 1 · Ativa · 1 Estresse
- [[Lâmina de Serviço]] — Nível 2 · Fixa · sempre ligada
- [[Silêncio de Casco]] — Nível 2 · Fixa · sempre ligada
- [[Rasante]] — Nível 3 · Ativa · 1 Estresse
- [[Leitura de Guarda]] — Nível 3 · Ativa · 1 Estresse
- [[Campo de Corte]] — Nível 4 · Tensa · liga com 4+ de Medo na mesa
- [[Aletas de Manobra]] — Nível 4 · Fixa · sempre ligada
- [[Primeiro Corte]] — Nível 5 · Fixa · sempre ligada
- [[Eco Falso]] — Nível 6 · Ativa · 1 Estresse
- [[Duas Lâminas]] — Nível 7 · Ativa · 2 Estresse
- [[Corte de Passagem]] — Nível 8 · Tensa · liga com 6+ de Medo na mesa
- [[Noite Portátil]] — Nível 9 · Ativa · 2 Estresse
- [[Sem Assinatura]] — Nível 9 · Fixa · sempre ligada
- [[O Que Não Estava Lá]] — Nível 10 · Ativa · 2 Estresse

## Fundição Catedral

- [[Véu de Luz]] — Nível 1 · Ativa · 1 Estresse
- [[Brasão]] — Nível 1 · Fixa · sempre ligada
- [[Voz de Comando]] — Nível 2 · Ativa · 1 Estresse
- [[Ombreira de Portão]] — Nível 2 · Fixa · sempre ligada
- [[Ordem de Parada]] — Nível 3 · Tensa · liga com 4+ de Medo na mesa
- [[Estandarte]] — Nível 3 · Fixa · sempre ligada
- [[Abóbada]] — Nível 4 · Ativa · 2 Estresse
- [[Formar]] — Nível 5 · Ativa · 1 Estresse
- [[Peso da Lei]] — Nível 6 · Tensa · liga com 4+ de Medo na mesa
- [[Chapa de Estado]] — Nível 6 · Fixa · sempre ligada
- [[Julgamento]] — Nível 7 · Ativa · 2 Estresse
- [[Segunda Abóbada]] — Nível 8 · Fixa · sempre ligada
- [[Muralha de Um]] — Nível 9 · Tensa · liga com 6+ de Medo na mesa
- [[Toque de Recolher]] — Nível 9 · Ativa · 2 Estresse
- [[A Catedral]] — Nível 10 · Ativa · 2 Estresse

## Estaleiros do Arco

- [[Casco Selado]] — Nível 1 · Fixa · sempre ligada
- [[Lastro]] — Nível 1 · Ativa · 1 Estresse
- [[Jato de Pressão]] — Nível 2 · Ativa · 1 Estresse
- [[Sonar]] — Nível 2 · Fixa · sempre ligada
- [[Correnteza]] — Nível 3 · Ativa · 2 Estresse
- [[Bolsão de Ar]] — Nível 3 · Ativa · 1 Estresse
- [[Agulha de Profundidade]] — Nível 4 · Fixa · sempre ligada
- [[Maré Vazante]] — Nível 5 · Ativa · 2 Estresse
- [[Trocador de Fundo]] — Nível 6 · Tensa · liga com 4+ de Medo na mesa
- [[Casco Duplo]] — Nível 6 · Fixa · sempre ligada
- [[Canto de Sonar]] — Nível 7 · Ativa · 1 Estresse
- [[Rompe-Casco]] — Nível 8 · Fixa · sempre ligada
- [[Olho do Redemoinho]] — Nível 9 · Ativa · 2 Estresse
- [[Pressão Negativa]] — Nível 9 · Tensa · liga com 6+ de Medo na mesa
- [[A Fossa]] — Nível 10 · Ativa · 2 Estresse

## Oficinas Gralha

- [[Encaixe Universal]] — Nível 1 · Fixa · sempre ligada
- [[Gambiarra]] — Nível 1 · Ativa · 1 Estresse
- [[Bolso Furado]] — Nível 2 · Fixa · sempre ligada
- [[Troca Quente]] — Nível 2 · Ativa · 2 Estresse
- [[Ferro-Velho]] — Nível 3 · Tensa · liga com 4+ de Medo na mesa
- [[Mão Torta]] — Nível 3 · Fixa · sempre ligada
- [[Reator Remendado]] — Nível 4 · Ativa · 1 Estresse
- [[Chassi Aberto]] — Nível 5 · Fixa · sempre ligada
- [[Areia no Motor]] — Nível 5 · Ativa · 1 Estresse
- [[Peça de Outro]] — Nível 6 · Ativa · 1 Estresse
- [[Oficina Ambulante]] — Nível 7 · Fixa · sempre ligada
- [[Tudo Que Tem]] — Nível 8 · Ativa · 2 Estresse
- [[Segundo Casco]] — Nível 9 · Fixa · sempre ligada
- [[Serviço Completo]] — Nível 9 · Tensa · liga com 6+ de Medo na mesa
- [[A Gralha]] — Nível 10 · Ativa · 2 Estresse

## Selo Civil

- [[Capacete de Órbita]] — Nível 1 · Fixa · sempre ligada
- [[Holofote de Apreensão]] — Nível 1 · Ativa · 1 Estresse
- [[Arpéu de Algema]] — Nível 2 · Ativa · 1 Estresse
- [[Escuta Passiva]] — Nível 2 · Fixa · sempre ligada
- [[Cassetete]] — Nível 3 · Fixa · sempre ligada
- [[Registro]] — Nível 3 · Fixa · sempre ligada
- [[Perímetro]] — Nível 4 · Ativa · 2 Estresse
- [[Tiro de Aviso]] — Nível 5 · Ativa · 1 Estresse
- [[Mandado]] — Nível 5 · Tensa · liga com 4+ de Medo na mesa
- [[Triangulação]] — Nível 6 · Ativa · 1 Estresse
- [[Ordem Pública]] — Nível 7 · Fixa · sempre ligada
- [[Reboque]] — Nível 8 · Ativa · 1 Estresse
- [[Olho de Órbita]] — Nível 9 · Tensa · liga com 4+ de Medo na mesa
- [[Apreensão]] — Nível 9 · Ativa · 2 Estresse
- [[O Selo]] — Nível 10 · Ativa · 2 Estresse

## Carvão

- [[Placa Fria]] — Nível 1 · Fixa · sempre ligada
- [[Carga de Fenda]] — Nível 1 · Ativa · 1 Estresse
- [[Chave-Mestra]] — Nível 2 · Ativa · 1 Estresse
- [[Gancho Sujo]] — Nível 2 · Fixa · sempre ligada
- [[Rombo]] — Nível 3 · Ativa · 1 Estresse
- [[Mercado]] — Nível 3 · Fixa · sempre ligada
- [[Fumaça de Bordo]] — Nível 4 · Ativa · 1 Estresse
- [[Boca de Lobo]] — Nível 5 · Ativa · 2 Estresse
- [[Ninguém Viu]] — Nível 5 · Tensa · liga com 4+ de Medo na mesa
- [[Retrato Roubado]] — Nível 6 · Ativa · 1 Estresse
- [[Serviço Completo (peça)]] — Nível 7 · Fixa · sempre ligada
- [[Saída pelos Fundos]] — Nível 8 · Ativa · 2 Estresse
- [[A Conta]] — Nível 9 · Tensa · liga com 6+ de Medo na mesa
- [[Sem Número]] — Nível 9 · Fixa · sempre ligada
- [[Já Era Seu]] — Nível 10 · Ativa · 2 Estresse

## Ossatura

- [[Enxerto]] — Nível 1 · Fixa · sempre ligada
- [[Garra Viva]] — Nível 1 · Fixa · sempre ligada
- [[Cicatriza]] — Nível 2 · Ativa · 1 Estresse
- [[Cheiro de Sangue]] — Nível 2 · Fixa · sempre ligada
- [[Berro]] — Nível 3 · Ativa · 1 Estresse
- [[Pele Errada]] — Nível 3 · Fixa · sempre ligada
- [[Segunda Boca]] — Nível 4 · Ativa · 1 Estresse
- [[Muda]] — Nível 5 · Ativa · 2 Estresse
- [[Braços Demais]] — Nível 6 · Fixa · sempre ligada
- [[Ninhada]] — Nível 6 · Ativa · 2 Estresse
- [[Raiz]] — Nível 7 · Ativa · 1 Estresse
- [[Sangue Alto]] — Nível 7 · Tensa · liga com 4+ de Medo na mesa
- [[Casulo]] — Nível 8 · Ativa · 2 Estresse
- [[O Que Estava Dentro]] — Nível 9 · Tensa · liga com 6+ de Medo na mesa
- [[Funda Menor]] — Nível 10 · Ativa · 2 Estresse

---

[[⚙️ As Fábricas|⬅ Voltar]]
