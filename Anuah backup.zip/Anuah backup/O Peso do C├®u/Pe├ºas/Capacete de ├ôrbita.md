---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/fixa
  - fabrica/selo
nivel: 1
fabrica: Selo Civil
custo_estresse: 0
pdf_page: 44
jogo: O Peso do Céu
---

# Capacete de Órbita

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=44|Consultar Texto Original no PDF (Página 44) — Peça Capacete de Órbita (Selo Civil)]]**

*Nível 1 · Fixa · sempre ligada · [[Selo Civil]]*

---

O seu capacete conversa com os satélites do Selo. Você enxerga a cena de cima: **+2** em rolagens para perceber, localizar e orientar, e uma vez por cena o Mestre te diz onde está uma coisa que você está procurando.

---

## Links Relacionados
- [[Selo Civil]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
