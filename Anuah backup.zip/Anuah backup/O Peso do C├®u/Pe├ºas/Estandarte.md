---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/fixa
  - fabrica/catedral
nivel: 3
fabrica: Fundição Catedral
custo_estresse: 0
pdf_page: 21
jogo: O Peso do Céu
---

# Estandarte

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=21|Consultar Texto Original no PDF (Página 21) — Peça Estandarte (Fundição Catedral)]]**

*Nível 3 · Fixa · sempre ligada · [[Fundição Catedral]]*

---

Aliados em Perto não podem ser forçados a fugir, e não marcam Estresse por medo, horror ou moral.

---

## Links Relacionados
- [[Fundição Catedral]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
