---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/fixa
  - fabrica/carvao
nivel: 7
fabrica: Carvão
custo_estresse: 0
pdf_page: 43
jogo: O Peso do Céu
---

# Serviço Completo (peça)

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=43|Consultar Texto Original no PDF (Página 43) — Peça Serviço Completo (Carvão)]]**

*Nível 7 · Fixa · sempre ligada · [[Carvão]]*

---

Suas cargas e sabotagens causam **uma Avaria** além do dano.

---

## Links Relacionados
- [[Carvão]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
