---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/tensa
  - fabrica/catedral
nivel: 6
fabrica: Fundição Catedral
custo_estresse: 4
pdf_page: 39
jogo: O Peso do Céu
---

# Peso da Lei

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=39|Consultar Texto Original no PDF (Página 39) — Peça Peso da Lei (Fundição Catedral)]]**

*Nível 6 · Tensa · liga com 4+ de Medo na mesa · [[Fundição Catedral]]*

---

Enquanto ligada, adversários gastam uma ação inteira para entrar no seu Setor em vez de atravessar de graça.

> [!WARNING] Peça Tensa
> Não custa nada, mas só funciona enquanto o Mestre tiver **4 ou mais de Medo**. Ele não pode gastar Medo só para desligar a Peça — mas se o gasto tem efeito na ficção, ela apaga junto. Ver [[O Medo]].

---

## Links Relacionados
- [[Fundição Catedral]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
