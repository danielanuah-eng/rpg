---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/tensa
  - fabrica/arco
nivel: 9
fabrica: Estaleiros do Arco
custo_estresse: 6
pdf_page: 41
jogo: O Peso do Céu
---

# Pressão Negativa

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=41|Consultar Texto Original no PDF (Página 41) — Peça Pressão Negativa (Estaleiros do Arco)]]**

*Nível 9 · Tensa · liga com 6+ de Medo na mesa · [[Estaleiros do Arco]]*

---

Enquanto ligada, quem estiver em Muito Perto de você marca 1 Estresse por ação. O casco deles range.

> [!WARNING] Peça Tensa
> Não custa nada, mas só funciona enquanto o Mestre tiver **6 ou mais de Medo**. Ele não pode gastar Medo só para desligar a Peça — mas se o gasto tem efeito na ficção, ela apaga junto. Ver [[O Medo]].

---

## Links Relacionados
- [[Estaleiros do Arco]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
