---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/catedral
nivel: 9
fabrica: Fundição Catedral
custo_estresse: 2
pdf_page: 39
jogo: O Peso do Céu
---

# Toque de Recolher

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=39|Consultar Texto Original no PDF (Página 39) — Peça Toque de Recolher (Fundição Catedral)]]**

*Nível 9 · Ativa · 2 Estresse · [[Fundição Catedral]]*

---

Encerre a cena de combate: todos os adversários de Escalão inferior recuam, se rendem ou se escondem. Uma vez por sessão, e sempre custa alguma coisa política.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **2 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Fundição Catedral]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
