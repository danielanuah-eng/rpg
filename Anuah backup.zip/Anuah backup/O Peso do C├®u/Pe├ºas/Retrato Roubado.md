---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/carvao
nivel: 6
fabrica: Carvão
custo_estresse: 1
pdf_page: 47
jogo: O Peso do Céu
---

# Retrato Roubado

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=47|Consultar Texto Original no PDF (Página 47) — Peça Retrato Roubado (Carvão)]]**

*Nível 6 · Ativa · 1 Estresse · [[Carvão]]*

---

Copie a silhueta e a assinatura de um colosso que você já viu. Quem não te viu fazer isso te trata como aquele colosso.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **1 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Carvão]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
