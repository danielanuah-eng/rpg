---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/vespertina
nivel: 10
fabrica: Vespertina Mecânica Fina
custo_estresse: 2
pdf_page: 37
jogo: O Peso do Céu
---

# O Que Não Estava Lá

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=37|Consultar Texto Original no PDF (Página 37) — Peça O Que Não Estava Lá (Vespertina Mecânica Fina)]]**

*Nível 10 · Ativa · 2 Estresse · [[Vespertina Mecânica Fina]]*

---

Uma vez por sortida: declare que você nunca esteve onde te acertaram. O golpe não aconteceu, você está a uma faixa dali, **Oculto**, e é a sua vez.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **2 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Vespertina Mecânica Fina]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
