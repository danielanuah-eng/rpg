---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/carvao
nivel: 10
fabrica: Carvão
custo_estresse: 2
pdf_page: 47
jogo: O Peso do Céu
---

# Já Era Seu

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=47|Consultar Texto Original no PDF (Página 47) — Peça Já Era Seu (Carvão)]]**

*Nível 10 · Ativa · 2 Estresse · [[Carvão]]*

---

Uma vez por sortida: declare que uma peça, uma porta, um veículo ou uma arma da cena era sua o tempo todo. Era. O Mestre diz quem vai vir cobrar, e quando.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **2 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Carvão]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
