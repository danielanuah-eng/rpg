---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/fixa
  - fabrica/catedral
nivel: 6
fabrica: Fundição Catedral
custo_estresse: 0
pdf_page: 39
jogo: O Peso do Céu
---

# Chapa de Estado

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=39|Consultar Texto Original no PDF (Página 39) — Peça Chapa de Estado (Fundição Catedral)]]**

*Nível 6 · Fixa · sempre ligada · [[Fundição Catedral]]*

---

**+3 no Limiar Maior.** Dano de Escalão inferior ao seu nunca passa dele.

---

## Links Relacionados
- [[Fundição Catedral]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
