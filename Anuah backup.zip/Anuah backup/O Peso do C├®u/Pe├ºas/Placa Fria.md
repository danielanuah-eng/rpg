---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/fixa
  - fabrica/carvao
nivel: 1
fabrica: Carvão
custo_estresse: 0
pdf_page: 46
jogo: O Peso do Céu
---

# Placa Fria

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=46|Consultar Texto Original no PDF (Página 46) — Peça Placa Fria (Carvão)]]**

*Nível 1 · Fixa · sempre ligada · [[Carvão]]*

---

Sensor, trava, sonar e rastreio não te pegam. Registro nenhum sabe que este casco existe.

---

## Links Relacionados
- [[Carvão]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
