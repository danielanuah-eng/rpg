---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/fixa
  - fabrica/arco
nivel: 6
fabrica: Estaleiros do Arco
custo_estresse: 0
pdf_page: 41
jogo: O Peso do Céu
---

# Casco Duplo

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=41|Consultar Texto Original no PDF (Página 41) — Peça Casco Duplo (Estaleiros do Arco)]]**

*Nível 6 · Fixa · sempre ligada · [[Estaleiros do Arco]]*

---

**+2 Estrutura** e **+2 no Limiar Severo**.

---

## Links Relacionados
- [[Estaleiros do Arco]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
