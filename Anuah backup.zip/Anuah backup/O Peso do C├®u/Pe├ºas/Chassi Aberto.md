---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/fixa
  - fabrica/gralha
nivel: 5
fabrica: Oficinas Gralha
custo_estresse: 0
pdf_page: 42
jogo: O Peso do Céu
---

# Chassi Aberto

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=42|Consultar Texto Original no PDF (Página 42) — Peça Chassi Aberto (Oficinas Gralha)]]**

*Nível 5 · Fixa · sempre ligada · [[Oficinas Gralha]]*

---

**+2 encaixes**, **–1 Blindagem**. Não há chapa sobrando: tudo que cabe, cabe porque alguma coisa saiu.

---

## Links Relacionados
- [[Oficinas Gralha]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
