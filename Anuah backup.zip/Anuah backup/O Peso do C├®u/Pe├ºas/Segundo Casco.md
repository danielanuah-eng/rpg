---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/fixa
  - fabrica/gralha
nivel: 9
fabrica: Oficinas Gralha
custo_estresse: 0
pdf_page: 43
jogo: O Peso do Céu
---

# Segundo Casco

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=43|Consultar Texto Original no PDF (Página 43) — Peça Segundo Casco (Oficinas Gralha)]]**

*Nível 9 · Fixa · sempre ligada · [[Oficinas Gralha]]*

---

Você tem outro colosso guardado num galpão, montado com as Peças que sobraram. Trocar entre os dois é uma Parada Longa.

---

## Links Relacionados
- [[Oficinas Gralha]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
