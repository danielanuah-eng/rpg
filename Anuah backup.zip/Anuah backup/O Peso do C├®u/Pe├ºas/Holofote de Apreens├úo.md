---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/selo
nivel: 1
fabrica: Selo Civil
custo_estresse: 1
pdf_page: 44
jogo: O Peso do Céu
---

# Holofote de Apreensão

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=44|Consultar Texto Original no PDF (Página 44) — Peça Holofote de Apreensão (Selo Civil)]]**

*Nível 1 · Ativa · 1 Estresse · [[Selo Civil]]*

---

Ninguém fica **Oculto** onde a sua luz bate, e quem estava Oculto fica **Vulnerável** até a próxima ação dele.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **1 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Selo Civil]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
