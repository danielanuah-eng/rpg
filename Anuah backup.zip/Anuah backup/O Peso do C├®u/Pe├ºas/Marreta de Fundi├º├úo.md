---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/brasa
nivel: 3
fabrica: Companhia Brasa e Filhos
custo_estresse: 1
pdf_page: 34
jogo: O Peso do Céu
---

# Marreta de Fundição

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=34|Consultar Texto Original no PDF (Página 34) — Peça Marreta de Fundição (Companhia Brasa e Filhos)]]**

*Nível 3 · Ativa · 1 Estresse · [[Companhia Brasa e Filhos]]*

---

Um golpe corpo a corpo que rola o dano **duas vezes** — fique com o maior — e joga o alvo uma faixa para longe.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **1 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Companhia Brasa e Filhos]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
