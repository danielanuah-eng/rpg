---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/catedral
nivel: 4
fabrica: Fundição Catedral
custo_estresse: 2
pdf_page: 38
jogo: O Peso do Céu
---

# Abóbada

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=38|Consultar Texto Original no PDF (Página 38) — Peça Abóbada (Fundição Catedral)]]**

*Nível 4 · Ativa · 2 Estresse · [[Fundição Catedral]]*

---

Um domo de luz cobre o seu Setor por uma cena: nada de fora acerta nada de dentro, e nada de dentro acerta nada de fora.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **2 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Fundição Catedral]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
