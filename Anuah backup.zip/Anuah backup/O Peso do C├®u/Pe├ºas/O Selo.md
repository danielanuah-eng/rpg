---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/selo
nivel: 10
fabrica: Selo Civil
custo_estresse: 2
pdf_page: 45
jogo: O Peso do Céu
---

# O Selo

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=45|Consultar Texto Original no PDF (Página 45) — Peça O Selo (Selo Civil)]]**

*Nível 10 · Ativa · 2 Estresse · [[Selo Civil]]*

---

Uma vez por sortida: anule uma ação de adversário que já aconteceu. Ela não aconteceu. O Mestre ganha 2 Medo e escolhe quem fica devendo esse favor a você.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **2 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Selo Civil]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
