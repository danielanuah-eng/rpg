---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/arco
nivel: 2
fabrica: Estaleiros do Arco
custo_estresse: 1
pdf_page: 40
jogo: O Peso do Céu
---

# Jato de Pressão

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=40|Consultar Texto Original no PDF (Página 40) — Peça Jato de Pressão (Estaleiros do Arco)]]**

*Nível 2 · Ativa · 1 Estresse · [[Estaleiros do Arco]]*

---

Um corte de água até Perto: `2d10` e o alvo fica **Instável**. Fora de combate, corta chapa, abre porta e limpa entulho.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **1 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Estaleiros do Arco]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
