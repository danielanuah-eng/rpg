---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/arco
nivel: 3
fabrica: Estaleiros do Arco
custo_estresse: 1
pdf_page: 40
jogo: O Peso do Céu
---

# Bolsão de Ar

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=40|Consultar Texto Original no PDF (Página 40) — Peça Bolsão de Ar (Estaleiros do Arco)]]**

*Nível 3 · Ativa · 1 Estresse · [[Estaleiros do Arco]]*

---

Crie um bolsão no fundo. Todos ali podem abrir cabine, respirar e fazer uma Parada Curta sem subir.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **1 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Estaleiros do Arco]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
