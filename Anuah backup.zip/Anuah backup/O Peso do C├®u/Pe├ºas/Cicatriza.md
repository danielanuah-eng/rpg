---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/ossatura
nivel: 2
fabrica: Ossatura
custo_estresse: 1
pdf_page: 48
jogo: O Peso do Céu
---

# Cicatriza

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=48|Consultar Texto Original no PDF (Página 48) — Peça Cicatriza (Ossatura)]]**

*Nível 2 · Ativa · 1 Estresse · [[Ossatura]]*

---

Quando você marcaria Estrutura, marque uma a menos. O casco se fecha sozinho, e você sente.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **1 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Ossatura]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
