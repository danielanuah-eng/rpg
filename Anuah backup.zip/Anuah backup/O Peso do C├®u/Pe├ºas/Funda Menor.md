---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/ossatura
nivel: 10
fabrica: Ossatura
custo_estresse: 2
pdf_page: 49
jogo: O Peso do Céu
---

# Funda Menor

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=49|Consultar Texto Original no PDF (Página 49) — Peça Funda Menor (Ossatura)]]**

*Nível 10 · Ativa · 2 Estresse · [[Ossatura]]*

---

Uma vez por campanha: pare de pilotar e comece a ser. Você vira um adversário Solo de Escalão 4, jogado pelo seu jogador, por uma cena. Depois dela, a mesa decide junto se ainda há alguém lá dentro.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **2 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Ossatura]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
