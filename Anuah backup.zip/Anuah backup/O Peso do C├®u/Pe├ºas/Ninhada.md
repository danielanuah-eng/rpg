---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/ossatura
nivel: 6
fabrica: Ossatura
custo_estresse: 2
pdf_page: 49
jogo: O Peso do Céu
---

# Ninhada

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=49|Consultar Texto Original no PDF (Página 49) — Peça Ninhada (Ossatura)]]**

*Nível 6 · Ativa · 2 Estresse · [[Ossatura]]*

---

Solte três crias do tamanho de um carro. Cada uma tem 3 Estrutura, Evasão 13, ataca por `2d6` e obedece até morrer.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **2 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Ossatura]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
