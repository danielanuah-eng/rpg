---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/tensa
  - fabrica/ossatura
nivel: 9
fabrica: Ossatura
custo_estresse: 6
pdf_page: 49
jogo: O Peso do Céu
---

# O Que Estava Dentro

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=49|Consultar Texto Original no PDF (Página 49) — Peça O Que Estava Dentro (Ossatura)]]**

*Nível 9 · Tensa · liga com 6+ de Medo na mesa · [[Ossatura]]*

---

Quando o seu colosso cairia, ele não cai: ele abre. Ganhe 6 Estrutura e **Garra Viva** até o fim da cena. Marque 3 Estresse. Quem vir isso vai lembrar.

> [!WARNING] Peça Tensa
> Não custa nada, mas só funciona enquanto o Mestre tiver **6 ou mais de Medo**. Ele não pode gastar Medo só para desligar a Peça — mas se o gasto tem efeito na ficção, ela apaga junto. Ver [[O Medo]].

---

## Links Relacionados
- [[Ossatura]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
