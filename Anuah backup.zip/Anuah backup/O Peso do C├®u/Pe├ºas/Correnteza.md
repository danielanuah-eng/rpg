---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/arco
nivel: 3
fabrica: Estaleiros do Arco
custo_estresse: 2
pdf_page: 40
jogo: O Peso do Céu
---

# Correnteza

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=40|Consultar Texto Original no PDF (Página 40) — Peça Correnteza (Estaleiros do Arco)]]**

*Nível 3 · Ativa · 2 Estresse · [[Estaleiros do Arco]]*

---

Puxe todos os alvos de uma faixa de alcance para outra à sua escolha. Quem resistir rola **Força** Dificuldade 15.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **2 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Estaleiros do Arco]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
