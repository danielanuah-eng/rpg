---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/fixa
  - fabrica/arco
nivel: 8
fabrica: Estaleiros do Arco
custo_estresse: 0
pdf_page: 41
jogo: O Peso do Céu
---

# Rompe-Casco

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=41|Consultar Texto Original no PDF (Página 41) — Peça Rompe-Casco (Estaleiros do Arco)]]**

*Nível 8 · Fixa · sempre ligada · [[Estaleiros do Arco]]*

---

Quando você causa uma Avaria em alguém submerso, role a Avaria duas vezes e fique com o pior resultado para ele.

---

## Links Relacionados
- [[Estaleiros do Arco]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
