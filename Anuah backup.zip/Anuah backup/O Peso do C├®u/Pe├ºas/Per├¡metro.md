---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/selo
nivel: 4
fabrica: Selo Civil
custo_estresse: 2
pdf_page: 44
jogo: O Peso do Céu
---

# Perímetro

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=44|Consultar Texto Original no PDF (Página 44) — Peça Perímetro (Selo Civil)]]**

*Nível 4 · Ativa · 2 Estresse · [[Selo Civil]]*

---

Feche um lugar. Ninguém entra nem sai sem gastar uma ação inteira e passar por você. Dura até você sair de lá.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **2 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Selo Civil]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
