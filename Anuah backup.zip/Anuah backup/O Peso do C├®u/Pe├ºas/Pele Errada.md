---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/fixa
  - fabrica/ossatura
nivel: 3
fabrica: Ossatura
custo_estresse: 0
pdf_page: 48
jogo: O Peso do Céu
---

# Pele Errada

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=48|Consultar Texto Original no PDF (Página 48) — Peça Pele Errada (Ossatura)]]**

*Nível 3 · Fixa · sempre ligada · [[Ossatura]]*

---

Fogo, ácido, frio, pressão e veneno não causam dano a você. Marque 1 Estresse na primeira vez que isso acontecer em cada cena.

---

## Links Relacionados
- [[Ossatura]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
