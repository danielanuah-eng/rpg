---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/tensa
  - fabrica/brasa
nivel: 5
fabrica: Companhia Brasa e Filhos
custo_estresse: 6
pdf_page: 35
jogo: O Peso do Céu
---

# Motor de Teimosia

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=35|Consultar Texto Original no PDF (Página 35) — Peça Motor de Teimosia (Companhia Brasa e Filhos)]]**

*Nível 5 · Tensa · liga com 6+ de Medo na mesa · [[Companhia Brasa e Filhos]]*

---

Enquanto estiver ligada, você age **duas vezes** antes de passar o holofote. Uma vez por cena.

> [!WARNING] Peça Tensa
> Não custa nada, mas só funciona enquanto o Mestre tiver **6 ou mais de Medo**. Ele não pode gastar Medo só para desligar a Peça — mas se o gasto tem efeito na ficção, ela apaga junto. Ver [[O Medo]].

---

## Links Relacionados
- [[Companhia Brasa e Filhos]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
