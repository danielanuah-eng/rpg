---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/arco
nivel: 7
fabrica: Estaleiros do Arco
custo_estresse: 1
pdf_page: 41
jogo: O Peso do Céu
---

# Canto de Sonar

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=41|Consultar Texto Original no PDF (Página 41) — Peça Canto de Sonar (Estaleiros do Arco)]]**

*Nível 7 · Ativa · 1 Estresse · [[Estaleiros do Arco]]*

---

Todo adversário em até Longe precisa vir na sua direção na próxima ação dele, ou marcar 2 Estresse para resistir.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **1 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Estaleiros do Arco]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
