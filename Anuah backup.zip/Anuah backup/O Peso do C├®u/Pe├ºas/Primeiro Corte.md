---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/fixa
  - fabrica/vespertina
nivel: 5
fabrica: Vespertina Mecânica Fina
custo_estresse: 0
pdf_page: 37
jogo: O Peso do Céu
---

# Primeiro Corte

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=37|Consultar Texto Original no PDF (Página 37) — Peça Primeiro Corte (Vespertina Mecânica Fina)]]**

*Nível 5 · Fixa · sempre ligada · [[Vespertina Mecânica Fina]]*

---

Contra um alvo que ainda não agiu nesta cena, o seu primeiro ataque acerta sem rolagem.

---

## Links Relacionados
- [[Vespertina Mecânica Fina]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
