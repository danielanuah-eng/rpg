---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/tensa
  - fabrica/vespertina
nivel: 8
fabrica: Vespertina Mecânica Fina
custo_estresse: 6
pdf_page: 37
jogo: O Peso do Céu
---

# Corte de Passagem

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=37|Consultar Texto Original no PDF (Página 37) — Peça Corte de Passagem (Vespertina Mecânica Fina)]]**

*Nível 8 · Tensa · liga com 6+ de Medo na mesa · [[Vespertina Mecânica Fina]]*

---

Quando você atravessa o espaço de um adversário, ele sofre o dano da sua arma corpo a corpo. Isso encadeia quantas vezes couber no movimento.

> [!WARNING] Peça Tensa
> Não custa nada, mas só funciona enquanto o Mestre tiver **6 ou mais de Medo**. Ele não pode gastar Medo só para desligar a Peça — mas se o gasto tem efeito na ficção, ela apaga junto. Ver [[O Medo]].

---

## Links Relacionados
- [[Vespertina Mecânica Fina]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
