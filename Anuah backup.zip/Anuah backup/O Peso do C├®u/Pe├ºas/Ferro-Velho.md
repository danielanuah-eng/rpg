---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/tensa
  - fabrica/gralha
nivel: 3
fabrica: Oficinas Gralha
custo_estresse: 4
pdf_page: 23
jogo: O Peso do Céu
---

# Ferro-Velho

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=23|Consultar Texto Original no PDF (Página 23) — Peça Ferro-Velho (Oficinas Gralha)]]**

*Nível 3 · Tensa · liga com 4+ de Medo na mesa · [[Oficinas Gralha]]*

---

Quando um colosso cai em Perto ou mais perto, arranque uma peça: uma arma, uma Peça instalada dele, ou 2 Estrutura para você.

> [!WARNING] Peça Tensa
> Não custa nada, mas só funciona enquanto o Mestre tiver **4 ou mais de Medo**. Ele não pode gastar Medo só para desligar a Peça — mas se o gasto tem efeito na ficção, ela apaga junto. Ver [[O Medo]].

---

## Links Relacionados
- [[Oficinas Gralha]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
