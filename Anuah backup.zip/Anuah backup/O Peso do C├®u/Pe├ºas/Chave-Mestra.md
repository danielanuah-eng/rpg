---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/carvao
nivel: 2
fabrica: Carvão
custo_estresse: 1
pdf_page: 46
jogo: O Peso do Céu
---

# Chave-Mestra

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=46|Consultar Texto Original no PDF (Página 46) — Peça Chave-Mestra (Carvão)]]**

*Nível 2 · Ativa · 1 Estresse · [[Carvão]]*

---

Abra qualquer coisa fechada: porta, comporta, cofre, cabine de colosso **Inerte**. Leva uma ação e faz barulho.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **1 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Carvão]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
