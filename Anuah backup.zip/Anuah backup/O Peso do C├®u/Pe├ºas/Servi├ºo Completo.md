---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/tensa
  - fabrica/gralha
nivel: 9
fabrica: Oficinas Gralha
custo_estresse: 6
pdf_page: 43
jogo: O Peso do Céu
---

# Serviço Completo

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=43|Consultar Texto Original no PDF (Página 43) — Peça Serviço Completo (Oficinas Gralha)]]**

*Nível 9 · Tensa · liga com 6+ de Medo na mesa · [[Oficinas Gralha]]*

---

Enquanto ligada, toda Peça Ativa sua custa **1 Estresse a menos**, até o mínimo de zero.

> [!WARNING] Peça Tensa
> Não custa nada, mas só funciona enquanto o Mestre tiver **6 ou mais de Medo**. Ele não pode gastar Medo só para desligar a Peça — mas se o gasto tem efeito na ficção, ela apaga junto. Ver [[O Medo]].

---

## Links Relacionados
- [[Oficinas Gralha]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
