---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/gralha
nivel: 6
fabrica: Oficinas Gralha
custo_estresse: 1
pdf_page: 43
jogo: O Peso do Céu
---

# Peça de Outro

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=43|Consultar Texto Original no PDF (Página 43) — Peça Peça de Outro (Oficinas Gralha)]]**

*Nível 6 · Ativa · 1 Estresse · [[Oficinas Gralha]]*

---

Uma vez por cena, use uma Peça instalada de um colosso que você esteja tocando — aliado ou não.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **1 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Oficinas Gralha]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
