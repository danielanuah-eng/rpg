---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/brasa
nivel: 2
fabrica: Companhia Brasa e Filhos
custo_estresse: 1
pdf_page: 34
jogo: O Peso do Céu
---

# Solda de Campo

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=34|Consultar Texto Original no PDF (Página 34) — Peça Solda de Campo (Companhia Brasa e Filhos)]]**

*Nível 2 · Ativa · 1 Estresse · [[Companhia Brasa e Filhos]]*

---

Limpe **2 Estrutura** marcada — sua ou de um aliado em Muito Perto. Fora de combate não custa nada e conserta o que precisar.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **1 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Companhia Brasa e Filhos]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
