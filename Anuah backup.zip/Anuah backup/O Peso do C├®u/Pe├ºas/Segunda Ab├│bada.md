---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/fixa
  - fabrica/catedral
nivel: 8
fabrica: Fundição Catedral
custo_estresse: 0
pdf_page: 39
jogo: O Peso do Céu
---

# Segunda Abóbada

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=39|Consultar Texto Original no PDF (Página 39) — Peça Segunda Abóbada (Fundição Catedral)]]**

*Nível 8 · Fixa · sempre ligada · [[Fundição Catedral]]*

---

O **Véu de Luz** passa a ter seis cargas e pode ser usado como reação por um aliado em até Longe.

---

## Links Relacionados
- [[Fundição Catedral]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
