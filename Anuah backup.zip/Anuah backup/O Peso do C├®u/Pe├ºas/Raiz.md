---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/ossatura
nivel: 7
fabrica: Ossatura
custo_estresse: 1
pdf_page: 49
jogo: O Peso do Céu
---

# Raiz

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=49|Consultar Texto Original no PDF (Página 49) — Peça Raiz (Ossatura)]]**

*Nível 7 · Ativa · 1 Estresse · [[Ossatura]]*

---

Crave o casco no chão, na parede ou no casco de outro. Você fica **Restrito**, não pode ser movido por nada e todo dano que sofrer cai **um degrau**. Soltar é de graça.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **1 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Ossatura]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
