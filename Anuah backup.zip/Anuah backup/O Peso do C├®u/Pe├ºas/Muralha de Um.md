---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/tensa
  - fabrica/catedral
nivel: 9
fabrica: Fundição Catedral
custo_estresse: 6
pdf_page: 39
jogo: O Peso do Céu
---

# Muralha de Um

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=39|Consultar Texto Original no PDF (Página 39) — Peça Muralha de Um (Fundição Catedral)]]**

*Nível 9 · Tensa · liga com 6+ de Medo na mesa · [[Fundição Catedral]]*

---

Enquanto ligada, nada atravessa a linha entre você e o que você está protegendo. Nem tiro, nem máquina, nem argumento.

> [!WARNING] Peça Tensa
> Não custa nada, mas só funciona enquanto o Mestre tiver **6 ou mais de Medo**. Ele não pode gastar Medo só para desligar a Peça — mas se o gasto tem efeito na ficção, ela apaga junto. Ver [[O Medo]].

---

## Links Relacionados
- [[Fundição Catedral]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
