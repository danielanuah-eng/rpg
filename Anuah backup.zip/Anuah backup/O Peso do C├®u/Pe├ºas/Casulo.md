---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/ossatura
nivel: 8
fabrica: Ossatura
custo_estresse: 2
pdf_page: 49
jogo: O Peso do Céu
---

# Casulo

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=49|Consultar Texto Original no PDF (Página 49) — Peça Casulo (Ossatura)]]**

*Nível 8 · Ativa · 2 Estresse · [[Ossatura]]*

---

Feche o casco por uma cena. Nada entra. Ao abrir, limpe todo o Estresse e toda a Estrutura — e role na tabela de **Virada**.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **2 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Ossatura]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
