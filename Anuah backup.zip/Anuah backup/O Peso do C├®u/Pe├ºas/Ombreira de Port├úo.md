---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/fixa
  - fabrica/catedral
nivel: 2
fabrica: Fundição Catedral
custo_estresse: 0
pdf_page: 38
jogo: O Peso do Céu
---

# Ombreira de Portão

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=38|Consultar Texto Original no PDF (Página 38) — Peça Ombreira de Portão (Fundição Catedral)]]**

*Nível 2 · Fixa · sempre ligada · [[Fundição Catedral]]*

---

**+1 Blindagem** e **+1 Estrutura**. A ombreira cobre meio corpo e é a primeira coisa que qualquer um acerta.

---

## Links Relacionados
- [[Fundição Catedral]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
