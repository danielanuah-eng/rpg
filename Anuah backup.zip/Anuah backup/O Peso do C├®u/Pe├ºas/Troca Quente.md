---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/gralha
nivel: 2
fabrica: Oficinas Gralha
custo_estresse: 2
pdf_page: 42
jogo: O Peso do Céu
---

# Troca Quente

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=42|Consultar Texto Original no PDF (Página 42) — Peça Troca Quente (Oficinas Gralha)]]**

*Nível 2 · Ativa · 2 Estresse · [[Oficinas Gralha]]*

---

Troque duas Peças instaladas por outras que você tenha no baú, agora, no meio da cena, sem doca.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **2 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Oficinas Gralha]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
