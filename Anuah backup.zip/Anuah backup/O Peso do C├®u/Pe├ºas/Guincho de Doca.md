---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/brasa
nivel: 1
fabrica: Companhia Brasa e Filhos
custo_estresse: 1
pdf_page: 34
jogo: O Peso do Céu
---

# Guincho de Doca

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=34|Consultar Texto Original no PDF (Página 34) — Peça Guincho de Doca (Companhia Brasa e Filhos)]]**

*Nível 1 · Ativa · 1 Estresse · [[Companhia Brasa e Filhos]]*

---

Puxe até você qualquer coisa do tamanho de um colosso, ou vá até ela. Fora de combate, isso levanta ponte caída, tira gente de escombro e reboca máquina morta.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **1 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Companhia Brasa e Filhos]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
