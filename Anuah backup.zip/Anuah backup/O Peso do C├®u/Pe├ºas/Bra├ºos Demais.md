---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/fixa
  - fabrica/ossatura
nivel: 6
fabrica: Ossatura
custo_estresse: 0
pdf_page: 49
jogo: O Peso do Céu
---

# Braços Demais

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=49|Consultar Texto Original no PDF (Página 49) — Peça Braços Demais (Ossatura)]]**

*Nível 6 · Fixa · sempre ligada · [[Ossatura]]*

---

Você tem dois braços a mais. Eles não usam arma: usam **Garra Viva**. Enquanto estiverem abertos, marque 1 Estresse por cena.

---

## Links Relacionados
- [[Ossatura]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
