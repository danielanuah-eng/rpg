---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/arco
nivel: 1
fabrica: Estaleiros do Arco
custo_estresse: 1
pdf_page: 40
jogo: O Peso do Céu
---

# Lastro

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=40|Consultar Texto Original no PDF (Página 40) — Peça Lastro (Estaleiros do Arco)]]**

*Nível 1 · Ativa · 1 Estresse · [[Estaleiros do Arco]]*

---

Afunde ou suba sem gastar ação, e fique **Oculto** de quem estiver acima da linha d'água.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **1 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Estaleiros do Arco]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
