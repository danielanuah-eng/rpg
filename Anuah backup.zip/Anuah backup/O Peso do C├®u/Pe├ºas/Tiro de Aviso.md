---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/selo
nivel: 5
fabrica: Selo Civil
custo_estresse: 1
pdf_page: 45
jogo: O Peso do Céu
---

# Tiro de Aviso

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=45|Consultar Texto Original no PDF (Página 45) — Peça Tiro de Aviso (Selo Civil)]]**

*Nível 5 · Ativa · 1 Estresse · [[Selo Civil]]*

---

Um ataque que, se fosse acertar, não causa dano: o alvo fica **Instável** e não pode atacar você até a próxima ação dele, a não ser que o Mestre gaste 1 Medo.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **1 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Selo Civil]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
