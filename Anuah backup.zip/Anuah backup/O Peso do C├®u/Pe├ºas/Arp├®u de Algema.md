---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/selo
nivel: 2
fabrica: Selo Civil
custo_estresse: 1
pdf_page: 44
jogo: O Peso do Céu
---

# Arpéu de Algema

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=44|Consultar Texto Original no PDF (Página 44) — Peça Arpéu de Algema (Selo Civil)]]**

*Nível 2 · Ativa · 1 Estresse · [[Selo Civil]]*

---

Prenda um alvo em até Longe. Ele fica **Restrito** até gastar uma ação e rolar **Força** Dificuldade 15.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **1 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Selo Civil]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
