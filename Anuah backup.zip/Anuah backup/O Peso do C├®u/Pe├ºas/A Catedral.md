---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/catedral
nivel: 10
fabrica: Fundição Catedral
custo_estresse: 2
pdf_page: 39
jogo: O Peso do Céu
---

# A Catedral

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=39|Consultar Texto Original no PDF (Página 39) — Peça A Catedral (Fundição Catedral)]]**

*Nível 10 · Ativa · 2 Estresse · [[Fundição Catedral]]*

---

Uma vez por sortida: pelo resto da cena, você não pode ser movido, não pode ser **Restrito** e não sofre Avaria. Ao fim, o casco precisa de uma doca de Estado para voltar a andar.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **2 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Fundição Catedral]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
