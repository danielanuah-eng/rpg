---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/fixa
  - fabrica/gralha
nivel: 7
fabrica: Oficinas Gralha
custo_estresse: 0
pdf_page: 43
jogo: O Peso do Céu
---

# Oficina Ambulante

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=43|Consultar Texto Original no PDF (Página 43) — Peça Oficina Ambulante (Oficinas Gralha)]]**

*Nível 7 · Fixa · sempre ligada · [[Oficinas Gralha]]*

---

Você faz Parada Longa de máquina em qualquer lugar, para qualquer um, sem doca e sem material.

---

## Links Relacionados
- [[Oficinas Gralha]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
