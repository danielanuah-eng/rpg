---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/fixa
  - fabrica/gralha
nivel: 2
fabrica: Oficinas Gralha
custo_estresse: 0
pdf_page: 42
jogo: O Peso do Céu
---

# Bolso Furado

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=42|Consultar Texto Original no PDF (Página 42) — Peça Bolso Furado (Oficinas Gralha)]]**

*Nível 2 · Fixa · sempre ligada · [[Oficinas Gralha]]*

---

Uma vez por sessão, declare que você tinha a peça, a ferramenta ou a carga pequena de que precisava. Você tinha.

---

## Links Relacionados
- [[Oficinas Gralha]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
