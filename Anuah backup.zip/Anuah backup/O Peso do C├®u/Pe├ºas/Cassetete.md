---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/fixa
  - fabrica/selo
nivel: 3
fabrica: Selo Civil
custo_estresse: 0
pdf_page: 44
jogo: O Peso do Céu
---

# Cassetete

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=44|Consultar Texto Original no PDF (Página 44) — Peça Cassetete (Selo Civil)]]**

*Nível 3 · Fixa · sempre ligada · [[Selo Civil]]*

---

Você pode declarar qualquer ataque seu como **não letal** sem perder dano. Um alvo derrubado assim fica **Inerte** em vez de destruído, e dá para levá-lo embora.

---

## Links Relacionados
- [[Selo Civil]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
