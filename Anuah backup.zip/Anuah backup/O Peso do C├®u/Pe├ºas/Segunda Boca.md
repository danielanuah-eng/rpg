---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/ossatura
nivel: 4
fabrica: Ossatura
custo_estresse: 1
pdf_page: 48
jogo: O Peso do Céu
---

# Segunda Boca

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=48|Consultar Texto Original no PDF (Página 48) — Peça Segunda Boca (Ossatura)]]**

*Nível 4 · Ativa · 1 Estresse · [[Ossatura]]*

---

Ataque um alvo **Restrito** ou **Inerte**. Se acertar, limpe **3 Estrutura** sua. Você não escolhe se quer engolir.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **1 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Ossatura]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
