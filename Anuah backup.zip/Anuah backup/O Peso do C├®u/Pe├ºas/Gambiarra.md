---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/gralha
nivel: 1
fabrica: Oficinas Gralha
custo_estresse: 1
pdf_page: 42
jogo: O Peso do Céu
---

# Gambiarra

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=42|Consultar Texto Original no PDF (Página 42) — Peça Gambiarra (Oficinas Gralha)]]**

*Nível 1 · Ativa · 1 Estresse · [[Oficinas Gralha]]*

---

Conserte qualquer coisa por uma cena com o que estiver na mão. Em combate, limpe **2 Estrutura** marcada.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **1 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Oficinas Gralha]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
