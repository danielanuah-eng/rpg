---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/brasa
nivel: 10
fabrica: Companhia Brasa e Filhos
custo_estresse: 2
pdf_page: 35
jogo: O Peso do Céu
---

# A Última Brasa

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=35|Consultar Texto Original no PDF (Página 35) — Peça A Última Brasa (Companhia Brasa e Filhos)]]**

*Nível 10 · Ativa · 2 Estresse · [[Companhia Brasa e Filhos]]*

---

Uma vez por sortida: quando o seu colosso cairia, ele não cai. Ele fica de pé com **4 Estrutura** até o fim da cena, e depois disso nunca mais anda.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **2 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Companhia Brasa e Filhos]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
