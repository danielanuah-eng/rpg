---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/fixa
  - fabrica/carvao
nivel: 9
fabrica: Carvão
custo_estresse: 0
pdf_page: 47
jogo: O Peso do Céu
---

# Sem Número

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=47|Consultar Texto Original no PDF (Página 47) — Peça Sem Número (Carvão)]]**

*Nível 9 · Fixa · sempre ligada · [[Carvão]]*

---

Você não pode ser identificado, denunciado, processado nem reconhecido por nenhum sistema. Só por gente que te viu o rosto.

---

## Links Relacionados
- [[Carvão]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
