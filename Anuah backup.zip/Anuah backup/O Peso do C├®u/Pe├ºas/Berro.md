---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/ossatura
nivel: 3
fabrica: Ossatura
custo_estresse: 1
pdf_page: 48
jogo: O Peso do Céu
---

# Berro

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=48|Consultar Texto Original no PDF (Página 48) — Peça Berro (Ossatura)]]**

*Nível 3 · Ativa · 1 Estresse · [[Ossatura]]*

---

Todo adversário em até Perto marca 1 Estresse e fica **Instável**. Aliados que não sabiam do enxerto passam a saber.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **1 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Ossatura]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
