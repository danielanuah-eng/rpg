---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/tensa
  - fabrica/catedral
nivel: 3
fabrica: Fundição Catedral
custo_estresse: 4
pdf_page: 38
jogo: O Peso do Céu
---

# Ordem de Parada

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=38|Consultar Texto Original no PDF (Página 38) — Peça Ordem de Parada (Fundição Catedral)]]**

*Nível 3 · Tensa · liga com 4+ de Medo na mesa · [[Fundição Catedral]]*

---

Adversários de Escalão inferior ao seu precisam gastar uma ação decidindo se obedecem antes de poderem te atacar.

> [!WARNING] Peça Tensa
> Não custa nada, mas só funciona enquanto o Mestre tiver **4 ou mais de Medo**. Ele não pode gastar Medo só para desligar a Peça — mas se o gasto tem efeito na ficção, ela apaga junto. Ver [[O Medo]].

---

## Links Relacionados
- [[Fundição Catedral]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
