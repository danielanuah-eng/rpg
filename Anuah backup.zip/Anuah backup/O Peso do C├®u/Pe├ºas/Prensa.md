---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/brasa
nivel: 8
fabrica: Companhia Brasa e Filhos
custo_estresse: 2
pdf_page: 35
jogo: O Peso do Céu
---

# Prensa

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=35|Consultar Texto Original no PDF (Página 35) — Peça Prensa (Companhia Brasa e Filhos)]]**

*Nível 8 · Ativa · 2 Estresse · [[Companhia Brasa e Filhos]]*

---

Agarre um alvo em Corpo a corpo. Ele fica **Restrito** e sofre o dano da sua arma a cada ação enquanto você não soltar. Você também não faz mais nada enquanto isso.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **2 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Companhia Brasa e Filhos]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
