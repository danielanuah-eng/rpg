---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/fixa
  - fabrica/brasa
nivel: 6
fabrica: Companhia Brasa e Filhos
custo_estresse: 0
pdf_page: 19
jogo: O Peso do Céu
---

# Bigorna (peça)

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=19|Consultar Texto Original no PDF (Página 19) — Peça Bigorna (Companhia Brasa e Filhos)]]**

*Nível 6 · Fixa · sempre ligada · [[Companhia Brasa e Filhos]]*

---

**+2 nos dois Limiares** e **+1 Estrutura**. O casco ficou pesado demais para qualquer coisa que não seja andar em frente.

---

## Links Relacionados
- [[Companhia Brasa e Filhos]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
