---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/carvao
nivel: 4
fabrica: Carvão
custo_estresse: 1
pdf_page: 46
jogo: O Peso do Céu
---

# Fumaça de Bordo

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=46|Consultar Texto Original no PDF (Página 46) — Peça Fumaça de Bordo (Carvão)]]**

*Nível 4 · Ativa · 1 Estresse · [[Carvão]]*

---

Encha o lugar de fumaça. Todos ficam **Cegos**; você não.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **1 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Carvão]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
