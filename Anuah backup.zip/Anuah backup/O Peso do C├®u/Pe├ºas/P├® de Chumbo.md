---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/fixa
  - fabrica/brasa
nivel: 1
fabrica: Companhia Brasa e Filhos
custo_estresse: 0
pdf_page: 34
jogo: O Peso do Céu
---

# Pé de Chumbo

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=34|Consultar Texto Original no PDF (Página 34) — Peça Pé de Chumbo (Companhia Brasa e Filhos)]]**

*Nível 1 · Fixa · sempre ligada · [[Companhia Brasa e Filhos]]*

---

Você não pode ser empurrado, derrubado, puxado nem arrastado por nada que pese menos que você. Em troca, o seu Deslocamento nunca passa de uma faixa por ação.

---

## Links Relacionados
- [[Companhia Brasa e Filhos]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
