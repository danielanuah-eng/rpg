---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/tensa
  - fabrica/carvao
nivel: 5
fabrica: Carvão
custo_estresse: 4
pdf_page: 47
jogo: O Peso do Céu
---

# Ninguém Viu

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=47|Consultar Texto Original no PDF (Página 47) — Peça Ninguém Viu (Carvão)]]**

*Nível 5 · Tensa · liga com 4+ de Medo na mesa · [[Carvão]]*

---

Enquanto ligada, você fica **Oculto** de novo sempre que termina uma ação, mesmo tendo atacado.

> [!WARNING] Peça Tensa
> Não custa nada, mas só funciona enquanto o Mestre tiver **4 ou mais de Medo**. Ele não pode gastar Medo só para desligar a Peça — mas se o gasto tem efeito na ficção, ela apaga junto. Ver [[O Medo]].

---

## Links Relacionados
- [[Carvão]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
