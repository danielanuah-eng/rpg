---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/carvao
nivel: 8
fabrica: Carvão
custo_estresse: 2
pdf_page: 47
jogo: O Peso do Céu
---

# Saída pelos Fundos

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=47|Consultar Texto Original no PDF (Página 47) — Peça Saída pelos Fundos (Carvão)]]**

*Nível 8 · Ativa · 2 Estresse · [[Carvão]]*

---

Você e todos os aliados em Perto saem da cena agora e reaparecem em qualquer borda dela. Ninguém consegue dizer como.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **2 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Carvão]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
