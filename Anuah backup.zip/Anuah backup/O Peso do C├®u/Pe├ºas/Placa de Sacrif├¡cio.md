---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/tensa
  - fabrica/brasa
nivel: 9
fabrica: Companhia Brasa e Filhos
custo_estresse: 4
pdf_page: 35
jogo: O Peso do Céu
---

# Placa de Sacrifício

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=35|Consultar Texto Original no PDF (Página 35) — Peça Placa de Sacrifício (Companhia Brasa e Filhos)]]**

*Nível 9 · Tensa · liga com 4+ de Medo na mesa · [[Companhia Brasa e Filhos]]*

---

Quando um aliado em Perto sofreria dano, você pode tomá-lo no lugar — e ele cai **um degrau** de Limiar no caminho.

> [!WARNING] Peça Tensa
> Não custa nada, mas só funciona enquanto o Mestre tiver **4 ou mais de Medo**. Ele não pode gastar Medo só para desligar a Peça — mas se o gasto tem efeito na ficção, ela apaga junto. Ver [[O Medo]].

---

## Links Relacionados
- [[Companhia Brasa e Filhos]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
