---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/fixa
  - fabrica/vespertina
nivel: 2
fabrica: Vespertina Mecânica Fina
custo_estresse: 0
pdf_page: 36
jogo: O Peso do Céu
---

# Silêncio de Casco

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=36|Consultar Texto Original no PDF (Página 36) — Peça Silêncio de Casco (Vespertina Mecânica Fina)]]**

*Nível 2 · Fixa · sempre ligada · [[Vespertina Mecânica Fina]]*

---

Você pode ficar **Oculto** em qualquer lugar com fumaça, ruína, água, multidão ou escuro — e continua Oculto depois de se mover.

---

## Links Relacionados
- [[Vespertina Mecânica Fina]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
