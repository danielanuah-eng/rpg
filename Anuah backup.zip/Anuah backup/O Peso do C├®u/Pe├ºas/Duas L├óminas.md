---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/vespertina
nivel: 7
fabrica: Vespertina Mecânica Fina
custo_estresse: 2
pdf_page: 37
jogo: O Peso do Céu
---

# Duas Lâminas

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=37|Consultar Texto Original no PDF (Página 37) — Peça Duas Lâminas (Vespertina Mecânica Fina)]]**

*Nível 7 · Ativa · 2 Estresse · [[Vespertina Mecânica Fina]]*

---

Ataque dois alvos diferentes com uma rolagem só, comparada com as duas Evasões.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **2 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Vespertina Mecânica Fina]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
