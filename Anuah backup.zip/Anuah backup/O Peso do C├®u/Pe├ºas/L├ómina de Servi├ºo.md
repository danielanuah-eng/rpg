---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/fixa
  - fabrica/vespertina
nivel: 2
fabrica: Vespertina Mecânica Fina
custo_estresse: 0
pdf_page: 36
jogo: O Peso do Céu
---

# Lâmina de Serviço

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=36|Consultar Texto Original no PDF (Página 36) — Peça Lâmina de Serviço (Vespertina Mecânica Fina)]]**

*Nível 2 · Fixa · sempre ligada · [[Vespertina Mecânica Fina]]*

---

Seus ataques corpo a corpo somam **+2** ao dano e, num Crítico, o alvo fica **Vulnerável**.

---

## Links Relacionados
- [[Vespertina Mecânica Fina]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
