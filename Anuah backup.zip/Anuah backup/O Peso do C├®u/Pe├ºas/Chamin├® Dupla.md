---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/brasa
nivel: 7
fabrica: Companhia Brasa e Filhos
custo_estresse: 1
pdf_page: 35
jogo: O Peso do Céu
---

# Chaminé Dupla

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=35|Consultar Texto Original no PDF (Página 35) — Peça Chaminé Dupla (Companhia Brasa e Filhos)]]**

*Nível 7 · Ativa · 1 Estresse · [[Companhia Brasa e Filhos]]*

---

Limpe **2 Estresse**. O escape abre, a cabine esfria e todo mundo num raio de quarteirão sabe onde você está.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **1 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Companhia Brasa e Filhos]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
