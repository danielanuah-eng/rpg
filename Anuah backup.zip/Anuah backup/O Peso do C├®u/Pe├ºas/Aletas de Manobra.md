---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/fixa
  - fabrica/vespertina
nivel: 4
fabrica: Vespertina Mecânica Fina
custo_estresse: 0
pdf_page: 36
jogo: O Peso do Céu
---

# Aletas de Manobra

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=36|Consultar Texto Original no PDF (Página 36) — Peça Aletas de Manobra (Vespertina Mecânica Fina)]]**

*Nível 4 · Fixa · sempre ligada · [[Vespertina Mecânica Fina]]*

---

Altura deixa de ser distância: você sobe, desce e atravessa vão como se fosse chão plano.

---

## Links Relacionados
- [[Vespertina Mecânica Fina]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
