---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/arco
nivel: 10
fabrica: Estaleiros do Arco
custo_estresse: 2
pdf_page: 41
jogo: O Peso do Céu
---

# A Fossa

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=41|Consultar Texto Original no PDF (Página 41) — Peça A Fossa (Estaleiros do Arco)]]**

*Nível 10 · Ativa · 2 Estresse · [[Estaleiros do Arco]]*

---

Uma vez por sortida: leve um alvo com você para baixo. Vocês dois saem da cena por uma cena inteira. Lá embaixo há vocês dois, a pressão, e o que houver no fundo.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **2 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Estaleiros do Arco]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
