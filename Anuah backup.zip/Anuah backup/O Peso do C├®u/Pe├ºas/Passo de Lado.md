---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/vespertina
nivel: 1
fabrica: Vespertina Mecânica Fina
custo_estresse: 1
pdf_page: 36
jogo: O Peso do Céu
---

# Passo de Lado

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=36|Consultar Texto Original no PDF (Página 36) — Peça Passo de Lado (Vespertina Mecânica Fina)]]**

*Nível 1 · Ativa · 1 Estresse · [[Vespertina Mecânica Fina]]*

---

Quando alguém declara um ataque contra você e antes de rolar, mude de posição: o ataque erra, e você descreve por onde passou.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **1 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Vespertina Mecânica Fina]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
