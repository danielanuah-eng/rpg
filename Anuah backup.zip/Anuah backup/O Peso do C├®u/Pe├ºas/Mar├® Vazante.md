---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/arco
nivel: 5
fabrica: Estaleiros do Arco
custo_estresse: 2
pdf_page: 40
jogo: O Peso do Céu
---

# Maré Vazante

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=40|Consultar Texto Original no PDF (Página 40) — Peça Maré Vazante (Estaleiros do Arco)]]**

*Nível 5 · Ativa · 2 Estresse · [[Estaleiros do Arco]]*

---

A água recua de um lugar e volta na sua próxima ação. Quem estava lá fica **Restrito** no lodo e sofre `3d10` quando ela volta.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **2 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Estaleiros do Arco]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
