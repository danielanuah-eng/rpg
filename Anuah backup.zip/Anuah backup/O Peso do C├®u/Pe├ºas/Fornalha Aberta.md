---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/tensa
  - fabrica/brasa
nivel: 2
fabrica: Companhia Brasa e Filhos
custo_estresse: 4
pdf_page: 34
jogo: O Peso do Céu
---

# Fornalha Aberta

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=34|Consultar Texto Original no PDF (Página 34) — Peça Fornalha Aberta (Companhia Brasa e Filhos)]]**

*Nível 2 · Tensa · liga com 4+ de Medo na mesa · [[Companhia Brasa e Filhos]]*

---

O seu Setor fica quente. Todo adversário que começar a ação em Muito Perto de você marca 1 Estresse.

> [!WARNING] Peça Tensa
> Não custa nada, mas só funciona enquanto o Mestre tiver **4 ou mais de Medo**. Ele não pode gastar Medo só para desligar a Peça — mas se o gasto tem efeito na ficção, ela apaga junto. Ver [[O Medo]].

---

## Links Relacionados
- [[Companhia Brasa e Filhos]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
