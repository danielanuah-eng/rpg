---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/fixa
  - fabrica/gralha
nivel: 3
fabrica: Oficinas Gralha
custo_estresse: 0
pdf_page: 42
jogo: O Peso do Céu
---

# Mão Torta

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=42|Consultar Texto Original no PDF (Página 42) — Peça Mão Torta (Oficinas Gralha)]]**

*Nível 3 · Fixa · sempre ligada · [[Oficinas Gralha]]*

---

Você pode usar qualquer arma de colosso que encontrar, sem instalar e sem licença. Ela quebra no fim da cena.

---

## Links Relacionados
- [[Oficinas Gralha]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
