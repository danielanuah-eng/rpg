---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/brasa
nivel: 4
fabrica: Companhia Brasa e Filhos
custo_estresse: 2
pdf_page: 35
jogo: O Peso do Céu
---

# Purga de Vapor

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=35|Consultar Texto Original no PDF (Página 35) — Peça Purga de Vapor (Companhia Brasa e Filhos)]]**

*Nível 4 · Ativa · 2 Estresse · [[Companhia Brasa e Filhos]]*

---

Encha um Setor de vapor. Todos ali ficam **Ocultos** e **Cegos** até o fim da cena, você inclusive — a não ser que tenha a **Esfera de Leitura**.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **2 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Companhia Brasa e Filhos]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
