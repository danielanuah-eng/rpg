---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/tensa
  - fabrica/arco
nivel: 6
fabrica: Estaleiros do Arco
custo_estresse: 4
pdf_page: 41
jogo: O Peso do Céu
---

# Trocador de Fundo

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=41|Consultar Texto Original no PDF (Página 41) — Peça Trocador de Fundo (Estaleiros do Arco)]]**

*Nível 6 · Tensa · liga com 4+ de Medo na mesa · [[Estaleiros do Arco]]*

---

Enquanto ligada, você limpa **1 Estresse** no fim de cada cena passada dentro d'água.

> [!WARNING] Peça Tensa
> Não custa nada, mas só funciona enquanto o Mestre tiver **4 ou mais de Medo**. Ele não pode gastar Medo só para desligar a Peça — mas se o gasto tem efeito na ficção, ela apaga junto. Ver [[O Medo]].

---

## Links Relacionados
- [[Estaleiros do Arco]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
