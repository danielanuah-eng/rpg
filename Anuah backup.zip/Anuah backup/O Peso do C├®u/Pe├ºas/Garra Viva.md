---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/fixa
  - fabrica/ossatura
nivel: 1
fabrica: Ossatura
custo_estresse: 0
pdf_page: 48
jogo: O Peso do Céu
---

# Garra Viva

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=48|Consultar Texto Original no PDF (Página 48) — Peça Garra Viva (Ossatura)]]**

*Nível 1 · Fixa · sempre ligada · [[Ossatura]]*

---

Um ataque corpo a corpo que não ocupa arma nenhuma: `d10` por Proficiência, **+3**. Em um acerto, o alvo fica **Restrito**.

---

## Links Relacionados
- [[Ossatura]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
