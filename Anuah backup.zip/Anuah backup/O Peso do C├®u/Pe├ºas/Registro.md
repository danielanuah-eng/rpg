---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/fixa
  - fabrica/selo
nivel: 3
fabrica: Selo Civil
custo_estresse: 0
pdf_page: 44
jogo: O Peso do Céu
---

# Registro

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=44|Consultar Texto Original no PDF (Página 44) — Peça Registro (Selo Civil)]]**

*Nível 3 · Fixa · sempre ligada · [[Selo Civil]]*

---

Tudo que os seus sensores pegam fica gravado, com hora e lugar. Uma vez por cena, o Mestre responde com a verdade a uma pergunta sobre algo que você olhou.

---

## Links Relacionados
- [[Selo Civil]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
