---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/catedral
nivel: 1
fabrica: Fundição Catedral
custo_estresse: 1
pdf_page: 38
jogo: O Peso do Céu
---

# Véu de Luz

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=38|Consultar Texto Original no PDF (Página 38) — Peça Véu de Luz (Fundição Catedral)]]**

*Nível 1 · Ativa · 1 Estresse · [[Fundição Catedral]]*

---

Reduza um dano que você ou um aliado em Perto acabou de sofrer em **um degrau**. Três vezes por sortida.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **1 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Fundição Catedral]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
