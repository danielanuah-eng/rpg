---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/fixa
  - fabrica/vespertina
nivel: 1
fabrica: Vespertina Mecânica Fina
custo_estresse: 0
pdf_page: 36
jogo: O Peso do Céu
---

# Patim de Competição

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=36|Consultar Texto Original no PDF (Página 36) — Peça Patim de Competição (Vespertina Mecânica Fina)]]**

*Nível 1 · Fixa · sempre ligada · [[Vespertina Mecânica Fina]]*

---

**+1 Deslocamento.** Em piso duro você atravessa duas faixas de alcance com uma ação.

---

## Links Relacionados
- [[Vespertina Mecânica Fina]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
