---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/tensa
  - fabrica/ossatura
nivel: 7
fabrica: Ossatura
custo_estresse: 4
pdf_page: 49
jogo: O Peso do Céu
---

# Sangue Alto

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=49|Consultar Texto Original no PDF (Página 49) — Peça Sangue Alto (Ossatura)]]**

*Nível 7 · Tensa · liga com 4+ de Medo na mesa · [[Ossatura]]*

---

Enquanto ligada, os seus ataques somam **+1d10** de dano. A máquina gosta quando a coisa está feia.

> [!WARNING] Peça Tensa
> Não custa nada, mas só funciona enquanto o Mestre tiver **4 ou mais de Medo**. Ele não pode gastar Medo só para desligar a Peça — mas se o gasto tem efeito na ficção, ela apaga junto. Ver [[O Medo]].

---

## Links Relacionados
- [[Ossatura]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
