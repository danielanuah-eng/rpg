---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/selo
nivel: 9
fabrica: Selo Civil
custo_estresse: 2
pdf_page: 45
jogo: O Peso do Céu
---

# Apreensão

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=45|Consultar Texto Original no PDF (Página 45) — Peça Apreensão (Selo Civil)]]**

*Nível 9 · Ativa · 2 Estresse · [[Selo Civil]]*

---

Um alvo **Restrito** de Escalão igual ou inferior ao seu sai da cena: está preso, desarmado e é problema seu agora.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **2 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Selo Civil]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
