---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/gralha
nivel: 10
fabrica: Oficinas Gralha
custo_estresse: 2
pdf_page: 43
jogo: O Peso do Céu
---

# A Gralha

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=43|Consultar Texto Original no PDF (Página 43) — Peça A Gralha (Oficinas Gralha)]]**

*Nível 10 · Ativa · 2 Estresse · [[Oficinas Gralha]]*

---

Uma vez por sortida: monte, agora, na frente de todo mundo, uma Peça que você não tem. Ela funciona por uma cena e depois vira sucata. O Mestre escolhe qual Peça de que fábrica — e nunca é exatamente a que você queria.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **2 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Oficinas Gralha]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
