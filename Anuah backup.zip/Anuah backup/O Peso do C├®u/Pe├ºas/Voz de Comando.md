---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/catedral
nivel: 2
fabrica: Fundição Catedral
custo_estresse: 1
pdf_page: 38
jogo: O Peso do Céu
---

# Voz de Comando

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=38|Consultar Texto Original no PDF (Página 38) — Peça Voz de Comando (Fundição Catedral)]]**

*Nível 2 · Ativa · 1 Estresse · [[Fundição Catedral]]*

---

Um aliado que você consiga ver age imediatamente, com vantagem.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **1 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Fundição Catedral]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
