---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/vespertina
nivel: 9
fabrica: Vespertina Mecânica Fina
custo_estresse: 2
pdf_page: 37
jogo: O Peso do Céu
---

# Noite Portátil

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=37|Consultar Texto Original no PDF (Página 37) — Peça Noite Portátil (Vespertina Mecânica Fina)]]**

*Nível 9 · Ativa · 2 Estresse · [[Vespertina Mecânica Fina]]*

---

A cena escurece. Todos ficam **Cegos** até o fim da cena, menos você e quem você tocar antes de usar.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **2 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Vespertina Mecânica Fina]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
