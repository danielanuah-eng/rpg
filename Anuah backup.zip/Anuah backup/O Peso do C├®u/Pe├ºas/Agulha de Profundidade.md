---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/fixa
  - fabrica/arco
nivel: 4
fabrica: Estaleiros do Arco
custo_estresse: 0
pdf_page: 40
jogo: O Peso do Céu
---

# Agulha de Profundidade

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=40|Consultar Texto Original no PDF (Página 40) — Peça Agulha de Profundidade (Estaleiros do Arco)]]**

*Nível 4 · Fixa · sempre ligada · [[Estaleiros do Arco]]*

---

Suas armas não perdem alcance na água, e contra alvos submersos o dano sobe **um degrau**.

---

## Links Relacionados
- [[Estaleiros do Arco]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
