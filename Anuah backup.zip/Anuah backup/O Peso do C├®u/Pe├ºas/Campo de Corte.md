---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/tensa
  - fabrica/vespertina
nivel: 4
fabrica: Vespertina Mecânica Fina
custo_estresse: 4
pdf_page: 36
jogo: O Peso do Céu
---

# Campo de Corte

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=36|Consultar Texto Original no PDF (Página 36) — Peça Campo de Corte (Vespertina Mecânica Fina)]]**

*Nível 4 · Tensa · liga com 4+ de Medo na mesa · [[Vespertina Mecânica Fina]]*

---

Enquanto ligada, os seus ataques ignoram **1 Blindagem** e cobertura leve.

> [!WARNING] Peça Tensa
> Não custa nada, mas só funciona enquanto o Mestre tiver **4 ou mais de Medo**. Ele não pode gastar Medo só para desligar a Peça — mas se o gasto tem efeito na ficção, ela apaga junto. Ver [[O Medo]].

---

## Links Relacionados
- [[Vespertina Mecânica Fina]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
