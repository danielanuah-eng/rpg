---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/arco
nivel: 9
fabrica: Estaleiros do Arco
custo_estresse: 2
pdf_page: 41
jogo: O Peso do Céu
---

# Olho do Redemoinho

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=41|Consultar Texto Original no PDF (Página 41) — Peça Olho do Redemoinho (Estaleiros do Arco)]]**

*Nível 9 · Ativa · 2 Estresse · [[Estaleiros do Arco]]*

---

Abra um funil de água. Tudo dentro fica **Restrito** e sofre `2d10` por ação. Você anda lá dentro como se fosse chão.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **2 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Estaleiros do Arco]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
