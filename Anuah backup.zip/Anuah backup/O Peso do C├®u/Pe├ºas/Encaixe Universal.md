---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/fixa
  - fabrica/gralha
nivel: 1
fabrica: Oficinas Gralha
custo_estresse: 0
pdf_page: 42
jogo: O Peso do Céu
---

# Encaixe Universal

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=42|Consultar Texto Original no PDF (Página 42) — Peça Encaixe Universal (Oficinas Gralha)]]**

*Nível 1 · Fixa · sempre ligada · [[Oficinas Gralha]]*

---

**+1 encaixe** no chassi. Você pode instalar Peças de qualquer fábrica em que tenha licença, sem restrição de casco.

---

## Links Relacionados
- [[Oficinas Gralha]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
