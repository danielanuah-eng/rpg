---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/catedral
nivel: 5
fabrica: Fundição Catedral
custo_estresse: 1
pdf_page: 38
jogo: O Peso do Céu
---

# Formar

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=38|Consultar Texto Original no PDF (Página 38) — Peça Formar (Fundição Catedral)]]**

*Nível 5 · Ativa · 1 Estresse · [[Fundição Catedral]]*

---

Todo aliado em até Longe ganha **1 Blindagem** até o fim da cena.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **1 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Fundição Catedral]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
