---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/fixa
  - fabrica/carvao
nivel: 3
fabrica: Carvão
custo_estresse: 0
pdf_page: 46
jogo: O Peso do Céu
---

# Mercado

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=46|Consultar Texto Original no PDF (Página 46) — Peça Mercado (Carvão)]]**

*Nível 3 · Fixa · sempre ligada · [[Carvão]]*

---

Você conhece alguém em qualquer cidade. Uma vez por sessão, consiga um item, uma informação ou uma saída — e fique devendo.

---

## Links Relacionados
- [[Carvão]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
