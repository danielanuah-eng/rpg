---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/vespertina
nivel: 6
fabrica: Vespertina Mecânica Fina
custo_estresse: 1
pdf_page: 37
jogo: O Peso do Céu
---

# Eco Falso

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=37|Consultar Texto Original no PDF (Página 37) — Peça Eco Falso (Vespertina Mecânica Fina)]]**

*Nível 6 · Ativa · 1 Estresse · [[Vespertina Mecânica Fina]]*

---

Deixe um eco seu onde estava. Até a sua próxima ação, quem quiser te atacar precisa acertar qual dos dois é você (Dificuldade 15).

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **1 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Vespertina Mecânica Fina]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
