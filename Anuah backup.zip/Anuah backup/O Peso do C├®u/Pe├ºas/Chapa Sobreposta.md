---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/fixa
  - fabrica/brasa
nivel: 1
fabrica: Companhia Brasa e Filhos
custo_estresse: 0
pdf_page: 34
jogo: O Peso do Céu
---

# Chapa Sobreposta

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=34|Consultar Texto Original no PDF (Página 34) — Peça Chapa Sobreposta (Companhia Brasa e Filhos)]]**

*Nível 1 · Fixa · sempre ligada · [[Companhia Brasa e Filhos]]*

---

**+1 Blindagem.** O casco ganha uma camada a mais de chapa parafusada por fora, e um barulho característico quando anda.

---

## Links Relacionados
- [[Companhia Brasa e Filhos]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
