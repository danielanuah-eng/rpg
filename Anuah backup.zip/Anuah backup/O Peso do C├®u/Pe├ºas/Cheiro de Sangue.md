---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/fixa
  - fabrica/ossatura
nivel: 2
fabrica: Ossatura
custo_estresse: 0
pdf_page: 48
jogo: O Peso do Céu
---

# Cheiro de Sangue

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=48|Consultar Texto Original no PDF (Página 48) — Peça Cheiro de Sangue (Ossatura)]]**

*Nível 2 · Fixa · sempre ligada · [[Ossatura]]*

---

Você sempre sabe onde está a coisa mais ferida da cena, e seus ataques contra ela têm vantagem.

---

## Links Relacionados
- [[Ossatura]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
