---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/vespertina
nivel: 3
fabrica: Vespertina Mecânica Fina
custo_estresse: 1
pdf_page: 36
jogo: O Peso do Céu
---

# Rasante

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=36|Consultar Texto Original no PDF (Página 36) — Peça Rasante (Vespertina Mecânica Fina)]]**

*Nível 3 · Ativa · 1 Estresse · [[Vespertina Mecânica Fina]]*

---

Atravesse até três faixas de alcance em linha reta e ataque no fim. Quem estiver no caminho rola **Agilidade** ou é derrubado.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **1 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Vespertina Mecânica Fina]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
