---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/ativa
  - fabrica/gralha
nivel: 4
fabrica: Oficinas Gralha
custo_estresse: 1
pdf_page: 42
jogo: O Peso do Céu
---

# Reator Remendado

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=42|Consultar Texto Original no PDF (Página 42) — Peça Reator Remendado (Oficinas Gralha)]]**

*Nível 4 · Ativa · 1 Estresse · [[Oficinas Gralha]]*

---

Limpe **3 Estresse**. Role `1d6`: com 1, marque também 1 Estrutura. O remendo cobra.

> [!NOTE] Peça Ativa
> Usar é uma ação e custa **1 Estresse**. Quem paga é o corpo do piloto — ver [[Estresse]].

---

## Links Relacionados
- [[Oficinas Gralha]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
