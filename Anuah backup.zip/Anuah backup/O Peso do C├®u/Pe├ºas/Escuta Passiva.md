---
tipo: Peça
categoria: Peça de fábrica
tags:
  - peso-do-ceu
  - peca
  - peca/fixa
  - fabrica/selo
nivel: 2
fabrica: Selo Civil
custo_estresse: 0
pdf_page: 44
jogo: O Peso do Céu
---

# Escuta Passiva

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=44|Consultar Texto Original no PDF (Página 44) — Peça Escuta Passiva (Selo Civil)]]**

*Nível 2 · Fixa · sempre ligada · [[Selo Civil]]*

---

Você sabe quantas coisas existem em cada direção e de que tamanho elas são, mesmo através de parede. Não sabe quem são.

---

## Links Relacionados
- [[Selo Civil]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
