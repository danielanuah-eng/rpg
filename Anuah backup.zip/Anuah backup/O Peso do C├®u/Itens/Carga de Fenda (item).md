---
tipo: Item
categoria: Arma de piloto
tags:
  - peso-do-ceu
  - item
  - arma
traco: Conhecimento
alcance: Corpo a corpo
pdf_page: 46
jogo: O Peso do Céu
---

# Carga de Fenda (item)

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=46|Consultar Texto Original no PDF (Página 46) — Arma Carga de Fenda]]**

*Conhecimento · Corpo a corpo · `d12+2`*  
**Antimáquina**

---

Feita para casco, não para gente. Plantar leva uma ação inteira. Uma por sortida.

> [!IMPORTANT] Antimáquina
> Cancela o debuff de gente contra colosso: rolagem normal e dano cheio. Ver [[Escala]].

---

## Links Relacionados
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
