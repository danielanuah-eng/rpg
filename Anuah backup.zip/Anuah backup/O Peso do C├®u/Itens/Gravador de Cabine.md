---
tipo: Item
categoria: Mecânico
tags:
  - peso-do-ceu
  - item
  - mecanico
  - fabrica/selo
usos: —
fabrica: Selo Civil
pdf_page: 58
jogo: O Peso do Céu
---

# Gravador de Cabine

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=58|Consultar Texto Original no PDF (Página 58) — Item mecânico Gravador de Cabine]]**

*— · saiu da [[Selo Civil]]*

---

Grava tudo que se disse e se fez dentro do casco. Já condenou mais gente do que qualquer testemunha.

---

## Links Relacionados
- [[Selo Civil]]
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
