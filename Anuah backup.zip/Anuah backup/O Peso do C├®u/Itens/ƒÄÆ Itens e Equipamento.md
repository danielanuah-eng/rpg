---
tipo: Hub
categoria: MOC
tags:
  - peso-do-ceu
  - moc
  - hub
jogo: O Peso do Céu
---

# 🎒 Itens e equipamento

Armas para o piloto, trajes, ferramentas de fábrica e as coisas que ninguém sabe explicar.

---

## Armas de piloto

- [[Pistola de Cabine]] — Finesse · Perto · `d6+1`
- [[Revólver Pesado]] — Finesse · Perto · `d8+1`
- [[Carabina Curta]] — Agilidade · Longe · `d8+2`
- [[Rifle de Ferrolho]] — Finesse · Muito Longe · `d10+2`
- [[Rifle Antimaterial]] — Finesse · Muito Longe · `d10+2` · **Antimáquina**
- [[Escopeta Serrada]] — Agilidade · Muito Perto · `d10+2`
- [[Metralhadora Leve]] — Força · Longe · `d6+2`
- [[Faca de Cabine]] — Finesse · Corpo a corpo · `d8+1`
- [[Bastão de Patrulha]] — Força · Corpo a corpo · `d8+1`
- [[Machadinha]] — Força · Corpo a corpo · `d10+1`
- [[Chave de Aperto]] — Força · Corpo a corpo · `d8+1`
- [[Lança-Cabos]] — Agilidade · Longe · `d6+1`
- [[Espingarda de Sinal]] — Instinto · Longe · `d6+1`
- [[Carga de Fenda (item)]] — Conhecimento · Corpo a corpo · `d12+2` · **Antimáquina**
- [[Lança de Fenda]] — Força · Corpo a corpo · `d10+2` · **Antimáquina**
- [[Granada de Concussão]] — Agilidade · Perto · `d8+1`
- [[Soqueira de Doca]] — Força · Corpo a corpo · `d6+1`
- [[Punho Nu]] — Força · Corpo a corpo · `d4+0`

## Trajes

- [[Macacão de Voo]] — Blindagem 1 · limiares 5 / 10
- [[Colete de Estilhaço]] — Blindagem 2 · limiares 6 / 12
- [[Traje de Pressão]] — Blindagem 2 · limiares 6 / 11
- [[Casaco de Patrulha]] — Blindagem 1 · limiares 6 / 11
- [[Placa de Doca]] — Blindagem 3 · limiares 7 / 13
- [[Traje Selado do Arco]] — Blindagem 2 · limiares 7 / 12
- [[Nada]] — Blindagem 0 · limiares 4 / 9

## Mecânicos

- [[Kit de Solda Rápida]] — 3 usos · [[Companhia Brasa e Filhos]]
- [[Cilindro de Argônio]] — 1 uso · [[Companhia Brasa e Filhos]]
- [[Macaco de Doca]] — — · [[Companhia Brasa e Filhos]]
- [[Talha de Corrente]] — — · [[Companhia Brasa e Filhos]]
- [[Célula Reserva]] — 2 usos · [[Vespertina Mecânica Fina]]
- [[Lâmina de Reposição]] — — · [[Vespertina Mecânica Fina]]
- [[Ampola de Calma]] — 3 usos · [[Vespertina Mecânica Fina]]
- [[Selo de Abóbada]] — 1 uso · [[Fundição Catedral]]
- [[Brasão Emprestado]] — — · [[Fundição Catedral]]
- [[Fumígeno de Linha]] — 4 usos · [[Fundição Catedral]]
- [[Boia de Sonar]] — — · [[Estaleiros do Arco]]
- [[Ampola de Ar]] — 2 usos · [[Estaleiros do Arco]]
- [[Casco de Emergência]] — 1 uso · [[Estaleiros do Arco]]
- [[Caixa de Encaixe]] — — · [[Oficinas Gralha]]
- [[Adaptador Universal]] — — · [[Oficinas Gralha]]
- [[Fita de Doca]] — — · [[Oficinas Gralha]]
- [[Marcador Orbital]] — 2 usos · [[Selo Civil]]
- [[Algema de Casco]] — — · [[Selo Civil]]
- [[Gravador de Cabine]] — — · [[Selo Civil]]
- [[Placa Falsa]] — — · [[Carvão]]
- [[Pó de Fenda]] — 2 usos · [[Carvão]]
- [[Chave Dupla]] — — · [[Carvão]]
- [[Frasco de Enxerto]] — 1 uso · [[Ossatura]]
- [[Osso de Funda]] — — · [[Ossatura]]
- [[Reparo de Campo]] — 3 usos
- [[Rádio de Campanha]] — —
- [[Binóculo de Cota]] — —
- [[Lanterna de Doca]] — —

## Estranhos

- [[Bússola de Funda]] — Incomum
- [[Vidro de Maré]] — Incomum
- [[Prego do Estaleiro]] — Incomum
- [[Dente Que Cresce]] — Incomum
- [[Carta Sem Remetente]] — Incomum
- [[Rádio da Frequência Vazia]] — Raro
- [[Casaco do Piloto Morto]] — Raro
- [[Olho Guardado]] — Raro
- [[Chave de Porta Nenhuma]] — Raro
- [[Medalha de Ninguém]] — Raro
- [[Caderno do Engenheiro]] — Raro
- [[Areia da Fossa]] — Raro
- [[Coração de Reator]] — Muito raro
- [[Placa do Primeiro Casco]] — Muito raro
- [[Semente Dormindo]] — Muito raro
- [[O Manual]] — Muito raro

---

[[🛰️ O Peso do Céu|⬅ Voltar]]
