---
tipo: Item
categoria: Arma de piloto
tags:
  - peso-do-ceu
  - item
  - arma
traco: Força
alcance: Longe
pdf_page: 56
jogo: O Peso do Céu
---

# Metralhadora Leve

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=56|Consultar Texto Original no PDF (Página 56) — Arma Metralhadora Leve]]**

*Força · Longe · `d6+2`*

---

Acerta todos em uma linha. Você fica **Instável** ao disparar.

---

## Links Relacionados
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
