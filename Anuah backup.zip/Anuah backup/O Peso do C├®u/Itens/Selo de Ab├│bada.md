---
tipo: Item
categoria: Mecânico
tags:
  - peso-do-ceu
  - item
  - mecanico
  - fabrica/catedral
usos: 1 uso
fabrica: Fundição Catedral
pdf_page: 57
jogo: O Peso do Céu
---

# Selo de Abóbada

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=57|Consultar Texto Original no PDF (Página 57) — Item mecânico Selo de Abóbada]]**

*1 uso · saiu da [[Fundição Catedral]]*

---

Uma reação: um golpe que ia acertar você ou um aliado em Perto simplesmente não acerta.

---

## Links Relacionados
- [[Fundição Catedral]]
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
