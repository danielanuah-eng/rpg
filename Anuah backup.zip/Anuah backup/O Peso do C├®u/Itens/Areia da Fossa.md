---
tipo: Item
categoria: Estranho
tags:
  - peso-do-ceu
  - item
  - estranho
raridade: Raro
pdf_page: 59
jogo: O Peso do Céu
---

# Areia da Fossa

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=59|Consultar Texto Original no PDF (Página 59) — Item estranho Areia da Fossa]]**

*Raro · ninguém sabe de onde veio*

---

Um saquinho. Jogada no chão, aquele lugar fica escuro como fundo de mar por uma cena. Você enxerga lá dentro; mais ninguém.

---

## Links Relacionados
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
