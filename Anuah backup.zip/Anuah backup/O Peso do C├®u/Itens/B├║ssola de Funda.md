---
tipo: Item
categoria: Estranho
tags:
  - peso-do-ceu
  - item
  - estranho
raridade: Incomum
pdf_page: 58
jogo: O Peso do Céu
---

# Bússola de Funda

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=58|Consultar Texto Original no PDF (Página 58) — Item estranho Bússola de Funda]]**

*Incomum · ninguém sabe de onde veio*

---

A agulha aponta para a Funda mais próxima, sempre, e gira mais depressa quanto mais perto. Nunca aponta para o norte.

---

## Links Relacionados
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
