---
tipo: Item
categoria: Mecânico
tags:
  - peso-do-ceu
  - item
  - mecanico
  - fabrica/gralha
usos: —
fabrica: Oficinas Gralha
pdf_page: 58
jogo: O Peso do Céu
---

# Adaptador Universal

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=58|Consultar Texto Original no PDF (Página 58) — Item mecânico Adaptador Universal]]**

*— · saiu da [[Oficinas Gralha]]*

---

Você pode instalar uma Peça de uma fábrica em que *não* tem licença. Ela falha com 1 em `1d6` toda vez que for usada.

---

## Links Relacionados
- [[Oficinas Gralha]]
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
