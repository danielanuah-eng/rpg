---
tipo: Item
categoria: Arma de piloto
tags:
  - peso-do-ceu
  - item
  - arma
traco: Agilidade
alcance: Perto
pdf_page: 56
jogo: O Peso do Céu
---

# Granada de Concussão

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=56|Consultar Texto Original no PDF (Página 56) — Arma Granada de Concussão]]**

*Agilidade · Perto · `d8+1`*

---

Acerta todos no lugar. Quem for atingido fica **Instável**. Duas por sortida.

---

## Links Relacionados
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
