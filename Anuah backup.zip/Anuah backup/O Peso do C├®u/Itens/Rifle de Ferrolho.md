---
tipo: Item
categoria: Arma de piloto
tags:
  - peso-do-ceu
  - item
  - arma
traco: Finesse
alcance: Muito Longe
pdf_page: 56
jogo: O Peso do Céu
---

# Rifle de Ferrolho

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=56|Consultar Texto Original no PDF (Página 56) — Arma Rifle de Ferrolho]]**

*Finesse · Muito Longe · `d10+2`*

---

Se você não se mexeu, a rolagem tem vantagem. Um tiro por cena.

---

## Links Relacionados
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
