---
tipo: Item
categoria: Mecânico
tags:
  - peso-do-ceu
  - item
  - mecanico
  - fabrica/arco
usos: 2 usos
fabrica: Estaleiros do Arco
pdf_page: 57
jogo: O Peso do Céu
---

# Ampola de Ar

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=57|Consultar Texto Original no PDF (Página 57) — Item mecânico Ampola de Ar]]**

*2 usos · saiu da [[Estaleiros do Arco]]*

---

Dez minutos de ar respirável para uma pessoa, em qualquer lugar.

---

## Links Relacionados
- [[Estaleiros do Arco]]
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
