---
tipo: Item
categoria: Arma de piloto
tags:
  - peso-do-ceu
  - item
  - arma
traco: Força
alcance: Corpo a corpo
pdf_page: 56
jogo: O Peso do Céu
---

# Punho Nu

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=56|Consultar Texto Original no PDF (Página 56) — Arma Punho Nu]]**

*Força · Corpo a corpo · `d4+0`*

---

Sempre disponível. Dano não letal por padrão.

---

## Links Relacionados
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
