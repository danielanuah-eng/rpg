---
tipo: Item
categoria: Mecânico
tags:
  - peso-do-ceu
  - item
  - mecanico
  - fabrica/carvao
usos: 2 usos
fabrica: Carvão
pdf_page: 58
jogo: O Peso do Céu
---

# Pó de Fenda

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=58|Consultar Texto Original no PDF (Página 58) — Item mecânico Pó de Fenda]]**

*2 usos · saiu da [[Carvão]]*

---

Corta qualquer metal com uma ação e sem barulho. Abre casco, cofre e comporta.

---

## Links Relacionados
- [[Carvão]]
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
