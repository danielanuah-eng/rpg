---
tipo: Item
categoria: Mecânico
tags:
  - peso-do-ceu
  - item
  - mecanico
  - fabrica/carvao
usos: —
fabrica: Carvão
pdf_page: 58
jogo: O Peso do Céu
---

# Placa Falsa

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=58|Consultar Texto Original no PDF (Página 58) — Item mecânico Placa Falsa]]**

*— · saiu da [[Carvão]]*

---

Seu colosso passa a ser outro colosso, em qualquer registro. Vale até alguém olhar com atenção.

---

## Links Relacionados
- [[Carvão]]
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
