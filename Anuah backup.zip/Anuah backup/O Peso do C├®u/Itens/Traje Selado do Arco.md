---
tipo: Item
categoria: Traje
tags:
  - peso-do-ceu
  - item
  - traje
blindagem: 2
pdf_page: 57
jogo: O Peso do Céu
---

# Traje Selado do Arco

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=57|Consultar Texto Original no PDF (Página 57) — Traje Traje Selado do Arco]]**

*Blindagem 2 · limiares 7 / 12*

---

Feito para fundo. Você não marca Estresse por ambiente nenhum.

---

## Links Relacionados
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
