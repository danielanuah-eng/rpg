---
tipo: Item
categoria: Estranho
tags:
  - peso-do-ceu
  - item
  - estranho
raridade: Muito raro
pdf_page: 59
jogo: O Peso do Céu
---

# O Manual

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=59|Consultar Texto Original no PDF (Página 59) — Item estranho O Manual]]**

*Muito raro · ninguém sabe de onde veio*

---

Trezentas páginas de instruções para uma máquina que ninguém reconhece. Uma vez por sessão, leia uma página: você sabe fazer uma coisa que não sabia.

---

## Links Relacionados
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
