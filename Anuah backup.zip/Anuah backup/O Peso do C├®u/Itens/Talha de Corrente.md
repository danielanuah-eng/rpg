---
tipo: Item
categoria: Mecânico
tags:
  - peso-do-ceu
  - item
  - mecanico
  - fabrica/brasa
usos: —
fabrica: Companhia Brasa e Filhos
pdf_page: 57
jogo: O Peso do Céu
---

# Talha de Corrente

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=57|Consultar Texto Original no PDF (Página 57) — Item mecânico Talha de Corrente]]**

*— · saiu da [[Companhia Brasa e Filhos]]*

---

**+3** em qualquer rolagem de **Força** para levantar, puxar ou segurar alguma coisa pesada.

---

## Links Relacionados
- [[Companhia Brasa e Filhos]]
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
