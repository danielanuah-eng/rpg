---
tipo: Item
categoria: Traje
tags:
  - peso-do-ceu
  - item
  - traje
blindagem: 3
pdf_page: 57
jogo: O Peso do Céu
---

# Placa de Doca

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=57|Consultar Texto Original no PDF (Página 57) — Traje Placa de Doca]]**

*Blindagem 3 · limiares 7 / 13*

---

Improvisada com chapa de colosso. Você não corre, você anda.

---

## Links Relacionados
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
