---
tipo: Item
categoria: Arma de piloto
tags:
  - peso-do-ceu
  - item
  - arma
traco: Força
alcance: Corpo a corpo
pdf_page: 56
jogo: O Peso do Céu
---

# Lança de Fenda

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=56|Consultar Texto Original no PDF (Página 56) — Arma Lança de Fenda]]**

*Força · Corpo a corpo · `d10+2`*  
**Antimáquina**

---

Uma haste de dois metros com uma carga na ponta. Um uso, e depois é uma haste de dois metros.

> [!IMPORTANT] Antimáquina
> Cancela o debuff de gente contra colosso: rolagem normal e dano cheio. Ver [[Escala]].

---

## Links Relacionados
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
