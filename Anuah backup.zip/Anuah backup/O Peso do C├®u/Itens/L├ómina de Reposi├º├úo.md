---
tipo: Item
categoria: Mecânico
tags:
  - peso-do-ceu
  - item
  - mecanico
  - fabrica/vespertina
usos: —
fabrica: Vespertina Mecânica Fina
pdf_page: 57
jogo: O Peso do Céu
---

# Lâmina de Reposição

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=57|Consultar Texto Original no PDF (Página 57) — Item mecânico Lâmina de Reposição]]**

*— · saiu da [[Vespertina Mecânica Fina]]*

---

Uma arma corpo a corpo de colosso que cabe numa mochila. Serve uma cena e depois entorta.

---

## Links Relacionados
- [[Vespertina Mecânica Fina]]
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
