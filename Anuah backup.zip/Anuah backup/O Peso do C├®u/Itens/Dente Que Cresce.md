---
tipo: Item
categoria: Estranho
tags:
  - peso-do-ceu
  - item
  - estranho
raridade: Incomum
pdf_page: 59
jogo: O Peso do Céu
---

# Dente Que Cresce

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=59|Consultar Texto Original no PDF (Página 59) — Item estranho Dente Que Cresce]]**

*Incomum · ninguém sabe de onde veio*

---

Uma faca que fica um pouco maior toda vez que corta alguma coisa viva. Já foi uma faca de cozinha.

---

## Links Relacionados
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
