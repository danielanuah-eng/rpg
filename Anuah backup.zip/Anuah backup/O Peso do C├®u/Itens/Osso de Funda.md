---
tipo: Item
categoria: Mecânico
tags:
  - peso-do-ceu
  - item
  - mecanico
  - fabrica/ossatura
usos: —
fabrica: Ossatura
pdf_page: 58
jogo: O Peso do Céu
---

# Osso de Funda

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=58|Consultar Texto Original no PDF (Página 58) — Item mecânico Osso de Funda]]**

*— · saiu da [[Ossatura]]*

---

Uma arma corpo a corpo de colosso: `d10` por Proficiência, **+4**. Fica mais afiada quando o piloto marca Estresse.

---

## Links Relacionados
- [[Ossatura]]
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
