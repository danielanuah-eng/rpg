---
tipo: Item
categoria: Arma de piloto
tags:
  - peso-do-ceu
  - item
  - arma
traco: Agilidade
alcance: Longe
pdf_page: 56
jogo: O Peso do Céu
---

# Carabina Curta

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=56|Consultar Texto Original no PDF (Página 56) — Arma Carabina Curta]]**

*Agilidade · Longe · `d8+2`*

---

Sem desvantagem por distância até Longe.

---

## Links Relacionados
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
