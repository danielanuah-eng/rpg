---
tipo: Item
categoria: Traje
tags:
  - peso-do-ceu
  - item
  - traje
blindagem: 1
pdf_page: 57
jogo: O Peso do Céu
---

# Casaco de Patrulha

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=57|Consultar Texto Original no PDF (Página 57) — Traje Casaco de Patrulha]]**

*Blindagem 1 · limiares 6 / 11*

---

Some **+1** em **Presença** com gente uniformizada.

---

## Links Relacionados
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
