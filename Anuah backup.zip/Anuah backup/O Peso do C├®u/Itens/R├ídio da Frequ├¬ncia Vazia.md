---
tipo: Item
categoria: Estranho
tags:
  - peso-do-ceu
  - item
  - estranho
raridade: Raro
pdf_page: 59
jogo: O Peso do Céu
---

# Rádio da Frequência Vazia

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=59|Consultar Texto Original no PDF (Página 59) — Item estranho Rádio da Frequência Vazia]]**

*Raro · ninguém sabe de onde veio*

---

Sintonizado numa faixa em que ninguém transmite. Uma vez por sessão, alguém responde e diz uma coisa que ajuda.

---

## Links Relacionados
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
