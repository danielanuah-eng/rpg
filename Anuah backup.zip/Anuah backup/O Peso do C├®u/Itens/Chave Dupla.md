---
tipo: Item
categoria: Mecânico
tags:
  - peso-do-ceu
  - item
  - mecanico
  - fabrica/carvao
usos: —
fabrica: Carvão
pdf_page: 58
jogo: O Peso do Céu
---

# Chave Dupla

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=58|Consultar Texto Original no PDF (Página 58) — Item mecânico Chave Dupla]]**

*— · saiu da [[Carvão]]*

---

Abre a cabine de qualquer colosso das fábricas comuns. Não abre Catedral, e a Catedral sabe disso.

---

## Links Relacionados
- [[Carvão]]
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
