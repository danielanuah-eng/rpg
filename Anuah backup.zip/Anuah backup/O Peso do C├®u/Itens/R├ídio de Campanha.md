---
tipo: Item
categoria: Mecânico
tags:
  - peso-do-ceu
  - item
  - mecanico
usos: —
pdf_page: 58
jogo: O Peso do Céu
---

# Rádio de Campanha

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=58|Consultar Texto Original no PDF (Página 58) — Item mecânico Rádio de Campanha]]**

*— · de fábrica nenhuma — acha-se em qualquer doca*

---

Fala com qualquer um na mesma cena, e com quem estiver fora dela se houver antena de pé.

---

## Links Relacionados
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
