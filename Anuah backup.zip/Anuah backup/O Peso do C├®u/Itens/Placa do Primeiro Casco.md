---
tipo: Item
categoria: Estranho
tags:
  - peso-do-ceu
  - item
  - estranho
raridade: Muito raro
pdf_page: 59
jogo: O Peso do Céu
---

# Placa do Primeiro Casco

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=59|Consultar Texto Original no PDF (Página 59) — Item estranho Placa do Primeiro Casco]]**

*Muito raro · ninguém sabe de onde veio*

---

A placa de identificação do colosso número um, de nenhuma fábrica. Enquanto estiver instalada, o seu colosso não pode ser destruído por outro colosso — só por Funda, por queda ou por decisão sua.

---

## Links Relacionados
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
