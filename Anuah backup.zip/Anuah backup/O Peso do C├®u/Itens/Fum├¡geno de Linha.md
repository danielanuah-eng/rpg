---
tipo: Item
categoria: Mecânico
tags:
  - peso-do-ceu
  - item
  - mecanico
  - fabrica/catedral
usos: 4 usos
fabrica: Fundição Catedral
pdf_page: 57
jogo: O Peso do Céu
---

# Fumígeno de Linha

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=57|Consultar Texto Original no PDF (Página 57) — Item mecânico Fumígeno de Linha]]**

*4 usos · saiu da [[Fundição Catedral]]*

---

Uma ação: um lugar fica cheio de fumaça por uma cena.

---

## Links Relacionados
- [[Fundição Catedral]]
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
