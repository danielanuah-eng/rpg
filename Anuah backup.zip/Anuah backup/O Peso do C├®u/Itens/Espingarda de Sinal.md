---
tipo: Item
categoria: Arma de piloto
tags:
  - peso-do-ceu
  - item
  - arma
traco: Instinto
alcance: Longe
pdf_page: 56
jogo: O Peso do Céu
---

# Espingarda de Sinal

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=56|Consultar Texto Original no PDF (Página 56) — Arma Espingarda de Sinal]]**

*Instinto · Longe · `d6+1`*

---

O tiro é visto a quilômetros. Quem você quer que venha, vem.

---

## Links Relacionados
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
