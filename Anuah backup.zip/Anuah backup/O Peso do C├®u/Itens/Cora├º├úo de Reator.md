---
tipo: Item
categoria: Estranho
tags:
  - peso-do-ceu
  - item
  - estranho
raridade: Muito raro
pdf_page: 59
jogo: O Peso do Céu
---

# Coração de Reator

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=59|Consultar Texto Original no PDF (Página 59) — Item estranho Coração de Reator]]**

*Muito raro · ninguém sabe de onde veio*

---

Cabe na mão e está sempre morno. Uma vez por sortida, todas as suas Peças Ativas custam zero Estresse por uma cena.

---

## Links Relacionados
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
