---
tipo: Item
categoria: Traje
tags:
  - peso-do-ceu
  - item
  - traje
blindagem: 2
pdf_page: 57
jogo: O Peso do Céu
---

# Colete de Estilhaço

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=57|Consultar Texto Original no PDF (Página 57) — Traje Colete de Estilhaço]]**

*Blindagem 2 · limiares 6 / 12*

---

Pesado no ombro. Desvantagem em corridas longas.

---

## Links Relacionados
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
