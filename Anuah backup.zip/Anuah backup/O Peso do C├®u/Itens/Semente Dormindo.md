---
tipo: Item
categoria: Estranho
tags:
  - peso-do-ceu
  - item
  - estranho
raridade: Muito raro
pdf_page: 59
jogo: O Peso do Céu
---

# Semente Dormindo

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=59|Consultar Texto Original no PDF (Página 59) — Item estranho Semente Dormindo]]**

*Muito raro · ninguém sabe de onde veio*

---

Uma coisa viva, pequena, num vidro lacrado. Quem a carrega sonha com água. Quebrando o vidro, ela cresce, e a mesa decide junto o que isso significa — uma vez.

---

## Links Relacionados
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
