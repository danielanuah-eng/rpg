---
tipo: Item
categoria: Arma de piloto
tags:
  - peso-do-ceu
  - item
  - arma
traco: Força
alcance: Corpo a corpo
pdf_page: 56
jogo: O Peso do Céu
---

# Bastão de Patrulha

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=56|Consultar Texto Original no PDF (Página 56) — Arma Bastão de Patrulha]]**

*Força · Corpo a corpo · `d8+1`*

---

Você pode declarar o dano como não letal sem perder nada.

---

## Links Relacionados
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
