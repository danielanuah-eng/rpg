---
tipo: Item
categoria: Estranho
tags:
  - peso-do-ceu
  - item
  - estranho
raridade: Raro
pdf_page: 59
jogo: O Peso do Céu
---

# Chave de Porta Nenhuma

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=59|Consultar Texto Original no PDF (Página 59) — Item estranho Chave de Porta Nenhuma]]**

*Raro · ninguém sabe de onde veio*

---

Abre uma porta por sessão. Qualquer porta, em qualquer lugar do mundo. Do outro lado é sempre o mesmo corredor.

---

## Links Relacionados
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
