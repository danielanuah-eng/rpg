---
tipo: Item
categoria: Arma de piloto
tags:
  - peso-do-ceu
  - item
  - arma
traco: Finesse
alcance: Corpo a corpo
pdf_page: 56
jogo: O Peso do Céu
---

# Faca de Cabine

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=56|Consultar Texto Original no PDF (Página 56) — Arma Faca de Cabine]]**

*Finesse · Corpo a corpo · `d8+1`*

---

Em um Crítico, o alvo não consegue gritar nesta cena.

---

## Links Relacionados
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
