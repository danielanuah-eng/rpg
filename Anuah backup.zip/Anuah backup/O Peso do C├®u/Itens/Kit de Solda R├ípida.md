---
tipo: Item
categoria: Mecânico
tags:
  - peso-do-ceu
  - item
  - mecanico
  - fabrica/brasa
usos: 3 usos
fabrica: Companhia Brasa e Filhos
pdf_page: 57
jogo: O Peso do Céu
---

# Kit de Solda Rápida

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=57|Consultar Texto Original no PDF (Página 57) — Item mecânico Kit de Solda Rápida]]**

*3 usos · saiu da [[Companhia Brasa e Filhos]]*

---

Uma ação: limpe 2 Estrutura de qualquer colosso que você alcance, de dentro ou de fora dele.

---

## Links Relacionados
- [[Companhia Brasa e Filhos]]
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
