---
tipo: Item
categoria: Arma de piloto
tags:
  - peso-do-ceu
  - item
  - arma
traco: Finesse
alcance: Perto
pdf_page: 56
jogo: O Peso do Céu
---

# Revólver Pesado

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=56|Consultar Texto Original no PDF (Página 56) — Arma Revólver Pesado]]**

*Finesse · Perto · `d8+1`*

---

Em um Crítico, o alvo fica **Vulnerável**.

---

## Links Relacionados
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
