---
tipo: Item
categoria: Traje
tags:
  - peso-do-ceu
  - item
  - traje
blindagem: 0
pdf_page: 57
jogo: O Peso do Céu
---

# Nada

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=57|Consultar Texto Original no PDF (Página 57) — Traje Nada]]**

*Blindagem 0 · limiares 4 / 9*

---

É uma opção. Costuma ser uma opção ruim.

---

## Links Relacionados
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
