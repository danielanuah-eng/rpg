---
tipo: Item
categoria: Estranho
tags:
  - peso-do-ceu
  - item
  - estranho
raridade: Incomum
pdf_page: 59
jogo: O Peso do Céu
---

# Carta Sem Remetente

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=59|Consultar Texto Original no PDF (Página 59) — Item estranho Carta Sem Remetente]]**

*Incomum · ninguém sabe de onde veio*

---

Chega toda manhã, endereçada a você, com uma frase verdadeira sobre o dia que vem. Nunca a mais útil.

---

## Links Relacionados
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
