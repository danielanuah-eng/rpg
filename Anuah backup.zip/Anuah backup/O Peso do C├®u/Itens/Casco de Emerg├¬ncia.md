---
tipo: Item
categoria: Mecânico
tags:
  - peso-do-ceu
  - item
  - mecanico
  - fabrica/arco
usos: 1 uso
fabrica: Estaleiros do Arco
pdf_page: 57
jogo: O Peso do Céu
---

# Casco de Emergência

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=57|Consultar Texto Original no PDF (Página 57) — Item mecânico Casco de Emergência]]**

*1 uso · saiu da [[Estaleiros do Arco]]*

---

Sela um colosso furado por uma cena. Funciona debaixo d'água.

---

## Links Relacionados
- [[Estaleiros do Arco]]
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
