---
tipo: Item
categoria: Mecânico
tags:
  - peso-do-ceu
  - item
  - mecanico
usos: —
pdf_page: 58
jogo: O Peso do Céu
---

# Binóculo de Cota

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=58|Consultar Texto Original no PDF (Página 58) — Item mecânico Binóculo de Cota]]**

*— · de fábrica nenhuma — acha-se em qualquer doca*

---

**+2** em rolagens para observar de longe, e você identifica fábrica e modelo de qualquer colosso que veja.

---

## Links Relacionados
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
