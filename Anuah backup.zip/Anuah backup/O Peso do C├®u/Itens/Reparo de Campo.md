---
tipo: Item
categoria: Mecânico
tags:
  - peso-do-ceu
  - item
  - mecanico
usos: 3 usos
pdf_page: 58
jogo: O Peso do Céu
---

# Reparo de Campo

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=58|Consultar Texto Original no PDF (Página 58) — Item mecânico Reparo de Campo]]**

*3 usos · de fábrica nenhuma — acha-se em qualquer doca*

---

Uma ação numa Parada Curta: limpe 3 Estrutura, ou desfaça uma Avaria.

---

## Links Relacionados
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
