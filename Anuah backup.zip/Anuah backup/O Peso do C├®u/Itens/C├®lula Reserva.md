---
tipo: Item
categoria: Mecânico
tags:
  - peso-do-ceu
  - item
  - mecanico
  - fabrica/vespertina
usos: 2 usos
fabrica: Vespertina Mecânica Fina
pdf_page: 57
jogo: O Peso do Céu
---

# Célula Reserva

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=57|Consultar Texto Original no PDF (Página 57) — Item mecânico Célula Reserva]]**

*2 usos · saiu da [[Vespertina Mecânica Fina]]*

---

Uma reação: use uma Peça Ativa sem marcar Estresse.

---

## Links Relacionados
- [[Vespertina Mecânica Fina]]
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
