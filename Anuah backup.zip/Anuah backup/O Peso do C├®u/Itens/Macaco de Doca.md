---
tipo: Item
categoria: Mecânico
tags:
  - peso-do-ceu
  - item
  - mecanico
  - fabrica/brasa
usos: —
fabrica: Companhia Brasa e Filhos
pdf_page: 57
jogo: O Peso do Céu
---

# Macaco de Doca

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=57|Consultar Texto Original no PDF (Página 57) — Item mecânico Macaco de Doca]]**

*— · saiu da [[Companhia Brasa e Filhos]]*

---

Levanta um colosso caído em uma ação, sem rolagem. Pesa o que pesa um carro pequeno.

---

## Links Relacionados
- [[Companhia Brasa e Filhos]]
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
