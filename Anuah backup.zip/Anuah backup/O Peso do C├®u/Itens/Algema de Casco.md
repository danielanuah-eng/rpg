---
tipo: Item
categoria: Mecânico
tags:
  - peso-do-ceu
  - item
  - mecanico
  - fabrica/selo
usos: —
fabrica: Selo Civil
pdf_page: 58
jogo: O Peso do Céu
---

# Algema de Casco

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=58|Consultar Texto Original no PDF (Página 58) — Item mecânico Algema de Casco]]**

*— · saiu da [[Selo Civil]]*

---

Prende um colosso **Inerte**. Só abre com a chave, ou com uma rolagem de **Força** Dificuldade 18.

---

## Links Relacionados
- [[Selo Civil]]
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
