---
tipo: Item
categoria: Estranho
tags:
  - peso-do-ceu
  - item
  - estranho
raridade: Incomum
pdf_page: 58
jogo: O Peso do Céu
---

# Vidro de Maré

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=58|Consultar Texto Original no PDF (Página 58) — Item estranho Vidro de Maré]]**

*Incomum · ninguém sabe de onde veio*

---

Olhando através dele, você vê o lugar como ele estava há uma hora. Uma vez por cena, isso responde a uma pergunta.

---

## Links Relacionados
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
