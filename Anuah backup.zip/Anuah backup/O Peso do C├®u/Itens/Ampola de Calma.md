---
tipo: Item
categoria: Mecânico
tags:
  - peso-do-ceu
  - item
  - mecanico
  - fabrica/vespertina
usos: 3 usos
fabrica: Vespertina Mecânica Fina
pdf_page: 57
jogo: O Peso do Céu
---

# Ampola de Calma

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=57|Consultar Texto Original no PDF (Página 57) — Item mecânico Ampola de Calma]]**

*3 usos · saiu da [[Vespertina Mecânica Fina]]*

---

Uma ação: alguém limpa 3 Estresse. Não funciona duas vezes na mesma pessoa na mesma sessão.

---

## Links Relacionados
- [[Vespertina Mecânica Fina]]
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
