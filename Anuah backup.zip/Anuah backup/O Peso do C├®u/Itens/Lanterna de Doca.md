---
tipo: Item
categoria: Mecânico
tags:
  - peso-do-ceu
  - item
  - mecanico
usos: —
pdf_page: 58
jogo: O Peso do Céu
---

# Lanterna de Doca

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=58|Consultar Texto Original no PDF (Página 58) — Item mecânico Lanterna de Doca]]**

*— · de fábrica nenhuma — acha-se em qualquer doca*

---

Alcança Longe e queima por dezoito horas. Também serve de sinal.

---

## Links Relacionados
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
