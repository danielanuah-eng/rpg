---
tipo: Item
categoria: Mecânico
tags:
  - peso-do-ceu
  - item
  - mecanico
  - fabrica/selo
usos: 2 usos
fabrica: Selo Civil
pdf_page: 58
jogo: O Peso do Céu
---

# Marcador Orbital

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=58|Consultar Texto Original no PDF (Página 58) — Item mecânico Marcador Orbital]]**

*2 usos · saiu da [[Selo Civil]]*

---

Uma ação: marque um alvo. Todo ataque contra ele nesta cena soma **+2 por Proficiência**.

---

## Links Relacionados
- [[Selo Civil]]
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
