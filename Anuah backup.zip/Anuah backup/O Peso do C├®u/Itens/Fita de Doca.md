---
tipo: Item
categoria: Mecânico
tags:
  - peso-do-ceu
  - item
  - mecanico
  - fabrica/gralha
usos: —
fabrica: Oficinas Gralha
pdf_page: 58
jogo: O Peso do Céu
---

# Fita de Doca

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=58|Consultar Texto Original no PDF (Página 58) — Item mecânico Fita de Doca]]**

*— · saiu da [[Oficinas Gralha]]*

---

Conserta qualquer coisa por uma cena. Uma coisa por cena. Todo mundo sabe que não devia funcionar.

---

## Links Relacionados
- [[Oficinas Gralha]]
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
