---
tipo: Item
categoria: Arma de piloto
tags:
  - peso-do-ceu
  - item
  - arma
traco: Finesse
alcance: Perto
pdf_page: 56
jogo: O Peso do Céu
---

# Pistola de Cabine

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=56|Consultar Texto Original no PDF (Página 56) — Arma Pistola de Cabine]]**

*Finesse · Perto · `d6+1`*

---

Cabe no bolso do macacão. Ninguém revista piloto.

---

## Links Relacionados
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
