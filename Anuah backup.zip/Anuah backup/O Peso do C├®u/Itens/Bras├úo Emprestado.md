---
tipo: Item
categoria: Mecânico
tags:
  - peso-do-ceu
  - item
  - mecanico
  - fabrica/catedral
usos: —
fabrica: Fundição Catedral
pdf_page: 57
jogo: O Peso do Céu
---

# Brasão Emprestado

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=57|Consultar Texto Original no PDF (Página 57) — Item mecânico Brasão Emprestado]]**

*— · saiu da [[Fundição Catedral]]*

---

Enquanto você estiver com ele à mostra, tropa regular de Estado assume que você tem autoridade. Até alguém checar.

---

## Links Relacionados
- [[Fundição Catedral]]
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
