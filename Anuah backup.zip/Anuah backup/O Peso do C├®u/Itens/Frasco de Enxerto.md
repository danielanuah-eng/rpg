---
tipo: Item
categoria: Mecânico
tags:
  - peso-do-ceu
  - item
  - mecanico
  - fabrica/ossatura
usos: 1 uso
fabrica: Ossatura
pdf_page: 58
jogo: O Peso do Céu
---

# Frasco de Enxerto

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=58|Consultar Texto Original no PDF (Página 58) — Item mecânico Frasco de Enxerto]]**

*1 uso · saiu da [[Ossatura]]*

---

Uma ação: limpe 5 Estrutura de um colosso. O piloto marca 2 Estresse e sonha com isso a semana inteira.

---

## Links Relacionados
- [[Ossatura]]
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
