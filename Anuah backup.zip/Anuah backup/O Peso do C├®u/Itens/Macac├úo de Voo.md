---
tipo: Item
categoria: Traje
tags:
  - peso-do-ceu
  - item
  - traje
blindagem: 1
pdf_page: 57
jogo: O Peso do Céu
---

# Macacão de Voo

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=57|Consultar Texto Original no PDF (Página 57) — Traje Macacão de Voo]]**

*Blindagem 1 · limiares 5 / 10*

---

O que todo mundo usa. Leve, quente, sem promessa nenhuma.

---

## Links Relacionados
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
