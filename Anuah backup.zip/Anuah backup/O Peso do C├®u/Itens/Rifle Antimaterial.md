---
tipo: Item
categoria: Arma de piloto
tags:
  - peso-do-ceu
  - item
  - arma
traco: Finesse
alcance: Muito Longe
pdf_page: 56
jogo: O Peso do Céu
---

# Rifle Antimaterial

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=56|Consultar Texto Original no PDF (Página 56) — Arma Rifle Antimaterial]]**

*Finesse · Muito Longe · `d10+2`*  
**Antimáquina**

---

Pesa dezoito quilos. Você não corre com ele.

> [!IMPORTANT] Antimáquina
> Cancela o debuff de gente contra colosso: rolagem normal e dano cheio. Ver [[Escala]].

---

## Links Relacionados
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
