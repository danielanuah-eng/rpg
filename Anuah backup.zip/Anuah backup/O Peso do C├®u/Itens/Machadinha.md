---
tipo: Item
categoria: Arma de piloto
tags:
  - peso-do-ceu
  - item
  - arma
traco: Força
alcance: Corpo a corpo
pdf_page: 56
jogo: O Peso do Céu
---

# Machadinha

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=56|Consultar Texto Original no PDF (Página 56) — Arma Machadinha]]**

*Força · Corpo a corpo · `d10+1`*

---

Arromba porta, cadeado e escotilha sem rolagem.

---

## Links Relacionados
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
