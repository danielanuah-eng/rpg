---
tipo: Item
categoria: Mecânico
tags:
  - peso-do-ceu
  - item
  - mecanico
  - fabrica/gralha
usos: —
fabrica: Oficinas Gralha
pdf_page: 57
jogo: O Peso do Céu
---

# Caixa de Encaixe

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=57|Consultar Texto Original no PDF (Página 57) — Item mecânico Caixa de Encaixe]]**

*— · saiu da [[Oficinas Gralha]]*

---

Uma ação numa Parada: troque uma Peça instalada por outra que você tenha, em qualquer lugar.

---

## Links Relacionados
- [[Oficinas Gralha]]
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
