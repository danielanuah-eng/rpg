---
tipo: Item
categoria: Mecânico
tags:
  - peso-do-ceu
  - item
  - mecanico
  - fabrica/arco
usos: —
fabrica: Estaleiros do Arco
pdf_page: 57
jogo: O Peso do Céu
---

# Boia de Sonar

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=57|Consultar Texto Original no PDF (Página 57) — Item mecânico Boia de Sonar]]**

*— · saiu da [[Estaleiros do Arco]]*

---

Largue na água: pelo resto da sessão, você sabe o que passa por aquele ponto.

---

## Links Relacionados
- [[Estaleiros do Arco]]
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
