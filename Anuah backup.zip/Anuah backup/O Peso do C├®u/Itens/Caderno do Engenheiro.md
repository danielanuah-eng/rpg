---
tipo: Item
categoria: Estranho
tags:
  - peso-do-ceu
  - item
  - estranho
raridade: Raro
pdf_page: 59
jogo: O Peso do Céu
---

# Caderno do Engenheiro

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=59|Consultar Texto Original no PDF (Página 59) — Item estranho Caderno do Engenheiro]]**

*Raro · ninguém sabe de onde veio*

---

Tem o desenho de uma Peça que não existe. Uma vez por campanha, ela passa a existir, montada por você, e o caderno perde aquela página.

---

## Links Relacionados
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
