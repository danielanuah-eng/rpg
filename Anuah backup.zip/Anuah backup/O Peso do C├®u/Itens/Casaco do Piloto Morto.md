---
tipo: Item
categoria: Estranho
tags:
  - peso-do-ceu
  - item
  - estranho
raridade: Raro
pdf_page: 59
jogo: O Peso do Céu
---

# Casaco do Piloto Morto

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=59|Consultar Texto Original no PDF (Página 59) — Item estranho Casaco do Piloto Morto]]**

*Raro · ninguém sabe de onde veio*

---

**+1** de Evasão do piloto. Quem o vestiu antes de você aparece nos seus sonhos e é educado.

---

## Links Relacionados
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
