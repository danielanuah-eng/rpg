---
tipo: Item
categoria: Arma de piloto
tags:
  - peso-do-ceu
  - item
  - arma
traco: Agilidade
alcance: Longe
pdf_page: 56
jogo: O Peso do Céu
---

# Lança-Cabos

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=56|Consultar Texto Original no PDF (Página 56) — Arma Lança-Cabos]]**

*Agilidade · Longe · `d6+1`*

---

Em um acerto, o alvo fica **Restrito**, ou você sobe até ele.

---

## Links Relacionados
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
