---
tipo: Item
categoria: Arma de piloto
tags:
  - peso-do-ceu
  - item
  - arma
traco: Agilidade
alcance: Muito Perto
pdf_page: 56
jogo: O Peso do Céu
---

# Escopeta Serrada

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=56|Consultar Texto Original no PDF (Página 56) — Arma Escopeta Serrada]]**

*Agilidade · Muito Perto · `d10+2`*

---

Acerta até dois alvos adjacentes com uma rolagem.

---

## Links Relacionados
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
