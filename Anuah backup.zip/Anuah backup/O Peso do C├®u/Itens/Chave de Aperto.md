---
tipo: Item
categoria: Arma de piloto
tags:
  - peso-do-ceu
  - item
  - arma
traco: Força
alcance: Corpo a corpo
pdf_page: 56
jogo: O Peso do Céu
---

# Chave de Aperto

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=56|Consultar Texto Original no PDF (Página 56) — Arma Chave de Aperto]]**

*Força · Corpo a corpo · `d8+1`*

---

Também é ferramenta: **+2** em consertos improvisados.

---

## Links Relacionados
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
