---
tipo: Item
categoria: Estranho
tags:
  - peso-do-ceu
  - item
  - estranho
raridade: Raro
pdf_page: 59
jogo: O Peso do Céu
---

# Olho Guardado

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=59|Consultar Texto Original no PDF (Página 59) — Item estranho Olho Guardado]]**

*Raro · ninguém sabe de onde veio*

---

Um olho de Funda num pote. Enquanto estiver aberto no seu colete, nada **Oculto** consegue se esconder de você. Ele pisca.

---

## Links Relacionados
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
