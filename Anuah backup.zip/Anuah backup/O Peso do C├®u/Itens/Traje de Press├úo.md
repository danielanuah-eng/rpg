---
tipo: Item
categoria: Traje
tags:
  - peso-do-ceu
  - item
  - traje
blindagem: 2
pdf_page: 57
jogo: O Peso do Céu
---

# Traje de Pressão

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=57|Consultar Texto Original no PDF (Página 57) — Traje Traje de Pressão]]**

*Blindagem 2 · limiares 6 / 11*

---

Água, vácuo e ar podre não te atingem. Demora uma cena para vestir.

---

## Links Relacionados
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
