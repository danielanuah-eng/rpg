---
tipo: Item
categoria: Mecânico
tags:
  - peso-do-ceu
  - item
  - mecanico
  - fabrica/brasa
usos: 1 uso
fabrica: Companhia Brasa e Filhos
pdf_page: 57
jogo: O Peso do Céu
---

# Cilindro de Argônio

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=57|Consultar Texto Original no PDF (Página 57) — Item mecânico Cilindro de Argônio]]**

*1 uso · saiu da [[Companhia Brasa e Filhos]]*

---

Uma ação: apague qualquer incêndio, ou faça uma cena inteira parar de queimar por uma cena.

---

## Links Relacionados
- [[Companhia Brasa e Filhos]]
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
