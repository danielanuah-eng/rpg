---
tipo: Item
categoria: Estranho
tags:
  - peso-do-ceu
  - item
  - estranho
raridade: Incomum
pdf_page: 59
jogo: O Peso do Céu
---

# Prego do Estaleiro

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=59|Consultar Texto Original no PDF (Página 59) — Item estranho Prego do Estaleiro]]**

*Incomum · ninguém sabe de onde veio*

---

Enquanto estiver cravado num casco, aquele casco não cai — ele *atrasa*. Uma vez por sortida, adie a queda por uma cena.

---

## Links Relacionados
- [[🎒 Itens e Equipamento]]
- [[🛰️ O Peso do Céu]]
