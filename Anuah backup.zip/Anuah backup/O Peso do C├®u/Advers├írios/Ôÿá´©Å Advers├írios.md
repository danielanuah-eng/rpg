---
tipo: Hub
categoria: MOC
tags:
  - peso-do-ceu
  - moc
  - hub
jogo: O Peso do Céu
---

# ☠️ Os 104 adversários

Sessenta e quatro colossos de fábrica, vinte e seis **Fundas** — o que sobe do fundo — e quatorze de gente e veículo. Toda ficha sai da linha do Escalão vezes o papel, então dá para inventar mais sem quebrar nada: ver [[Montar uma Briga]].

---

## Companhia Brasa e Filhos

- [[Milícia]] — Lacaio · Escalão 1º · Estrutura 1
- [[Mula (adversário)]] — Regular · Escalão 1º · Estrutura 5
- [[Guincho]] — Apoio · Escalão 1º · Estrutura 4
- [[Bigorna (adversário)]] — Brutamontes · Escalão 2º · Estrutura 13
- [[Fornalha]] — Brutamontes · Escalão 2º · Estrutura 13
- [[Quebra-Linha]] — Brutamontes · Escalão 3º · Estrutura 16
- [[Capataz]] — Comandante · Escalão 3º · Estrutura 13
- [[A Última Brasa (adversário)]] — Solo · Escalão 4º · Estrutura 31

## Vespertina Mecânica Fina

- [[Aluno]] — Lacaio · Escalão 1º · Estrutura 1
- [[Batedor]] — Batedor · Escalão 1º · Estrutura 3
- [[Andorinha (adversário)]] — Batedor · Escalão 2º · Estrutura 4
- [[Florete (adversário)]] — Regular · Escalão 2º · Estrutura 7
- [[Estilete]] — Batedor · Escalão 3º · Estrutura 5
- [[Aurora]] — Apoio · Escalão 3º · Estrutura 7
- [[Vespertina]] — Solo · Escalão 4º · Estrutura 31
- [[Leque]] — Comandante · Escalão 4º · Estrutura 15

## Fundição Catedral

- [[Guarnição]] — Regular · Escalão 1º · Estrutura 5
- [[Sargento]] — Comandante · Escalão 1º · Estrutura 7
- [[Guarda (adversário)]] — Regular · Escalão 2º · Estrutura 7
- [[Tenente]] — Comandante · Escalão 2º · Estrutura 10
- [[Arcada (adversário)]] — Brutamontes · Escalão 3º · Estrutura 16
- [[Capitão]] — Comandante · Escalão 3º · Estrutura 13
- [[Legado]] — Solo · Escalão 4º · Estrutura 31
- [[Campanário]] — Atirador · Escalão 4º · Estrutura 7

## Estaleiros do Arco

- [[Vazante (adversário)]] — Regular · Escalão 1º · Estrutura 5
- [[Mergulho]] — Batedor · Escalão 1º · Estrutura 3
- [[Boia]] — Atirador · Escalão 2º · Estrutura 4
- [[Draga]] — Regular · Escalão 2º · Estrutura 7
- [[Guarda-Costa]] — Regular · Escalão 3º · Estrutura 9
- [[Quilha (adversário)]] — Brutamontes · Escalão 3º · Estrutura 16
- [[Fossa]] — Solo · Escalão 4º · Estrutura 31
- [[Maré]] — Comandante · Escalão 4º · Estrutura 15

## Oficinas Gralha

- [[Ferro-Velho (adversário)]] — Apoio · Escalão 1º · Estrutura 4
- [[Tratorista]] — Brutamontes · Escalão 1º · Estrutura 9
- [[Serrador]] — Regular · Escalão 2º · Estrutura 7
- [[Carroça (adversário)]] — Apoio · Escalão 2º · Estrutura 6
- [[Enxame de Gralhas]] — Bando · Escalão 3º · Estrutura 11
- [[Mestre de Obras]] — Comandante · Escalão 3º · Estrutura 13
- [[Frankenstein]] — Brutamontes · Escalão 4º · Estrutura 20
- [[A Oficina]] — Apoio · Escalão 4º · Estrutura 9

## Selo Civil

- [[Patrulha]] — Regular · Escalão 1º · Estrutura 5
- [[Olho]] — Atirador · Escalão 1º · Estrutura 3
- [[Ronda (adversário)]] — Regular · Escalão 2º · Estrutura 7
- [[Xerife]] — Comandante · Escalão 2º · Estrutura 10
- [[Torre (adversário)]] — Atirador · Escalão 3º · Estrutura 5
- [[Delegado]] — Comandante · Escalão 3º · Estrutura 13
- [[Órbita]] — Solo · Escalão 4º · Estrutura 31
- [[Guarda Civil]] — Bando · Escalão 4º · Estrutura 13

## Carvão

- [[Fora da Lei]] — Batedor · Escalão 1º · Estrutura 3
- [[Gancho (adversário)]] — Regular · Escalão 1º · Estrutura 5
- [[Corsário (adversário)]] — Batedor · Escalão 2º · Estrutura 4
- [[Sombra (adversário)]] — Batedor · Escalão 2º · Estrutura 4
- [[Estopim]] — Regular · Escalão 3º · Estrutura 9
- [[Carrasco]] — Comandante · Escalão 3º · Estrutura 13
- [[Carvão (adversário)]] — Solo · Escalão 4º · Estrutura 31
- [[Matilha]] — Bando · Escalão 2º · Estrutura 8

## Ossatura

- [[Enxerto (adversário)]] — Regular · Escalão 1º · Estrutura 5
- [[Coleira]] — Apoio · Escalão 2º · Estrutura 6
- [[Costela (adversário)]] — Regular · Escalão 2º · Estrutura 7
- [[Ninhada (adversário)]] — Bando · Escalão 3º · Estrutura 11
- [[Carcaça (adversário)]] — Brutamontes · Escalão 3º · Estrutura 16
- [[A Virada]] — Solo · Escalão 4º · Estrutura 31
- [[Pastor]] — Comandante · Escalão 4º · Estrutura 15
- [[Semente]] — Lacaio · Escalão 1º · Estrutura 1

## 🌊 As Fundas — os kaijus

- [[Cria]] — Bando · Escalão 1º · Estrutura 6
- [[Lacraia]] — Batedor · Escalão 1º · Estrutura 3
- [[Carapaça]] — Brutamontes · Escalão 1º · Estrutura 9
- [[Cardume]] — Bando · Escalão 2º · Estrutura 8
- [[Lodo]] — Brutamontes · Escalão 2º · Estrutura 13
- [[Agulha]] — Atirador · Escalão 2º · Estrutura 4
- [[Nadador]] — Batedor · Escalão 2º · Estrutura 4
- [[Asa-Seca]] — Batedor · Escalão 2º · Estrutura 4
- [[Bocarra]] — Brutamontes · Escalão 3º · Estrutura 16
- [[Torre Velha]] — Atirador · Escalão 3º · Estrutura 5
- [[Porão]] — Solo · Escalão 3º · Estrutura 25
- [[Vazante (adversário 2)]] — Bando · Escalão 3º · Estrutura 11
- [[Mergulhadora]] — Regular · Escalão 3º · Estrutura 9
- [[A Boca]] — Solo · Escalão 4º · Estrutura 31
- [[O Monte]] — Solo · Escalão 4º · Estrutura 31
- [[Céu Aberto]] — Solo · Escalão 4º · Estrutura 31
- [[Espinha]] — Brutamontes · Escalão 4º · Estrutura 20
- [[Travessia]] — Comandante · Escalão 3º · Estrutura 13
- [[Casco]] — Regular · Escalão 2º · Estrutura 7
- [[Olho-Fundo]] — Apoio · Escalão 3º · Estrutura 7
- [[Raiz (adversário)]] — Apoio · Escalão 2º · Estrutura 6
- [[Pele]] — Apoio · Escalão 1º · Estrutura 4
- [[Coroa]] — Comandante · Escalão 4º · Estrutura 15
- [[Semente-Mãe]] — Regular · Escalão 3º · Estrutura 9
- [[A Casa]] — Solo · Escalão 4º · Estrutura 31
- [[Eco]] — Batedor · Escalão 2º · Estrutura 4

## Gente e veículos

- [[Soldado]] — Lacaio · Escalão 1º · Estrutura 1
- [[Equipe de Fenda]] — Regular · Escalão 2º · Estrutura 7
- [[Atirador de Elite]] — Atirador · Escalão 2º · Estrutura 4
- [[Oficial]] — Comandante · Escalão 2º · Estrutura 10
- [[Multidão]] — Bando · Escalão 2º · Estrutura 8
- [[Piloto a Pé]] — Batedor · Escalão 2º · Estrutura 4
- [[Blindado]] — Regular · Escalão 1º · Estrutura 5
- [[Lança-Foguetes]] — Atirador · Escalão 2º · Estrutura 4
- [[Helicóptero]] — Batedor · Escalão 2º · Estrutura 4
- [[Comboio]] — Bando · Escalão 3º · Estrutura 11
- [[Trem Blindado]] — Brutamontes · Escalão 3º · Estrutura 16
- [[Dirigível]] — Apoio · Escalão 3º · Estrutura 7
- [[Engenheiro]] — Apoio · Escalão 1º · Estrutura 4
- [[Interventor]] — Comandante · Escalão 4º · Estrutura 15

## Ver também

- [[Montar uma Briga]]
- [[Escala]]
- [[Levar Dano]]

---

[[🛰️ O Peso do Céu|⬅ Voltar]]
