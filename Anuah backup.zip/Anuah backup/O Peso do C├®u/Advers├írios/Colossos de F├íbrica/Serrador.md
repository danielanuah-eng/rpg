---
tipo: Adversário
categoria: Colosso de fábrica
tags:
  - peso-do-ceu
  - adversario
  - colosso
  - fabrica/gralha
  - escalao/2
escalao: 2
papel: Regular
fabrica: Oficinas Gralha
pdf_page: 74
jogo: O Peso do Céu
---

# Serrador

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=74|Consultar Texto Original no PDF (Página 74) — Serrador — ficha e traços]]**

*Regular · Escalão 2º · [[Oficinas Gralha]]*

> Duas serras de desmanche de três metros. Foi adaptado por alguém com pressa e sem medo.

---

## Ficha

| | |
|---|---|
| **Evasão** | 13 |
| **Limiares** | 10 / 19 |
| **Estrutura** | 7 |
| **Ataque** | +4 |
| **Dano** | `2d10+6` |
| **Discos gêmeos** | Corpo a corpo |

**Motivos.** *Cortar até chegar no meio · não parar · levar a peça*

---

## Traços

### Corta-Casco — Passiva

Ignora toda a Blindagem.

### Trava na Junta — Ação de Medo

Gaste 2 Medo: causa uma Avaria além do dano.

> [!NOTE] Marcas
> Dano abaixo de 10 marca **1**; de 10 para cima, **2**; de 19 para cima, **3**. A linha. É por ela que se mede tudo.

---

## Links Relacionados
- [[Oficinas Gralha]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
