---
tipo: Adversário
categoria: Colosso de fábrica
tags:
  - peso-do-ceu
  - adversario
  - colosso
  - fabrica/catedral
  - escalao/1
escalao: 1
papel: Comandante
fabrica: Fundição Catedral
pdf_page: 68
jogo: O Peso do Céu
---

# Sargento

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=68|Consultar Texto Original no PDF (Página 68) — Sargento — ficha e traços]]**

*Comandante · Escalão 1º · [[Fundição Catedral]]*

> Vinte anos de farda. Sabe exatamente quanto vale cada um dos seus.

---

## Ficha

| | |
|---|---|
| **Evasão** | 11 |
| **Limiares** | 6 / 13 |
| **Estrutura** | 7 |
| **Ataque** | +2 |
| **Dano** | `1d10+5` |
| **Espada de serviço** | Perto |

**Motivos.** *Manter a formação · não perder ninguém · ganhar devagar*

---

## Traços

### Formar — Ação

Todo adversário em Perto ganha **+2** de Evasão até a próxima ação dele.

### Avançar! — Ação de Medo

Gaste 2 Medo: todos os adversários perto dele agem uma vez, agora.

> [!NOTE] Marcas
> Dano abaixo de 6 marca **1**; de 6 para cima, **2**; de 13 para cima, **3**. Gasta o Medo do Mestre melhor que os outros.

---

## Links Relacionados
- [[Fundição Catedral]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
