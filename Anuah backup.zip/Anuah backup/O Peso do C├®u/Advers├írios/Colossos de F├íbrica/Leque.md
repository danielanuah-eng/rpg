---
tipo: Adversário
categoria: Colosso de fábrica
tags:
  - peso-do-ceu
  - adversario
  - colosso
  - fabrica/vespertina
  - escalao/4
escalao: 4
papel: Comandante
fabrica: Vespertina Mecânica Fina
pdf_page: 67
jogo: O Peso do Céu
---

# Leque

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=67|Consultar Texto Original no PDF (Página 67) — Leque — ficha e traços]]**

*Comandante · Escalão 4º · [[Vespertina Mecânica Fina]]*

> Comanda um esquadrão de seis e nunca perdeu nenhum. Isso é um problema, porque ela sabe.

---

## Ficha

| | |
|---|---|
| **Evasão** | 17 |
| **Limiares** | 17 / 32 |
| **Estrutura** | 15 |
| **Ataque** | +8 |
| **Dano** | `4d10+9` |
| **Par de lâminas** | Corpo a corpo |

**Motivos.** *Trazer todos de volta · ser obedecida · não ser a primeira a cair*

---

## Traços

### Esquadrão — Passiva

Todo aliado em até Longe soma **+1** de Evasão e de ataque.

### Em Formação — Ação de Medo

Gaste 2 Medo: três aliados agem imediatamente, um de cada vez.

> [!NOTE] Marcas
> Dano abaixo de 17 marca **1**; de 17 para cima, **2**; de 32 para cima, **3**. Gasta o Medo do Mestre melhor que os outros.

---

## Links Relacionados
- [[Vespertina Mecânica Fina]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
