---
tipo: Adversário
categoria: Colosso de fábrica
tags:
  - peso-do-ceu
  - adversario
  - colosso
  - fabrica/brasa
  - escalao/1
escalao: 1
papel: Regular
fabrica: Companhia Brasa e Filhos
pdf_page: 51
jogo: O Peso do Céu
---

# Mula (adversário)

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=51|Consultar Texto Original no PDF (Página 51) — Mula — ficha e traços]]**

*Regular · Escalão 1º · [[Companhia Brasa e Filhos]]*

> O casco mais vendido do continente. Feio, lento, e ainda de pé.

---

## Ficha

| | |
|---|---|
| **Evasão** | 11 |
| **Limiares** | 6 / 13 |
| **Estrutura** | 5 |
| **Ataque** | +2 |
| **Dano** | `1d10+5` |
| **Marreta de serviço** | Corpo a corpo |

**Motivos.** *Aguentar · empurrar · terminar o turno*

---

## Traços

### Chapa em Cima de Chapa — Passiva

Reduz em um degrau o primeiro dano que sofre em cada cena.

### Empurra — Ação de Medo

Gaste 1 Medo: joga um alvo uma faixa de alcance para longe e o deixa **Instável**.

> [!NOTE] Marcas
> Dano abaixo de 6 marca **1**; de 6 para cima, **2**; de 13 para cima, **3**. A linha. É por ela que se mede tudo.

---

## Links Relacionados
- [[Companhia Brasa e Filhos]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
