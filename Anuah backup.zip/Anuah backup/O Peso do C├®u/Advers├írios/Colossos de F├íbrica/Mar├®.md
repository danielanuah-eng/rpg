---
tipo: Adversário
categoria: Colosso de fábrica
tags:
  - peso-do-ceu
  - adversario
  - colosso
  - fabrica/arco
  - escalao/4
escalao: 4
papel: Comandante
fabrica: Estaleiros do Arco
pdf_page: 73
jogo: O Peso do Céu
---

# Maré

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=73|Consultar Texto Original no PDF (Página 73) — Maré — ficha e traços]]**

*Comandante · Escalão 4º · [[Estaleiros do Arco]]*

> Comanda tudo que flutua em trezentos quilômetros de costa, e raramente precisa disparar para provar isso.

---

## Ficha

| | |
|---|---|
| **Evasão** | 17 |
| **Limiares** | 17 / 32 |
| **Estrutura** | 15 |
| **Ataque** | +8 |
| **Dano** | `4d10+9` |
| **Bateria de esquadra** | Longe |

**Motivos.** *Controlar o canal · cobrar pedágio · afundar só quem insistir*

---

## Traços

### Esquadra — Passiva

Todo adversário na água soma **+2** de ataque e de Evasão.

### Enchente — Ação de Medo

Gaste 3 Medo: a água sobe. A cena inteira vira terreno difícil para quem não tem casco selado.

> [!NOTE] Marcas
> Dano abaixo de 17 marca **1**; de 17 para cima, **2**; de 32 para cima, **3**. Gasta o Medo do Mestre melhor que os outros.

---

## Links Relacionados
- [[Estaleiros do Arco]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
