---
tipo: Adversário
categoria: Colosso de fábrica
tags:
  - peso-do-ceu
  - adversario
  - colosso
  - fabrica/selo
  - escalao/2
escalao: 2
papel: Comandante
fabrica: Selo Civil
pdf_page: 78
jogo: O Peso do Céu
---

# Xerife

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=78|Consultar Texto Original no PDF (Página 78) — Xerife — ficha e traços]]**

*Comandante · Escalão 2º · [[Selo Civil]]*

> A lei de uma cidade que não vê um juiz há quatro anos. Funciona.

---

## Ficha

| | |
|---|---|
| **Evasão** | 13 |
| **Limiares** | 10 / 19 |
| **Estrutura** | 10 |
| **Ataque** | +4 |
| **Dano** | `2d10+6` |
| **Par de revólveres** | Perto |

**Motivos.** *Manter a paz do jeito dele · cobrar o devido · ser obedecido*

---

## Traços

### Dois Tiros — Passiva

Ataca dois alvos diferentes com a mesma ação.

### Última Palavra — Ação de Medo

Gaste 2 Medo: um personagem que ia agir não age. Tudo que ele tinha a dizer, o Xerife já ouviu.

> [!NOTE] Marcas
> Dano abaixo de 10 marca **1**; de 10 para cima, **2**; de 19 para cima, **3**. Gasta o Medo do Mestre melhor que os outros.

---

## Links Relacionados
- [[Selo Civil]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
