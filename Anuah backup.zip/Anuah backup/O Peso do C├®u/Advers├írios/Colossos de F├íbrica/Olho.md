---
tipo: Adversário
categoria: Colosso de fábrica
tags:
  - peso-do-ceu
  - adversario
  - colosso
  - fabrica/selo
  - escalao/1
escalao: 1
papel: Atirador
fabrica: Selo Civil
pdf_page: 77
jogo: O Peso do Céu
---

# Olho

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=77|Consultar Texto Original no PDF (Página 77) — Olho — ficha e traços]]**

*Atirador · Escalão 1º · [[Selo Civil]]*

> Casco de observação. Não atira para matar: atira para avisar todo mundo onde você está.

---

## Ficha

| | |
|---|---|
| **Evasão** | 11 |
| **Limiares** | 6 / 13 |
| **Estrutura** | 3 |
| **Ataque** | +2 |
| **Dano** | `1d10+5` |
| **Rifle de marcação** | Muito Longe |

**Motivos.** *Ver · avisar · não ser visto*

---

## Traços

### Marcado — Passiva

Em um acerto, o alvo fica **Travado** até o fim da cena: todos os ataques contra ele têm vantagem.

### Rede — Ação de Medo

Gaste 1 Medo: todos os adversários da cena sabem exatamente onde cada personagem está.

> [!NOTE] Marcas
> Dano abaixo de 6 marca **1**; de 6 para cima, **2**; de 13 para cima, **3**. Fica longe. Se deixarem chegar perto, acaba.

---

## Links Relacionados
- [[Selo Civil]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
