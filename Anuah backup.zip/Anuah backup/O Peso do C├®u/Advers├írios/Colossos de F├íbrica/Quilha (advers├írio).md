---
tipo: Adversário
categoria: Colosso de fábrica
tags:
  - peso-do-ceu
  - adversario
  - colosso
  - fabrica/arco
  - escalao/3
escalao: 3
papel: Brutamontes
fabrica: Estaleiros do Arco
pdf_page: 22
jogo: O Peso do Céu
---

# Quilha (adversário)

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=22|Consultar Texto Original no PDF (Página 22) — Quilha — ficha e traços]]**

*Brutamontes · Escalão 3º · [[Estaleiros do Arco]]*

> Casco de fundo profundo adaptado para terra. Anda devagar porque pesa o que um navio pesa.

---

## Ficha

| | |
|---|---|
| **Evasão** | 14 |
| **Limiares** | 13 / 26 |
| **Estrutura** | 16 |
| **Ataque** | +6 |
| **Dano** | `3d10+7` |
| **Martelo de pressão** | Corpo a corpo |

**Motivos.** *Chegar · não parar · afundar o chão*

---

## Traços

### Peso de Lastro — Passiva

Não pode ser movido. O chão onde ele pisa vira terreno difícil para os outros.

### Afunda — Ação de Medo

Gaste 2 Medo: o chão em Muito Perto cede. Todos lá ficam **Restritos**.

> [!NOTE] Marcas
> Dano abaixo de 13 marca **1**; de 13 para cima, **2**; de 26 para cima, **3**. Aguenta. Lento e caro de derrubar.

---

## Links Relacionados
- [[Estaleiros do Arco]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
