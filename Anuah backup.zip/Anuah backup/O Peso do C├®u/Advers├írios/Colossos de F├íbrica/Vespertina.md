---
tipo: Adversário
categoria: Colosso de fábrica
tags:
  - peso-do-ceu
  - adversario
  - colosso
  - fabrica/vespertina
  - escalao/4
escalao: 4
papel: Solo
fabrica: Vespertina Mecânica Fina
pdf_page: 36
jogo: O Peso do Céu
---

# Vespertina

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=36|Consultar Texto Original no PDF (Página 36) — Vespertina — ficha e traços]]**

*Solo · Escalão 4º · [[Vespertina Mecânica Fina]]*

> Casco branco de última geração, manto e um nome que os soldados dos dois lados conhecem.

---

## Ficha

| | |
|---|---|
| **Evasão** | 18 |
| **Limiares** | 17 / 32 |
| **Estrutura** | 31 |
| **Ataque** | +8 |
| **Dano** | `4d10+9` |
| **Lança do serviço pessoal** | Muito Perto |

**Motivos.** *Terminar a guerra do jeito dela · proteger uma pessoa · não perder*

---

## Traços

### Aletas — Passiva

Voa. Não existe terreno, altura nem cobertura para ela.

### Guarda Alta — Passiva

A primeira vez em cada cena que sofreria dano, não sofre.

### Três Tempos — Ação de Medo

Gaste 3 Medo: age três vezes seguidas, sem passar o holofote.

> [!NOTE] Marcas
> Dano abaixo de 17 marca **1**; de 17 para cima, **2**; de 32 para cima, **3**. Sozinho contra o grupo inteiro.

---

## Links Relacionados
- [[Vespertina Mecânica Fina]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
