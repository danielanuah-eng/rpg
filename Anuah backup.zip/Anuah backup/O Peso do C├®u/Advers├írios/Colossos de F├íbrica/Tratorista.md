---
tipo: Adversário
categoria: Colosso de fábrica
tags:
  - peso-do-ceu
  - adversario
  - colosso
  - fabrica/gralha
  - escalao/1
escalao: 1
papel: Brutamontes
fabrica: Oficinas Gralha
pdf_page: 74
jogo: O Peso do Céu
---

# Tratorista

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=74|Consultar Texto Original no PDF (Página 74) — Tratorista — ficha e traços]]**

*Brutamontes · Escalão 1º · [[Oficinas Gralha]]*

> Máquina de obra com chapa parafusada por cima. Não foi feita para brigar, mas pesa quarenta toneladas.

---

## Ficha

| | |
|---|---|
| **Evasão** | 10 |
| **Limiares** | 6 / 13 |
| **Estrutura** | 9 |
| **Ataque** | +2 |
| **Dano** | `1d10+5` |
| **Garra de carga** | Corpo a corpo |

**Motivos.** *Empurrar · derrubar parede · abrir caminho*

---

## Traços

### Peso Morto — Passiva

Não pode ser empurrado, puxado nem derrubado.

### Passa Por Cima — Ação de Medo

Gaste 2 Medo: atravessa em linha reta. Todos no caminho sofrem o dano e ficam **Instáveis**.

> [!NOTE] Marcas
> Dano abaixo de 6 marca **1**; de 6 para cima, **2**; de 13 para cima, **3**. Aguenta. Lento e caro de derrubar.

---

## Links Relacionados
- [[Oficinas Gralha]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
