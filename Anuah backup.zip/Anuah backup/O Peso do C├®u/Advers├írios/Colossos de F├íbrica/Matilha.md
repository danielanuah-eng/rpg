---
tipo: Adversário
categoria: Colosso de fábrica
tags:
  - peso-do-ceu
  - adversario
  - colosso
  - fabrica/carvao
  - escalao/2
escalao: 2
papel: Bando
fabrica: Carvão
pdf_page: 82
jogo: O Peso do Céu
---

# Matilha

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=82|Consultar Texto Original no PDF (Página 82) — Matilha — ficha e traços]]**

*Bando · Escalão 2º · [[Carvão]]*

> Quatro cascos leves sem cabine, pilotados por rádio de um caminhão, por uma pessoa só.

---

## Ficha

| | |
|---|---|
| **Evasão** | 13 |
| **Limiares** | 10 / 19 |
| **Estrutura** | 8 |
| **Ataque** | +4 |
| **Dano** | `2d10+6` |
| **Garras e dentes** | Corpo a corpo |

**Motivos.** *Cercar · cansar · nunca atacar de frente*

---

## Traços

### Cerco — Passiva

Se houver dois ou mais adversários perto do alvo, o dano da Matilha sobe um degrau.

### Espalhar — Ação de Medo

Gaste 1 Medo: a Matilha se divide e ataca em duas frentes.

> [!NOTE] Marcas
> Dano abaixo de 10 marca **1**; de 10 para cima, **2**; de 19 para cima, **3**. Conta como vários. O dano cai pela metade na segunda metade da Estrutura.

---

## Links Relacionados
- [[Carvão]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
