---
tipo: Adversário
categoria: Colosso de fábrica
tags:
  - peso-do-ceu
  - adversario
  - colosso
  - fabrica/brasa
  - escalao/1
escalao: 1
papel: Apoio
fabrica: Companhia Brasa e Filhos
pdf_page: 62
jogo: O Peso do Céu
---

# Guincho

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=62|Consultar Texto Original no PDF (Página 62) — Guincho — ficha e traços]]**

*Apoio · Escalão 1º · [[Companhia Brasa e Filhos]]*

> Máquina de doca convertida às pressas. Dois braços de guincho e nenhuma arma de verdade.

---

## Ficha

| | |
|---|---|
| **Evasão** | 11 |
| **Limiares** | 6 / 13 |
| **Estrutura** | 4 |
| **Ataque** | +2 |
| **Dano** | `1d10+5` |
| **Gancho duplo** | Longe |

**Motivos.** *Puxar · levantar · tirar alguém de debaixo de alguma coisa*

---

## Traços

### Reboque — Ação

Arrasta um alvo **Restrito** duas faixas de alcance, ou tira um aliado caído da cena.

### Solda — Ação

Limpa 2 Estrutura de um adversário que alcance.

> [!NOTE] Marcas
> Dano abaixo de 6 marca **1**; de 6 para cima, **2**; de 13 para cima, **3**. Não vence sozinho. Faz os outros vencerem.

---

## Links Relacionados
- [[Companhia Brasa e Filhos]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
