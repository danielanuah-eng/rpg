---
tipo: Adversário
categoria: Colosso de fábrica
tags:
  - peso-do-ceu
  - adversario
  - colosso
  - fabrica/ossatura
  - escalao/1
escalao: 1
papel: Lacaio
fabrica: Ossatura
pdf_page: 85
jogo: O Peso do Céu
---

# Semente

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=85|Consultar Texto Original no PDF (Página 85) — Semente — ficha e traços]]**

*Lacaio · Escalão 1º · [[Ossatura]]*

> Cabe dentro de um homem. Já coube.

---

## Ficha

| | |
|---|---|
| **Evasão** | 9 |
| **Limiares** | 6 / 13 |
| **Estrutura** | 1 |
| **Ataque** | +2 |
| **Dano** | `1d10+5` |
| **Garras** | Corpo a corpo |

**Motivos.** *Encontrar um casco · entrar · crescer*

---

## Traços

### Entra — Passiva

Quando cai em Corpo a corpo de um colosso, o piloto marca 1 Estresse.

### Nunca Sozinha — Passiva

Sementes aparecem em grupos de cinco.

> [!NOTE] Marcas
> Dano abaixo de 6 marca **1**; de 6 para cima, **2**; de 13 para cima, **3**. Cai com qualquer acerto. Vem em grupo de três ou mais.

---

## Links Relacionados
- [[Ossatura]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
