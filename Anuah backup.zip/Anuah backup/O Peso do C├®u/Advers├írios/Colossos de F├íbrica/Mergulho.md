---
tipo: Adversário
categoria: Colosso de fábrica
tags:
  - peso-do-ceu
  - adversario
  - colosso
  - fabrica/arco
  - escalao/1
escalao: 1
papel: Batedor
fabrica: Estaleiros do Arco
pdf_page: 71
jogo: O Peso do Céu
---

# Mergulho

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=71|Consultar Texto Original no PDF (Página 71) — Mergulho — ficha e traços]]**

*Batedor · Escalão 1º · [[Estaleiros do Arco]]*

> Casco selado, sem pernas, com quatro propulsores de água. Em terra é uma piada; na água, não.

---

## Ficha

| | |
|---|---|
| **Evasão** | 13 |
| **Limiares** | 6 / 13 |
| **Estrutura** | 3 |
| **Ataque** | +2 |
| **Dano** | `1d10+5` |
| **Garras de fundo** | Corpo a corpo |

**Motivos.** *Puxar para o fundo · esperar embaixo · nunca sair da água*

---

## Traços

### Só na Água — Passiva

Fora da água não se move e rola tudo com desvantagem. Dentro, **+2** de Evasão.

### Puxa — Ação de Medo

Gaste 2 Medo: leva um alvo para o fundo. Sem casco selado, o alvo marca 1 Estrutura por cena.

> [!NOTE] Marcas
> Dano abaixo de 6 marca **1**; de 6 para cima, **2**; de 13 para cima, **3**. Chega, morde e sai. Difícil de acertar.

---

## Links Relacionados
- [[Estaleiros do Arco]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
