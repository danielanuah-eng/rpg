---
tipo: Adversário
categoria: Colosso de fábrica
tags:
  - peso-do-ceu
  - adversario
  - colosso
  - fabrica/selo
  - escalao/3
escalao: 3
papel: Atirador
fabrica: Selo Civil
pdf_page: 24
jogo: O Peso do Céu
---

# Torre (adversário)

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=24|Consultar Texto Original no PDF (Página 24) — Torre — ficha e traços]]**

*Atirador · Escalão 3º · [[Selo Civil]]*

> Um posto de observação que aprendeu a andar. Enxerga a cena inteira e acerta o que enxerga.

---

## Ficha

| | |
|---|---|
| **Evasão** | 15 |
| **Limiares** | 13 / 26 |
| **Estrutura** | 5 |
| **Ataque** | +6 |
| **Dano** | `3d10+7` |
| **Canhão de sítio** | Muito Longe |

**Motivos.** *Cobrir tudo · não deixar ninguém sair · não sair também*

---

## Traços

### Vista de Cima — Passiva

Nada fica **Oculto** dele, e ele não sofre desvantagem por distância.

### Fecha o Cerco — Ação de Medo

Gaste 2 Medo: ninguém sai da cena nesta rodada.

> [!NOTE] Marcas
> Dano abaixo de 13 marca **1**; de 13 para cima, **2**; de 26 para cima, **3**. Fica longe. Se deixarem chegar perto, acaba.

---

## Links Relacionados
- [[Selo Civil]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
