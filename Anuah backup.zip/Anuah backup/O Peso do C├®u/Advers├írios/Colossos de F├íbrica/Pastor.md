---
tipo: Adversário
categoria: Colosso de fábrica
tags:
  - peso-do-ceu
  - adversario
  - colosso
  - fabrica/ossatura
  - escalao/4
escalao: 4
papel: Comandante
fabrica: Ossatura
pdf_page: 85
jogo: O Peso do Céu
---

# Pastor

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=85|Consultar Texto Original no PDF (Página 85) — Pastor — ficha e traços]]**

*Comandante · Escalão 4º · [[Ossatura]]*

> O trabalho dele é manter vivas coisas que não deviam obedecer a ninguém, e apontá-las para o lado certo.

---

## Ficha

| | |
|---|---|
| **Evasão** | 17 |
| **Limiares** | 17 / 32 |
| **Estrutura** | 15 |
| **Ataque** | +8 |
| **Dano** | `4d10+9` |
| **Coleira longa** | Longe |

**Motivos.** *Manter o rebanho em pé · apontá-lo · ser o último a sair*

---

## Traços

### Rebanho Grande — Passiva

Toda Funda e todo Bando na cena soma **+3** de ataque e não pode ser afugentado.

### Larga Tudo — Ação de Medo

Gaste 4 Medo: chega uma Funda de Escalão 3 à escolha do Mestre.

> [!NOTE] Marcas
> Dano abaixo de 17 marca **1**; de 17 para cima, **2**; de 32 para cima, **3**. Gasta o Medo do Mestre melhor que os outros.

---

## Links Relacionados
- [[Ossatura]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
