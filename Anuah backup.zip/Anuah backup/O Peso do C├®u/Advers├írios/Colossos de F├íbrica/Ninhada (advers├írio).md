---
tipo: Adversário
categoria: Colosso de fábrica
tags:
  - peso-do-ceu
  - adversario
  - colosso
  - fabrica/ossatura
  - escalao/3
escalao: 3
papel: Bando
fabrica: Ossatura
pdf_page: 49
jogo: O Peso do Céu
---

# Ninhada (adversário)

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=49|Consultar Texto Original no PDF (Página 49) — Ninhada — ficha e traços]]**

*Bando · Escalão 3º · [[Ossatura]]*

> Não são colossos: são coisas do tamanho de um carro que saíram de dentro de um. Ninguém ali planejou isso.

---

## Ficha

| | |
|---|---|
| **Evasão** | 15 |
| **Limiares** | 13 / 26 |
| **Estrutura** | 11 |
| **Ataque** | +6 |
| **Dano** | `3d10+7` |
| **Muitas bocas** | Corpo a corpo |

**Motivos.** *Comer · seguir o cheiro · crescer*

---

## Traços

### Bando — Passiva

Dano em área acerta a Ninhada inteira e mata o dobro.

### Cheiro — Ação de Medo

Gaste 1 Medo: encontram o alvo mais ferido da cena, onde quer que ele esteja.

> [!NOTE] Marcas
> Dano abaixo de 13 marca **1**; de 13 para cima, **2**; de 26 para cima, **3**. Conta como vários. O dano cai pela metade na segunda metade da Estrutura.

---

## Links Relacionados
- [[Ossatura]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
