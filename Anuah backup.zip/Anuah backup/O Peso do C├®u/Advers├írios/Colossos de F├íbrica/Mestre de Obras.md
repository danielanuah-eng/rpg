---
tipo: Adversário
categoria: Colosso de fábrica
tags:
  - peso-do-ceu
  - adversario
  - colosso
  - fabrica/gralha
  - escalao/3
escalao: 3
papel: Comandante
fabrica: Oficinas Gralha
pdf_page: 75
jogo: O Peso do Céu
---

# Mestre de Obras

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=75|Consultar Texto Original no PDF (Página 75) — Mestre de Obras — ficha e traços]]**

*Comandante · Escalão 3º · [[Oficinas Gralha]]*

> Dono de galpão, chefe de turma e a única pessoa em cem quilômetros que sabe montar o que ele monta.

---

## Ficha

| | |
|---|---|
| **Evasão** | 15 |
| **Limiares** | 13 / 26 |
| **Estrutura** | 13 |
| **Ataque** | +6 |
| **Dano** | `3d10+7` |
| **Serra e cabo** | Perto |

**Motivos.** *Proteger a oficina · cobrar o que é devido · terminar o projeto*

---

## Traços

### Improviso — Ação

Uma vez por cena, um adversário aliado ganha uma Peça nova até o fim da cena.

### Tudo Que Tem — Ação de Medo

Gaste 2 Medo: dispara todas as armas de uma vez, uma rolagem cada.

> [!NOTE] Marcas
> Dano abaixo de 13 marca **1**; de 13 para cima, **2**; de 26 para cima, **3**. Gasta o Medo do Mestre melhor que os outros.

---

## Links Relacionados
- [[Oficinas Gralha]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
