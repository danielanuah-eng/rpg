---
tipo: Adversário
categoria: Colosso de fábrica
tags:
  - peso-do-ceu
  - adversario
  - colosso
  - fabrica/catedral
  - escalao/4
escalao: 4
papel: Solo
fabrica: Fundição Catedral
pdf_page: 70
jogo: O Peso do Céu
---

# Legado

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=70|Consultar Texto Original no PDF (Página 70) — Legado — ficha e traços]]**

*Solo · Escalão 4º · [[Fundição Catedral]]*

> Não é um piloto: é uma instituição com pernas. Está em serviço há mais tempo que a maioria dos exércitos que enfrentou.

---

## Ficha

| | |
|---|---|
| **Evasão** | 18 |
| **Limiares** | 17 / 32 |
| **Estrutura** | 31 |
| **Ataque** | +8 |
| **Dano** | `4d10+9` |
| **Lança e escudo de estandarte** | Corpo a corpo |

**Motivos.** *Manter a ordem antiga · não recuar um metro · ser o último*

---

## Traços

### Estandarte — Passiva

Todo adversário em campo soma **+1** de ataque e não pode fugir.

### Não Cai — Passiva

Quando marcaria a última Estrutura, marca metade e continua. Uma vez por cena.

### Ordem Final — Ação de Medo

Gaste 4 Medo: todo adversário em campo age uma vez, na ordem que o Mestre quiser.

> [!NOTE] Marcas
> Dano abaixo de 17 marca **1**; de 17 para cima, **2**; de 32 para cima, **3**. Sozinho contra o grupo inteiro.

---

## Links Relacionados
- [[Fundição Catedral]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
