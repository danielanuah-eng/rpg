---
tipo: Adversário
categoria: Colosso de fábrica
tags:
  - peso-do-ceu
  - adversario
  - colosso
  - fabrica/selo
  - escalao/2
escalao: 2
papel: Regular
fabrica: Selo Civil
pdf_page: 51
jogo: O Peso do Céu
---

# Ronda (adversário)

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=51|Consultar Texto Original no PDF (Página 51) — Ronda — ficha e traços]]**

*Regular · Escalão 2º · [[Selo Civil]]*

> Casco de contenção urbana. Foi desenhado para prender colosso sem destruir quarteirão, e faz isso bem.

---

## Ficha

| | |
|---|---|
| **Evasão** | 13 |
| **Limiares** | 10 / 19 |
| **Estrutura** | 7 |
| **Ataque** | +4 |
| **Dano** | `2d10+6` |
| **Lança-redes** | Longe |

**Motivos.** *Prender · conter · entregar vivo*

---

## Traços

### Captura — Passiva

Em um acerto com a rede, o alvo fica **Restrito** e não pode ser movido por ninguém.

### Cerco — Ação de Medo

Gaste 2 Medo: dois adversários aliados aparecem cercando um alvo **Restrito**.

> [!NOTE] Marcas
> Dano abaixo de 10 marca **1**; de 10 para cima, **2**; de 19 para cima, **3**. A linha. É por ela que se mede tudo.

---

## Links Relacionados
- [[Selo Civil]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
