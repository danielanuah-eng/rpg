---
tipo: Adversário
categoria: Colosso de fábrica
tags:
  - peso-do-ceu
  - adversario
  - colosso
  - fabrica/selo
  - escalao/4
escalao: 4
papel: Solo
fabrica: Selo Civil
pdf_page: 79
jogo: O Peso do Céu
---

# Órbita

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=79|Consultar Texto Original no PDF (Página 79) — Órbita — ficha e traços]]**

*Solo · Escalão 4º · [[Selo Civil]]*

> Ligado direto à constelação de satélites do Selo. Não precisa ver você: precisa que você exista em algum registro.

---

## Ficha

| | |
|---|---|
| **Evasão** | 18 |
| **Limiares** | 17 / 32 |
| **Estrutura** | 31 |
| **Ataque** | +8 |
| **Dano** | `4d10+9` |
| **Designador orbital** | Muito Longe |

**Motivos.** *Localizar · designar · encerrar de longe*

---

## Traços

### Do Alto — Passiva

Não pode ser surpreendido, e todo personagem que já apareceu em qualquer registro é encontrado por ele.

### Designação — Ação

Marca um alvo. Todo ataque contra ele nesta cena acerta sem rolagem.

### Queda — Ação de Medo

Gaste 4 Medo: alguma coisa cai da órbita no lugar designado. `6d10` em tudo lá, ignorando Blindagem.

> [!NOTE] Marcas
> Dano abaixo de 17 marca **1**; de 17 para cima, **2**; de 32 para cima, **3**. Sozinho contra o grupo inteiro.

---

## Links Relacionados
- [[Selo Civil]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
