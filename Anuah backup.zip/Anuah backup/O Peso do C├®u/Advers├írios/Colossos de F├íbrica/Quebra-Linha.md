---
tipo: Adversário
categoria: Colosso de fábrica
tags:
  - peso-do-ceu
  - adversario
  - colosso
  - fabrica/brasa
  - escalao/3
escalao: 3
papel: Brutamontes
fabrica: Companhia Brasa e Filhos
pdf_page: 63
jogo: O Peso do Céu
---

# Quebra-Linha

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=63|Consultar Texto Original no PDF (Página 63) — Quebra-Linha — ficha e traços]]**

*Brutamontes · Escalão 3º · [[Companhia Brasa e Filhos]]*

> Desenhado para uma coisa só: atravessar uma formação pelo meio.

---

## Ficha

| | |
|---|---|
| **Evasão** | 14 |
| **Limiares** | 13 / 26 |
| **Estrutura** | 16 |
| **Ataque** | +6 |
| **Dano** | `3d10+7` |
| **Aríete de encaixe** | Muito Perto |

**Motivos.** *Abrir o meio · não desviar · chegar no que está atrás*

---

## Traços

### Nada no Caminho — Passiva

Atravessa parede, barricada e cobertura como se não existissem.

### Rompe — Ação de Medo

Gaste 3 Medo: atravessa a cena em linha reta. Cada colosso no caminho sofre o dano e fica **Instável**.

> [!NOTE] Marcas
> Dano abaixo de 13 marca **1**; de 13 para cima, **2**; de 26 para cima, **3**. Aguenta. Lento e caro de derrubar.

---

## Links Relacionados
- [[Companhia Brasa e Filhos]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
