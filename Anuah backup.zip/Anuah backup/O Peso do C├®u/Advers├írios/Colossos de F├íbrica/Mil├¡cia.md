---
tipo: Adversário
categoria: Colosso de fábrica
tags:
  - peso-do-ceu
  - adversario
  - colosso
  - fabrica/brasa
  - escalao/1
escalao: 1
papel: Lacaio
fabrica: Companhia Brasa e Filhos
pdf_page: 62
jogo: O Peso do Céu
---

# Milícia

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=62|Consultar Texto Original no PDF (Página 62) — Milícia — ficha e traços]]**

*Lacaio · Escalão 1º · [[Companhia Brasa e Filhos]]*

> Casco de fábrica com tinta nova por cima da tinta velha. Quem está dentro aprendeu a pilotar em seis semanas.

---

## Ficha

| | |
|---|---|
| **Evasão** | 9 |
| **Limiares** | 6 / 13 |
| **Estrutura** | 1 |
| **Ataque** | +2 |
| **Dano** | `1d10+5` |
| **Fuzil requisitado** | Perto |

**Motivos.** *Cumprir a ordem · não ficar sozinho · voltar*

---

## Traços

### Grupo de Três — Passiva

Milícias vêm em três ou mais. Dano que sobra de derrubar uma passa para a seguinte.

### Recuar — Reação

Quando a primeira cai, as outras ficam **Instáveis** até a próxima ação delas.

> [!NOTE] Marcas
> Dano abaixo de 6 marca **1**; de 6 para cima, **2**; de 13 para cima, **3**. Cai com qualquer acerto. Vem em grupo de três ou mais.

---

## Links Relacionados
- [[Companhia Brasa e Filhos]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
