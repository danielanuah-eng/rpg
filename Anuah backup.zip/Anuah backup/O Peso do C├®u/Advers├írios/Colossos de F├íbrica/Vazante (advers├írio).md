---
tipo: Adversário
categoria: Colosso de fábrica
tags:
  - peso-do-ceu
  - adversario
  - colosso
  - fabrica/arco
  - escalao/1
escalao: 1
papel: Regular
fabrica: Estaleiros do Arco
pdf_page: 51
jogo: O Peso do Céu
---

# Vazante (adversário)

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=51|Consultar Texto Original no PDF (Página 51) — Vazante — ficha e traços]]**

*Regular · Escalão 1º · [[Estaleiros do Arco]]*

> Casco anfíbio de patrulha portuária. Passa metade do turno na água e metade no cais.

---

## Ficha

| | |
|---|---|
| **Evasão** | 11 |
| **Limiares** | 6 / 13 |
| **Estrutura** | 5 |
| **Ataque** | +2 |
| **Dano** | `1d10+5` |
| **Canhão de convés** | Longe |

**Motivos.** *Interditar · abordar · não deixar sair do porto*

---

## Traços

### Anfíbio — Passiva

Água não é terreno difícil, e ele fica submerso indefinidamente.

### Interditado — Ação de Medo

Gaste 2 Medo: um trecho de água fica fechado. Quem entrar sofre o dano dele automaticamente.

> [!NOTE] Marcas
> Dano abaixo de 6 marca **1**; de 6 para cima, **2**; de 13 para cima, **3**. A linha. É por ela que se mede tudo.

---

## Links Relacionados
- [[Estaleiros do Arco]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
