---
tipo: Adversário
categoria: Colosso de fábrica
tags:
  - peso-do-ceu
  - adversario
  - colosso
  - fabrica/catedral
  - escalao/2
escalao: 2
papel: Comandante
fabrica: Fundição Catedral
pdf_page: 69
jogo: O Peso do Céu
---

# Tenente

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=69|Consultar Texto Original no PDF (Página 69) — Tenente — ficha e traços]]**

*Comandante · Escalão 2º · [[Fundição Catedral]]*

> Manto curto, casco de fundição boa e uma carreira inteira apostada nesta missão.

---

## Ficha

| | |
|---|---|
| **Evasão** | 13 |
| **Limiares** | 10 / 19 |
| **Estrutura** | 10 |
| **Ataque** | +4 |
| **Dano** | `2d10+6` |
| **Espada de comando** | Perto |

**Motivos.** *Vencer com a tropa viva · provar alguma coisa · ser promovido*

---

## Traços

### Ordem — Ação

Dois adversários em até Longe agem imediatamente.

### Escudo Humano — Reação

Quando seria atingido, um adversário em Muito Perto leva no lugar.

> [!NOTE] Marcas
> Dano abaixo de 10 marca **1**; de 10 para cima, **2**; de 19 para cima, **3**. Gasta o Medo do Mestre melhor que os outros.

---

## Links Relacionados
- [[Fundição Catedral]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
