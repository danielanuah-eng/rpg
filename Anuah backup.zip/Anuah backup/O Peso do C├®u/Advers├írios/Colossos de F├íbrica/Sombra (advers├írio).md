---
tipo: Adversário
categoria: Colosso de fábrica
tags:
  - peso-do-ceu
  - adversario
  - colosso
  - fabrica/carvao
  - escalao/2
escalao: 2
papel: Batedor
fabrica: Carvão
pdf_page: 51
jogo: O Peso do Céu
---

# Sombra (adversário)

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=51|Consultar Texto Original no PDF (Página 51) — Sombra — ficha e traços]]**

*Batedor · Escalão 2º · [[Carvão]]*

> Placa fria, casco mudo, nenhuma luz acesa. Você já o viu hoje e não lembra.

---

## Ficha

| | |
|---|---|
| **Evasão** | 15 |
| **Limiares** | 10 / 19 |
| **Estrutura** | 4 |
| **Ataque** | +4 |
| **Dano** | `2d10+6` |
| **Faca de casco** | Corpo a corpo |

**Motivos.** *Ver tudo · contar para quem paga · nunca entrar em combate*

---

## Traços

### Placa Fria — Passiva

Está sempre **Oculto** até agir, e volta a ficar no fim da ação dele.

### Já Sabíamos — Ação de Medo

Gaste 2 Medo: um plano dos jogadores já era conhecido. O Mestre diz qual.

> [!NOTE] Marcas
> Dano abaixo de 10 marca **1**; de 10 para cima, **2**; de 19 para cima, **3**. Chega, morde e sai. Difícil de acertar.

---

## Links Relacionados
- [[Carvão]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
