---
tipo: Adversário
categoria: Colosso de fábrica
tags:
  - peso-do-ceu
  - adversario
  - colosso
  - fabrica/selo
  - escalao/1
escalao: 1
papel: Regular
fabrica: Selo Civil
pdf_page: 24
jogo: O Peso do Céu
---

# Patrulha

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=24|Consultar Texto Original no PDF (Página 24) — Patrulha — ficha e traços]]**

*Regular · Escalão 1º · [[Selo Civil]]*

> Farda limpa, casco com o número pintado grande, e a certeza de que isto aqui é jurisdição dele.

---

## Ficha

| | |
|---|---|
| **Evasão** | 11 |
| **Limiares** | 6 / 13 |
| **Estrutura** | 5 |
| **Ataque** | +2 |
| **Dano** | `1d10+5` |
| **Bastão e escudo** | Perto |

**Motivos.** *Identificar · deter · não matar se der*

---

## Traços

### Parado Aí — Ação

Um alvo perde a próxima ação se não tiver documento, desculpa ou velocidade.

### Reforço — Ação de Medo

Gaste 1 Medo: chega outra Patrulha.

> [!NOTE] Marcas
> Dano abaixo de 6 marca **1**; de 6 para cima, **2**; de 13 para cima, **3**. A linha. É por ela que se mede tudo.

---

## Links Relacionados
- [[Selo Civil]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
