---
tipo: Adversário
categoria: Funda
tags:
  - peso-do-ceu
  - adversario
  - funda
  - kaiju
  - escalao/2
escalao: 2
papel: Bando
plano: enxame
pdf_page: 87
jogo: O Peso do Céu
---

# Cardume

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=87|Consultar Texto Original no PDF (Página 87) — Cardume — ficha e traços]]**

*Bando · Escalão 2º · Funda*

> Milhares de coisas pequenas voando juntas. De longe parece fumaça com intenção.

---

## Ficha

| | |
|---|---|
| **Evasão** | 13 |
| **Limiares** | 10 / 19 |
| **Estrutura** | 8 |
| **Ataque** | +4 |
| **Dano** | `2d10+6` |
| **Nuvem** | Perto |

**Motivos.** *Cegar · entrar pelas frestas · não parar*

---

## Traços

### Nuvem — Passiva

Quem estiver dentro do Cardume fica **Cego**.

### Entra — Ação de Medo

Gaste 2 Medo: entra num colosso. Uma Peça instalada desliga a cada ação até o piloto marcar 2 Estresse.

> [!NOTE] Marcas
> Dano abaixo de 10 marca **1**; de 10 para cima, **2**; de 19 para cima, **3**. Conta como vários. O dano cai pela metade na segunda metade da Estrutura.

---

## Links Relacionados
- [[🌊 As Fundas]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
