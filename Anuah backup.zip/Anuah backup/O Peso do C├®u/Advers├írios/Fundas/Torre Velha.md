---
tipo: Adversário
categoria: Funda
tags:
  - peso-do-ceu
  - adversario
  - funda
  - kaiju
  - escalao/3
escalao: 3
papel: Atirador
plano: torre
pdf_page: 89
jogo: O Peso do Céu
---

# Torre Velha

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=89|Consultar Texto Original no PDF (Página 89) — Torre Velha — ficha e traços]]**

*Atirador · Escalão 3º · Funda*

> Está lá há tanto tempo que construíram uma vila em volta antes de descobrirem que ela respirava.

---

## Ficha

| | |
|---|---|
| **Evasão** | 15 |
| **Limiares** | 13 / 26 |
| **Estrutura** | 5 |
| **Ataque** | +6 |
| **Dano** | `3d10+7` |
| **Chuva de esporos** | Muito Longe |

**Motivos.** *Não se mexer · espalhar · esperar*

---

## Traços

### Parece Paisagem — Passiva

Até agir pela primeira vez, não conta como adversário e não pode ser atacada.

### Esporos — Ação de Medo

Gaste 2 Medo: a cena inteira fica coberta. Todos marcam 1 Estresse por cena, menos quem tiver casco selado.

> [!NOTE] Marcas
> Dano abaixo de 13 marca **1**; de 13 para cima, **2**; de 26 para cima, **3**. Fica longe. Se deixarem chegar perto, acaba.

---

## Links Relacionados
- [[🌊 As Fundas]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
