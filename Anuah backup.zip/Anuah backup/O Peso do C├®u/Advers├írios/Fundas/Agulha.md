---
tipo: Adversário
categoria: Funda
tags:
  - peso-do-ceu
  - adversario
  - funda
  - kaiju
  - escalao/2
escalao: 2
papel: Atirador
plano: torre
pdf_page: 87
jogo: O Peso do Céu
---

# Agulha

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=87|Consultar Texto Original no PDF (Página 87) — Agulha — ficha e traços]]**

*Atirador · Escalão 2º · Funda*

> Fica parada, alta e fina, e cospe. Ninguém sabe em que ela se apoia.

---

## Ficha

| | |
|---|---|
| **Evasão** | 13 |
| **Limiares** | 10 / 19 |
| **Estrutura** | 4 |
| **Ataque** | +4 |
| **Dano** | `2d10+6` |
| **Cuspe ácido** | Muito Longe |

**Motivos.** *Não se mexer · acertar de longe · não ser alcançada*

---

## Traços

### Enraizada — Passiva

Não se move. **+4** no Limiar Maior.

### Cospe — Ação de Medo

Gaste 2 Medo: o dano ignora Blindagem e o alvo fica **Vulnerável**.

> [!NOTE] Marcas
> Dano abaixo de 10 marca **1**; de 10 para cima, **2**; de 19 para cima, **3**. Fica longe. Se deixarem chegar perto, acaba.

---

## Links Relacionados
- [[🌊 As Fundas]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
