---
tipo: Adversário
categoria: Funda
tags:
  - peso-do-ceu
  - adversario
  - funda
  - kaiju
  - escalao/4
escalao: 4
papel: Solo
plano: rastejante
pdf_page: 94
jogo: O Peso do Céu
---

# A Casa

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=94|Consultar Texto Original no PDF (Página 94) — A Casa — ficha e traços]]**

*Solo · Escalão 4º · Funda*

> Do tamanho de um estaleiro. Há gente morando nas juntas dela há dois anos, e essa gente a defende.

---

## Ficha

| | |
|---|---|
| **Evasão** | 18 |
| **Limiares** | 17 / 32 |
| **Estrutura** | 31 |
| **Ataque** | +8 |
| **Dano** | `4d10+9` |
| **Pinças de porto** | Perto |

**Motivos.** *Andar · abrigar · não ser incomodada*

---

## Traços

### Tem Gente Dentro — Passiva

Dano em área contra ela acerta civis. O Mestre não avisa duas vezes.

### Juntas — Passiva

Só sofre dano cheio de quem estiver em Corpo a corpo, entre as placas.

### Levanta — Ação de Medo

Gaste 3 Medo: levanta. Tudo que estava em cima dela cai, e a cena muda de altura.

> [!NOTE] Marcas
> Dano abaixo de 17 marca **1**; de 17 para cima, **2**; de 32 para cima, **3**. Sozinho contra o grupo inteiro.

---

## Links Relacionados
- [[🌊 As Fundas]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
