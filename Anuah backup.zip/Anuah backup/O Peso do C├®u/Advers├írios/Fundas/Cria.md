---
tipo: Adversário
categoria: Funda
tags:
  - peso-do-ceu
  - adversario
  - funda
  - kaiju
  - escalao/1
escalao: 1
papel: Bando
plano: enxame
pdf_page: 86
jogo: O Peso do Céu
---

# Cria

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=86|Consultar Texto Original no PDF (Página 86) — Cria — ficha e traços]]**

*Bando · Escalão 1º · Funda*

> Do tamanho de um cachorro grande, em bando de vinte. Saem de onde a coisa grande passou.

---

## Ficha

| | |
|---|---|
| **Evasão** | 11 |
| **Limiares** | 6 / 13 |
| **Estrutura** | 6 |
| **Ataque** | +2 |
| **Dano** | `1d10+5` |
| **Dentes** | Corpo a corpo |

**Motivos.** *Comer · seguir o cheiro · crescer*

---

## Traços

### Bando — Passiva

Dano em área acerta o bando inteiro e mata o dobro.

### Cheiro de Sangue — Ação de Medo

Gaste 1 Medo: encontram o alvo mais ferido da cena, onde quer que esteja.

> [!NOTE] Marcas
> Dano abaixo de 6 marca **1**; de 6 para cima, **2**; de 13 para cima, **3**. Conta como vários. O dano cai pela metade na segunda metade da Estrutura.

---

## Links Relacionados
- [[🌊 As Fundas]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
