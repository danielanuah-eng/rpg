---
tipo: Adversário
categoria: Funda
tags:
  - peso-do-ceu
  - adversario
  - funda
  - kaiju
  - escalao/3
escalao: 3
papel: Regular
plano: nadadora
pdf_page: 90
jogo: O Peso do Céu
---

# Mergulhadora

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=90|Consultar Texto Original no PDF (Página 90) — Mergulhadora — ficha e traços]]**

*Regular · Escalão 3º · Funda*

> Quarenta metros. Sobe do escuro uma vez por dia, come o que estiver na superfície, e desce.

---

## Ficha

| | |
|---|---|
| **Evasão** | 15 |
| **Limiares** | 13 / 26 |
| **Estrutura** | 9 |
| **Ataque** | +6 |
| **Dano** | `3d10+7` |
| **Boca de fundo** | Muito Perto |

**Motivos.** *Subir · comer · descer*

---

## Traços

### Sobe — Ação

Aparece em qualquer ponto com água, sem aviso, e ataca ao chegar.

### Desce — Reação

Quando sofre 3 Estrutura de um golpe só, desaparece e volta na cena seguinte, inteira.

> [!NOTE] Marcas
> Dano abaixo de 13 marca **1**; de 13 para cima, **2**; de 26 para cima, **3**. A linha. É por ela que se mede tudo.

---

## Links Relacionados
- [[🌊 As Fundas]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
