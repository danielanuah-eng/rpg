---
tipo: Adversário
categoria: Funda
tags:
  - peso-do-ceu
  - adversario
  - funda
  - kaiju
  - escalao/1
escalao: 1
papel: Apoio
plano: massa
pdf_page: 93
jogo: O Peso do Céu
---

# Pele

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=93|Consultar Texto Original no PDF (Página 93) — Pele — ficha e traços]]**

*Apoio · Escalão 1º · Funda*

> Uma coisa fina do tamanho de um lençol que gruda em casco e não sai.

---

## Ficha

| | |
|---|---|
| **Evasão** | 11 |
| **Limiares** | 6 / 13 |
| **Estrutura** | 4 |
| **Ataque** | +2 |
| **Dano** | `1d10+5` |
| **Adere** | Corpo a corpo |

**Motivos.** *Grudar · cobrir o visor · esperar a cabine abrir*

---

## Traços

### Gruda — Passiva

Em um acerto, cola no alvo. Ele fica **Cego** até gastar uma ação arrancando.

### Nunca Uma Só — Passiva

Peles aparecem em grupos de seis.

> [!NOTE] Marcas
> Dano abaixo de 6 marca **1**; de 6 para cima, **2**; de 13 para cima, **3**. Não vence sozinho. Faz os outros vencerem.

---

## Links Relacionados
- [[🌊 As Fundas]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
