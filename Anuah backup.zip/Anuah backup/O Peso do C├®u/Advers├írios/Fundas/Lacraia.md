---
tipo: Adversário
categoria: Funda
tags:
  - peso-do-ceu
  - adversario
  - funda
  - kaiju
  - escalao/1
escalao: 1
papel: Batedor
plano: rastejante
pdf_page: 86
jogo: O Peso do Céu
---

# Lacraia

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=86|Consultar Texto Original no PDF (Página 86) — Lacraia — ficha e traços]]**

*Batedor · Escalão 1º · Funda*

> Seis metros de coisa baixa e rápida que atravessa galeria, duto e cano de esgoto como se fosse rua.

---

## Ficha

| | |
|---|---|
| **Evasão** | 13 |
| **Limiares** | 6 / 13 |
| **Estrutura** | 3 |
| **Ataque** | +2 |
| **Dano** | `1d10+5` |
| **Ferrão** | Corpo a corpo |

**Motivos.** *Entrar · picar · sair pelo mesmo buraco*

---

## Traços

### Por Dentro — Passiva

Atravessa qualquer vão maior que um homem, e sai do outro lado na mesma ação.

### Ferrão — Ação de Medo

Gaste 1 Medo: o alvo marca 2 Estresse além do dano.

> [!NOTE] Marcas
> Dano abaixo de 6 marca **1**; de 6 para cima, **2**; de 13 para cima, **3**. Chega, morde e sai. Difícil de acertar.

---

## Links Relacionados
- [[🌊 As Fundas]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
