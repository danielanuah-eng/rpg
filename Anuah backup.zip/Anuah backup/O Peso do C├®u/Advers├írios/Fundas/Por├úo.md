---
tipo: Adversário
categoria: Funda
tags:
  - peso-do-ceu
  - adversario
  - funda
  - kaiju
  - escalao/3
escalao: 3
papel: Solo
plano: massa
pdf_page: 89
jogo: O Peso do Céu
---

# Porão

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=89|Consultar Texto Original no PDF (Página 89) — Porão — ficha e traços]]**

*Solo · Escalão 3º · Funda*

> Ocupou o casco de um navio e não saiu mais. O navio ainda navega.

---

## Ficha

| | |
|---|---|
| **Evasão** | 16 |
| **Limiares** | 13 / 26 |
| **Estrutura** | 25 |
| **Ataque** | +6 |
| **Dano** | `3d10+7` |
| **Braços de dentro** | Perto |

**Motivos.** *Ficar onde está · pegar quem entra · crescer para dentro*

---

## Traços

### Dentro — Passiva

Só pode ser atacado por quem estiver dentro do casco com ele.

### O Navio Fecha — Ação de Medo

Gaste 3 Medo: uma saída deixa de existir.

### Puxa — Ação de Medo

Gaste 2 Medo: um alvo em Perto vai para o ponto mais fundo do porão, sozinho.

> [!NOTE] Marcas
> Dano abaixo de 13 marca **1**; de 13 para cima, **2**; de 26 para cima, **3**. Sozinho contra o grupo inteiro.

---

## Links Relacionados
- [[🌊 As Fundas]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
