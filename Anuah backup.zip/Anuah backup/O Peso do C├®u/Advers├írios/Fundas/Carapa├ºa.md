---
tipo: Adversário
categoria: Funda
tags:
  - peso-do-ceu
  - adversario
  - funda
  - kaiju
  - escalao/1
escalao: 1
papel: Brutamontes
plano: rastejante
pdf_page: 86
jogo: O Peso do Céu
---

# Carapaça

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=86|Consultar Texto Original no PDF (Página 86) — Carapaça — ficha e traços]]**

*Brutamontes · Escalão 1º · Funda*

> Anda devagar, come pedra e não tem lado de trás. Já foi confundida com terreno.

---

## Ficha

| | |
|---|---|
| **Evasão** | 10 |
| **Limiares** | 6 / 13 |
| **Estrutura** | 9 |
| **Ataque** | +2 |
| **Dano** | `1d10+5` |
| **Investida** | Corpo a corpo |

**Motivos.** *Atravessar · comer · não parar*

---

## Traços

### Casca — Passiva

Reduz em um degrau todo dano vindo de Perto ou mais longe.

### Rola — Ação de Medo

Gaste 2 Medo: atravessa a cena em linha reta. Tudo no caminho sofre o dano e fica **Restrito**.

> [!NOTE] Marcas
> Dano abaixo de 6 marca **1**; de 6 para cima, **2**; de 13 para cima, **3**. Aguenta. Lento e caro de derrubar.

---

## Links Relacionados
- [[🌊 As Fundas]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
