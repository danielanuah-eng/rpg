---
tipo: Adversário
categoria: Funda
tags:
  - peso-do-ceu
  - adversario
  - funda
  - kaiju
  - escalao/3
escalao: 3
papel: Comandante
plano: ereta
pdf_page: 91
jogo: O Peso do Céu
---

# Travessia

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=91|Consultar Texto Original no PDF (Página 91) — Travessia — ficha e traços]]**

*Comandante · Escalão 3º · Funda*

> Anda na frente do resto e as outras seguem. Nenhum biólogo aceita chamar isso de liderança, e nenhum soldado aceita chamar de outra coisa.

---

## Ficha

| | |
|---|---|
| **Evasão** | 15 |
| **Limiares** | 13 / 26 |
| **Estrutura** | 13 |
| **Ataque** | +6 |
| **Dano** | `3d10+7` |
| **Berro** | Perto |

**Motivos.** *Atravessar · levar as outras · chegar ao mar*

---

## Traços

### Segue — Passiva

Toda Funda na cena age quando ela age.

### Berro — Ação de Medo

Gaste 2 Medo: todos na cena marcam 2 Estresse e ficam **Instáveis**.

> [!NOTE] Marcas
> Dano abaixo de 13 marca **1**; de 13 para cima, **2**; de 26 para cima, **3**. Gasta o Medo do Mestre melhor que os outros.

---

## Links Relacionados
- [[🌊 As Fundas]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
