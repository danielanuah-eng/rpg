---
tipo: Adversário
categoria: Funda
tags:
  - peso-do-ceu
  - adversario
  - funda
  - kaiju
  - escalao/4
escalao: 4
papel: Solo
plano: voadora
pdf_page: 91
jogo: O Peso do Céu
---

# Céu Aberto

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=91|Consultar Texto Original no PDF (Página 91) — Céu Aberto — ficha e traços]]**

*Solo · Escalão 4º · Funda*

> A envergadura tapa o sol de um vale inteiro. Quem viu de baixo descreve como uma nuvem que resolveu descer.

---

## Ficha

| | |
|---|---|
| **Evasão** | 18 |
| **Limiares** | 17 / 32 |
| **Estrutura** | 31 |
| **Ataque** | +8 |
| **Dano** | `4d10+9` |
| **Sombra** | Longe |

**Motivos.** *Voar · escolher · descer uma vez*

---

## Traços

### Alto — Passiva

Só pode ser atacada por quem voa ou por arma de Muito Longe.

### Sombra — Passiva

Onde a sombra dela passa, todos ficam **Cegos** e marcam 1 Estresse.

### Desce — Ação de Medo

Gaste 4 Medo: desce. `6d10` em tudo na cena, e a cena muda de forma.

> [!NOTE] Marcas
> Dano abaixo de 17 marca **1**; de 17 para cima, **2**; de 32 para cima, **3**. Sozinho contra o grupo inteiro.

---

## Links Relacionados
- [[🌊 As Fundas]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
