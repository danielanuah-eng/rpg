---
tipo: Adversário
categoria: Funda
tags:
  - peso-do-ceu
  - adversario
  - funda
  - kaiju
  - escalao/2
escalao: 2
papel: Batedor
plano: voadora
pdf_page: 94
jogo: O Peso do Céu
---

# Eco

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=94|Consultar Texto Original no PDF (Página 94) — Eco — ficha e traços]]**

*Batedor · Escalão 2º · Funda*

> Cega, pequena e rápida. Enxerga por som, e por isso ataca sempre o que estiver fazendo mais barulho.

---

## Ficha

| | |
|---|---|
| **Evasão** | 15 |
| **Limiares** | 10 / 19 |
| **Estrutura** | 4 |
| **Ataque** | +4 |
| **Dano** | `2d10+6` |
| **Grito** | Perto |

**Motivos.** *Ouvir · chegar · calar*

---

## Traços

### Por Som — Passiva

Ataca sempre quem usou arma pesada, Peça Ativa ou Núcleo na última ação, e com vantagem.

### Grito — Ação de Medo

Gaste 1 Medo: todos em Perto ficam **Cegos** até a próxima ação deles.

> [!NOTE] Marcas
> Dano abaixo de 10 marca **1**; de 10 para cima, **2**; de 19 para cima, **3**. Chega, morde e sai. Difícil de acertar.

---

## Links Relacionados
- [[🌊 As Fundas]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
