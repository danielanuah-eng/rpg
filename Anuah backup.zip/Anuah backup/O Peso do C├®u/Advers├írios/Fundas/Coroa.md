---
tipo: Adversário
categoria: Funda
tags:
  - peso-do-ceu
  - adversario
  - funda
  - kaiju
  - escalao/4
escalao: 4
papel: Comandante
plano: colossal
pdf_page: 93
jogo: O Peso do Céu
---

# Coroa

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=93|Consultar Texto Original no PDF (Página 93) — Coroa — ficha e traços]]**

*Comandante · Escalão 4º · Funda*

> A maior de um bando. Não é a mais forte: é a que as outras escutam, e isso é pior.

---

## Ficha

| | |
|---|---|
| **Evasão** | 17 |
| **Limiares** | 17 / 32 |
| **Estrutura** | 15 |
| **Ataque** | +8 |
| **Dano** | `4d10+9` |
| **Braços de comando** | Perto |

**Motivos.** *Manter o bando · escolher o caminho · chegar inteira*

---

## Traços

### Bando Grande — Passiva

Toda Funda na cena soma **+2** de ataque, de Evasão e de Limiares.

### Chamado — Ação de Medo

Gaste 3 Medo: chegam duas Fundas de Escalão 2.

> [!NOTE] Marcas
> Dano abaixo de 17 marca **1**; de 17 para cima, **2**; de 32 para cima, **3**. Gasta o Medo do Mestre melhor que os outros.

---

## Links Relacionados
- [[🌊 As Fundas]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
