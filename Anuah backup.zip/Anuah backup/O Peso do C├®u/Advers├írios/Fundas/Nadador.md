---
tipo: Adversário
categoria: Funda
tags:
  - peso-do-ceu
  - adversario
  - funda
  - kaiju
  - escalao/2
escalao: 2
papel: Batedor
plano: nadadora
pdf_page: 88
jogo: O Peso do Céu
---

# Nadador

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=88|Consultar Texto Original no PDF (Página 88) — Nadador — ficha e traços]]**

*Batedor · Escalão 2º · Funda*

> Dezoito metros de coisa lisa que se move na água como se a água não estivesse lá.

---

## Ficha

| | |
|---|---|
| **Evasão** | 15 |
| **Limiares** | 10 / 19 |
| **Estrutura** | 4 |
| **Ataque** | +4 |
| **Dano** | `2d10+6` |
| **Garras longas** | Corpo a corpo |

**Motivos.** *Atacar por baixo · levar um · voltar ao fundo*

---

## Traços

### Por Baixo — Passiva

Está sempre **Oculto** na água. Sair e voltar não custa ação.

### Leva — Ação de Medo

Gaste 3 Medo: agarra um alvo e desce. Os dois saem da cena por uma cena inteira.

> [!NOTE] Marcas
> Dano abaixo de 10 marca **1**; de 10 para cima, **2**; de 19 para cima, **3**. Chega, morde e sai. Difícil de acertar.

---

## Links Relacionados
- [[🌊 As Fundas]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
