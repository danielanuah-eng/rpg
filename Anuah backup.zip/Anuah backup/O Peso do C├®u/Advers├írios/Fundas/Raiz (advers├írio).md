---
tipo: Adversário
categoria: Funda
tags:
  - peso-do-ceu
  - adversario
  - funda
  - kaiju
  - escalao/2
escalao: 2
papel: Apoio
plano: torre
pdf_page: 49
jogo: O Peso do Céu
---

# Raiz (adversário)

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=49|Consultar Texto Original no PDF (Página 49) — Raiz — ficha e traços]]**

*Apoio · Escalão 2º · Funda*

> Só se vê a ponta. O resto está embaixo do chão, e o chão é a criatura.

---

## Ficha

| | |
|---|---|
| **Evasão** | 13 |
| **Limiares** | 10 / 19 |
| **Estrutura** | 6 |
| **Ataque** | +4 |
| **Dano** | `2d10+6` |
| **Tentáculo de fundo** | Perto |

**Motivos.** *Prender · puxar para baixo · esperar*

---

## Traços

### Embaixo — Passiva

Só pode ser atacada em Corpo a corpo e apenas pela ponta que estiver de fora.

### Puxa — Ação de Medo

Gaste 2 Medo: um alvo fica **Restrito** e afunda até a cintura.

> [!NOTE] Marcas
> Dano abaixo de 10 marca **1**; de 10 para cima, **2**; de 19 para cima, **3**. Não vence sozinho. Faz os outros vencerem.

---

## Links Relacionados
- [[🌊 As Fundas]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
