---
tipo: Adversário
categoria: Funda
tags:
  - peso-do-ceu
  - adversario
  - funda
  - kaiju
  - escalao/3
escalao: 3
papel: Bando
plano: rastejante
pdf_page: 51
jogo: O Peso do Céu
---

# Vazante (adversário 2)

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=51|Consultar Texto Original no PDF (Página 51) — Vazante — ficha e traços]]**

*Bando · Escalão 3º · Funda*

> Não é uma: são trezentas, e elas atravessam a planície quando a água baixa.

---

## Ficha

| | |
|---|---|
| **Evasão** | 15 |
| **Limiares** | 13 / 26 |
| **Estrutura** | 11 |
| **Ataque** | +6 |
| **Dano** | `3d10+7` |
| **Onda de patas** | Corpo a corpo |

**Motivos.** *Atravessar · comer o que estiver no caminho · chegar do outro lado*

---

## Traços

### Onda — Passiva

Ocupa todas as faixas de alcance até Perto ao mesmo tempo.

### Passa Por Cima — Ação de Medo

Gaste 2 Medo: todos na cena sofrem o dano e ficam **Instáveis**.

> [!NOTE] Marcas
> Dano abaixo de 13 marca **1**; de 13 para cima, **2**; de 26 para cima, **3**. Conta como vários. O dano cai pela metade na segunda metade da Estrutura.

---

## Links Relacionados
- [[🌊 As Fundas]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
