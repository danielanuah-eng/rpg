---
tipo: Adversário
categoria: Funda
tags:
  - peso-do-ceu
  - adversario
  - funda
  - kaiju
  - escalao/4
escalao: 4
papel: Solo
plano: massa
pdf_page: 90
jogo: O Peso do Céu
---

# O Monte

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=90|Consultar Texto Original no PDF (Página 90) — O Monte — ficha e traços]]**

*Solo · Escalão 4º · Funda*

> Três quilômetros de massa que absorveu duas vilas, uma refinaria e um comboio inteiro. Partes ainda funcionam.

---

## Ficha

| | |
|---|---|
| **Evasão** | 18 |
| **Limiares** | 17 / 32 |
| **Estrutura** | 31 |
| **Ataque** | +8 |
| **Dano** | `4d10+9` |
| **Tudo que ela já comeu** | Perto |

**Motivos.** *Absorver · crescer · não ter pressa*

---

## Traços

### Absorve — Passiva

Quando qualquer coisa cai perto dela, ela ganha 4 Estrutura e uma Peça daquela coisa.

### Lembranças — Ação de Medo

Gaste 3 Medo: uma máquina que o Monte comeu sai de dentro dele e ataca, como adversário de Escalão 2.

### Sem Centro — Passiva

Não existe ponto fraco. Só existe menos monte.

> [!NOTE] Marcas
> Dano abaixo de 17 marca **1**; de 17 para cima, **2**; de 32 para cima, **3**. Sozinho contra o grupo inteiro.

---

## Links Relacionados
- [[🌊 As Fundas]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
