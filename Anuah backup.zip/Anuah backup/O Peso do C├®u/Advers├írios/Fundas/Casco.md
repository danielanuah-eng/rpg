---
tipo: Adversário
categoria: Funda
tags:
  - peso-do-ceu
  - adversario
  - funda
  - kaiju
  - escalao/2
escalao: 2
papel: Regular
plano: rastejante
pdf_page: 92
jogo: O Peso do Céu
---

# Casco

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=92|Consultar Texto Original no PDF (Página 92) — Casco — ficha e traços]]**

*Regular · Escalão 2º · Funda*

> Carrega nas costas alguma coisa que já foi um prédio. Ninguém sabe por quê.

---

## Ficha

| | |
|---|---|
| **Evasão** | 13 |
| **Limiares** | 10 / 19 |
| **Estrutura** | 7 |
| **Ataque** | +4 |
| **Dano** | `2d10+6` |
| **Pinça** | Corpo a corpo |

**Motivos.** *Carregar · atravessar · não largar*

---

## Traços

### Carga — Passiva

Reduz em um degrau todo dano vindo de cima ou de trás.

### Larga — Ação de Medo

Gaste 2 Medo: solta o que carrega em cima de alguém. `4d10` e o alvo fica **Restrito**.

> [!NOTE] Marcas
> Dano abaixo de 10 marca **1**; de 10 para cima, **2**; de 19 para cima, **3**. A linha. É por ela que se mede tudo.

---

## Links Relacionados
- [[🌊 As Fundas]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
