---
tipo: Adversário
categoria: Funda
tags:
  - peso-do-ceu
  - adversario
  - funda
  - kaiju
  - escalao/3
escalao: 3
papel: Apoio
plano: massa
pdf_page: 92
jogo: O Peso do Céu
---

# Olho-Fundo

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=92|Consultar Texto Original no PDF (Página 92) — Olho-Fundo — ficha e traços]]**

*Apoio · Escalão 3º · Funda*

> Não ataca. Fica olhando, e as outras ficam melhores.

---

## Ficha

| | |
|---|---|
| **Evasão** | 15 |
| **Limiares** | 13 / 26 |
| **Estrutura** | 7 |
| **Ataque** | +6 |
| **Dano** | `3d10+7` |
| **Olhar** | Longe |

**Motivos.** *Olhar · coordenar · nunca chegar perto*

---

## Traços

### Enquanto Ele Olha — Passiva

Toda Funda na cena soma **+3** de ataque e não pode ser surpreendida.

### Vê Você — Ação de Medo

Gaste 1 Medo: um personagem marca 2 Estresse e perde qualquer **Oculto**.

> [!NOTE] Marcas
> Dano abaixo de 13 marca **1**; de 13 para cima, **2**; de 26 para cima, **3**. Não vence sozinho. Faz os outros vencerem.

---

## Links Relacionados
- [[🌊 As Fundas]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
