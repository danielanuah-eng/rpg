---
tipo: Adversário
categoria: Funda
tags:
  - peso-do-ceu
  - adversario
  - funda
  - kaiju
  - escalao/2
escalao: 2
papel: Brutamontes
plano: massa
pdf_page: 87
jogo: O Peso do Céu
---

# Lodo

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=87|Consultar Texto Original no PDF (Página 87) — Lodo — ficha e traços]]**

*Brutamontes · Escalão 2º · Funda*

> Não tem forma fixa. Escorre, cobre e endurece. Já foi outra coisa.

---

## Ficha

| | |
|---|---|
| **Evasão** | 12 |
| **Limiares** | 10 / 19 |
| **Estrutura** | 13 |
| **Ataque** | +4 |
| **Dano** | `2d10+6` |
| **Massa** | Muito Perto |

**Motivos.** *Cobrir · endurecer · digerir devagar*

---

## Traços

### Sem Junta — Passiva

Armas de corte e perfuração causam metade do dano.

### Cobre — Ação de Medo

Gaste 2 Medo: escorre por cima de um colosso. O alvo fica **Restrito** e o piloto marca 1 Estresse por ação.

> [!NOTE] Marcas
> Dano abaixo de 10 marca **1**; de 10 para cima, **2**; de 19 para cima, **3**. Aguenta. Lento e caro de derrubar.

---

## Links Relacionados
- [[🌊 As Fundas]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
