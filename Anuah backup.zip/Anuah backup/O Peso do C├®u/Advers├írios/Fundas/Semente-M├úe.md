---
tipo: Adversário
categoria: Funda
tags:
  - peso-do-ceu
  - adversario
  - funda
  - kaiju
  - escalao/3
escalao: 3
papel: Regular
plano: massa
pdf_page: 93
jogo: O Peso do Céu
---

# Semente-Mãe

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=93|Consultar Texto Original no PDF (Página 93) — Semente-Mãe — ficha e traços]]**

*Regular · Escalão 3º · Funda*

> Não se move e não se defende. Só produz, a cada poucos minutos, mais uma.

---

## Ficha

| | |
|---|---|
| **Evasão** | 15 |
| **Limiares** | 13 / 26 |
| **Estrutura** | 9 |
| **Ataque** | +6 |
| **Dano** | `3d10+7` |
| **Parto** | Muito Perto |

**Motivos.** *Produzir · não ser interrompida · encher o lugar*

---

## Traços

### Não Para — Passiva

No fim de cada cena, chega um Bando de Crias.

### Última Ninhada — Reação

Quando cai, solta um Bando de Crias imediatamente.

> [!NOTE] Marcas
> Dano abaixo de 13 marca **1**; de 13 para cima, **2**; de 26 para cima, **3**. A linha. É por ela que se mede tudo.

---

## Links Relacionados
- [[🌊 As Fundas]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
