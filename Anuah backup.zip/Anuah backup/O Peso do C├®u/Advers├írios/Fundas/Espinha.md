---
tipo: Adversário
categoria: Funda
tags:
  - peso-do-ceu
  - adversario
  - funda
  - kaiju
  - escalao/4
escalao: 4
papel: Brutamontes
plano: torre
pdf_page: 91
jogo: O Peso do Céu
---

# Espinha

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=91|Consultar Texto Original no PDF (Página 91) — Espinha — ficha e traços]]**

*Brutamontes · Escalão 4º · Funda*

> Cento e vinte metros de coisa fina que cresceu no meio da cidade em uma noite e agora dispara.

---

## Ficha

| | |
|---|---|
| **Evasão** | 16 |
| **Limiares** | 17 / 32 |
| **Estrutura** | 20 |
| **Ataque** | +8 |
| **Dano** | `4d10+9` |
| **Lança de osso** | Muito Longe |

**Motivos.** *Crescer · espalhar sementes · não cair*

---

## Traços

### Não Tomba — Passiva

Não pode ser derrubada, empurrada nem movida por nada.

### Semeia — Ação de Medo

Gaste 2 Medo: chega um Bando de Crias, em qualquer lugar da cena.

> [!NOTE] Marcas
> Dano abaixo de 17 marca **1**; de 17 para cima, **2**; de 32 para cima, **3**. Aguenta. Lento e caro de derrubar.

---

## Links Relacionados
- [[🌊 As Fundas]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
