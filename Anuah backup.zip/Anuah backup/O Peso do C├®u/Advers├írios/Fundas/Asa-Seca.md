---
tipo: Adversário
categoria: Funda
tags:
  - peso-do-ceu
  - adversario
  - funda
  - kaiju
  - escalao/2
escalao: 2
papel: Batedor
plano: voadora
pdf_page: 88
jogo: O Peso do Céu
---

# Asa-Seca

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=88|Consultar Texto Original no PDF (Página 88) — Asa-Seca — ficha e traços]]**

*Batedor · Escalão 2º · Funda*

> Envergadura de vinte metros e um corpo que cabe num carro. Mergulha de tão alto que chega antes do som.

---

## Ficha

| | |
|---|---|
| **Evasão** | 15 |
| **Limiares** | 10 / 19 |
| **Estrutura** | 4 |
| **Ataque** | +4 |
| **Dano** | `2d10+6` |
| **Garras de mergulho** | Perto |

**Motivos.** *Mergulhar · levar · voltar a subir*

---

## Traços

### Alto Demais — Passiva

Só pode ser atacada de Longe ou mais longe, a não ser que esteja mergulhando.

### Rapina — Ação de Medo

Gaste 2 Medo: pega um personagem a pé e o leva para cima. Soltar é decisão dela.

> [!NOTE] Marcas
> Dano abaixo de 10 marca **1**; de 10 para cima, **2**; de 19 para cima, **3**. Chega, morde e sai. Difícil de acertar.

---

## Links Relacionados
- [[🌊 As Fundas]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
