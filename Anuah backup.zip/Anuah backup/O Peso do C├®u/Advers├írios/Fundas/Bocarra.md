---
tipo: Adversário
categoria: Funda
tags:
  - peso-do-ceu
  - adversario
  - funda
  - kaiju
  - escalao/3
escalao: 3
papel: Brutamontes
plano: ereta
pdf_page: 88
jogo: O Peso do Céu
---

# Bocarra

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=88|Consultar Texto Original no PDF (Página 88) — Bocarra — ficha e traços]]**

*Brutamontes · Escalão 3º · Funda*

> Quatro andares de coisa que anda em duas pernas e não tem nenhum outro plano além de morder.

---

## Ficha

| | |
|---|---|
| **Evasão** | 14 |
| **Limiares** | 13 / 26 |
| **Estrutura** | 16 |
| **Ataque** | +6 |
| **Dano** | `3d10+7` |
| **Mordida** | Corpo a corpo |

**Motivos.** *Morder · engolir · continuar*

---

## Traços

### Engole — Passiva

Quando derruba qualquer coisa, limpa 5 Estrutura.

### Sacode — Ação de Medo

Gaste 2 Medo: um alvo **Restrito** sofre o dano dela duas vezes.

> [!NOTE] Marcas
> Dano abaixo de 13 marca **1**; de 13 para cima, **2**; de 26 para cima, **3**. Aguenta. Lento e caro de derrubar.

---

## Links Relacionados
- [[🌊 As Fundas]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
