---
tipo: Adversário
categoria: Funda
tags:
  - peso-do-ceu
  - adversario
  - funda
  - kaiju
  - escalao/4
escalao: 4
papel: Solo
plano: colossal
pdf_page: 90
jogo: O Peso do Céu
---

# A Boca

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=90|Consultar Texto Original no PDF (Página 90) — A Boca — ficha e traços]]**

*Solo · Escalão 4º · Funda*

> Do tamanho de um quarteirão. Ninguém viu o corpo inteiro e voltou com uma descrição que batesse com a de outro.

---

## Ficha

| | |
|---|---|
| **Evasão** | 18 |
| **Limiares** | 17 / 32 |
| **Estrutura** | 31 |
| **Ataque** | +8 |
| **Dano** | `4d10+9` |
| **A boca** | Muito Perto |

**Motivos.** *Comer · continuar · não ser impedida*

---

## Traços

### Tamanho — Passiva

Ocupa todas as faixas de alcance até Perto e não pode ser **Restrita**, empurrada nem movida.

### Engole — Ação de Medo

Gaste 3 Medo: um colosso em Muito Perto é engolido. Lá dentro é outro lugar.

### Continua — Passiva

A Boca não persegue ninguém: ela vai para onde ia. O problema é que há uma cidade no caminho.

> [!NOTE] Marcas
> Dano abaixo de 17 marca **1**; de 17 para cima, **2**; de 32 para cima, **3**. Sozinho contra o grupo inteiro.

---

## Links Relacionados
- [[🌊 As Fundas]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
