---
tipo: Adversário
categoria: Gente e veículo
tags:
  - peso-do-ceu
  - adversario
  - gente
  - escalao/1
escalao: 1
papel: Regular
pdf_page: 97
jogo: O Peso do Céu
---

# Blindado

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=97|Consultar Texto Original no PDF (Página 97) — Blindado — ficha e traços]]**

*Regular · Escalão 1º · gente a pé ou veículo*

> Tanque de linha. Contra gente é o fim do mundo; contra colosso é um incômodo bem-armado.

---

## Ficha

| | |
|---|---|
| **Evasão** | 11 |
| **Limiares** | 6 / 13 |
| **Estrutura** | 5 |
| **Ataque** | +2 |
| **Dano** | `1d10+5` |
| **Canhão de torre** | Longe |

**Motivos.** *Cobrir a estrada · não avançar sozinho · aguentar*

---

## Traços

### Blindagem Frontal — Passiva

Reduz em um degrau todo dano vindo de frente.

### Coluna — Passiva

Blindados aparecem em grupos de três.

> [!NOTE] Marcas
> Dano abaixo de 6 marca **1**; de 6 para cima, **2**; de 13 para cima, **3**. A linha. É por ela que se mede tudo.

---

## Links Relacionados
- [[☠️ Adversários]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
