---
tipo: Adversário
categoria: Gente e veículo
tags:
  - peso-do-ceu
  - adversario
  - gente
  - escalao/3
escalao: 3
papel: Apoio
pdf_page: 98
jogo: O Peso do Céu
---

# Dirigível

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=98|Consultar Texto Original no PDF (Página 98) — Dirigível — ficha e traços]]**

*Apoio · Escalão 3º · gente a pé ou veículo*

> Lento, enorme e cheio de gente que enxerga tudo. É um posto de comando que flutua.

---

## Ficha

| | |
|---|---|
| **Evasão** | 15 |
| **Limiares** | 13 / 26 |
| **Estrutura** | 7 |
| **Ataque** | +6 |
| **Dano** | `3d10+7` |
| **Metralhas de gôndola** | Muito Longe |

**Motivos.** *Ver tudo · coordenar · não ser furado*

---

## Traços

### De Cima — Passiva

Todo adversário na cena soma **+2** de ataque enquanto ele estiver no ar.

### Desce Gente — Ação de Medo

Gaste 2 Medo: uma Equipe de Fenda desce de rapel em qualquer ponto da cena.

> [!NOTE] Marcas
> Dano abaixo de 13 marca **1**; de 13 para cima, **2**; de 26 para cima, **3**. Não vence sozinho. Faz os outros vencerem.

---

## Links Relacionados
- [[☠️ Adversários]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
