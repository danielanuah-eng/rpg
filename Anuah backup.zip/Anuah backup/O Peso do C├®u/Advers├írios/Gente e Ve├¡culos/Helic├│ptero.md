---
tipo: Adversário
categoria: Gente e veículo
tags:
  - peso-do-ceu
  - adversario
  - gente
  - escalao/2
escalao: 2
papel: Batedor
pdf_page: 97
jogo: O Peso do Céu
---

# Helicóptero

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=97|Consultar Texto Original no PDF (Página 97) — Helicóptero — ficha e traços]]**

*Batedor · Escalão 2º · gente a pé ou veículo*

> Rápido, barulhento e frágil. Serve para ver, levar e incomodar.

---

## Ficha

| | |
|---|---|
| **Evasão** | 15 |
| **Limiares** | 10 / 19 |
| **Estrutura** | 4 |
| **Ataque** | +4 |
| **Dano** | `2d10+6` |
| **Metralha de porta** | Perto |

**Motivos.** *Ver · levar gente · não ser acertado*

---

## Traços

### Voa — Passiva

Só pode ser atacado por quem voa ou por arma de Longe ou mais longe.

### Evacua — Ação

Tira duas pessoas da cena, ou traz duas.

> [!NOTE] Marcas
> Dano abaixo de 10 marca **1**; de 10 para cima, **2**; de 19 para cima, **3**. Chega, morde e sai. Difícil de acertar.

---

## Links Relacionados
- [[☠️ Adversários]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
