---
tipo: Adversário
categoria: Gente e veículo
tags:
  - peso-do-ceu
  - adversario
  - gente
  - escalao/2
escalao: 2
papel: Atirador
pdf_page: 95
jogo: O Peso do Céu
---

# Atirador de Elite

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=95|Consultar Texto Original no PDF (Página 95) — Atirador de Elite — ficha e traços]]**

*Atirador · Escalão 2º · gente a pé ou veículo*

> Uma pessoa, um rifle, e três horas deitada no mesmo lugar.

---

## Ficha

| | |
|---|---|
| **Evasão** | 13 |
| **Limiares** | 10 / 19 |
| **Estrutura** | 4 |
| **Ataque** | +4 |
| **Dano** | `2d10+6` |
| **Rifle antimaterial** | Muito Longe |

**Motivos.** *Atirar primeiro · não ser encontrado · escolher o alvo*

---

## Traços

### Antimáquina — Passiva

Dano cheio contra colosso.

### Sem Fumaça — Passiva

Está **Oculto** até disparar, e volta a ficar se ninguém agir contra ele.

> [!NOTE] Marcas
> Dano abaixo de 10 marca **1**; de 10 para cima, **2**; de 19 para cima, **3**. Fica longe. Se deixarem chegar perto, acaba.

---

## Links Relacionados
- [[☠️ Adversários]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
