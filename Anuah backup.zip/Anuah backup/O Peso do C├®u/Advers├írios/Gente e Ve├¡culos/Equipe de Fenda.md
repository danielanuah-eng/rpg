---
tipo: Adversário
categoria: Gente e veículo
tags:
  - peso-do-ceu
  - adversario
  - gente
  - escalao/2
escalao: 2
papel: Regular
pdf_page: 95
jogo: O Peso do Céu
---

# Equipe de Fenda

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=95|Consultar Texto Original no PDF (Página 95) — Equipe de Fenda — ficha e traços]]**

*Regular · Escalão 2º · gente a pé ou veículo*

> Quatro pessoas, uma mochila cada, e a paciência de esperar um colosso ficar parado tempo suficiente.

---

## Ficha

| | |
|---|---|
| **Evasão** | 13 |
| **Limiares** | 10 / 19 |
| **Estrutura** | 7 |
| **Ataque** | +4 |
| **Dano** | `2d10+6` |
| **Carga de fenda** | Corpo a corpo |

**Motivos.** *Chegar perto · plantar · sair correndo*

---

## Traços

### Antimáquina — Passiva

O dano deles contra colosso é cheio e ignora Blindagem.

### Sobe — Ação de Medo

Gaste 2 Medo: sobem num colosso. Ele fica **Vulnerável** e eles atacam de dentro da guarda.

> [!NOTE] Marcas
> Dano abaixo de 10 marca **1**; de 10 para cima, **2**; de 19 para cima, **3**. A linha. É por ela que se mede tudo.

---

## Links Relacionados
- [[☠️ Adversários]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
