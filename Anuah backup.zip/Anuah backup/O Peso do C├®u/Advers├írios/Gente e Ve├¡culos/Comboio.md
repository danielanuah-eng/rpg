---
tipo: Adversário
categoria: Gente e veículo
tags:
  - peso-do-ceu
  - adversario
  - gente
  - escalao/3
escalao: 3
papel: Bando
pdf_page: 98
jogo: O Peso do Céu
---

# Comboio

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=98|Consultar Texto Original no PDF (Página 98) — Comboio — ficha e traços]]**

*Bando · Escalão 3º · gente a pé ou veículo*

> Doze veículos em fila, cada um com alguma coisa parafusada em cima. Juntos são um problema de verdade.

---

## Ficha

| | |
|---|---|
| **Evasão** | 15 |
| **Limiares** | 13 / 26 |
| **Estrutura** | 11 |
| **Ataque** | +6 |
| **Dano** | `3d10+7` |
| **Tudo que estiver montado** | Longe |

**Motivos.** *Atravessar · entregar a carga · não parar*

---

## Traços

### Fila — Passiva

Ocupa duas faixas de alcance ao mesmo tempo.

### Dispersa — Ação de Medo

Gaste 2 Medo: o comboio se abre. Cada metade age separadamente a partir de agora.

> [!NOTE] Marcas
> Dano abaixo de 13 marca **1**; de 13 para cima, **2**; de 26 para cima, **3**. Conta como vários. O dano cai pela metade na segunda metade da Estrutura.

---

## Links Relacionados
- [[☠️ Adversários]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
