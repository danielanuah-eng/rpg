---
tipo: Adversário
categoria: Gente e veículo
tags:
  - peso-do-ceu
  - adversario
  - gente
  - escalao/1
escalao: 1
papel: Apoio
pdf_page: 99
jogo: O Peso do Céu
---

# Engenheiro

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=99|Consultar Texto Original no PDF (Página 99) — Engenheiro — ficha e traços]]**

*Apoio · Escalão 1º · gente a pé ou veículo*

> Não briga. Conserta, abre e fecha coisas, e sabe onde é o ponto fraco de tudo que existe naquele lugar.

---

## Ficha

| | |
|---|---|
| **Evasão** | 11 |
| **Limiares** | 6 / 13 |
| **Estrutura** | 4 |
| **Ataque** | +2 |
| **Dano** | `1d10+5` |
| **Maçarico** | Corpo a corpo |

**Motivos.** *Consertar · abrir passagem · não estar lá quando começar*

---

## Traços

### Conserta — Ação

Limpa 3 Estrutura de um adversário que alcance.

### Sabe Onde — Ação de Medo

Gaste 1 Medo: revela um ponto fraco da Localização. Uma coisa que estava fechada abre.

> [!NOTE] Marcas
> Dano abaixo de 6 marca **1**; de 6 para cima, **2**; de 13 para cima, **3**. Não vence sozinho. Faz os outros vencerem.

---

## Links Relacionados
- [[☠️ Adversários]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
