---
tipo: Adversário
categoria: Gente e veículo
tags:
  - peso-do-ceu
  - adversario
  - gente
  - escalao/4
escalao: 4
papel: Comandante
pdf_page: 99
jogo: O Peso do Céu
---

# Interventor

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=99|Consultar Texto Original no PDF (Página 99) — Interventor — ficha e traços]]**

*Comandante · Escalão 4º · gente a pé ou veículo*

> Chegou com papel assinado e autoridade para reescrever o que estava combinado. Não trouxe arma nenhuma.

---

## Ficha

| | |
|---|---|
| **Evasão** | 17 |
| **Limiares** | 17 / 32 |
| **Estrutura** | 15 |
| **Ataque** | +8 |
| **Dano** | `4d10+9` |
| **A autoridade** | Perto |

**Motivos.** *Executar a ordem · não negociar · sair com a assinatura*

---

## Traços

### Papel — Passiva

Enquanto ele estiver vivo e falando, nenhum adversário de força regular pode ser convencido a mudar de lado.

### Revogado — Ação de Medo

Gaste 3 Medo: uma permissão, licença ou acordo que os personagens tinham deixa de valer, agora.

### Escolta — Passiva

Nunca aparece sem quatro adversários de Escalão 3 junto.

> [!NOTE] Marcas
> Dano abaixo de 17 marca **1**; de 17 para cima, **2**; de 32 para cima, **3**. Gasta o Medo do Mestre melhor que os outros.

---

## Links Relacionados
- [[☠️ Adversários]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
