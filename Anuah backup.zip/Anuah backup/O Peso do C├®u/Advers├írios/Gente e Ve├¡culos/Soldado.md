---
tipo: Adversário
categoria: Gente e veículo
tags:
  - peso-do-ceu
  - adversario
  - gente
  - escalao/1
escalao: 1
papel: Lacaio
pdf_page: 95
jogo: O Peso do Céu
---

# Soldado

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=95|Consultar Texto Original no PDF (Página 95) — Soldado — ficha e traços]]**

*Lacaio · Escalão 1º · gente a pé ou veículo*

> Gente a pé com um fuzil que não fura casco nenhum. Eles sabem disso.

---

## Ficha

| | |
|---|---|
| **Evasão** | 9 |
| **Limiares** | 6 / 13 |
| **Estrutura** | 1 |
| **Ataque** | +2 |
| **Dano** | `1d10+5` |
| **Fuzil de infantaria** | Perto |

**Motivos.** *Cumprir a ordem · não morrer por engano · voltar*

---

## Traços

### Não Fura Casco — Passiva

Contra colosso, o dano é metade — a não ser que estejam em Corpo a corpo com carga de fenda.

### Pelotão — Passiva

Soldados aparecem em grupos de seis ou mais.

> [!NOTE] Marcas
> Dano abaixo de 6 marca **1**; de 6 para cima, **2**; de 13 para cima, **3**. Cai com qualquer acerto. Vem em grupo de três ou mais.

---

## Links Relacionados
- [[☠️ Adversários]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
