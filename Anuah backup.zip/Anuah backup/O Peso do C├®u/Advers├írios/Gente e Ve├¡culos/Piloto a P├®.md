---
tipo: Adversário
categoria: Gente e veículo
tags:
  - peso-do-ceu
  - adversario
  - gente
  - escalao/2
escalao: 2
papel: Batedor
pdf_page: 96
jogo: O Peso do Céu
---

# Piloto a Pé

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=96|Consultar Texto Original no PDF (Página 96) — Piloto a Pé — ficha e traços]]**

*Batedor · Escalão 2º · gente a pé ou veículo*

> Saiu do casco vivo e agora está no meio de uma briga de máquinas com uma arma que cabe no bolso.

---

## Ficha

| | |
|---|---|
| **Evasão** | 15 |
| **Limiares** | 10 / 19 |
| **Estrutura** | 4 |
| **Ataque** | +4 |
| **Dano** | `2d10+6` |
| **Pistola de cabine** | Perto |

**Motivos.** *Chegar num casco · não ser pisado · voltar para a doca*

---

## Traços

### Pequeno Demais — Passiva

Colossos precisam gastar 1 Medo para se dar ao trabalho de atacá-lo.

### Sobe — Ação

Sobe em um colosso adjacente. De cima, ele não alcança sem gastar uma ação se sacudindo.

> [!NOTE] Marcas
> Dano abaixo de 10 marca **1**; de 10 para cima, **2**; de 19 para cima, **3**. Chega, morde e sai. Difícil de acertar.

---

## Links Relacionados
- [[☠️ Adversários]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
