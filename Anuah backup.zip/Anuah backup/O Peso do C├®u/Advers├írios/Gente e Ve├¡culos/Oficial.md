---
tipo: Adversário
categoria: Gente e veículo
tags:
  - peso-do-ceu
  - adversario
  - gente
  - escalao/2
escalao: 2
papel: Comandante
pdf_page: 96
jogo: O Peso do Céu
---

# Oficial

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=96|Consultar Texto Original no PDF (Página 96) — Oficial — ficha e traços]]**

*Comandante · Escalão 2º · gente a pé ou veículo*

> Não atira bem. Não precisa: o rádio dele alcança mais que qualquer arma na cena.

---

## Ficha

| | |
|---|---|
| **Evasão** | 13 |
| **Limiares** | 10 / 19 |
| **Estrutura** | 10 |
| **Ataque** | +4 |
| **Dano** | `2d10+6` |
| **Pistola e rádio** | Perto |

**Motivos.** *Manter o controle · relatar · não sujar a farda*

---

## Traços

### Rádio — Ação

Dois adversários em qualquer lugar da cena agem imediatamente.

### Chamar Fogo — Ação de Medo

Gaste 3 Medo: artilharia cai num lugar à escolha dele. `5d10` em tudo lá.

> [!NOTE] Marcas
> Dano abaixo de 10 marca **1**; de 10 para cima, **2**; de 19 para cima, **3**. Gasta o Medo do Mestre melhor que os outros.

---

## Links Relacionados
- [[☠️ Adversários]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
