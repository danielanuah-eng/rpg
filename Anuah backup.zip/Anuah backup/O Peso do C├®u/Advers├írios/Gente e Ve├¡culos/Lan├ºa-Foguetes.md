---
tipo: Adversário
categoria: Gente e veículo
tags:
  - peso-do-ceu
  - adversario
  - gente
  - escalao/2
escalao: 2
papel: Atirador
pdf_page: 97
jogo: O Peso do Céu
---

# Lança-Foguetes

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=97|Consultar Texto Original no PDF (Página 97) — Lança-Foguetes — ficha e traços]]**

*Atirador · Escalão 2º · gente a pé ou veículo*

> Caminhão com trilhos nas costas. Dispara tudo e vai embora, nessa ordem.

---

## Ficha

| | |
|---|---|
| **Evasão** | 13 |
| **Limiares** | 10 / 19 |
| **Estrutura** | 4 |
| **Ataque** | +4 |
| **Dano** | `2d10+6` |
| **Salva de foguetes** | Muito Longe |

**Motivos.** *Descarregar · sumir · recarregar em outro lugar*

---

## Traços

### Antimáquina — Passiva

Dano cheio contra colosso.

### E Sai — Reação

Depois de disparar, sai da cena. Volta na cena seguinte, recarregado.

> [!NOTE] Marcas
> Dano abaixo de 10 marca **1**; de 10 para cima, **2**; de 19 para cima, **3**. Fica longe. Se deixarem chegar perto, acaba.

---

## Links Relacionados
- [[☠️ Adversários]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
