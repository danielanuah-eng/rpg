---
tipo: Adversário
categoria: Gente e veículo
tags:
  - peso-do-ceu
  - adversario
  - gente
  - escalao/3
escalao: 3
papel: Brutamontes
pdf_page: 98
jogo: O Peso do Céu
---

# Trem Blindado

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=98|Consultar Texto Original no PDF (Página 98) — Trem Blindado — ficha e traços]]**

*Brutamontes · Escalão 3º · gente a pé ou veículo*

> Uma fortaleza que anda em trilho. Só vai aonde o trilho vai, e é exatamente por isso que o trilho é o alvo.

---

## Ficha

| | |
|---|---|
| **Evasão** | 14 |
| **Limiares** | 13 / 26 |
| **Estrutura** | 16 |
| **Ataque** | +6 |
| **Dano** | `3d10+7` |
| **Bateria de vagão** | Muito Longe |

**Motivos.** *Chegar ao destino · não descarrilar · cobrir a linha*

---

## Traços

### Trilho — Passiva

Só se move ao longo do trilho. Quebrar o trilho é uma ação com Dificuldade 16.

### Salva de Vagão — Ação de Medo

Gaste 2 Medo: três alvos diferentes sofrem o dano dele.

> [!NOTE] Marcas
> Dano abaixo de 13 marca **1**; de 13 para cima, **2**; de 26 para cima, **3**. Aguenta. Lento e caro de derrubar.

---

## Links Relacionados
- [[☠️ Adversários]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
