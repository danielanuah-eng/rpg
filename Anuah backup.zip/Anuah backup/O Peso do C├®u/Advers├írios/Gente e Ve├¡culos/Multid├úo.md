---
tipo: Adversário
categoria: Gente e veículo
tags:
  - peso-do-ceu
  - adversario
  - gente
  - escalao/2
escalao: 2
papel: Bando
pdf_page: 96
jogo: O Peso do Céu
---

# Multidão

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=96|Consultar Texto Original no PDF (Página 96) — Multidão — ficha e traços]]**

*Bando · Escalão 2º · gente a pé ou veículo*

> Não é um adversário: é uma condição do terreno que resolveu ter opinião.

---

## Ficha

| | |
|---|---|
| **Evasão** | 13 |
| **Limiares** | 10 / 19 |
| **Estrutura** | 8 |
| **Ataque** | +4 |
| **Dano** | `2d10+6` |
| **Muita gente** | Corpo a corpo |

**Motivos.** *Sair dali · ser ouvida · não ser atropelada*

---

## Traços

### Gente — Passiva

Não pode ser atacada por colosso sem consequência. O Mestre anota quem tentou.

### Onda — Ação de Medo

Gaste 1 Medo: a multidão se move. Tudo no caminho fica **Restrito** por uma ação.

> [!NOTE] Marcas
> Dano abaixo de 10 marca **1**; de 10 para cima, **2**; de 19 para cima, **3**. Conta como vários. O dano cai pela metade na segunda metade da Estrutura.

---

## Links Relacionados
- [[☠️ Adversários]]
- [[☠️ Adversários]]
- [[Montar uma Briga]]
- [[🛰️ O Peso do Céu]]
