---
tipo: Hub
categoria: MOC
tags:
  - peso-do-ceu
  - moc
  - hub
jogo: O Peso do Céu
---

# 🌊 As Fundas

Não são máquinas e não vieram de fábrica nenhuma. Sobem do fundo, e ninguém combinou com elas as regras que o resto do mundo segue.

---

## Escalão 1º

- [[Cria]] — Bando · Escalão 1º · Estrutura 6
- [[Lacraia]] — Batedor · Escalão 1º · Estrutura 3
- [[Carapaça]] — Brutamontes · Escalão 1º · Estrutura 9
- [[Pele]] — Apoio · Escalão 1º · Estrutura 4

## Escalão 2º

- [[Cardume]] — Bando · Escalão 2º · Estrutura 8
- [[Lodo]] — Brutamontes · Escalão 2º · Estrutura 13
- [[Agulha]] — Atirador · Escalão 2º · Estrutura 4
- [[Nadador]] — Batedor · Escalão 2º · Estrutura 4
- [[Asa-Seca]] — Batedor · Escalão 2º · Estrutura 4
- [[Casco]] — Regular · Escalão 2º · Estrutura 7
- [[Raiz (adversário)]] — Apoio · Escalão 2º · Estrutura 6
- [[Eco]] — Batedor · Escalão 2º · Estrutura 4

## Escalão 3º

- [[Bocarra]] — Brutamontes · Escalão 3º · Estrutura 16
- [[Torre Velha]] — Atirador · Escalão 3º · Estrutura 5
- [[Porão]] — Solo · Escalão 3º · Estrutura 25
- [[Vazante (adversário 2)]] — Bando · Escalão 3º · Estrutura 11
- [[Mergulhadora]] — Regular · Escalão 3º · Estrutura 9
- [[Travessia]] — Comandante · Escalão 3º · Estrutura 13
- [[Olho-Fundo]] — Apoio · Escalão 3º · Estrutura 7
- [[Semente-Mãe]] — Regular · Escalão 3º · Estrutura 9

## Escalão 4º

- [[A Boca]] — Solo · Escalão 4º · Estrutura 31
- [[O Monte]] — Solo · Escalão 4º · Estrutura 31
- [[Céu Aberto]] — Solo · Escalão 4º · Estrutura 31
- [[Espinha]] — Brutamontes · Escalão 4º · Estrutura 20
- [[Coroa]] — Comandante · Escalão 4º · Estrutura 15
- [[A Casa]] — Solo · Escalão 4º · Estrutura 31

---

[[☠️ Adversários|⬅ Voltar]]
