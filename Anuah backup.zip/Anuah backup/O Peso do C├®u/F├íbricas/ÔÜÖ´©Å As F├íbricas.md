---
tipo: Hub
categoria: MOC
tags:
  - peso-do-ceu
  - moc
  - hub
jogo: O Peso do Céu
---

# ⚙️ As oito fábricas

Oito casas que constroem colossos, e oito maneiras diferentes de achar que uma máquina deve ser. A licença de fábrica é de onde vem tudo o que o seu colosso sabe fazer: as **Peças** estão aqui, não em domínios.

---

## As oito casas

- **[[Companhia Brasa e Filhos]]** — *Fundição · chapa rebitada · a máquina que volta*
- **[[Vespertina Mecânica Fina]]** — *Academia · cintura estreita · chegar primeiro*
- **[[Fundição Catedral]]** — *Estado · chapa cerimonial · ser visto e obedecido*
- **[[Estaleiros do Arco]]** — *Naval · casco selado · a água é estrada*
- **[[Oficinas Gralha]]** — *Modular · encaixe universal · nenhuma igual à outra*
- **[[Selo Civil]]** — *Guarda · sensor e algema · entregar vivo*
- **[[Carvão]]** — *Mercado preto · placa trocada · o parafuso que ninguém checa*
- **[[Ossatura]]** — *Enxerto · carne de Funda · a carne lembra*

## Ver também

- [[🔩 As Peças]]
- [[🤖 O Colosso]]
- [[☠️ Adversários]]

---

[[🛰️ O Peso do Céu|⬅ Voltar]]
