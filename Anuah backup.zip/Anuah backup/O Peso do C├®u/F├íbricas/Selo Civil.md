---
tipo: Fábrica
categoria: Fábrica
tags:
  - peso-do-ceu
  - fabrica
  - fabrica/selo
pdf_page: 44
jogo: O Peso do Céu
---

# 🛡️ Selo Civil

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=44|Consultar Texto Original no PDF (Página 44) — A fábrica Selo Civil]]**

*Guarda · sensor e algema · entregar vivo*

> Não é sobre vencer. É sobre entregar vivo e com papel assinado.

---

## A proposta

O Selo Civil nasceu como fornecedor de guarda portuária e virou a maior fabricante de *sensor* do continente. Os cascos dele atiram pior que todos os outros e enxergam melhor que todos os outros juntos: antena de órbita, esfera de leitura, escuta passiva, holofote de apreensão, arpéu de algema. A doutrina da casa é explícita — um colosso do Selo que precisou disparar já tinha errado antes.

## A cultura

O Selo vende para polícia, para alfândega, para resgate e para empresa de segurança, e mantém uma rede de satélites de baixa órbita que aluga por assinatura. Metade dos pilotos do Selo nunca esteve numa guerra; a outra metade esteve em todas e resolveu mudar de trabalho. É a única fábrica que imprime o número de série do casco em letra grande nos dois ombros, de propósito.

## No olho

Chapa lisa e uniforme, faixa refletiva, torre de antenas na cabeça, ombreira quadrada com número pintado grande. Branco sujo e amarelo-sinal.

---

## Os chassis da casa

- [[Ronda]] — Médio · Estrutura 8 · Evasão 11 · Blindagem 2 · 5 encaixes
- [[Torre]] — Pesado · Estrutura 10 · Evasão 10 · Blindagem 3 · 4 encaixes

## A classe licenciada

- [[Sentinela]] — Alguém tem que anotar o que aconteceu aqui. Vai ser você.

## As quinze Peças

**Nível 1**

- [[Capacete de Órbita]] — *Fixa · sempre ligada*
- [[Holofote de Apreensão]] — *Ativa · 1 Estresse*

**Nível 2**

- [[Arpéu de Algema]] — *Ativa · 1 Estresse*
- [[Escuta Passiva]] — *Fixa · sempre ligada*

**Nível 3**

- [[Cassetete]] — *Fixa · sempre ligada*
- [[Registro]] — *Fixa · sempre ligada*

**Nível 4**

- [[Perímetro]] — *Ativa · 2 Estresse*

**Nível 5**

- [[Tiro de Aviso]] — *Ativa · 1 Estresse*
- [[Mandado]] — *Tensa · liga com 4+ de Medo na mesa*


---

## Links Relacionados
- [[⚙️ As Fábricas]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
