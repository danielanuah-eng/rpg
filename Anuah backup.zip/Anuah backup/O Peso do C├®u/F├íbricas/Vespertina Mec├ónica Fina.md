---
tipo: Fábrica
categoria: Fábrica
tags:
  - peso-do-ceu
  - fabrica
  - fabrica/vespertina
pdf_page: 36
jogo: O Peso do Céu
---

# 🕊️ Vespertina Mecânica Fina

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=36|Consultar Texto Original no PDF (Página 36) — A fábrica Vespertina Mecânica Fina]]**

*Academia · cintura estreita · chegar primeiro*

> Quem te vê não te alcança. Quem te alcança não te viu.

---

## A proposta

A Vespertina fabrica menos cascos em um ano do que a Brasa fabrica em uma semana, e cada um custa o que custa um quarteirão. São máquinas de cintura muito fina, patim polido, leque de aletas nas costas e uma ficha técnica que cabe numa folha — porque tudo que não era essencial foi tirado. A fábrica mantém contrato com as três academias de pilotagem do continente e escolhe a dedo quem pode comprar.

## A cultura

Pilotar Vespertina é uma declaração. Quem pilota foi treinado, tem nome, tem professor, e tem inimigos que sabem o nome dele. A fábrica manda um técnico junto com o casco e esse técnico responde à Vespertina, não ao piloto — o que já causou mais de um incidente diplomático. Um casco Vespertina abandonado no campo é recolhido pela própria fábrica antes de a poeira baixar.

## No olho

Branco e cinza-pérola, cintura de vespa, perna digitígrada, leque de quatro aletas varridas para cima. Zero rebite aparente. Tudo que aparece, aparece de propósito.

---

## Os chassis da casa

- [[Andorinha (chassi)]] — Leve · Estrutura 6 · Evasão 13 · Blindagem 0 · 5 encaixes
- [[Florete]] — Médio · Estrutura 7 · Evasão 12 · Blindagem 1 · 4 encaixes

## A classe licenciada

- [[Andorinha]] — A distância entre você e o problema é uma decisão sua, e você decide depressa.

## As quinze Peças

**Nível 1**

- [[Patim de Competição]] — *Fixa · sempre ligada*
- [[Passo de Lado]] — *Ativa · 1 Estresse*

**Nível 2**

- [[Lâmina de Serviço]] — *Fixa · sempre ligada*
- [[Silêncio de Casco]] — *Fixa · sempre ligada*

**Nível 3**

- [[Rasante]] — *Ativa · 1 Estresse*
- [[Leitura de Guarda]] — *Ativa · 1 Estresse*

**Nível 4**

- [[Campo de Corte]] — *Tensa · liga com 4+ de Medo na mesa*
- [[Aletas de Manobra]] — *Fixa · sempre ligada*

**Nível 5**

- [[Primeiro Corte]] — *Fixa · sempre ligada*


---

## Links Relacionados
- [[⚙️ As Fábricas]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
