---
tipo: Fábrica
categoria: Fábrica
tags:
  - peso-do-ceu
  - fabrica
  - fabrica/brasa
pdf_page: 34
jogo: O Peso do Céu
---

# 🔥 Companhia Brasa e Filhos

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=34|Consultar Texto Original no PDF (Página 34) — A fábrica Companhia Brasa e Filhos]]**

*Fundição · chapa rebitada · a máquina que volta*

> A gente não faz máquina bonita. A gente faz máquina que volta.

---

## A proposta

A Brasa é uma fundição de cidade operária que virou fabricante de colosso por acidente, quando a guerra chegou e ninguém mais tinha quem soubesse dobrar chapa daquela espessura. Ela nunca perdeu o jeito de fundição: os cascos saem com rebite aparente, solda visível, chaminé de escape e um manual de trinta páginas que qualquer mecânico de beira de estrada entende. Não há eletrônica que o piloto não consiga consertar com chave de fenda e teimosia.

## A cultura

Quem compra Brasa não compra desempenho, compra conserto. Uma Brasa quebrada volta a andar em seis horas com peça de caminhão. É o casco das milícias, das defesas civis, dos que não têm contrato com ninguém — e é, por isso mesmo, o casco mais numeroso de todas as frentes. Existe um ditado de doca que diz que toda guerra acaba sendo ganha por quem tinha a Brasa mais velha ainda de pé.

## No olho

Chapa grossa parafusada por fora, chaminés de escape nos ombros, membros de mangueira sanfonada, pé largo de bota. Tinta industrial por cima de tinta industrial. Nunca houve uma Brasa sem fuligem.

---

## Os chassis da casa

- [[Mula]] — Médio · Estrutura 8 · Evasão 10 · Blindagem 2 · 4 encaixes
- [[Bigorna]] — Pesado · Estrutura 10 · Evasão 9 · Blindagem 3 · 3 encaixes

## A classe licenciada

- [[Ferreiro]] — Você conhece essa máquina parafuso por parafuso, porque foi você que parafusou.

## As quinze Peças

**Nível 1**

- [[Chapa Sobreposta]] — *Fixa · sempre ligada*
- [[Pé de Chumbo]] — *Fixa · sempre ligada*
- [[Guincho de Doca]] — *Ativa · 1 Estresse*

**Nível 2**

- [[Solda de Campo]] — *Ativa · 1 Estresse*
- [[Fornalha Aberta]] — *Tensa · liga com 4+ de Medo na mesa*

**Nível 3**

- [[Marreta de Fundição]] — *Ativa · 1 Estresse*
- [[Braço de Carga]] — *Fixa · sempre ligada*

**Nível 4**

- [[Purga de Vapor]] — *Ativa · 2 Estresse*
- [[Casco Teimoso]] — *Fixa · sempre ligada*

**Nível 5**

- [[Motor de Teimosia]] — *Tensa · liga com 6+ de Medo na mesa*


---

## Links Relacionados
- [[⚙️ As Fábricas]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
