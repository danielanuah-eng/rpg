---
tipo: Fábrica
categoria: Fábrica
tags:
  - peso-do-ceu
  - fabrica
  - fabrica/ossatura
pdf_page: 48
jogo: O Peso do Céu
---

# 🦴 Ossatura

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=48|Consultar Texto Original no PDF (Página 48) — A fábrica Ossatura]]**

*Enxerto · carne de Funda · a carne lembra*

> Puseram carne de Funda dentro do casco. A carne lembra.

---

## A proposta

Ossatura é o nome que se deu ao programa de enxerto depois que ele deixou de ser segredo. A ideia é simples e é péssima: tecido de Funda, colhido fresco, integrado ao casco. Uma peça de Ossatura cicatriza sozinha, cresce, aprende e responde ao piloto antes de ele mandar. Funciona melhor do que qualquer coisa que as outras sete fábricas já venderam. Também cobra, e cobra do piloto.

## A cultura

Não existe uma Ossatura oficial. Existem três laboratórios de Estado que negam tudo, dois cartéis que não negam nada e uma quantidade crescente de pilotos com uma cicatriz no pescoço. Quem instala Ossatura entra numa conta que não fecha: a peça melhora, o piloto piora, e o dia em que os dois se encontram no meio tem nome próprio nas docas — chamam de *a virada*.

## No olho

Carapaça nervurada no lugar da chapa, ombreira de calota viva com espinhos, braço-garra desproporcional, nenhum visor — olhos. Osso, âmbar e uma cor de carne que ninguém escolheu.

---

## Os chassis da casa

- [[Costela]] — Médio · Estrutura 9 · Evasão 11 · Blindagem 1 · 5 encaixes
- [[Carcaça]] — Pesado · Estrutura 11 · Evasão 9 · Blindagem 2 · 4 encaixes

## A classe licenciada

- [[Herdeiro]] — Você desceu fundo demais uma vez. Alguma coisa subiu com você.

## As quinze Peças

**Nível 1**

- [[Enxerto]] — *Fixa · sempre ligada*
- [[Garra Viva]] — *Fixa · sempre ligada*

**Nível 2**

- [[Cicatriza]] — *Ativa · 1 Estresse*
- [[Cheiro de Sangue]] — *Fixa · sempre ligada*

**Nível 3**

- [[Berro]] — *Ativa · 1 Estresse*
- [[Pele Errada]] — *Fixa · sempre ligada*

**Nível 4**

- [[Segunda Boca]] — *Ativa · 1 Estresse*

**Nível 5**

- [[Muda]] — *Ativa · 2 Estresse*


---

## Links Relacionados
- [[⚙️ As Fábricas]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
