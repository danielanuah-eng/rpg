---
tipo: Fábrica
categoria: Fábrica
tags:
  - peso-do-ceu
  - fabrica
  - fabrica/gralha
pdf_page: 42
jogo: O Peso do Céu
---

# 🔧 Oficinas Gralha

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=42|Consultar Texto Original no PDF (Página 42) — A fábrica Oficinas Gralha]]**

*Modular · encaixe universal · nenhuma igual à outra*

> Não existe uma Gralha igual a outra. Existe a sua.

---

## A proposta

A Gralha não fabrica colosso: fabrica *encaixe*. O que sai da oficina é um esqueleto com pontos de fixação universais e um catálogo de trezentas páginas de coisas que cabem neles — inclusive coisas de outras fábricas, o que é ilegal em quatro países e praticado nos quatro. Um casco Gralha de dez anos não tem uma peça original, e a fábrica considera isso um elogio.

## A cultura

Quem pilota Gralha é quem mexe. A oficina vende direto para o piloto, sem intermediário, e mantém uma rede de galpões onde qualquer um pode alugar bancada por hora. É a fábrica dos mecânicos, dos convoios, dos independentes e de todo mundo que já foi despedido de outra fábrica. Também é a que mais mata piloto por peça mal instalada, e ninguém finge o contrário.

## No olho

Assimetria deliberada: um ombro de gaiola tubular, outro de chapa de outra cor; membros de mangueira; adesivos de fábricas que não existem mais. A tinta nunca bate.

---

## Os chassis da casa

- [[Remendo]] — Leve · Estrutura 7 · Evasão 12 · Blindagem 0 · 6 encaixes
- [[Carroça]] — Médio · Estrutura 9 · Evasão 10 · Blindagem 1 · 6 encaixes

## A classe licenciada

- [[Remendão]] — Todo mundo tem um plano. Você tem uma caixa de ferramentas.

## As quinze Peças

**Nível 1**

- [[Encaixe Universal]] — *Fixa · sempre ligada*
- [[Gambiarra]] — *Ativa · 1 Estresse*

**Nível 2**

- [[Bolso Furado]] — *Fixa · sempre ligada*
- [[Troca Quente]] — *Ativa · 2 Estresse*

**Nível 3**

- [[Ferro-Velho]] — *Tensa · liga com 4+ de Medo na mesa*
- [[Mão Torta]] — *Fixa · sempre ligada*

**Nível 4**

- [[Reator Remendado]] — *Ativa · 1 Estresse*

**Nível 5**

- [[Chassi Aberto]] — *Fixa · sempre ligada*
- [[Areia no Motor]] — *Ativa · 1 Estresse*


---

## Links Relacionados
- [[⚙️ As Fábricas]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
