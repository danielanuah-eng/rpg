---
tipo: Fábrica
categoria: Fábrica
tags:
  - peso-do-ceu
  - fabrica
  - fabrica/arco
pdf_page: 40
jogo: O Peso do Céu
---

# ⚓ Estaleiros do Arco

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=40|Consultar Texto Original no PDF (Página 40) — A fábrica Estaleiros do Arco]]**

*Naval · casco selado · a água é estrada*

> Toda superfície é o teto de alguma coisa.

---

## A proposta

O Arco começou fazendo submarino e nunca aprendeu a fazer outra coisa. Os cascos dele são selados de fábrica: junta de borracha, solda contínua, zero fresta. Andam no fundo de rio, de canal e de fossa como quem anda em rua, e o preço disso é que são lentos em terra e não têm uma única abertura de ventilação — o calor sai por trocador, devagar, do jeito que sai num navio.

## A cultura

O Arco vende para porto, para guarda-costeira, para contrabandista e para quem trabalha em plataforma. É a única fábrica que treina o piloto a ficar parado: metade do manual é sobre esperar. Os pilotos do Arco têm fama de serem os mais difíceis de assustar do continente, e a explicação que eles dão é sempre a mesma — já estiveram em lugares mais escuros que este.

## No olho

Casco liso e arredondado, sem frestas, cabeça em domo de vidro blindado, leme dorsal, bocais de propulsão no lugar de canos de escape. Verde-fundo e cinza-maré.

---

## Os chassis da casa

- [[Vazante]] — Médio · Estrutura 8 · Evasão 11 · Blindagem 2 · 4 encaixes
- [[Quilha]] — Pesado · Estrutura 10 · Evasão 10 · Blindagem 2 · 4 encaixes

## A classe licenciada

- [[Mergulhador]] — Você já esteve em lugares mais escuros que este.

## As quinze Peças

**Nível 1**

- [[Casco Selado]] — *Fixa · sempre ligada*
- [[Lastro]] — *Ativa · 1 Estresse*

**Nível 2**

- [[Jato de Pressão]] — *Ativa · 1 Estresse*
- [[Sonar]] — *Fixa · sempre ligada*

**Nível 3**

- [[Correnteza]] — *Ativa · 2 Estresse*
- [[Bolsão de Ar]] — *Ativa · 1 Estresse*

**Nível 4**

- [[Agulha de Profundidade]] — *Fixa · sempre ligada*

**Nível 5**

- [[Maré Vazante]] — *Ativa · 2 Estresse*


---

## Links Relacionados
- [[⚙️ As Fábricas]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
