---
tipo: Fábrica
categoria: Fábrica
tags:
  - peso-do-ceu
  - fabrica
  - fabrica/catedral
pdf_page: 38
jogo: O Peso do Céu
---

# ⛪ Fundição Catedral

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=38|Consultar Texto Original no PDF (Página 38) — A fábrica Fundição Catedral]]**

*Estado · chapa cerimonial · ser visto e obedecido*

> Metade do trabalho de um colosso é chegar. A outra metade é ser visto chegando.

---

## A proposta

A Catedral é a fábrica do Estado, e não esconde isso: os cascos dela têm brasão no peito, manto de tecido blindado, ombreira do tamanho de uma porta e um sistema de projeção de escudo que custa mais que o resto da máquina junta. Nada na Catedral é discreto, porque a discrição nunca foi o objetivo. Um colosso da Catedral é um argumento antes de ser uma arma.

## A cultura

Só quem tem patente pilota Catedral, e a patente vem com responsabilidade escrita: há um livro de protocolo do tamanho de uma bíblia sobre quando um casco da Catedral pode e não pode disparar. Pilotos da Catedral são julgados por tribunal próprio. Alguns acham isso proteção; outros já descobriram que não é.

## No olho

Arco ogival na cabeça, ombreira em calota com espigões, faixas de chapa sobrepostas como degraus, manto. Cinza-pedra e osso, com um único acento quente.

---

## Os chassis da casa

- [[Arcada]] — Pesado · Estrutura 10 · Evasão 10 · Blindagem 3 · 3 encaixes
- [[Guarda]] — Médio · Estrutura 9 · Evasão 11 · Blindagem 2 · 4 encaixes

## A classe licenciada

- [[Baluarte]] — Você é a razão pela qual o resto tem para onde recuar.

## As quinze Peças

**Nível 1**

- [[Véu de Luz]] — *Ativa · 1 Estresse*
- [[Brasão]] — *Fixa · sempre ligada*

**Nível 2**

- [[Voz de Comando]] — *Ativa · 1 Estresse*
- [[Ombreira de Portão]] — *Fixa · sempre ligada*

**Nível 3**

- [[Ordem de Parada]] — *Tensa · liga com 4+ de Medo na mesa*
- [[Estandarte]] — *Fixa · sempre ligada*

**Nível 4**

- [[Abóbada]] — *Ativa · 2 Estresse*

**Nível 5**

- [[Formar]] — *Ativa · 1 Estresse*


---

## Links Relacionados
- [[⚙️ As Fábricas]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
