---
tipo: Fábrica
categoria: Fábrica
tags:
  - peso-do-ceu
  - fabrica
  - fabrica/carvao
pdf_page: 46
jogo: O Peso do Céu
---

# 🌑 Carvão

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=46|Consultar Texto Original no PDF (Página 46) — A fábrica Carvão]]**

*Mercado preto · placa trocada · o parafuso que ninguém checa*

> Toda máquina tem um parafuso que ninguém checa. Eu checo.

---

## A proposta

Carvão não é uma fábrica: é um nome que várias oficinas usam quando precisam assinar alguma coisa. O que sai com o selo do Carvão é sempre peça de outra fábrica com o número lixado, remontada por alguém muito bom e vendida por alguém muito pior. A qualidade varia de excepcional a homicida dentro do mesmo lote, e o catálogo circula em papel, de mão em mão, sem endereço.

## A cultura

Quem compra Carvão compra o que não devia existir: carga de fenda, placa fria, sistema de identificação falso, chave-mestra de cabine alheia. Também compra silêncio — é o único fornecedor que garante que a venda não ficou registrada em lugar nenhum. O preço nunca é dinheiro sozinho. Sempre tem um favor junto, e o favor vence.

## No olho

Chapa faltando de propósito, capuz de lona sobre a cabine, ganchos e lâminas parafusadas por fora, tinta fosca preta por cima de qualquer cor original. Nenhum número em lugar nenhum.

---

## Os chassis da casa

- [[Sombra]] — Leve · Estrutura 6 · Evasão 13 · Blindagem 0 · 5 encaixes
- [[Gancho]] — Médio · Estrutura 8 · Evasão 11 · Blindagem 1 · 5 encaixes

## A classe licenciada

- [[Corsário]] — Não se afunda uma carga. Se afunda quem não quis entregar.

## As quinze Peças

**Nível 1**

- [[Placa Fria]] — *Fixa · sempre ligada*
- [[Carga de Fenda]] — *Ativa · 1 Estresse*

**Nível 2**

- [[Chave-Mestra]] — *Ativa · 1 Estresse*
- [[Gancho Sujo]] — *Fixa · sempre ligada*

**Nível 3**

- [[Rombo]] — *Ativa · 1 Estresse*
- [[Mercado]] — *Fixa · sempre ligada*

**Nível 4**

- [[Fumaça de Bordo]] — *Ativa · 1 Estresse*

**Nível 5**

- [[Boca de Lobo]] — *Ativa · 2 Estresse*
- [[Ninguém Viu]] — *Tensa · liga com 4+ de Medo na mesa*


---

## Links Relacionados
- [[⚙️ As Fábricas]]
- [[🔩 As Peças]]
- [[🛰️ O Peso do Céu]]
