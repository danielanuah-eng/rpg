---
tipo: Regra
categoria: Sistema
tags:
  - peso-do-ceu
  - regra
pdf_page: 14
jogo: O Peso do Céu
---

# 🛠️ Levar Dano

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=14|Consultar Texto Original no PDF (Página 14) — Levar Dano]]**

| O dano foi | Você marca | E mais |
|---|---|---|
| Abaixo do **Limiar Maior** | 1 Estrutura | — |
| **Limiar Maior** ou acima | 2 Estrutura | — |
| **Limiar Severo** ou acima | 3 Estrutura | role a [[Avaria]] |

Antes de marcar, gaste **1 Blindagem** para descer um degrau. Com toda a
Estrutura marcada, o colosso cai.

## Quando o colosso cai

- **O piloto sai.** Sempre. Uma ação para abandonar a cabine, e depois disso você
  é uma pessoa de carne no meio de uma briga de máquinas — o que é uma cena, não
  um fim.
- **O chassi volta.** Numa doca, com uma Parada Longa e alguma negociação. É
  caro; não é o fim da campanha.
- **As Peças, nem sempre.** Role `1d6` por Peça instalada: com 4 ou mais, ela
  sobreviveu. As outras ficaram no campo, e alguém vai achar.

---

## Links Relacionados
- [[📐 As Regras]]
- [[🛰️ O Peso do Céu]]
