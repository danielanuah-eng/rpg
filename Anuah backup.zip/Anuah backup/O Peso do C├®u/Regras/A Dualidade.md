---
tipo: Regra
categoria: Sistema
tags:
  - peso-do-ceu
  - regra
pdf_page: 9
jogo: O Peso do Céu
---

# 🎲 A Dualidade

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=9|Consultar Texto Original no PDF (Página 9) — A Dualidade]]**

Some os dois d12 e o traço que couber. Compare com a **Dificuldade**, ou com a
**Evasão** do alvo.

| O que saiu | O que significa |
|---|---|
| **Total ≥ Dificuldade** | Você conseguiu. |
| **Total < Dificuldade** | Você não conseguiu. |
| **Esperança maior** | *com Esperança*: ganhe **1 Esperança**. |
| **Medo maior** | *com Medo*: o Mestre ganha **1 Medo**. |
| **Os dois iguais** | **Crítico**: sucesso automático, ganhe 1 Esperança e limpe 1 Estresse. |

> [!TIP] Falhar com Esperança é bom
> A coisa não saiu, mas você não pagou por isso: o Mestre não ganha nada e você
> ganha um marcador. É o segundo melhor resultado da tabela, e muita mesa demora
> a perceber.

## Dificuldades, quando o Mestre precisa inventar uma

| Dificuldade | Quando usar |
|---|---|
| **10** | Quase certo. Peça só se a falha for interessante. |
| **13** | O padrão. Use quando não souber. |
| **15** | Difícil: contra treino, pressa ou tempo ruim. |
| **17** | Muito difícil: ninguém faz isso sem pagar. |
| **20** | Uma vez por campanha. |

---

## Links Relacionados
- [[📐 As Regras]]
- [[🛰️ O Peso do Céu]]
