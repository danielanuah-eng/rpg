---
tipo: Hub
categoria: MOC
tags:
  - peso-do-ceu
  - moc
  - hub
jogo: O Peso do Céu
---

# 📐 As regras

O sistema inteiro, em doze notas. Dois d12, cinco faixas de alcance, cinco condições e nenhum tabuleiro.

---

## A rolagem

- [[A Dualidade]]
- [[Esperança]]
- [[O Medo]]
- [[Estresse]]
- [[Experiências]]

## A briga

- [[O Combate]]
- [[Condições]]
- [[Escala]]
- [[Levar Dano]]
- [[Avaria]]

## A mesa

- [[Montar uma Briga]]
- [[Subir de Nível]]

---

[[🛰️ O Peso do Céu|⬅ Voltar]]
