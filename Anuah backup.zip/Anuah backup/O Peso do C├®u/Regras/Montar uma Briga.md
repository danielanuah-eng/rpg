---
tipo: Regra
categoria: Sistema
tags:
  - peso-do-ceu
  - regra
pdf_page: 17
jogo: O Peso do Céu
---

# 🎯 Montar uma Briga

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=17|Consultar Texto Original no PDF (Página 17) — Montar uma Briga]]**

**Pontos de Batalha = (3 × número de pilotos) + 2.**

| Custo | O que compra |
|---|---|
| **1** | Um Lacaio. |
| **2** | Um Batedor, um Atirador ou um Apoio. |
| **3** | Um Regular. |
| **4** | Um Bando ou um Comandante. |
| **5** | Um Brutamontes. |
| **10** | Um Solo. |

**−1 ponto** se todos forem de Escalão abaixo do da mesa. **+2** se houver uma
Contagem correndo.

## A linha do Escalão

Cada Escalão tem uma linha fixa; cada papel multiplica a Estrutura e mexe na
Evasão. Dá para inventar um adversário novo em trinta segundos.

| Escalão | Evasão | Limiares | Ataque | Dano | Estrutura |
|---|---|---|---|---|---|
| **1º** | 11 | 6 / 13 | +2 | `1d10+5` | 5 |
| **2º** | 13 | 10 / 19 | +4 | `2d10+6` | 7 |
| **3º** | 15 | 13 / 26 | +6 | `3d10+7` | 9 |
| **4º** | 17 | 17 / 32 | +8 | `4d10+9` | 11 |

## Os nove papéis

| Papel | Pontos | Estrutura | Evasão | O que ele é |
|---|---|---|---|---|
| **Lacaio** | 1 | — | -2 | Cai com qualquer acerto. Vem em grupo de três ou mais. |
| **Batedor** | 2 | ×0.6 | +2 | Chega, morde e sai. Difícil de acertar. |
| **Atirador** | 2 | ×0.6 | — | Fica longe. Se deixarem chegar perto, acaba. |
| **Apoio** | 2 | ×0.8 | — | Não vence sozinho. Faz os outros vencerem. |
| **Regular** | 3 | ×1 | — | A linha. É por ela que se mede tudo. |
| **Bando** | 4 | ×1.2 | — | Conta como vários. O dano cai pela metade na segunda metade da Estrutura. |
| **Comandante** | 4 | ×1.4 | — | Gasta o Medo do Mestre melhor que os outros. |
| **Brutamontes** | 5 | ×1.8 | -1 | Aguenta. Lento e caro de derrubar. |
| **Solo** | 10 | ×2.8 | +1 | Sozinho contra o grupo inteiro. |


---

## Links Relacionados
- [[📐 As Regras]]
- [[🛰️ O Peso do Céu]]
