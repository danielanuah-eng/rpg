---
tipo: Regra
categoria: Sistema
tags:
  - peso-do-ceu
  - regra
pdf_page: 9
jogo: O Peso do Céu
---

# 🌑 O Medo

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=9|Consultar Texto Original no PDF (Página 9) — O Medo]]**

> [!IMPORTANT] Medo não é castigo
> É o mundo se inclinando para ver o que vai acontecer. Quando o Mestre tem Medo
> guardado, a cena fica maior: coisas aparecem, desafios começam, gente entra —
> e as máquinas dos jogadores *acordam*. Um Mestre que só usa Medo para machucar
> está usando errado.

O Mestre começa a sessão com o que sobrou, até **12**, e ganha 1 toda vez que
alguém rola com Medo.

| Custo | O quê |
|---|---|
| **1** | **Fazer aparecer.** Alguma coisa entra na cena: reforço, testemunha, uma porta que não estava ali, uma chance. Pode ser bom para a mesa. Muitas vezes é. |
| **1** | **Dar foco.** Entregue 1 Medo a um jogador: ele soma `+1d6` na próxima rolagem. Em troca, o Mestre faz uma pergunta sobre o personagem e o jogador responde com a verdade. |
| **1** | Um adversário age fora da vez dele. |
| **1** | Uma **Contagem** anda um passo. |
| **2** | Uma **Ação de Medo** de um adversário. |
| **2** | **Ligar um desafio**: começa uma Contagem nova, e a mesa sabe qual. |
| **3** | **A maré vira**: o que estava longe fica perto. |

## As Peças Tensas

Algumas Peças de fábrica são **Tensas**: não custam nada e funcionam apenas
enquanto o Mestre tiver **4 ou mais de Medo** — algumas pedem 6.

O Mestre *não pode* gastar Medo só para desligar uma Peça Tensa. Se o gasto tem
um efeito na ficção, tudo bem que a Peça apague junto.

## Contagens

| Passos | Para quê |
|---|---|
| **4** | Uma coisa curta: a porta que abre, o trem que chega. |
| **6** | Segurar um lugar. A metade traz reforço. |
| **8** | A cena inteira: a evacuação, a maré, o resgate. |
| **12** | Uma sessão. Diga o número em voz alta. |

Contagem é relógio aberto: a mesa tem de ver o número subindo.

---

## Links Relacionados
- [[📐 As Regras]]
- [[🛰️ O Peso do Céu]]
