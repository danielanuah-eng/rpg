---
tipo: Regra
categoria: Sistema
tags:
  - peso-do-ceu
  - regra
pdf_page: 9
jogo: O Peso do Céu
---

# ✨ Esperança

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=9|Consultar Texto Original no PDF (Página 9) — Esperança]]**

Começa em **2**, guarda até **6**.

| Custo | No que se gasta |
|---|---|
| **1** | **Ajudar**: um aliado que está rolando ganha `+1d6`. |
| **1** | **Experiência**: some **+2**, se ela couber. |
| **1** | **Fôlego**: limpe 1 Estresse. |
| **3** | **Traço de Esperança** da sua classe. |

Ver também [[Experiências]].

---

## Links Relacionados
- [[📐 As Regras]]
- [[🛰️ O Peso do Céu]]
