---
tipo: Regra
categoria: Sistema
tags:
  - peso-do-ceu
  - regra
pdf_page: 10
jogo: O Peso do Céu
---

# 🧭 Experiências

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=10|Consultar Texto Original no PDF (Página 10) — Experiências]]**

Uma frase curta sobre o que já te aconteceu: *"Cresci numa doca"*, *"Fui do
outro lado por três anos"*. Você começa com duas, valendo **+2**, e ganha mais
subindo de nível. Gaste 1 [[Esperança]] para usar.

> [!TIP] Experiência não é perícia
> Não faça uma lista de habilidades; faça uma lista de coisas que aconteceram
> com você. As primeiras se gastam, as segundas rendem a campanha inteira.

---

## Links Relacionados
- [[📐 As Regras]]
- [[🛰️ O Peso do Céu]]
