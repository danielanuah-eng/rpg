---
tipo: Regra
categoria: Sistema
tags:
  - peso-do-ceu
  - regra
pdf_page: 16
jogo: O Peso do Céu
---

# 🩹 Condições

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=16|Consultar Texto Original no PDF (Página 16) — Condições]]**

Cinco, e só cinco. O que não couber aqui é ficção, não regra.

| Condição | Efeito |
|---|---|
| **Vulnerável** | Ataques contra você têm vantagem. |
| **Restrito** | Você não muda de faixa. Sair gasta uma ação. |
| **Oculto** | Não pode ser alvo sem que alguém gaste uma ação te achando. Sai ao agir, salvo se a Peça disser outra coisa. |
| **Instável** | O seu próximo ataque tem desvantagem. |
| **Inerte** | Você não age. Ataques contra você acertam sem rolar. |

---

## Links Relacionados
- [[📐 As Regras]]
- [[🛰️ O Peso do Céu]]
