---
tipo: Regra
categoria: Sistema
tags:
  - peso-do-ceu
  - regra
pdf_page: 101
jogo: O Peso do Céu
---

# 📈 Subir de Nível

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=101|Consultar Texto Original no PDF (Página 101) — Subir de Nível]]**

Duas escolhas por nível. As caixas zeram a cada Escalão novo.

- +1 a dois traços
- +1 Estrutura
- +1 Estresse
- +1 Evasão
- +1 encaixe
- Peça nova
- Licença nova
- Experiência nova
- Experiência para +3
- Limiares do piloto
- **Um contato** — alguém que atende quando você chama
- **Uma marca** — uma reputação que abre e fecha portas
- **Um bem** — uma coisa no mundo que é sua

**Automático:** Proficiência 2 no nível 2, 3 no 5, 4 no 8. Especialização no 5,
Maestria no 8. Experiência nova nos níveis 2, 5 e 8.

## Escalões

| Escalão | Níveis | Proficiência | O tamanho da briga |
|---|---|---|---|
| **1º** | 1 | 1 | Uma cidade, uma doca, uma estrada. |
| **2º** | 2 a 4 | 2 | Uma frente, um porto, uma fábrica. |
| **3º** | 5 a 7 | 3 | Uma campanha inteira. |
| **4º** | 8 a 10 | 4 | A guerra, e o que existe embaixo dela. |

**Proficiência** é quantos dados de dano você rola. Uma arma `d8+3` rola *um* d8
no Escalão 1 e *quatro* no Escalão 4, somando o +3 uma vez só.

---

## Links Relacionados
- [[📐 As Regras]]
- [[🛰️ O Peso do Céu]]
