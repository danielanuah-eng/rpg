---
tipo: Regra
categoria: Sistema
tags:
  - peso-do-ceu
  - regra
pdf_page: 14
jogo: O Peso do Céu
---

# 💥 Avaria

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=14|Consultar Texto Original no PDF (Página 14) — Avaria]]**

`1d12`, somando **+1 por Avaria anterior nesta sortida**.

| 1d12 | Resultado |
|---|---|
| **1–4** | **Raspão.** Nada além do dano. |
| **5–6** | **Tranco.** Você fica **Vulnerável** até a sua próxima ação e marca 1 Estresse. |
| **7–8** | **Peça solta.** Uma Peça instalada desliga até a próxima Parada Longa. Você escolhe qual. |
| **9–10** | **Fratura.** Os dois Limiares caem **3** até o conserto. Acumula. |
| **11** | **Núcleo torto.** O colosso fica **Inerte**. Religar custa uma ação e 1 Estresse. |
| **12+** | **Colapso.** O colosso cai agora. Você tem uma ação para sair. |

---

## Links Relacionados
- [[📐 As Regras]]
- [[🛰️ O Peso do Céu]]
