---
tipo: Regra
categoria: Sistema
tags:
  - peso-do-ceu
  - regra
pdf_page: 15
jogo: O Peso do Céu
---

# ⚔️ O Combate

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=15|Consultar Texto Original no PDF (Página 15) — O Combate]]**

**Não existe tabuleiro e não existe iniciativa.** Existe o holofote, que passa de
mão em mão, e existem cinco faixas de alcance. Colosso e gente usam as mesmas
regras; a diferença está em [[Escala]].

## O teatro da mente

No começo da cena, o Mestre diz em voz alta **três a cinco coisas que existem
ali**: a passarela, o guindaste, o canal, a fila de gente, o prédio que já está
caindo. Isso é o mapa inteiro.

- Cada personagem está **em** uma dessas coisas, ou **entre** duas.
- Distância se mede em **faixas de alcance**, não em metros.
- **Mover não custa ação** se você estiver indo fazer alguma coisa. Atravessar
  duas ou mais faixas é que custa a ação inteira — ou uma só, com Deslocamento 2+.

| Faixa | O que é |
|---|---|
| **Corpo a corpo** | Encostado. Dá para tocar. |
| **Muito Perto** | Um passo. Dá para gritar sem rádio. |
| **Perto** | Uma corrida. O outro lado do pátio. |
| **Longe** | O outro lado do rio. Precisa de arma longa. |
| **Muito Longe** | Você vê, e é só. |

## O holofote

Quem age é quem tem o holofote. Terminou, passa para outro jogador — nunca de
volta para quem acabou de agir. O Mestre entra quando alguém falha, quando um
sucesso sai com Medo, ou quando paga Medo para entrar. Faz uma coisa e devolve.

## O que se faz com uma ação

| Ação | O que é |
|---|---|
| **Atacar** | Role contra a **Evasão** do alvo. |
| **Atravessar** | Duas faixas ou mais. |
| **Usar uma Peça** | O que ela disser. As Ativas custam [[Estresse]]. |
| **Abrir o Núcleo** | Uma vez por sortida. |
| **Ajudar** | Um aliado ganha `+1d6`. Custa 1 [[Esperança]]. |
| **Ler a cena** | Role **Instinto**; o Mestre conta uma coisa verdadeira e útil. |
| **Qualquer outra** | Descreva. O Mestre diz o traço e a Dificuldade. |

## Atacar

| Resultado | O que acontece |
|---|---|
| **Crítico** | Acerta, o dano sobe um degrau, ganha 1 Esperança e limpa 1 Estresse. |
| **Acerto com Esperança** | Dano cheio. Ganhe 1 Esperança. |
| **Acerto com Medo** | Dano cheio. O Mestre ganha 1 Medo. |
| **Erro com Esperança** | Não acerta, mas alguma coisa melhora. |
| **Erro com Medo** | Não acerta, e o Mestre entra. |

---

## Links Relacionados
- [[📐 As Regras]]
- [[🛰️ O Peso do Céu]]
