---
tipo: Regra
categoria: Sistema
tags:
  - peso-do-ceu
  - regra
pdf_page: 10
jogo: O Peso do Céu
---

# 💢 Estresse

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=10|Consultar Texto Original no PDF (Página 10) — Estresse]]**

O piloto tem **6 Estresse**. É o único custo da máquina: não existe calor, não
existe carga, não existe bateria. As Peças **Ativas** das fábricas custam
Estresse, e é o corpo do piloto que paga.

- **Parada Curta** limpa 2.
- **Parada Longa** limpa tudo, troca as Peças instaladas e conserta o casco.

Com todo o Estresse marcado você fica **Vulnerável** e não pode marcar mais — o
que significa que a próxima coisa que pediria Estresse vai pedir outra coisa.

---

## Links Relacionados
- [[📐 As Regras]]
- [[🛰️ O Peso do Céu]]
