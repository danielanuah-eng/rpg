---
tipo: Regra
categoria: Sistema
tags:
  - peso-do-ceu
  - regra
pdf_page: 16
jogo: O Peso do Céu
---

# 📏 Escala

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=16|Consultar Texto Original no PDF (Página 16) — Escala]]**

Colosso e gente usam exatamente as mesmas regras, o mesmo holofote e as mesmas
faixas. O que muda é isto, e nada mais:

| Situação | Regra |
|---|---|
| **Gente atacando colosso** | Desvantagem, e o dano cai pela **metade**. |
| **Arma Antimáquina** | Cancela as duas coisas acima: rolagem normal, dano cheio. |
| **Colosso atacando gente** | Se acertar, o dano é sempre **Severo** — a não ser que a pessoa esteja coberta. |
| **Gente escondida de colosso** | Uma pessoa a pé conta como **Oculta** sempre que houver entulho, fumaça, multidão ou noite. |

## O que uma pessoa a pé faz com uma máquina

| O quê | Dificuldade | Resultado |
|---|---|---|
| **Subir** | Agilidade 15 | Você está em cima. Ele gasta uma ação para te sacudir. |
| **Plantar carga** | Conhecimento 14 | Uma ação, em cima. Estoura na sua próxima: `4d12+4`, ignorando Blindagem. |
| **Cortar um cabo** | Finesse 16 | O colosso perde 1 Deslocamento, ou uma Peça, ou os sensores. |
| **Abrir a cabine** | Força 18 | Em cima, com o colosso **Inerte** ou **Restrito**. |
| **Falar** | Presença 15 | Tem gente ali dentro. Às vezes é tudo de que se precisa. |

---

## Links Relacionados
- [[📐 As Regras]]
- [[🛰️ O Peso do Céu]]
