---
tipo: Hub
categoria: Início
tags:
  - peso-do-ceu
  - moc
  - hub
  - inicio
pdf_page: 1
jogo: O Peso do Céu
---

# 🛰️ O Peso do Céu
### RPG de mechas — Daggerheart × Lancer · segunda edição

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=1|Consultar Texto Original no PDF (Página 1) — Capa e sumário]]**

Dois d12, oito fábricas e uma máquina que só sabe fazer o que a fábrica dela ensinou. Combate no teatro da mente, sem tabuleiro. O Medo do Mestre não serve para machucar: serve para acender as coisas.

---

## 🧭 Navegação

- ⚙️ **[[⚙️ As Fábricas]]** — as oito casas e a licença que define o seu colosso.
- 🔩 **[[🔩 As Peças]]** — as 120 Peças, Fixas, Ativas e Tensas.
- 🎖️ **[[🎖️ O Piloto]]** — as oito classes, ancestralidades e comunidades.
- 🤖 **[[🤖 O Colosso]]** — os dezesseis chassis e o que cada Núcleo faz.
- ☠️ **[[☠️ Adversários]]** — os 104 adversários, com as **[[🌊 As Fundas|Fundas]]** no meio.
- 🎒 **[[🎒 Itens e Equipamento]]** — 69 itens, dos mecânicos aos estranhos.
- 📐 **[[📐 As Regras]]** — o sistema inteiro em doze notas.

---

## ⚡ Guia rápido de mesa

[[A Dualidade]] · [[O Medo]] · [[O Combate]] · [[Escala]] · [[Condições]] · [[Levar Dano]] · [[Avaria]] · [[Montar uma Briga]]

---

## 📊 O que existe aqui

| | |
|---|---|
| Fábricas | 8 |
| Peças | 120 |
| Classes | 8 (16 subclasses) |
| Chassis | 16 |
| Ancestralidades | 10 |
| Comunidades | 8 |
| Adversários | 104 (26 Fundas) |
| Itens | 69 |

> [!TIP] Consulta rápida
> Toda nota tem `pdf_page` nas Propriedades e um link para a página exata do livro. Os `tags` seguem um vocabulário fechado: `peso-do-ceu`, `fabrica/<nome>`, `escalao/<1-4>`, `peca/<tipo>`.
