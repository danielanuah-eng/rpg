---
tipo: Hub
categoria: MOC
tags:
  - peso-do-ceu
  - moc
  - hub
jogo: O Peso do Céu
---

# 🎖️ O piloto

A pessoa dentro da cabine. Poucas mecânicas de propósito: o que varia é classe, subclasse, armas e equipamento — e o que o colosso sabe fazer vem da fábrica, não do piloto.

---

## As oito classes

- **[[Ferreiro]]** — licença [[Companhia Brasa e Filhos]] · *Você conhece essa máquina parafuso por parafuso, porque foi você que parafusou.*
- **[[Andorinha]]** — licença [[Vespertina Mecânica Fina]] · *A distância entre você e o problema é uma decisão sua, e você decide depressa.*
- **[[Baluarte]]** — licença [[Fundição Catedral]] · *Você é a razão pela qual o resto tem para onde recuar.*
- **[[Mergulhador]]** — licença [[Estaleiros do Arco]] · *Você já esteve em lugares mais escuros que este.*
- **[[Remendão]]** — licença [[Oficinas Gralha]] · *Todo mundo tem um plano. Você tem uma caixa de ferramentas.*
- **[[Sentinela]]** — licença [[Selo Civil]] · *Alguém tem que anotar o que aconteceu aqui. Vai ser você.*
- **[[Corsário]]** — licença [[Carvão]] · *Não se afunda uma carga. Se afunda quem não quis entregar.*
- **[[Herdeiro]]** — licença [[Ossatura]] · *Você desceu fundo demais uma vez. Alguma coisa subiu com você.*

## De onde você veio

- [[🧬 Ancestralidades]]
- [[🏘️ Comunidades]]

## Ver também

- [[Subir de Nível]]
- [[Experiências]]
- [[🎒 Itens e Equipamento]]

---

[[🛰️ O Peso do Céu|⬅ Voltar]]
