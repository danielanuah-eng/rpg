---
tipo: Classe
categoria: Piloto
tags:
  - peso-do-ceu
  - classe
  - fabrica/selo
fabrica: Selo Civil
chassi_inicial: Ronda
evasao: 10
pv: 7
pdf_page: 23
jogo: O Peso do Céu
---

# Sentinela

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=23|Consultar Texto Original no PDF (Página 23) — A classe Sentinela]]**

*Licença de fábrica: [[Selo Civil]] · chassi de partida: [[Ronda]]*

> Alguém tem que anotar o que aconteceu aqui. Vai ser você.

---

**Evasão 10 · PV 7**

**Na cabine.** Um apito de patrulha, um bloco de autuação e a lanterna mais cara que você já comprou.

---

## Ronda — traço, sempre ligado

No começo de cada cena, escolha um lugar: você sabe tudo que entra e sai dele até o fim da cena, mesmo sem estar lá.

## Parado Aí — 3 Esperança

Gaste 3 Esperança: uma pessoa ou máquina que você consiga ver para o que está fazendo e escuta você por uma cena.

---

## As duas subclasses

### PATRULHA

*Estar onde o problema vai estar.*

- **Fundação (nível 1).** Você pode mudar de posição como reação quando alguém entra no lugar que você escolheu na Ronda.
- **Especialização (nível 5).** Aliados perto de você ganham **+1** de Evasão e não podem ser surpreendidos.
- **Maestria (nível 8).** Uma vez por sortida, chegue a tempo: você estava lá o tempo todo, e a coisa ruim não aconteceu.

### TORRE

*Estar onde dá para ver tudo.*

- **Fundação (nível 1).** Enquanto você não muda de lugar, os seus ataques de Longe e Muito Longe têm vantagem.
- **Especialização (nível 5).** Marque um alvo por cena como reação: todo ataque aliado contra ele soma **+2 por Proficiência**.
- **Maestria (nível 8).** Um alvo marcado por você não pode ficar **Oculto**, mudar de lugar sem ser visto, nem sair da cena.


---

## Links Relacionados
- [[Selo Civil]]
- [[Ronda]]
- [[🎖️ O Piloto]]
- [[Subir de Nível]]
- [[🛰️ O Peso do Céu]]
