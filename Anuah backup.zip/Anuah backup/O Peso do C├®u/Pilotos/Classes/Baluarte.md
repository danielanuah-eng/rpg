---
tipo: Classe
categoria: Piloto
tags:
  - peso-do-ceu
  - classe
  - fabrica/catedral
fabrica: Fundição Catedral
chassi_inicial: Arcada
evasao: 9
pv: 7
pdf_page: 21
jogo: O Peso do Céu
---

# Baluarte

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=21|Consultar Texto Original no PDF (Página 21) — A classe Baluarte]]**

*Licença de fábrica: [[Fundição Catedral]] · chassi de partida: [[Arcada]]*

> Você é a razão pela qual o resto tem para onde recuar.

---

**Evasão 9 · PV 7**

**Na cabine.** Um casaco de oficial furado no ombro esquerdo, um livro de protocolo e a chave da sua primeira cabine.

---

## Linha — traço, sempre ligado

Enquanto houver um aliado atrás de você, você tem **+1 Blindagem** e não pode ficar **Instável**.

## Em Nome de Quem — 3 Esperança

Gaste 3 Esperança: declare uma ordem em voz alta. Todo adversário de Escalão inferior ao seu perde a próxima ação decidindo se obedece.

---

## As duas subclasses

### PORTÃO

*O que fecha.*

- **Fundação (nível 1).** Adversários gastam uma ação inteira para passar por você. Some **+2** em tudo que for impedir alguém de passar.
- **Especialização (nível 5).** Aliados no seu alcance ganham **+1** de Evasão e não podem ser pegos de surpresa.
- **Maestria (nível 8).** Uma vez por sortida, declare uma linha fechada: nada a atravessa por uma cena enquanto você estiver de pé.

### ESTANDARTE

*O que chama.*

- **Fundação (nível 1).** Uma vez por cena, um aliado que te ouça age imediatamente, com vantagem.
- **Especialização (nível 5).** Aliados que te ouçam limpam 1 Estresse no começo de cada cena.
- **Maestria (nível 8).** Uma vez por sortida, todo aliado em campo age uma vez, na ordem que você quiser.


---

## Links Relacionados
- [[Fundição Catedral]]
- [[Arcada]]
- [[🎖️ O Piloto]]
- [[Subir de Nível]]
- [[🛰️ O Peso do Céu]]
