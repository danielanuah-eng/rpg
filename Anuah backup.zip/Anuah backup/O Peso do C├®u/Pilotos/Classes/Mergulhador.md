---
tipo: Classe
categoria: Piloto
tags:
  - peso-do-ceu
  - classe
  - fabrica/arco
fabrica: Estaleiros do Arco
chassi_inicial: Vazante
evasao: 11
pv: 6
pdf_page: 22
jogo: O Peso do Céu
---

# Mergulhador

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=22|Consultar Texto Original no PDF (Página 22) — A classe Mergulhador]]**

*Licença de fábrica: [[Estaleiros do Arco]] · chassi de partida: [[Vazante]]*

> Você já esteve em lugares mais escuros que este.

---

**Evasão 11 · PV 6**

**Na cabine.** Tampões de ouvido que você nunca tira, uma corda de trinta metros e um frasco lacrado com alguma coisa dentro.

---

## Fundo — traço, sempre ligado

Pressão, frio, vácuo e falta de ar não te afetam, dentro ou fora do colosso. Você não marca Estresse por ambiente.

## Escuta — 3 Esperança

Gaste 3 Esperança: pergunte ao Mestre onde está a coisa mais perigosa em um quilômetro, e o que ela quer.

---

## As duas subclasses

### QUILHA

*O peso da água.*

- **Fundação (nível 1).** Seus ataques contra alvos submersos, presos ou sem apoio somam **+1d8**, e você pode arrastar um alvo para baixo.
- **Especialização (nível 5).** Adversários gastam uma ação a mais para se afastar de você, como se a água fosse mais pesada ali.
- **Maestria (nível 8).** Uma vez por sortida, o chão onde você está afunda. Tudo que não for você vai junto.

### SONAR

*O que responde lá embaixo.*

- **Fundação (nível 1).** Você sabe o que existe em cada direção até Muito Longe, através de parede, água e escuro.
- **Especialização (nível 5).** Fundas menores não te atacam sem um bom motivo. Algumas obedecem por uma cena se você marcar 2 Estresse.
- **Maestria (nível 8).** Uma vez por campanha, chame uma coisa grande. Ela vem. O que ela faz quando chega não é decisão sua.


---

## Links Relacionados
- [[Estaleiros do Arco]]
- [[Vazante]]
- [[🎖️ O Piloto]]
- [[Subir de Nível]]
- [[🛰️ O Peso do Céu]]
