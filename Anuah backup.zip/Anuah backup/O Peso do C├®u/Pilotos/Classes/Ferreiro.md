---
tipo: Classe
categoria: Piloto
tags:
  - peso-do-ceu
  - classe
  - fabrica/brasa
fabrica: Companhia Brasa e Filhos
chassi_inicial: Mula
evasao: 10
pv: 7
pdf_page: 19
jogo: O Peso do Céu
---

# Ferreiro

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=19|Consultar Texto Original no PDF (Página 19) — A classe Ferreiro]]**

*Licença de fábrica: [[Companhia Brasa e Filhos]] · chassi de partida: [[Mula]]*

> Você conhece essa máquina parafuso por parafuso, porque foi você que parafusou.

---

**Evasão 10 · PV 7**

**Na cabine.** Uma chave de aperto gasta no cabo, um caderno de peças e uma lata de graxa quase vazia.

---

## Mão de Oficina — traço, sempre ligado

Você conserta qualquer coisa com o que tiver à mão. Fora de combate, consertos não custam nada e não falham; em combate, uma vez por cena, limpe **2 Estrutura** de qualquer colosso que você alcance.

## Aguenta Mais Um Pouco — 3 Esperança

Gaste 3 Esperança: um colosso que cairia agora não cai. Ele fica de pé até o fim da cena.

---

## As duas subclasses

### MARTELO

*O que bate.*

- **Fundação (nível 1).** Seus ataques corpo a corpo somam **+2 por Proficiência** contra alvos **Restritos**, **Instáveis** ou parados.
- **Especialização (nível 5).** Quando você derruba um adversário, todo adversário em Muito Perto fica **Instável**. Isso encadeia.
- **Maestria (nível 8).** Uma vez por cena, um ataque seu ignora Blindagem, cobertura, escudo e Véu de Luz.

### BIGORNA

*O que aguenta.*

- **Fundação (nível 1).** **+1 Blindagem**, e você não pode ser empurrado nem derrubado por nada menor que um colosso.
- **Especialização (nível 5).** Quando um aliado em Perto sofreria dano, você pode tomá-lo no lugar, com **um degrau a menos**.
- **Maestria (nível 8).** Enquanto você estiver de pé, nenhum aliado que esteja atrás de você pode ser alvo de ataque de Longe ou mais longe.


---

## Links Relacionados
- [[Companhia Brasa e Filhos]]
- [[Mula]]
- [[🎖️ O Piloto]]
- [[Subir de Nível]]
- [[🛰️ O Peso do Céu]]
