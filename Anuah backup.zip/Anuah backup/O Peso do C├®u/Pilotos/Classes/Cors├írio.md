---
tipo: Classe
categoria: Piloto
tags:
  - peso-do-ceu
  - classe
  - fabrica/carvao
fabrica: Carvão
chassi_inicial: Gancho
evasao: 11
pv: 6
pdf_page: 25
jogo: O Peso do Céu
---

# Corsário

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=25|Consultar Texto Original no PDF (Página 25) — A classe Corsário]]**

*Licença de fábrica: [[Carvão]] · chassi de partida: [[Gancho]]*

> Não se afunda uma carga. Se afunda quem não quis entregar.

---

**Evasão 11 · PV 6**

**Na cabine.** Uma corda de abordagem com gancho de ferro batido, uma dívida escrita num pedaço de lona e três chaves que não são suas.

---

## Abordagem — traço, sempre ligado

Quando você prende alguém com gancho, corda, arpéu ou garra, pode arrastá-lo junto no mesmo movimento — e ele fica **Restrito**.

## Parte do Butim — 3 Esperança

Gaste 3 Esperança: cada aliado que te ouça limpa 1 Estresse, e você ganha 1 Esperança de volta se algum deles usar isso na mesma cena.

---

## As duas subclasses

### GANCHO

*Chegar no casco do outro.*

- **Fundação (nível 1).** Seus ganchos alcançam Longe e prendem dois alvos ao mesmo tempo.
- **Especialização (nível 5).** Enquanto você segura um alvo preso, os ataques dele contra qualquer um que não seja você têm desvantagem.
- **Maestria (nível 8).** Uma vez por sortida, abra a cabine de um colosso preso. O que acontece lá dentro é uma cena de gente.

### FUMAÇA

*Não estar onde procuram.*

- **Fundação (nível 1).** Você não pode ser identificado, rastreado nem denunciado por sistema nenhum.
- **Especialização (nível 5).** Uma vez por cena, você e um aliado somem e reaparecem em qualquer ponto da cena.
- **Maestria (nível 8).** Uma vez por sortida, a cena inteira perde você de vista. Ninguém sabe dizer quando foi que você saiu.


---

## Links Relacionados
- [[Carvão]]
- [[Gancho]]
- [[🎖️ O Piloto]]
- [[Subir de Nível]]
- [[🛰️ O Peso do Céu]]
