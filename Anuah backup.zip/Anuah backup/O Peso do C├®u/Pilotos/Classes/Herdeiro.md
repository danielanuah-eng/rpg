---
tipo: Classe
categoria: Piloto
tags:
  - peso-do-ceu
  - classe
  - fabrica/ossatura
fabrica: Ossatura
chassi_inicial: Costela
evasao: 10
pv: 6
pdf_page: 25
jogo: O Peso do Céu
---

# Herdeiro

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=25|Consultar Texto Original no PDF (Página 25) — A classe Herdeiro]]**

*Licença de fábrica: [[Ossatura]] · chassi de partida: [[Costela]]*

> Você desceu fundo demais uma vez. Alguma coisa subiu com você.

---

**Evasão 10 · PV 6**

**Na cabine.** Um cabresto de aço com quinze metros, um caderno com o nome de tudo que você já prendeu, e uma cicatriz no pescoço.

---

## A Carne Lembra — traço, sempre ligado

Marque 1 Estresse para limpar 2 Estrutura do seu colosso, a qualquer momento. O enxerto fecha o buraco antes de você pedir.

## Palavra Boa — 3 Esperança

Gaste 3 Esperança: uma criatura que não seja personagem jogador para de atacar e escuta você por uma cena.

---

## As duas subclasses

### COLEIRA

*Segurar o que não devia andar solto.*

- **Fundação (nível 1).** Você pode prender uma criatura ou colosso com uma ação: ele fica **Restrito** enquanto você não soltar nem atacar outra coisa.
- **Especialização (nível 5).** Você prende dois alvos ao mesmo tempo, e prender deixou de gastar a sua ação.
- **Maestria (nível 8).** Um alvo preso por você de Escalão inferior luta ao seu lado até o fim da cena.

### VIRADA

*Deixar de segurar.*

- **Fundação (nível 1).** **Garra Viva** de graça, sem ocupar encaixe.
- **Especialização (nível 5).** Quando você marca Estresse por causa do enxerto, ganhe **+1d6** na sua próxima rolagem.
- **Maestria (nível 8).** Quando o seu colosso cai, você não fica a pé: o enxerto levanta com 6 Estrutura e obedece por uma cena.


---

## Links Relacionados
- [[Ossatura]]
- [[Costela]]
- [[🎖️ O Piloto]]
- [[Subir de Nível]]
- [[🛰️ O Peso do Céu]]
