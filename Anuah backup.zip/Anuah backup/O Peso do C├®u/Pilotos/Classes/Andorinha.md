---
tipo: Classe
categoria: Piloto
tags:
  - peso-do-ceu
  - classe
  - fabrica/vespertina
fabrica: Vespertina Mecânica Fina
chassi_inicial: Andorinha (chassi)
evasao: 12
pv: 5
pdf_page: 20
jogo: O Peso do Céu
---

# Andorinha

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=20|Consultar Texto Original no PDF (Página 20) — A classe Andorinha]]**

*Licença de fábrica: [[Vespertina Mecânica Fina]] · chassi de partida: [[Andorinha (chassi)]]*

> A distância entre você e o problema é uma decisão sua, e você decide depressa.

---

**Evasão 12 · PV 5**

**Na cabine.** Óculos escuros de piloto, um mapa desenhado à mão de uma cidade que não existe mais, e o diploma.

---

## Rasante — traço, sempre ligado

Sempre que você atravessa duas faixas de alcance ou mais numa ação, fique **Oculto** ao chegar, mesmo sem cobertura.

## Passarinho — 3 Esperança

Gaste 3 Esperança: o próximo ataque feito contra você nesta cena erra. Descreva por onde você passou.

---

## As duas subclasses

### VENTO

*Estar em toda parte.*

- **Fundação (nível 1).** **+1 Deslocamento**. Uma vez por cena, mude de posição como reação, sem gastar ação.
- **Especialização (nível 5).** Você pode carregar um aliado em todos os seus deslocamentos, e ele também chega **Oculto**.
- **Maestria (nível 8).** Uma vez por cena, aja imediatamente depois de qualquer outra pessoa, sem custo e sem o holofote sair de quem estava com ele.

### CORTE

*Estar num lugar só, uma vez só.*

- **Fundação (nível 1).** Ataques feitos saindo de **Oculto** rolam o dano duas vezes; fique com o maior.
- **Especialização (nível 5).** Quando você derruba um adversário, fique **Oculto** imediatamente.
- **Maestria (nível 8).** Contra um alvo que ainda não agiu nesta cena, o seu primeiro ataque acerta sem rolagem e causa dano Severo.


---

## Links Relacionados
- [[Vespertina Mecânica Fina]]
- [[Andorinha (chassi)]]
- [[🎖️ O Piloto]]
- [[Subir de Nível]]
- [[🛰️ O Peso do Céu]]
