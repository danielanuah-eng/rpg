---
tipo: Classe
categoria: Piloto
tags:
  - peso-do-ceu
  - classe
  - fabrica/gralha
fabrica: Oficinas Gralha
chassi_inicial: Remendo
evasao: 11
pv: 6
pdf_page: 23
jogo: O Peso do Céu
---

# Remendão

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=23|Consultar Texto Original no PDF (Página 23) — A classe Remendão]]**

*Licença de fábrica: [[Oficinas Gralha]] · chassi de partida: [[Remendo]]*

> Todo mundo tem um plano. Você tem uma caixa de ferramentas.

---

**Evasão 11 · PV 6**

**Na cabine.** Uma caixa de ferramentas que não é sua, um crachá de manutenção de uma fundição que fechou e fita de amarrar.

---

## Puxadinho — traço, sempre ligado

**+1 encaixe** no seu chassi. Você pode instalar Peças de qualquer fábrica em que tenha licença, em qualquer casco.

## Tinha Isso Aqui — 3 Esperança

Gaste 3 Esperança: você tinha exatamente o item, a peça ou a ferramenta de que a cena precisava. Diga qual, e de onde veio.

---

## As duas subclasses

### FERRO-VELHO

*Nada se perde.*

- **Fundação (nível 1).** Quando um colosso cai perto de você, arranque uma peça dele: uma arma, uma Peça instalada, ou 3 Estrutura para você.
- **Especialização (nível 5).** Uma vez por cena, use uma Peça instalada de um colosso que você esteja tocando, amigo ou não.
- **Maestria (nível 8).** Uma vez por sortida, monte na hora uma Peça que você não tem. Funciona por uma cena e vira sucata.

### ESTOPIM

*Nada fica inteiro.*

- **Fundação (nível 1).** Suas cargas e sabotagens causam **+1d10** e ignoram Blindagem.
- **Especialização (nível 5).** Quando uma Peça inimiga desliga por culpa sua, ela estoura: `3d10` em tudo em Muito Perto dela.
- **Maestria (nível 8).** Você pode plantar uma carga num colosso que ainda nem chegou à cena, desde que tenha visto a doca dele.


---

## Links Relacionados
- [[Oficinas Gralha]]
- [[Remendo]]
- [[🎖️ O Piloto]]
- [[Subir de Nível]]
- [[🛰️ O Peso do Céu]]
