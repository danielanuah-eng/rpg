---
tipo: Ancestralidade
categoria: Piloto
tags:
  - peso-do-ceu
  - ancestralidade
  - povo
pdf_page: 29
jogo: O Peso do Céu
---

# Aparelhado

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=29|Consultar Texto Original no PDF (Página 29) — Ancestralidade Aparelhado]]**

*Ligado a uma máquina desde criança — por programa, por acidente ou por escolha de outra pessoa.*

---

Aparelhados têm o enxerto de interface na nuca e a papelada que diz quem pagou por ele. São os melhores pilotos brutos que existem e a categoria com maior índice de abandono, porque descobrem cedo que a facilidade tem um preço que não está escrito em lugar nenhum. Há uma associação deles em quatro cidades. Nenhuma tem sede fixa.

---

## O que ela dá

- **Conexão Direta.** Você opera o colosso sem cabine: pode pilotá-lo de fora, de qualquer lugar da mesma cena.
- **Leitura Crua.** Você lê o estado de qualquer colosso que veja: Estrutura, Blindagem, Peças instaladas e o que está quebrado.

---

## Links Relacionados
- [[🧬 Ancestralidades]]
- [[🎖️ O Piloto]]
- [[🛰️ O Peso do Céu]]
