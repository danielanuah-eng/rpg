---
tipo: Hub
categoria: MOC
tags:
  - peso-do-ceu
  - moc
  - hub
jogo: O Peso do Céu
---

# 🏘️ As oito comunidades

Onde você cresceu. Cada uma dá uma coisa.

---

## As oito

- **[[Academia]]** — *Você veio de uma faculdade de pilotagem, com nota, fardamento e colegas que hoje voam do outro lado.*
- **[[Fundição]]** — *Cidade de forno aceso, turno de doze horas e sindicato que já parou o continente duas vezes.*
- **[[Quartel]]** — *Filho de farda, criado em vila militar, mudando de base a cada dois anos e nunca terminando um ano letivo no mesmo lugar.*
- **[[Doca]]** — *Porto, guindaste, contêiner e o barulho da água batendo no concreto às três da manhã.*
- **[[Sucata]]** — *Você cresceu desmontando o que os outros abandonaram, num pátio sem dono e com regras que ninguém escreveu.*
- **[[Solar]]** — *Casa de oficiais, jantar com talher demais, retratos na parede e um sobrenome que abre porta antes de você falar.*
- **[[Roça]]** — *Terra ocupada, colheita requisitada, e o trator que a vizinhança converteu em colosso numa semana.*
- **[[Caravana]]** — *Comboio de refugiados: gente que perdeu o lugar e aprendeu a carregá-lo.*

---

[[🎖️ O Piloto|⬅ Voltar]]
