---
tipo: Comunidade
categoria: Piloto
tags:
  - peso-do-ceu
  - comunidade
  - povo
pdf_page: 32
jogo: O Peso do Céu
---

# Caravana

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=32|Consultar Texto Original no PDF (Página 32) — Comunidade Caravana]]**

*Comboio de refugiados: gente que perdeu o lugar e aprendeu a carregá-lo.*

---

Uma caravana é uma cidade que anda. Tem conselho, tem escola, tem cemitério que fica para trás. Quem cresce em caravana tem uma memória absurda para rostos e uma relação estranha com o verbo voltar, que na língua deles é o mesmo que o verbo lembrar.

---

## O que ela dá

- **V.** o

---

## Links Relacionados
- [[🏘️ Comunidades]]
- [[🎖️ O Piloto]]
- [[🛰️ O Peso do Céu]]
