---
tipo: Ancestralidade
categoria: Piloto
tags:
  - peso-do-ceu
  - ancestralidade
  - povo
pdf_page: 28
jogo: O Peso do Céu
---

# Fundido

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=28|Consultar Texto Original no PDF (Página 28) — Ancestralidade Fundido]]**

*Criado dentro das cidades-fundição, entre forno e turno, com o barulho da prensa marcando a hora.*

---

Fundidos nascem com o ouvido calibrado: sabem que uma máquina vai quebrar dois dias antes de ela quebrar. Crescem em vila de empresa, com escola de empresa e médico de empresa, e saem de lá com uma relação complicada com a palavra lealdade. Metade dos mecânicos do continente é fundida; a outra metade aprendeu com um.

---

## O que ela dá

- **Calo de Forja.** Calor, faísca e metal quente não te machucam. Você pega a peça com a mão.
- **Ouvido de Motor.** Você sabe o que há de errado com qualquer máquina só de ouvir. Uma vez por cena, o Mestre te conta um defeito de algo na cena.

---

## Links Relacionados
- [[🧬 Ancestralidades]]
- [[🎖️ O Piloto]]
- [[🛰️ O Peso do Céu]]
