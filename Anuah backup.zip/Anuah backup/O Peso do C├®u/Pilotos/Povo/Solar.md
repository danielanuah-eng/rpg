---
tipo: Comunidade
categoria: Piloto
tags:
  - peso-do-ceu
  - comunidade
  - povo
pdf_page: 32
jogo: O Peso do Céu
---

# Solar

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=32|Consultar Texto Original no PDF (Página 32) — Comunidade Solar]]**

*Casa de oficiais, jantar com talher demais, retratos na parede e um sobrenome que abre porta antes de você falar.*

---

As famílias de solar controlam a oficialidade há tanto tempo que já não distinguem serviço público de patrimônio. Quem nasce ali recebe educação excelente, contatos excelentes e uma dívida de lealdade que nunca foi combinada e que vence sempre no pior momento possível.

---

## O que ela dá

- **P.** o

---

## Links Relacionados
- [[🏘️ Comunidades]]
- [[🎖️ O Piloto]]
- [[🛰️ O Peso do Céu]]
