---
tipo: Ancestralidade
categoria: Piloto
tags:
  - peso-do-ceu
  - ancestralidade
  - povo
pdf_page: 29
jogo: O Peso do Céu
---

# Caminhante

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=29|Consultar Texto Original no PDF (Página 29) — Ancestralidade Caminhante]]**

*Dos comboios que atravessam a linha carregando gente, peça e notícia, e que não param em lugar nenhum por mais de três dias.*

---

Caminhantes são o sistema nervoso do continente: se alguma coisa acontece num lugar, um comboio leva a notícia ao outro antes de qualquer rádio. Têm parentes em todo canto, dívidas em todo canto e uma etiqueta rígida sobre hospitalidade que forasteiros costumam violar sem perceber.

---

## O que ela dá

- **Estrada.** Você nunca se perde e sempre sabe para onde ir. Viagens por terra levam metade do tempo previsto.
- **Bagagem.** Uma vez por sessão, você tinha exatamente o item mundano de que se precisava. Estava no fundo do bornal.

---

## Links Relacionados
- [[🧬 Ancestralidades]]
- [[🎖️ O Piloto]]
- [[🛰️ O Peso do Céu]]
