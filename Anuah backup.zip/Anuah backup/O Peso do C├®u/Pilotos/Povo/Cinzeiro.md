---
tipo: Ancestralidade
categoria: Piloto
tags:
  - peso-do-ceu
  - ancestralidade
  - povo
pdf_page: 28
jogo: O Peso do Céu
---

# Cinzeiro

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=28|Consultar Texto Original no PDF (Página 28) — Ancestralidade Cinzeiro]]**

*Do cinturão de cinza, onde a guerra passou primeiro e nunca terminou de ir embora.*

---

Cinzeiros crescem sabendo o nome de três tipos de gás e o som de cinco tipos de artilharia. Têm um humor seco que gente de fora acha cruel e que entre eles é carinho. Ninguém de fora do cinturão entende por que eles não saem de lá; a resposta é sempre que alguém tem que ficar, e por enquanto é a vez deles.

---

## O que ela dá

- **Pulmão Sujo.** Fumaça, gás, pó e ar ruim não te afetam, e você enxerga através deles.
- **Já Vi Pior.** Uma vez por sessão, quando o Mestre gasta Medo para piorar uma cena, você ganha 1 Esperança.

---

## Links Relacionados
- [[🧬 Ancestralidades]]
- [[🎖️ O Piloto]]
- [[🛰️ O Peso do Céu]]
