---
tipo: Comunidade
categoria: Piloto
tags:
  - peso-do-ceu
  - comunidade
  - povo
pdf_page: 31
jogo: O Peso do Céu
---

# Fundição

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=31|Consultar Texto Original no PDF (Página 31) — Comunidade Fundição]]**

*Cidade de forno aceso, turno de doze horas e sindicato que já parou o continente duas vezes.*

---

Vila de fundição é um lugar onde todo mundo trabalha para a mesma empresa e todo mundo sabe disso. A solidariedade é real e a vigilância também. Quem sai de uma fundição sai sabendo fazer coisas com as mãos e sabendo exatamente quanto vale uma hora de trabalho de outra pessoa.

---

## O que ela dá

- **P.** e

---

## Links Relacionados
- [[🏘️ Comunidades]]
- [[🎖️ O Piloto]]
- [[🛰️ O Peso do Céu]]
