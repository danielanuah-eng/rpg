---
tipo: Comunidade
categoria: Piloto
tags:
  - peso-do-ceu
  - comunidade
  - povo
pdf_page: 31
jogo: O Peso do Céu
---

# Quartel

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=31|Consultar Texto Original no PDF (Página 31) — Comunidade Quartel]]**

*Filho de farda, criado em vila militar, mudando de base a cada dois anos e nunca terminando um ano letivo no mesmo lugar.*

---

Gente de quartel aprende hierarquia antes de aprender a ler e desenvolve uma facilidade assustadora para se adaptar a lugar novo. Também desenvolve, quase sempre, uma dificuldade igual de grande para confiar que alguém vai continuar por perto.

---

## O que ela dá

- **V.** o

---

## Links Relacionados
- [[🏘️ Comunidades]]
- [[🎖️ O Piloto]]
- [[🛰️ O Peso do Céu]]
