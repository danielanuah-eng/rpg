---
tipo: Ancestralidade
categoria: Piloto
tags:
  - peso-do-ceu
  - ancestralidade
  - povo
pdf_page: 27
jogo: O Peso do Céu
---

# Serrano

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=27|Consultar Texto Original no PDF (Página 27) — Ancestralidade Serrano]]**

*Gente das cordilheiras de dentro, onde o ar é fino, a estrada é uma só e a neblina fecha às quatro da tarde.*

---

Serranos medem tudo em dias de caminhada e não confiam em pressa. Crescem subindo, o que dá um fôlego que gente de planície não tem e uma teimosia que gente de planície não entende. As vilas de serra foram as últimas a serem ocupadas em todas as guerras, não por coragem, mas por logística.

---

## O que ela dá

- **Fôlego Longo.** Você não marca Estresse por esforço, altitude, calor ou falta de sono. O Mestre precisa de um motivo melhor do que cansaço.
- **Pé de Pedra.** Você não fica **Instável** por terreno, e escala qualquer superfície com uma rolagem de **Força**, sem equipamento.

---

## Links Relacionados
- [[🧬 Ancestralidades]]
- [[🎖️ O Piloto]]
- [[🛰️ O Peso do Céu]]
