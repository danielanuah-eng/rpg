---
tipo: Ancestralidade
categoria: Piloto
tags:
  - peso-do-ceu
  - ancestralidade
  - povo
pdf_page: 28
jogo: O Peso do Céu
---

# Vento-Alto

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=28|Consultar Texto Original no PDF (Página 28) — Ancestralidade Vento-Alto]]**

*De cima: das plataformas ancoradas, das torres de sinal e das rotas que ninguém olha do chão.*

---

Vento-altos passam a infância com um arnês preso na cintura e aprendem cedo que a queda não é o problema — o problema é o *susto* da queda, e esse dá para desligar. São contratados como instaladores, sinaleiros e carteiros de plataforma, e têm um vocabulário inteiro para tipos de vento.

---

## O que ela dá

- **Sem Fundo.** Queda não é problema: você reduz qualquer dano de queda a zero e cai de pé.
- **Olho de Longe.** Você enxerga detalhe a distâncias absurdas. Ataques de Muito Longe não sofrem desvantagem por distância.

---

## Links Relacionados
- [[🧬 Ancestralidades]]
- [[🎖️ O Piloto]]
- [[🛰️ O Peso do Céu]]
