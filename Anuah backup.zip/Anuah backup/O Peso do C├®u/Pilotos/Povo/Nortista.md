---
tipo: Ancestralidade
categoria: Piloto
tags:
  - peso-do-ceu
  - ancestralidade
  - povo
pdf_page: 29
jogo: O Peso do Céu
---

# Nortista

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=29|Consultar Texto Original no PDF (Página 29) — Ancestralidade Nortista]]**

*Da frente fria, onde a linha de batalha não se mexe há dezoito anos e as duas trincheiras já trocaram de dono duas vezes.*

---

Nortistas têm a paciência de quem foi criado esperando: esperando degelo, esperando comboio, esperando ordem. São os melhores atiradores e os piores negociadores do continente, porque acham que quem fala demais está escondendo alguma coisa — e costumam estar certos.

---

## O que ela dá

- **Casca.** Frio, fome e espera não te atingem. **+1** nos dois Limiares do piloto.
- **Teimosia.** Quando você falha em uma rolagem com Medo, ganhe 1 Esperança. Uma vez por cena.

---

## Links Relacionados
- [[🧬 Ancestralidades]]
- [[🎖️ O Piloto]]
- [[🛰️ O Peso do Céu]]
