---
tipo: Comunidade
categoria: Piloto
tags:
  - peso-do-ceu
  - comunidade
  - povo
pdf_page: 32
jogo: O Peso do Céu
---

# Sucata

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=32|Consultar Texto Original no PDF (Página 32) — Comunidade Sucata]]**

*Você cresceu desmontando o que os outros abandonaram, num pátio sem dono e com regras que ninguém escreveu.*

---

Ferro-velho é uma economia inteira: tem hierarquia, tem território, tem acordo de não-agressão e tem gente que passou a vida sem sair de lá. Quem cresce na sucata sabe o preço de tudo e aprende cedo que a diferença entre lixo e tesouro é só quem está perguntando.

---

## O que ela dá

- **V.** o

---

## Links Relacionados
- [[🏘️ Comunidades]]
- [[🎖️ O Piloto]]
- [[🛰️ O Peso do Céu]]
