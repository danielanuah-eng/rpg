---
tipo: Comunidade
categoria: Piloto
tags:
  - peso-do-ceu
  - comunidade
  - povo
pdf_page: 32
jogo: O Peso do Céu
---

# Roça

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=32|Consultar Texto Original no PDF (Página 32) — Comunidade Roça]]**

*Terra ocupada, colheita requisitada, e o trator que a vizinhança converteu em colosso numa semana.*

---

Zona rural em guerra é a parte que ninguém filma: alimenta os dois lados, é revistada pelos dois lados e não é defendida por nenhum. Quem sai da roça sai sabendo trabalhar, sabendo esconder e sabendo, com precisão desconfortável, de quanta comida uma pessoa precisa por dia.

---

## O que ela dá

- **V.** o

---

## Links Relacionados
- [[🏘️ Comunidades]]
- [[🎖️ O Piloto]]
- [[🛰️ O Peso do Céu]]
