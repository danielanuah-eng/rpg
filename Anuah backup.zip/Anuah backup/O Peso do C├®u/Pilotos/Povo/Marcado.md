---
tipo: Ancestralidade
categoria: Piloto
tags:
  - peso-do-ceu
  - ancestralidade
  - povo
pdf_page: 28
jogo: O Peso do Céu
---

# Marcado

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=28|Consultar Texto Original no PDF (Página 28) — Ancestralidade Marcado]]**

*Tocado por uma Funda antes de nascer. Ninguém combina isso, e ninguém sabe direito como acontece.*

---

Marcados têm alguma coisa levemente errada — o formato da pupila, a temperatura da pele, o fato de nunca terem tido uma infecção. São recrutados cedo por programas que negam existir e evitados por vizinhos que não sabem explicar por quê. A maioria leva uma vida comum e morre sem descobrir para que servia.

---

## O que ela dá

- **Sinal.** Você sente Fundas a quilômetros e sabe de que tamanho. Elas também sentem você.
- **Carne Errada.** Uma vez por cena, marque 1 Estresse para ignorar completamente um ferimento, um veneno ou uma condição que afete o seu corpo.

---

## Links Relacionados
- [[🧬 Ancestralidades]]
- [[🎖️ O Piloto]]
- [[🛰️ O Peso do Céu]]
