---
tipo: Ancestralidade
categoria: Piloto
tags:
  - peso-do-ceu
  - ancestralidade
  - povo
pdf_page: 27
jogo: O Peso do Céu
---

# Vazanteiro

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=27|Consultar Texto Original no PDF (Página 27) — Ancestralidade Vazanteiro]]**

*Nascido na planície que alaga seis meses por ano e seca nos outros seis, e que muda de forma entre uma coisa e outra.*

---

Vazanteiros aprendem a nadar antes de andar e a desmontar casa antes de aprender a ler. Não têm noção de propriedade fixa: onde a água passa, é de todo mundo. Isso os torna péssimos em cartório e excelentes em qualquer coisa que exija mudar de plano no meio.

---

## O que ela dá

- **Guelra Velha.** Você respira debaixo d'água o tempo que quiser e enxerga na água turva.
- **Barro.** Uma vez por cena, marque 1 Estresse para escapar de qualquer agarrão, algema, rede ou aperto — inclusive de um colosso.

---

## Links Relacionados
- [[🧬 Ancestralidades]]
- [[🎖️ O Piloto]]
- [[🛰️ O Peso do Céu]]
