---
tipo: Comunidade
categoria: Piloto
tags:
  - peso-do-ceu
  - comunidade
  - povo
pdf_page: 31
jogo: O Peso do Céu
---

# Doca

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=31|Consultar Texto Original no PDF (Página 31) — Comunidade Doca]]**

*Porto, guindaste, contêiner e o barulho da água batendo no concreto às três da manhã.*

---

Doca é onde o mundo se encontra: a carga de todo mundo passa por ali, e com a carga passa a informação. Gente de doca fala quatro línguas mal e entende oito, negocia por instinto e tem uma noção muito própria de quando uma lei se aplica.

---

## O que ela dá

- **V.** o

---

## Links Relacionados
- [[🏘️ Comunidades]]
- [[🎖️ O Piloto]]
- [[🛰️ O Peso do Céu]]
