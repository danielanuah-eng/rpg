---
tipo: Ancestralidade
categoria: Piloto
tags:
  - peso-do-ceu
  - ancestralidade
  - povo
pdf_page: 29
jogo: O Peso do Céu
---

# Ilhéu

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=29|Consultar Texto Original no PDF (Página 29) — Ancestralidade Ilhéu]]**

*Do arquipélago: mergulho, sal, e uma língua que só se fala lá e que não tem palavra para fronteira.*

---

Ilhéus medem riqueza em profundidade alcançada e contam história cantando. Foram os primeiros a ver Funda de perto e a única cultura que tem nome próprio para cada uma das grandes. Trabalham como mergulhadores, pilotos de casco selado e — quando a coisa aperta — como guias para lugares de onde ninguém mais volta.

---

## O que ela dá

- **Sopro Guardado.** Você aguenta cinco minutos sem respirar e nada tão rápido quanto anda.
- **Corda e Nó.** Você amarra, prende e solta qualquer coisa com uma ação. Nós seus não cedem sem uma rolagem Dificuldade 18.

---

## Links Relacionados
- [[🧬 Ancestralidades]]
- [[🎖️ O Piloto]]
- [[🛰️ O Peso do Céu]]
