---
tipo: Comunidade
categoria: Piloto
tags:
  - peso-do-ceu
  - comunidade
  - povo
pdf_page: 31
jogo: O Peso do Céu
---

# Academia

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=31|Consultar Texto Original no PDF (Página 31) — Comunidade Academia]]**

*Você veio de uma faculdade de pilotagem, com nota, fardamento e colegas que hoje voam do outro lado.*

---

As três academias do continente formam menos de quatrocentos pilotos por ano e decidem, na prática, quem comanda o quê pelos próximos trinta. Quem sai de lá carrega uma rede de contatos que vale mais que o diploma — e uma reputação que chega antes dele em qualquer sala.

---

## O que ela dá

- **V.** o

---

## Links Relacionados
- [[🏘️ Comunidades]]
- [[🎖️ O Piloto]]
- [[🛰️ O Peso do Céu]]
