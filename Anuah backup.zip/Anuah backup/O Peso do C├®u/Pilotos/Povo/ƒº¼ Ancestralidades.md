---
tipo: Hub
categoria: MOC
tags:
  - peso-do-ceu
  - moc
  - hub
jogo: O Peso do Céu
---

# 🧬 As dez ancestralidades

De que gente você veio. Cada uma dá duas coisas.

---

## As dez

- **[[Serrano]]** — *Gente das cordilheiras de dentro, onde o ar é fino, a estrada é uma só e a neblina fecha às quatro da tarde.*
- **[[Vazanteiro]]** — *Nascido na planície que alaga seis meses por ano e seca nos outros seis, e que muda de forma entre uma coisa e outra.*
- **[[Fundido]]** — *Criado dentro das cidades-fundição, entre forno e turno, com o barulho da prensa marcando a hora.*
- **[[Vento-Alto]]** — *De cima: das plataformas ancoradas, das torres de sinal e das rotas que ninguém olha do chão.*
- **[[Cinzeiro]]** — *Do cinturão de cinza, onde a guerra passou primeiro e nunca terminou de ir embora.*
- **[[Marcado]]** — *Tocado por uma Funda antes de nascer. Ninguém combina isso, e ninguém sabe direito como acontece.*
- **[[Nortista]]** — *Da frente fria, onde a linha de batalha não se mexe há dezoito anos e as duas trincheiras já trocaram de dono duas vezes.*
- **[[Aparelhado]]** — *Ligado a uma máquina desde criança — por programa, por acidente ou por escolha de outra pessoa.*
- **[[Caminhante]]** — *Dos comboios que atravessam a linha carregando gente, peça e notícia, e que não param em lugar nenhum por mais de três dias.*
- **[[Ilhéu]]** — *Do arquipélago: mergulho, sal, e uma língua que só se fala lá e que não tem palavra para fronteira.*

---

[[🎖️ O Piloto|⬅ Voltar]]
