---
tipo: Hub
categoria: MOC
tags:
  - peso-do-ceu
  - moc
  - hub
jogo: O Peso do Céu
---

# 🤖 O colosso

Dezesseis cascos, dois por fábrica. O chassi é a base: ele diz quanta **Blindagem** você tem, quantos encaixes, e qual é o truque que a máquina faz uma vez por sortida. O chassi define a Blindagem — nenhuma Peça dá Blindagem de graça, com uma exceção por fábrica.

---

## Companhia Brasa e Filhos

- [[Mula]] — Médio · Estrutura 8 · Evasão 10 · Blindagem 2 · 4 encaixes
- [[Bigorna]] — Pesado · Estrutura 10 · Evasão 9 · Blindagem 3 · 3 encaixes

## Vespertina Mecânica Fina

- [[Andorinha (chassi)]] — Leve · Estrutura 6 · Evasão 13 · Blindagem 0 · 5 encaixes
- [[Florete]] — Médio · Estrutura 7 · Evasão 12 · Blindagem 1 · 4 encaixes

## Fundição Catedral

- [[Arcada]] — Pesado · Estrutura 10 · Evasão 10 · Blindagem 3 · 3 encaixes
- [[Guarda]] — Médio · Estrutura 9 · Evasão 11 · Blindagem 2 · 4 encaixes

## Estaleiros do Arco

- [[Vazante]] — Médio · Estrutura 8 · Evasão 11 · Blindagem 2 · 4 encaixes
- [[Quilha]] — Pesado · Estrutura 10 · Evasão 10 · Blindagem 2 · 4 encaixes

## Oficinas Gralha

- [[Remendo]] — Leve · Estrutura 7 · Evasão 12 · Blindagem 0 · 6 encaixes
- [[Carroça]] — Médio · Estrutura 9 · Evasão 10 · Blindagem 1 · 6 encaixes

## Selo Civil

- [[Ronda]] — Médio · Estrutura 8 · Evasão 11 · Blindagem 2 · 5 encaixes
- [[Torre]] — Pesado · Estrutura 10 · Evasão 10 · Blindagem 3 · 4 encaixes

## Carvão

- [[Sombra]] — Leve · Estrutura 6 · Evasão 13 · Blindagem 0 · 5 encaixes
- [[Gancho]] — Médio · Estrutura 8 · Evasão 11 · Blindagem 1 · 5 encaixes

## Ossatura

- [[Costela]] — Médio · Estrutura 9 · Evasão 11 · Blindagem 1 · 5 encaixes
- [[Carcaça]] — Pesado · Estrutura 11 · Evasão 9 · Blindagem 2 · 4 encaixes

## Ver também

- [[🔩 As Peças]]
- [[Levar Dano]]
- [[Avaria]]

---

[[🛰️ O Peso do Céu|⬅ Voltar]]
