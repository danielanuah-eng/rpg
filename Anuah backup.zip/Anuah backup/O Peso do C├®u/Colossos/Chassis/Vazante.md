---
tipo: Chassi
categoria: Colosso
tags:
  - peso-do-ceu
  - chassi
  - fabrica/arco
porte: Médio
fabrica: Estaleiros do Arco
estrutura: 8
evasao: 11
blindagem: 2
encaixes: 4
pdf_page: 51
jogo: O Peso do Céu
---

# Vazante

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=51|Consultar Texto Original no PDF (Página 51) — Chassi VAZANTE]]**

*Vazante · porte Médio · [[Estaleiros do Arco]]*

---

| | |
|---|---|
| **Estrutura** | 8 |
| **Evasão** | 11 |
| **Limiares** | 9 / 16 |
| **Blindagem** | 2 |
| **Encaixes** | 4 |
| **Deslocamento** | 2 |

## Núcleo — Enchente

Um lugar alaga por uma cena. Tudo lá fica **Instável**; você não.

> [!TIP] Uma vez por sortida
> Abrir o Núcleo é uma ação e só acontece uma vez por sortida. Ver [[O Combate]].

## Quem começa nele

- [[Mergulhador]]

---

## Links Relacionados
- [[Estaleiros do Arco]]
- [[🤖 O Colosso]]
- [[🛰️ O Peso do Céu]]
