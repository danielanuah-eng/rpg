---
tipo: Chassi
categoria: Colosso
tags:
  - peso-do-ceu
  - chassi
  - fabrica/ossatura
porte: Pesado
fabrica: Ossatura
estrutura: 11
evasao: 9
blindagem: 2
encaixes: 4
pdf_page: 51
jogo: O Peso do Céu
---

# Carcaça

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=51|Consultar Texto Original no PDF (Página 51) — Chassi CARCAÇA]]**

*Carcaça · porte Pesado · [[Ossatura]]*

---

| | |
|---|---|
| **Estrutura** | 11 |
| **Evasão** | 9 |
| **Limiares** | 11 / 19 |
| **Blindagem** | 2 |
| **Encaixes** | 4 |
| **Deslocamento** | 1 |

## Núcleo — Come

Ataque um alvo **Restrito**, **Inerte** ou caído. Se acertar, limpe toda a Estrutura marcada.

> [!TIP] Uma vez por sortida
> Abrir o Núcleo é uma ação e só acontece uma vez por sortida. Ver [[O Combate]].

---

## Links Relacionados
- [[Ossatura]]
- [[🤖 O Colosso]]
- [[🛰️ O Peso do Céu]]
