---
tipo: Chassi
categoria: Colosso
tags:
  - peso-do-ceu
  - chassi
  - fabrica/brasa
porte: Pesado
fabrica: Companhia Brasa e Filhos
estrutura: 10
evasao: 9
blindagem: 3
encaixes: 3
pdf_page: 19
jogo: O Peso do Céu
---

# Bigorna

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=19|Consultar Texto Original no PDF (Página 19) — Chassi BIGORNA]]**

*Bigorna · porte Pesado · [[Companhia Brasa e Filhos]]*

---

| | |
|---|---|
| **Estrutura** | 10 |
| **Evasão** | 9 |
| **Limiares** | 11 / 19 |
| **Blindagem** | 3 |
| **Encaixes** | 3 |
| **Deslocamento** | 1 |

## Núcleo — Bater Até Parar

Ataque corpo a corpo três vezes seguidas contra o mesmo alvo, com uma rolagem cada.

> [!TIP] Uma vez por sortida
> Abrir o Núcleo é uma ação e só acontece uma vez por sortida. Ver [[O Combate]].

---

## Links Relacionados
- [[Companhia Brasa e Filhos]]
- [[🤖 O Colosso]]
- [[🛰️ O Peso do Céu]]
