---
tipo: Chassi
categoria: Colosso
tags:
  - peso-do-ceu
  - chassi
  - fabrica/carvao
porte: Médio
fabrica: Carvão
estrutura: 8
evasao: 11
blindagem: 1
encaixes: 5
pdf_page: 25
jogo: O Peso do Céu
---

# Gancho

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=25|Consultar Texto Original no PDF (Página 25) — Chassi GANCHO]]**

*Gancho · porte Médio · [[Carvão]]*

---

| | |
|---|---|
| **Estrutura** | 8 |
| **Evasão** | 11 |
| **Limiares** | 9 / 16 |
| **Blindagem** | 1 |
| **Encaixes** | 5 |
| **Deslocamento** | 2 |

## Núcleo — Abre Essa Porta

Abra a cabine de um colosso **Restrito** ou **Inerte**. O que acontece depois é uma cena de gente.

> [!TIP] Uma vez por sortida
> Abrir o Núcleo é uma ação e só acontece uma vez por sortida. Ver [[O Combate]].

## Quem começa nele

- [[Corsário]]

---

## Links Relacionados
- [[Carvão]]
- [[🤖 O Colosso]]
- [[🛰️ O Peso do Céu]]
