---
tipo: Chassi
categoria: Colosso
tags:
  - peso-do-ceu
  - chassi
  - fabrica/carvao
porte: Leve
fabrica: Carvão
estrutura: 6
evasao: 13
blindagem: 0
encaixes: 5
pdf_page: 51
jogo: O Peso do Céu
---

# Sombra

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=51|Consultar Texto Original no PDF (Página 51) — Chassi SOMBRA]]**

*Sombra · porte Leve · [[Carvão]]*

---

| | |
|---|---|
| **Estrutura** | 6 |
| **Evasão** | 13 |
| **Limiares** | 8 / 14 |
| **Blindagem** | 0 |
| **Encaixes** | 5 |
| **Deslocamento** | 2 |

## Núcleo — Nunca Estive Aqui

Saia da cena e volte em qualquer ponto dela, em qualquer momento, inclusive no meio da ação de outro.

> [!TIP] Uma vez por sortida
> Abrir o Núcleo é uma ação e só acontece uma vez por sortida. Ver [[O Combate]].

---

## Links Relacionados
- [[Carvão]]
- [[🤖 O Colosso]]
- [[🛰️ O Peso do Céu]]
