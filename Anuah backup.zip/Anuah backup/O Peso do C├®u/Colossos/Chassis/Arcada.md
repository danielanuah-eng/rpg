---
tipo: Chassi
categoria: Colosso
tags:
  - peso-do-ceu
  - chassi
  - fabrica/catedral
porte: Pesado
fabrica: Fundição Catedral
estrutura: 10
evasao: 10
blindagem: 3
encaixes: 3
pdf_page: 51
jogo: O Peso do Céu
---

# Arcada

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=51|Consultar Texto Original no PDF (Página 51) — Chassi ARCADA]]**

*Arcada · porte Pesado · [[Fundição Catedral]]*

---

| | |
|---|---|
| **Estrutura** | 10 |
| **Evasão** | 10 |
| **Limiares** | 10 / 18 |
| **Blindagem** | 3 |
| **Encaixes** | 3 |
| **Deslocamento** | 1 |

## Núcleo — Abóbada

Um domo de luz cobre a sua posição por uma cena: nada de fora acerta nada de dentro.

> [!TIP] Uma vez por sortida
> Abrir o Núcleo é uma ação e só acontece uma vez por sortida. Ver [[O Combate]].

## Quem começa nele

- [[Baluarte]]

---

## Links Relacionados
- [[Fundição Catedral]]
- [[🤖 O Colosso]]
- [[🛰️ O Peso do Céu]]
