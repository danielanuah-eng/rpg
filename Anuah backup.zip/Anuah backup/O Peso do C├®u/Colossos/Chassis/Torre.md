---
tipo: Chassi
categoria: Colosso
tags:
  - peso-do-ceu
  - chassi
  - fabrica/selo
porte: Pesado
fabrica: Selo Civil
estrutura: 10
evasao: 10
blindagem: 3
encaixes: 4
pdf_page: 24
jogo: O Peso do Céu
---

# Torre

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=24|Consultar Texto Original no PDF (Página 24) — Chassi TORRE]]**

*Torre · porte Pesado · [[Selo Civil]]*

---

| | |
|---|---|
| **Estrutura** | 10 |
| **Evasão** | 10 |
| **Limiares** | 10 / 18 |
| **Blindagem** | 3 |
| **Encaixes** | 4 |
| **Deslocamento** | 1 |

## Núcleo — Perímetro Fechado

Ninguém entra nem sai da cena sem passar por você. Dura até você sair do lugar.

> [!TIP] Uma vez por sortida
> Abrir o Núcleo é uma ação e só acontece uma vez por sortida. Ver [[O Combate]].

---

## Links Relacionados
- [[Selo Civil]]
- [[🤖 O Colosso]]
- [[🛰️ O Peso do Céu]]
