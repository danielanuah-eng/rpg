---
tipo: Chassi
categoria: Colosso
tags:
  - peso-do-ceu
  - chassi
  - fabrica/selo
porte: Médio
fabrica: Selo Civil
estrutura: 8
evasao: 11
blindagem: 2
encaixes: 5
pdf_page: 51
jogo: O Peso do Céu
---

# Ronda

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=51|Consultar Texto Original no PDF (Página 51) — Chassi RONDA]]**

*Ronda · porte Médio · [[Selo Civil]]*

---

| | |
|---|---|
| **Estrutura** | 8 |
| **Evasão** | 11 |
| **Limiares** | 9 / 16 |
| **Blindagem** | 2 |
| **Encaixes** | 5 |
| **Deslocamento** | 2 |

## Núcleo — Vista de Cima

Por uma cena, você e todos os aliados que consigam te ouvir sabem onde está tudo na cena.

> [!TIP] Uma vez por sortida
> Abrir o Núcleo é uma ação e só acontece uma vez por sortida. Ver [[O Combate]].

## Quem começa nele

- [[Sentinela]]

---

## Links Relacionados
- [[Selo Civil]]
- [[🤖 O Colosso]]
- [[🛰️ O Peso do Céu]]
