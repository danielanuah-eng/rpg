---
tipo: Chassi
categoria: Colosso
tags:
  - peso-do-ceu
  - chassi
  - fabrica/gralha
porte: Leve
fabrica: Oficinas Gralha
estrutura: 7
evasao: 12
blindagem: 0
encaixes: 6
pdf_page: 51
jogo: O Peso do Céu
---

# Remendo

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=51|Consultar Texto Original no PDF (Página 51) — Chassi REMENDO]]**

*Remendo · porte Leve · [[Oficinas Gralha]]*

---

| | |
|---|---|
| **Estrutura** | 7 |
| **Evasão** | 12 |
| **Limiares** | 8 / 15 |
| **Blindagem** | 0 |
| **Encaixes** | 6 |
| **Deslocamento** | 2 |

## Núcleo — Troca Quente

Instale ou troque duas Peças agora, no meio da cena, sem doca e sem ação.

> [!TIP] Uma vez por sortida
> Abrir o Núcleo é uma ação e só acontece uma vez por sortida. Ver [[O Combate]].

## Quem começa nele

- [[Remendão]]

---

## Links Relacionados
- [[Oficinas Gralha]]
- [[🤖 O Colosso]]
- [[🛰️ O Peso do Céu]]
