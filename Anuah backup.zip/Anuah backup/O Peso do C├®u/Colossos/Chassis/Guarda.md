---
tipo: Chassi
categoria: Colosso
tags:
  - peso-do-ceu
  - chassi
  - fabrica/catedral
porte: Médio
fabrica: Fundição Catedral
estrutura: 9
evasao: 11
blindagem: 2
encaixes: 4
pdf_page: 51
jogo: O Peso do Céu
---

# Guarda

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=51|Consultar Texto Original no PDF (Página 51) — Chassi GUARDA]]**

*Guarda · porte Médio · [[Fundição Catedral]]*

---

| | |
|---|---|
| **Estrutura** | 9 |
| **Evasão** | 11 |
| **Limiares** | 10 / 17 |
| **Blindagem** | 2 |
| **Encaixes** | 4 |
| **Deslocamento** | 1 |

## Núcleo — Ordem de Parada

Todo adversário em até Perto perde a próxima ação, ou o Mestre gasta 1 Medo por cada um que não perder.

> [!TIP] Uma vez por sortida
> Abrir o Núcleo é uma ação e só acontece uma vez por sortida. Ver [[O Combate]].

---

## Links Relacionados
- [[Fundição Catedral]]
- [[🤖 O Colosso]]
- [[🛰️ O Peso do Céu]]
