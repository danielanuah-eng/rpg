---
tipo: Chassi
categoria: Colosso
tags:
  - peso-do-ceu
  - chassi
  - fabrica/gralha
porte: Médio
fabrica: Oficinas Gralha
estrutura: 9
evasao: 10
blindagem: 1
encaixes: 6
pdf_page: 51
jogo: O Peso do Céu
---

# Carroça

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=51|Consultar Texto Original no PDF (Página 51) — Chassi CARROÇA]]**

*Carroça · porte Médio · [[Oficinas Gralha]]*

---

| | |
|---|---|
| **Estrutura** | 9 |
| **Evasão** | 10 |
| **Limiares** | 10 / 17 |
| **Blindagem** | 1 |
| **Encaixes** | 6 |
| **Deslocamento** | 1 |

## Núcleo — Descarga

Solte o que estiver carregando: até três aliados ou uma tonelada de carga aparecem ao seu lado, prontos.

> [!TIP] Uma vez por sortida
> Abrir o Núcleo é uma ação e só acontece uma vez por sortida. Ver [[O Combate]].

---

## Links Relacionados
- [[Oficinas Gralha]]
- [[🤖 O Colosso]]
- [[🛰️ O Peso do Céu]]
