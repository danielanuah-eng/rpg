---
tipo: Chassi
categoria: Colosso
tags:
  - peso-do-ceu
  - chassi
  - fabrica/vespertina
porte: Leve
fabrica: Vespertina Mecânica Fina
estrutura: 6
evasao: 13
blindagem: 0
encaixes: 5
pdf_page: 20
jogo: O Peso do Céu
---

# Andorinha (chassi)

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=20|Consultar Texto Original no PDF (Página 20) — Chassi ANDORINHA]]**

*Andorinha · porte Leve · [[Vespertina Mecânica Fina]]*

---

| | |
|---|---|
| **Estrutura** | 6 |
| **Evasão** | 13 |
| **Limiares** | 8 / 14 |
| **Blindagem** | 0 |
| **Encaixes** | 5 |
| **Deslocamento** | 2 |

## Núcleo — Passo Duplo

Até o fim da cena, mover e atacar custam uma ação só.

> [!TIP] Uma vez por sortida
> Abrir o Núcleo é uma ação e só acontece uma vez por sortida. Ver [[O Combate]].

## Quem começa nele

- [[Andorinha]]

---

## Links Relacionados
- [[Vespertina Mecânica Fina]]
- [[🤖 O Colosso]]
- [[🛰️ O Peso do Céu]]
