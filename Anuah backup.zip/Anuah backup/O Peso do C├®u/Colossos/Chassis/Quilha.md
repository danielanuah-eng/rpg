---
tipo: Chassi
categoria: Colosso
tags:
  - peso-do-ceu
  - chassi
  - fabrica/arco
porte: Pesado
fabrica: Estaleiros do Arco
estrutura: 10
evasao: 10
blindagem: 2
encaixes: 4
pdf_page: 22
jogo: O Peso do Céu
---

# Quilha

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=22|Consultar Texto Original no PDF (Página 22) — Chassi QUILHA]]**

*Quilha · porte Pesado · [[Estaleiros do Arco]]*

---

| | |
|---|---|
| **Estrutura** | 10 |
| **Evasão** | 10 |
| **Limiares** | 10 / 19 |
| **Blindagem** | 2 |
| **Encaixes** | 4 |
| **Deslocamento** | 1 |

## Núcleo — Lastro Solto

Afunde o chão sob os seus pés. Tudo em Muito Perto fica **Restrito** até gastar uma ação subindo.

> [!TIP] Uma vez por sortida
> Abrir o Núcleo é uma ação e só acontece uma vez por sortida. Ver [[O Combate]].

---

## Links Relacionados
- [[Estaleiros do Arco]]
- [[🤖 O Colosso]]
- [[🛰️ O Peso do Céu]]
