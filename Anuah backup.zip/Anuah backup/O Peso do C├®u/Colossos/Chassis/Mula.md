---
tipo: Chassi
categoria: Colosso
tags:
  - peso-do-ceu
  - chassi
  - fabrica/brasa
porte: Médio
fabrica: Companhia Brasa e Filhos
estrutura: 8
evasao: 10
blindagem: 2
encaixes: 4
pdf_page: 51
jogo: O Peso do Céu
---

# Mula

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=51|Consultar Texto Original no PDF (Página 51) — Chassi MULA]]**

*Mula · porte Médio · [[Companhia Brasa e Filhos]]*

---

| | |
|---|---|
| **Estrutura** | 8 |
| **Evasão** | 10 |
| **Limiares** | 9 / 16 |
| **Blindagem** | 2 |
| **Encaixes** | 4 |
| **Deslocamento** | 1 |

## Núcleo — Empurrão

Atravesse em linha reta até duas faixas de alcance. Tudo no caminho sofre o dano da sua arma e é jogado para o lado.

> [!TIP] Uma vez por sortida
> Abrir o Núcleo é uma ação e só acontece uma vez por sortida. Ver [[O Combate]].

## Quem começa nele

- [[Ferreiro]]

---

## Links Relacionados
- [[Companhia Brasa e Filhos]]
- [[🤖 O Colosso]]
- [[🛰️ O Peso do Céu]]
