---
tipo: Chassi
categoria: Colosso
tags:
  - peso-do-ceu
  - chassi
  - fabrica/vespertina
porte: Médio
fabrica: Vespertina Mecânica Fina
estrutura: 7
evasao: 12
blindagem: 1
encaixes: 4
pdf_page: 51
jogo: O Peso do Céu
---

# Florete

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=51|Consultar Texto Original no PDF (Página 51) — Chassi FLORETE]]**

*Florete · porte Médio · [[Vespertina Mecânica Fina]]*

---

| | |
|---|---|
| **Estrutura** | 7 |
| **Evasão** | 12 |
| **Limiares** | 9 / 15 |
| **Blindagem** | 1 |
| **Encaixes** | 4 |
| **Deslocamento** | 2 |

## Núcleo — Estocada

Um ataque corpo a corpo que acerta sem rolagem e ignora toda a Blindagem.

> [!TIP] Uma vez por sortida
> Abrir o Núcleo é uma ação e só acontece uma vez por sortida. Ver [[O Combate]].

---

## Links Relacionados
- [[Vespertina Mecânica Fina]]
- [[🤖 O Colosso]]
- [[🛰️ O Peso do Céu]]
