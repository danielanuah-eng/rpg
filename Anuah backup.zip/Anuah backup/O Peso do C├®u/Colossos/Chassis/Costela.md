---
tipo: Chassi
categoria: Colosso
tags:
  - peso-do-ceu
  - chassi
  - fabrica/ossatura
porte: Médio
fabrica: Ossatura
estrutura: 9
evasao: 11
blindagem: 1
encaixes: 5
pdf_page: 51
jogo: O Peso do Céu
---

# Costela

> [!INFO] Fonte no PDF Original
> 📖 **[[O-Peso-do-Ceu-Livro.pdf#page=51|Consultar Texto Original no PDF (Página 51) — Chassi COSTELA]]**

*Costela · porte Médio · [[Ossatura]]*

---

| | |
|---|---|
| **Estrutura** | 9 |
| **Evasão** | 11 |
| **Limiares** | 10 / 17 |
| **Blindagem** | 1 |
| **Encaixes** | 5 |
| **Deslocamento** | 2 |

## Núcleo — Abre

Ganhe 6 Estrutura e **Garra Viva** até o fim da cena. Marque 3 Estresse.

> [!TIP] Uma vez por sortida
> Abrir o Núcleo é uma ação e só acontece uma vez por sortida. Ver [[O Combate]].

## Quem começa nele

- [[Herdeiro]]

---

## Links Relacionados
- [[Ossatura]]
- [[🤖 O Colosso]]
- [[🛰️ O Peso do Céu]]
