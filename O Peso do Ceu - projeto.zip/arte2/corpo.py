# -*- coding: utf-8 -*-
"""
O corpo do colosso — segunda geração.

A primeira versão tinha um defeito que só aparece quando se põem os
dezesseis chassis lado a lado: **era o mesmo boneco pintado de cores
diferentes**. Mesmo torso, mesma perna fina, mesmo quadril, mesma
cabecinha. E o braço girava num pivô só, o que fazia o cotovelo sair
do lugar — o "torto" que o Anuah viu.

Esta versão conserta as duas coisas e acrescenta a terceira que
faltava:

  MEMBRO DE DOIS OSSOS   braço = úmero + antebraço, perna = coxa +
                         canela, com cotovelo e joelho de verdade.
                         É o que dá movimento em vez de pau girado.

  SILHUETA POR CASA      cada fábrica tem proporção própria: largura
                         de ombro, massa de panturrilha, altura de
                         torso, tamanho de cabeça. Dá para reconhecer
                         a casa pela sombra, a dois centímetros.

  CONTRAPPOSTO           o quadril inclina para o lado da perna que
                         segura o peso e o ombro inclina para o outro.
                         Sem isso, todo boneco fica em posição de
                         sentido.

A direção de arte vem das sete licenças que o Anuah escreveu, mapeadas
nas oito casas do jogo:

    Couraçados a Vapor  → BRASA       escapamento, rebite, fumaça
    Serafins Apex       → VESPERTINA  aleta, quilha, linha de neon
    Égides Arcanos      → CATEDRAL    capa, alabarda, pátina
    Leviatãs de Pressão → ARCO        domo de vidro, casco bojudo
    Arautos do Ermo     → GRALHA      assimetria severa, sucata, serra
    Falanges Urbanas    → SELO        listra de perigo, radar, número
    Espectros           → CARVAO      capuz, manto, garra
    Biomassa Aberrante  → OSSATURA    osso, núcleo, assimetria doente
"""
import math
from .cena import (Cena, FUNDO, LONGE, CENTRO, PERTO, PLACA, CABECA,
                   escurece, clareia, caixa, trapezio, elipse, cunha,
                   gira, move, escala)

# ---------------------------------------------------------------- escala
MEIO = 400.0
BASE = 46.0
H = 700.0


def y(f):
    """Altura em fração do corpo: 0 é o chão, 1 é o topo da cabeça."""
    return BASE + H * f


# Os pontos do esqueleto, em fração da altura. Proporção de Knightmare:
# perna com mais da metade do corpo, cabeça de um nono, cintura estreita.
ANC = {
    "sola":     0.000,
    "tornozelo": 0.098,
    "joelho":   0.300,
    "quadril":  0.520,
    "cintura":  0.585,
    "peito":    0.760,
    "ombro":    0.862,
    "pescoco":  0.892,
    "cabeca":   0.945,
    "topo":     0.998,
}

COXA = H * (ANC["quadril"] - ANC["joelho"])
CANELA = H * (ANC["joelho"] - ANC["tornozelo"])
UMERO = H * 0.118
ANTEBRACO = H * 0.104


class Molde:
    """Tudo que distingue uma linha de fábrica da outra."""

    def __init__(self, base, escuro, trim, vidro, traco=2.0,
                 cabeca="visor", torso="estreito", ombro="placa",
                 perna="reversa", quadril="saia", pe="patim",
                 mochila="nenhuma", larg=1.0, alt=1.0, sujo=False,
                 # proporção — é isto que muda a silhueta
                 ombro_larg=1.0, torso_larg=1.0, torso_alt=1.0,
                 braco_larg=1.0, perna_larg=1.0, panturrilha=1.0,
                 cabeca_k=1.0, assim=0.0, marca=None):
        self.base = base           # cor principal da chapa
        self.escuro = escuro       # juntas e maquinário
        self.trim = trim           # ouro, branco, laranja
        self.vidro = vidro         # viseira e sensores
        self.traco = traco
        self.cabeca = cabeca
        self.torso = torso
        self.ombro = ombro
        self.perna = perna
        self.quadril = quadril
        self.pe = pe
        self.mochila = mochila
        self.larg = larg
        self.alt = alt
        self.sujo = sujo
        self.ombro_larg = ombro_larg
        self.torso_larg = torso_larg
        self.torso_alt = torso_alt
        self.braco_larg = braco_larg
        self.perna_larg = perna_larg
        self.panturrilha = panturrilha
        self.cabeca_k = cabeca_k
        self.assim = assim         # 0 = simétrico, 1 = Ferro-Velho
        self.marca = marca         # assinatura da casa: listra, rebite…


# ============================================================= geometria
def _ponta(p, comp, ang):
    """Ponta de um osso de comprimento `comp` saindo de `p`.

    Ângulo 0 aponta para baixo (pendurado); positivo gira para a
    frente do desenho, negativo para trás.
    """
    a = math.radians(ang - 90.0)
    return (p[0] + comp * math.cos(a), p[1] + comp * math.sin(a))


def _ik(a, alvo, l1, l2, dobra=1):
    """Cinemática inversa de dois ossos: onde fica o joelho.

    Sem isto a perna é um pau girado no quadril e o pé sai flutuando
    acima do chão quando a pose abre. Com isto o pé vai onde a pose
    manda e o joelho se resolve sozinho — que é como perna funciona.
    """
    dx, dy = alvo[0] - a[0], alvo[1] - a[1]
    d = math.hypot(dx, dy) or 1e-6
    d = min(d, (l1 + l2) * 0.999)
    d = max(d, abs(l1 - l2) * 1.001 + 1e-6)
    base = math.atan2(dy, dx)
    cos_a = (d * d + l1 * l1 - l2 * l2) / (2 * d * l1)
    cos_a = max(-1.0, min(1.0, cos_a))
    ang = base + dobra * math.acos(cos_a)
    joelho = (a[0] + l1 * math.cos(ang), a[1] + l1 * math.sin(ang))
    # o alvo pode estar longe demais; devolve o pé realmente alcançado
    dir2 = math.atan2(alvo[1] - joelho[1], alvo[0] - joelho[0])
    pe = (joelho[0] + l2 * math.cos(dir2), joelho[1] + l2 * math.sin(dir2))
    return joelho, pe


def _osso(cn, a, b, w0, w1, cor, camada, traco, sombra=0.20):
    """Um segmento cônico entre dois pontos — coxa, canela, úmero."""
    dx, dy = b[0] - a[0], b[1] - a[1]
    L = math.hypot(dx, dy) or 1.0
    nx, ny = -dy / L, dx / L
    pts = [(a[0] + nx * w0 / 2, a[1] + ny * w0 / 2),
           (b[0] + nx * w1 / 2, b[1] + ny * w1 / 2),
           (b[0] - nx * w1 / 2, b[1] - ny * w1 / 2),
           (a[0] - nx * w0 / 2, a[1] - ny * w0 / 2)]
    cn.forma(pts, cor, camada, traco=traco, sombra=sombra)
    return pts


def _barriga(cn, a, b, w, cor, camada, traco, lado=1, cheio=1.0):
    """Massa que se prende a um osso — panturrilha, bíceps, motor."""
    dx, dy = b[0] - a[0], b[1] - a[1]
    L = math.hypot(dx, dy) or 1.0
    ux, uy = dx / L, dy / L
    nx, ny = -uy * lado, ux * lado
    p0 = (a[0] + ux * L * 0.12, a[1] + uy * L * 0.12)
    p1 = (a[0] + ux * L * 0.62, a[1] + uy * L * 0.62)
    e = w * cheio
    pts = [p0, (p0[0] + nx * e * 0.55, p0[1] + ny * e * 0.55),
           (p1[0] + nx * e, p1[1] + ny * e), p1]
    cn.forma(pts, cor, camada, traco=traco, sombra=0.22)


def _rebites(cn, pts, n, r, cor, camada):
    """Pontinhos de rebite ao longo de uma borda — cheiro de diesel."""
    for i in range(n):
        t = (i + 0.5) / n
        a, b = pts[0], pts[1]
        x = a[0] + (b[0] - a[0]) * t
        yy = a[1] + (b[1] - a[1]) * t
        cn.forma(elipse(x, yy, r, r, 8), cor, camada, traco=0, sombra=0)


# ================================================================ CABEÇA
def cabeca(cn, m, cx, cy, esc=1.0, camada=CABECA, inclina=0.0):
    k = 46.0 * esc * m.cabeca_k
    c = {"visor": _cab_visor, "crista": _cab_crista, "mono": _cab_mono,
         "domo": _cab_domo, "capuz": _cab_capuz, "cranio": _cab_cranio,
         "placa": _cab_placa, "coroa": _cab_coroa}
    f = c.get(m.cabeca, _cab_visor)
    # o pescoço primeiro, atrás
    cn.forma(caixa(cx - k * 0.26, cy - k * 0.85, k * 0.52, k * 0.9),
             escurece(m.escuro, 0.1), camada - 1, traco=m.traco * 0.8,
             sombra=0.25)
    f(cn, m, cx, cy, k, camada)
    return k


def _cab_visor(cn, m, cx, cy, k, c):
    """SELO — capacete quadrado, viseira em fenda, listra de perigo."""
    casco = [(cx - k * .62, cy - k * .55), (cx + k * .62, cy - k * .55),
             (cx + k * .70, cy + k * .30), (cx + k * .40, cy + k * .62),
             (cx - k * .40, cy + k * .62), (cx - k * .70, cy + k * .30)]
    cn.forma(casco, m.base, c, traco=m.traco)
    cn.forma(caixa(cx - k * .58, cy - k * .16, k * 1.16, k * .30),
             m.vidro, c, traco=m.traco * .8, sombra=0.12)
    # listra de perigo no topo, marca da Falange
    cn.forma(caixa(cx - k * .40, cy + k * .40, k * .80, k * .14),
             m.trim, c, traco=m.traco * .6, sombra=0)
    cn.forma([(cx - k * .10, cy + k * .62), (cx + k * .10, cy + k * .62),
              (cx, cy + k * .95)], m.escuro, c, traco=m.traco * .7)


def _cab_crista(cn, m, cx, cy, k, c):
    """VESPERTINA — quilha central, duas aletas, cara de falcão."""
    casco = [(cx - k * .48, cy - k * .58), (cx + k * .48, cy - k * .58),
             (cx + k * .56, cy + k * .34), (cx, cy + k * .70),
             (cx - k * .56, cy + k * .34)]
    cn.forma(casco, m.base, c, traco=m.traco)
    cn.forma([(cx - k * .44, cy - k * .06), (cx + k * .44, cy - k * .06),
              (cx + k * .30, cy + k * .26), (cx - k * .30, cy + k * .26)],
             m.vidro, c, traco=m.traco * .8, sombra=0.12)
    cn.forma([(cx - k * .07, cy + k * .34), (cx + k * .07, cy + k * .34),
              (cx, cy + k * 1.15)], m.trim, c, traco=m.traco * .7)
    for s in (-1, 1):
        cn.forma([(cx + s * k * .46, cy + k * .16),
                  (cx + s * k * 1.28, cy + k * .62),
                  (cx + s * k * 1.16, cy + k * .34),
                  (cx + s * k * .50, cy - k * .06)],
                 m.trim, c, traco=m.traco * .7, sombra=0.26)
    # queixo
    cn.forma(trapezio(cx, cy - k * .80, k * .34, k * .62, k * .24),
             escurece(m.base, .18), c, traco=m.traco * .7)


def _cab_mono(cn, m, cx, cy, k, c):
    """GRALHA — mono-olho de linha de montagem, num casco redondo."""
    cn.forma(elipse(cx, cy, k * .66, k * .60), m.base, c, traco=m.traco)
    # o trilho onde o olho corre
    cn.forma(caixa(cx - k * .62, cy - k * .10, k * 1.24, k * .26),
             escurece(m.escuro, .05), c, traco=m.traco * .7, sombra=0.1)
    ox = cx + k * .18
    cn.forma(elipse(ox, cy + k * .03, k * .19, k * .19),
             "#E8452F", c, traco=m.traco * .7, sombra=0.05)
    cn.forma(elipse(ox, cy + k * .03, k * .08, k * .08),
             clareia("#E8452F", .55), c, traco=0, sombra=0)
    # antena torta de sucata
    cn.forma([(cx - k * .30, cy + k * .52), (cx - k * .22, cy + k * .52),
              (cx - k * .46, cy + k * 1.16), (cx - k * .54, cy + k * 1.10)],
             m.escuro, c, traco=m.traco * .6)


def _cab_domo(cn, m, cx, cy, k, c):
    """ARCO — domo de pressão, com o piloto visível e cracas no aro."""
    cn.forma(elipse(cx, cy - k * .18, k * .70, k * .34), m.escuro, c,
             traco=m.traco, sombra=0.25)
    cn.forma(elipse(cx, cy - k * .10, k * .60, k * .74, 30, 0, 180),
             m.vidro, c, traco=m.traco, sombra=0.10)
    # o vulto de quem está lá dentro
    cn.forma(elipse(cx + k * .05, cy + k * .10, k * .17, k * .21),
             escurece(m.escuro, -0.25), c, traco=0, sombra=0.3)
    # aro com cracas
    for i in range(5):
        a = math.radians(24 + i * 33)
        cn.forma(elipse(cx + k * .60 * math.cos(a),
                        cy - k * .10 + k * .72 * math.sin(a),
                        k * .09, k * .07), m.trim, c,
                 traco=m.traco * .5, sombra=0.2)


def _cab_capuz(cn, m, cx, cy, k, c):
    """CARVAO — capuz de pano sobre metal, uma fenda vermelha só."""
    capuz = [(cx - k * .80, cy - k * .72), (cx - k * .52, cy + k * .34),
             (cx - k * .16, cy + k * .80), (cx + k * .26, cy + k * .74),
             (cx + k * .70, cy + k * .10), (cx + k * .74, cy - k * .72),
             (cx + k * .30, cy - k * .52), (cx - k * .34, cy - k * .56)]
    cn.forma(capuz, escurece(m.base, .30), c, traco=m.traco, sombra=0.26)
    # a cara, na sombra do capuz
    cn.forma([(cx - k * .34, cy - k * .42), (cx + k * .36, cy - k * .42),
              (cx + k * .30, cy + k * .22), (cx - k * .30, cy + k * .22)],
             escurece(m.escuro, .18), c, traco=m.traco * .7, sombra=0)
    cn.forma([(cx - k * .22, cy - k * .10), (cx + k * .26, cy - k * .04),
              (cx + k * .26, cy + k * .06), (cx - k * .22, cy)],
             "#D8443E", c, traco=0, sombra=0)


def _cab_cranio(cn, m, cx, cy, k, c):
    """OSSATURA — crânio com placa de osso e o núcleo pulsando atrás."""
    cn.forma([(cx - k * .52, cy - k * .62), (cx + k * .52, cy - k * .62),
              (cx + k * .62, cy + k * .22), (cx + k * .22, cy + k * .66),
              (cx - k * .22, cy + k * .66), (cx - k * .62, cy + k * .22)],
             m.trim, c, traco=m.traco, sombra=0.22)
    # órbitas
    for s in (-1, 1):
        cn.forma(elipse(cx + s * k * .27, cy + k * .10, k * .17, k * .15),
                 escurece(m.escuro, .2), c, traco=m.traco * .6, sombra=0)
        cn.forma(elipse(cx + s * k * .27, cy + k * .10, k * .07, k * .07),
                 "#F26060", c, traco=0, sombra=0)
    # dentes
    for i in range(6):
        x = cx - k * .40 + i * k * .16
        cn.forma([(x, cy - k * .62), (x + k * .12, cy - k * .62),
                  (x + k * .06, cy - k * .86)], m.trim, c,
                 traco=m.traco * .5, sombra=0.15)


def _cab_placa(cn, m, cx, cy, k, c):
    """BRASA — cabeça de caldeira: chapa rebitada e um visor de fenda."""
    cn.forma([(cx - k * .66, cy - k * .58), (cx + k * .66, cy - k * .58),
              (cx + k * .66, cy + k * .42), (cx - k * .66, cy + k * .42)],
             m.base, c, traco=m.traco)
    cn.forma(trapezio(cx, cy + k * .42, k * 1.24, k * .70, k * .30),
             escurece(m.base, .12), c, traco=m.traco)
    cn.forma(caixa(cx - k * .54, cy - k * .18, k * 1.08, k * .24),
             "#E8452F", c, traco=m.traco * .7, sombra=0.1)
    _rebites(cn, [(cx - k * .58, cy + k * .30), (cx + k * .58, cy + k * .30)],
             6, k * .055, m.escuro, c)
    _rebites(cn, [(cx - k * .58, cy - k * .48), (cx + k * .58, cy - k * .48)],
             6, k * .055, m.escuro, c)


def _cab_coroa(cn, m, cx, cy, k, c):
    """CATEDRAL — elmo de cavaleiro, com chifres e grade."""
    cn.forma([(cx - k * .54, cy - k * .70), (cx + k * .54, cy - k * .70),
              (cx + k * .62, cy + k * .30), (cx, cy + k * .74),
              (cx - k * .62, cy + k * .30)], m.base, c, traco=m.traco)
    # grade do visor
    cn.forma(caixa(cx - k * .46, cy - k * .30, k * .92, k * .38),
             escurece(m.escuro, .1), c, traco=m.traco * .7, sombra=0.1)
    for i in range(4):
        x = cx - k * .32 + i * k * .21
        cn.linha([(x, cy - k * .28), (x, cy + k * .06)],
                 c, traco=m.traco * .5, cor=m.trim)
    # chifres
    for s in (-1, 1):
        cn.forma([(cx + s * k * .40, cy + k * .38),
                  (cx + s * k * .60, cy + k * .30),
                  (cx + s * k * 1.02, cy + k * 1.10),
                  (cx + s * k * .74, cy + k * .56)],
                 m.trim, c, traco=m.traco * .7, sombra=0.24)


# ================================================================= TORSO
def torso(cn, m, cx, topo, base_y, camada=CENTRO, torcao=0.0):
    """O tronco. `torcao` gira o peitoral em relação à bacia."""
    w = 106.0 * m.larg * m.torso_larg
    alt = (topo - base_y)
    t = m.torso
    cor = m.base
    dx = torcao * 0.55          # o ombro sai de cima do quadril

    if t == "remendado":        # BRASA / GRALHA — chapa sobre chapa
        pts = [(cx - w * .52, base_y), (cx + w * .54, base_y),
               (cx + w * .60 + dx, topo - alt * .30),
               (cx + w * .50 + dx, topo), (cx - w * .54 + dx, topo),
               (cx - w * .62 + dx, topo - alt * .34)]
        cn.forma(pts, cor, camada, traco=m.traco)
        cn.forma(caixa(cx - w * .40 + dx, base_y + alt * .40,
                       w * .84, alt * .26), escurece(cor, .12), camada,
                 traco=m.traco * .8, sombra=0.22)
        _rebites(cn, [(cx - w * .44 + dx, base_y + alt * .70),
                      (cx + w * .44 + dx, base_y + alt * .70)],
                 7, 3.2, m.escuro, camada)
    elif t == "estreito":       # VESPERTINA / CARVAO — quilha no peito
        pts = [(cx - w * .36, base_y), (cx + w * .36, base_y),
               (cx + w * .54 + dx, topo - alt * .22),
               (cx + w * .34 + dx, topo), (cx - w * .34 + dx, topo),
               (cx - w * .54 + dx, topo - alt * .22)]
        cn.forma(pts, cor, camada, traco=m.traco)
        cn.forma([(cx + dx, base_y + alt * .10),
                  (cx + w * .26 + dx, base_y + alt * .56),
                  (cx + dx, topo - alt * .06),
                  (cx - w * .26 + dx, base_y + alt * .56)],
                 m.trim, camada, traco=m.traco * .7, sombra=0.18)
    elif t == "blindado":       # CATEDRAL — peitoral em cruz
        pts = [(cx - w * .46, base_y), (cx + w * .46, base_y),
               (cx + w * .62 + dx, topo - alt * .26),
               (cx + w * .44 + dx, topo), (cx - w * .44 + dx, topo),
               (cx - w * .62 + dx, topo - alt * .26)]
        cn.forma(pts, cor, camada, traco=m.traco)
        cn.forma(caixa(cx - w * .09 + dx, base_y + alt * .14,
                       w * .18, alt * .74), m.trim, camada,
                 traco=m.traco * .7, sombra=0.2)
        cn.forma(caixa(cx - w * .40 + dx, base_y + alt * .52,
                       w * .80, alt * .16), m.trim, camada,
                 traco=m.traco * .7, sombra=0.2)
    elif t == "bloco":          # SELO — caixa funcional, número pintado
        pts = [(cx - w * .48, base_y), (cx + w * .48, base_y),
               (cx + w * .56 + dx, topo), (cx - w * .56 + dx, topo)]
        cn.forma(pts, cor, camada, traco=m.traco)
        cn.forma(caixa(cx - w * .50 + dx, base_y + alt * .62,
                       w * 1.00, alt * .16), m.trim, camada,
                 traco=m.traco * .6, sombra=0)
        for i in range(5):      # listra de perigo
            cn.forma([(cx - w * .46 + dx + i * w * .20,
                       base_y + alt * .62),
                      (cx - w * .36 + dx + i * w * .20,
                       base_y + alt * .62),
                      (cx - w * .42 + dx + i * w * .20,
                       base_y + alt * .78),
                      (cx - w * .52 + dx + i * w * .20,
                       base_y + alt * .78)],
                     m.escuro, camada, traco=0, sombra=0)
    elif t == "casco":          # ARCO — bojudo, de pressão
        pts = elipse(cx + dx * .6, (topo + base_y) / 2,
                     w * .60, alt * .56, 26)
        cn.forma(pts, cor, camada, traco=m.traco)
        cn.forma(elipse(cx + dx * .6, (topo + base_y) / 2 + alt * .06,
                        w * .26, alt * .22), m.vidro, camada,
                 traco=m.traco * .8, sombra=0.12)
        for s in (-1, 1):
            cn.forma(elipse(cx + dx * .6 + s * w * .40,
                            (topo + base_y) / 2 - alt * .18,
                            w * .07, w * .07), m.trim, camada,
                     traco=m.traco * .5, sombra=0.2)
    elif t == "organico":       # OSSATURA — costelas e núcleo
        pts = [(cx - w * .40, base_y), (cx + w * .44, base_y),
               (cx + w * .58 + dx, topo - alt * .38),
               (cx + w * .30 + dx, topo), (cx - w * .34 + dx, topo),
               (cx - w * .56 + dx, topo - alt * .34)]
        cn.forma(pts, cor, camada, traco=m.traco)
        for i in range(4):      # costelas
            yy = base_y + alt * (.18 + i * .18)
            cn.forma([(cx - w * .40 + dx, yy),
                      (cx + w * .42 + dx, yy - alt * .03),
                      (cx + w * .42 + dx, yy + alt * .05),
                      (cx - w * .40 + dx, yy + alt * .08)],
                     m.trim, camada, traco=m.traco * .5, sombra=0.2)
        cn.forma(elipse(cx + dx, base_y + alt * .56, w * .17, w * .17),
                 "#F26060", camada, traco=m.traco * .6, sombra=0.05)
    else:
        cn.forma(trapezio(cx, base_y, w, w * .9, alt), cor, camada,
                 traco=m.traco)

    # a cabine, que lembra que tem gente ali dentro
    cn.forma(caixa(cx - w * .16 + dx, base_y + alt * .06,
                   w * .32, alt * .22), escurece(m.escuro, .05), camada,
             traco=m.traco * .7, sombra=0.2)
    return w


def quadril(cn, m, cx, cy, camada=CENTRO):
    w = 80.0 * m.larg * m.torso_larg
    t = m.quadril
    if t == "saia":
        cn.forma(trapezio(cx, cy - 34, w * 1.18, w * .86, 40),
                 escurece(m.base, .10), camada, traco=m.traco)
        for s in (-1, 1):
            cn.forma([(cx + s * w * .30, cy + 4),
                      (cx + s * w * .62, cy - 2),
                      (cx + s * w * .52, cy - 52),
                      (cx + s * w * .24, cy - 44)],
                     m.base, camada, traco=m.traco * .8, sombra=0.24)
    elif t == "blocos":
        cn.forma(caixa(cx - w * .56, cy - 34, w * 1.12, 44),
                 escurece(m.base, .08), camada, traco=m.traco)
        for s in (-1, 1):
            cn.forma(caixa(cx + s * w * .34 - w * .16, cy - 46,
                           w * .32, 30), m.escuro, camada,
                     traco=m.traco * .7, sombra=0.25)
    else:                        # liso
        cn.forma(trapezio(cx, cy - 30, w * .96, w * .78, 36),
                 escurece(m.base, .12), camada, traco=m.traco)
    cn.junta(cx, cy - 12, 9, camada, m.escuro)
    return w


# =============================================================== OMBREIRA
def ombro(cn, m, cx, cy, lado, camada=PLACA, esc=1.0, w_torso=92.0):
    """A ombreira é o segundo maior sinal de fábrica depois da cabeça."""
    t = m.ombro
    # Gralha e Ossatura: um lado tem, o outro não
    if m.assim > 0.5 and lado < 0 and t not in ("nenhum",):
        t = "sucata"
    x = cx + lado * (w_torso * .46 + 6) * m.ombro_larg
    k = 44.0 * esc * m.larg * m.ombro_larg
    cor = m.base

    if t == "laje":              # BRASA — laje enorme e rebitada
        pts = [(x - lado * k * .30, cy - k * .52),
               (x + lado * k * 1.10, cy - k * .40),
               (x + lado * k * 1.16, cy + k * .46),
               (x - lado * k * .26, cy + k * .62)]
        cn.forma(pts, cor, camada, traco=m.traco)
        _rebites(cn, [(x + lado * k * .05, cy + k * .40),
                      (x + lado * k * 1.00, cy + k * .26)],
                 5, k * .07, m.escuro, camada)
        cn.forma(caixa(x + lado * k * .20 - k * .18, cy - k * .20,
                       k * .36, k * .40), m.trim, camada,
                 traco=m.traco * .6, sombra=0.2)
    elif t == "leque":           # VESPERTINA — aleta fina
        cn.forma([(x - lado * k * .24, cy - k * .40),
                  (x + lado * k * .96, cy - k * .10),
                  (x + lado * k * 1.30, cy + k * .70),
                  (x - lado * k * .18, cy + k * .52)],
                 cor, camada, traco=m.traco)
        cn.forma([(x + lado * k * .30, cy + k * .16),
                  (x + lado * k * 1.10, cy + k * .58),
                  (x + lado * k * .96, cy + k * .16)],
                 m.trim, camada, traco=m.traco * .6, sombra=0.2)
    elif t == "pauldron":        # CATEDRAL — pauldron com borda de ouro
        pts = elipse(x + lado * k * .30, cy + k * .05, k * .92, k * .70,
                     20, -20, 200)
        cn.forma(pts, cor, camada, traco=m.traco)
        cn.forma(elipse(x + lado * k * .30, cy + k * .05, k * .92,
                        k * .70, 20, 140, 200), m.trim, camada,
                 traco=m.traco * .6, sombra=0)
        cn.forma([(x + lado * k * .30, cy + k * .74),
                  (x + lado * k * .46, cy + k * 1.34),
                  (x + lado * k * .12, cy + k * .74)],
                 m.trim, camada, traco=m.traco * .6, sombra=0.25)
    elif t == "placa":           # ARCO — placa curva, lisa
        cn.forma(elipse(x + lado * k * .22, cy, k * .82, k * .62, 18,
                        -30, 210), cor, camada, traco=m.traco)
        cn.forma(elipse(x + lado * k * .22, cy + k * .10, k * .30,
                        k * .22), m.trim, camada, traco=m.traco * .5,
                 sombra=0.2)
    elif t == "pod":             # SELO — casulo de mísseis
        cn.forma(caixa(x - k * .40, cy - k * .46, k * .96, k * 1.00),
                 cor, camada, traco=m.traco)
        for i in range(3):
            for j in range(2):
                cn.forma(elipse(x - k * .18 + j * k * .40,
                                cy - k * .26 + i * k * .34,
                                k * .13, k * .13), m.escuro, camada,
                         traco=m.traco * .5, sombra=0.1)
        cn.forma(caixa(x - k * .40, cy + k * .40, k * .96, k * .16),
                 "#D8443E", camada, traco=m.traco * .5, sombra=0)
    elif t == "gaiola":          # GRALHA — gaiola de vergalhão
        cn.forma([(x - lado * k * .20, cy - k * .46),
                  (x + lado * k * 1.04, cy - k * .24),
                  (x + lado * k * .88, cy + k * .64),
                  (x - lado * k * .22, cy + k * .50)],
                 escurece(cor, .16), camada, traco=m.traco)
        for i in range(3):
            cn.linha([(x + lado * k * (.05 + i * .30), cy - k * .40),
                      (x + lado * k * (.02 + i * .28), cy + k * .56)],
                     camada, traco=m.traco * .7, cor=m.escuro)
    elif t == "sucata":          # o lado remendado
        cn.forma([(x - lado * k * .16, cy - k * .40),
                  (x + lado * k * .70, cy - k * .46),
                  (x + lado * k * .84, cy + k * .26),
                  (x - lado * k * .10, cy + k * .44)],
                 escurece(cor, .28), camada, traco=m.traco * 1.1)
        cn.forma(cunha(x + lado * k * .60, cy + k * .20, k * .62,
                       k * .24, 40 * lado), m.escuro, camada,
                 traco=m.traco * .6, sombra=0.25)
    elif t == "carne":           # OSSATURA — placa de osso
        cn.forma([(x - lado * k * .22, cy - k * .44),
                  (x + lado * k * .80, cy - k * .30),
                  (x + lado * k * 1.06, cy + k * .50),
                  (x + lado * k * .30, cy + k * .72),
                  (x - lado * k * .20, cy + k * .46)],
                 m.trim, camada, traco=m.traco, sombra=0.24)
        for i in range(3):
            cn.forma(cunha(x + lado * k * (.30 + i * .26),
                           cy + k * .56, k * .50, k * .16, 70 * lado),
                     m.trim, camada, traco=m.traco * .5, sombra=0.2)
    elif t == "nenhum":          # CARVAO — ombro nu, só o eixo
        cn.junta(x - lado * k * .10, cy, k * .30, camada, m.escuro)
        return
    else:
        cn.forma(elipse(x, cy, k * .8, k * .6), cor, camada, traco=m.traco)


# ================================================================= BRAÇO
def braco(cn, m, cx, cy_ombro, lado, ang_ombro=0.0, ang_cotovelo=0.0,
          arma="punho", camada=PERTO, w_torso=92.0, esc=1.0):
    """Braço de dois ossos: úmero e antebraço, com cotovelo de verdade.

    É a diferença entre um membro e um pau girado no ombro.
    """
    cor = m.base if camada >= PERTO else escurece(m.base, 0.16)
    escuro = m.escuro if camada >= PERTO else escurece(m.escuro, 0.16)
    w = 40.0 * m.larg * m.braco_larg * esc
    o = (cx + lado * w_torso * .40 * m.ombro_larg, cy_ombro)
    u = UMERO * esc
    f = ANTEBRACO * esc

    cotovelo = _ponta(o, u, ang_ombro)
    punho = _ponta(cotovelo, f, ang_ombro + ang_cotovelo)

    cn.junta(o[0], o[1], w * .52, camada, escuro)
    _osso(cn, o, cotovelo, w, w * .86, cor, camada, m.traco)
    _barriga(cn, o, cotovelo, w * .42, escurece(cor, .10), camada,
             m.traco * .7, lado=-lado)
    cn.junta(cotovelo[0], cotovelo[1], w * .44, camada, escuro)
    _osso(cn, cotovelo, punho, w * .84, w * .68, cor, camada, m.traco)
    # manopla
    cn.forma(elipse(punho[0], punho[1], w * .46, w * .42), escuro,
             camada, traco=m.traco * .8, sombra=0.25)

    ang_arma = ang_ombro + ang_cotovelo
    _arma(cn, m, punho[0], punho[1], lado, ang_arma, arma, camada, cor, esc)
    return punho


def _arma(cn, m, px, py, lado, ang, arma, camada, cor, esc=1.0):
    e = m.escuro
    k = 1.22 * esc

    def g(pts):
        return move(gira(pts, ang, (0, 0)), px, py)

    if arma in (None, "punho", ""):
        return
    if arma == "espada":
        cn.forma(g([(-7 * k, 0), (7 * k, 0), (6 * k, 150 * k),
                    (0, 176 * k), (-6 * k, 150 * k)]),
                 m.trim, camada, traco=m.traco * .8, sombra=0.18)
        cn.forma(g([(-22 * k, -6 * k), (22 * k, -6 * k),
                    (22 * k, 6 * k), (-22 * k, 6 * k)]), e, camada,
                 traco=m.traco * .7)
    elif arma == "alabarda":
        cn.forma(g([(-5 * k, -40 * k), (5 * k, -40 * k),
                    (5 * k, 190 * k), (-5 * k, 190 * k)]), e, camada,
                 traco=m.traco * .8)
        cn.forma(g([(4 * k, 130 * k), (52 * k, 168 * k),
                    (16 * k, 206 * k), (4 * k, 196 * k)]),
                 m.trim, camada, traco=m.traco * .8, sombra=0.2)
        cn.forma(g([(-4 * k, 150 * k), (-34 * k, 176 * k),
                    (-4 * k, 186 * k)]), m.trim, camada,
                 traco=m.traco * .7, sombra=0.24)
    elif arma == "lamina_dupla":
        for s in (-1, 1):
            cn.forma(g([(-5 * k, 0), (5 * k, 0), (3 * k + s * 26 * k,
                        118 * k), (-3 * k + s * 26 * k, 126 * k)]),
                     m.trim, camada, traco=m.traco * .7, sombra=0.18)
    elif arma == "canhao":
        cn.forma(g(caixa(-20 * k, -14 * k, 40 * k, 118 * k)), e, camada,
                 traco=m.traco)
        cn.forma(g(caixa(-11 * k, 100 * k, 22 * k, 46 * k)),
                 escurece(e, .2), camada, traco=m.traco * .8)
        cn.forma(g(caixa(-24 * k, 10 * k, 48 * k, 16 * k)), m.trim,
                 camada, traco=m.traco * .6, sombra=0.2)
    elif arma == "pod":               # colmeia balística
        cn.forma(g(caixa(-26 * k, -10 * k, 52 * k, 86 * k)), cor, camada,
                 traco=m.traco)
        for i in range(3):
            for j in range(2):
                cn.forma(g(elipse(-12 * k + j * 24 * k, 8 * k + i * 26 * k,
                                  9 * k, 9 * k)), e, camada,
                         traco=m.traco * .5, sombra=0.1)
        cn.forma(g(caixa(-26 * k, 62 * k, 52 * k, 10 * k)), "#D8443E",
                 camada, traco=0, sombra=0)
    elif arma == "hadron":
        cn.forma(g(caixa(-17 * k, -10 * k, 34 * k, 96 * k)), e, camada,
                 traco=m.traco)
        cn.forma(g(elipse(0, 108 * k, 30 * k, 30 * k, 22, 0, 180)),
                 m.vidro, camada, traco=m.traco * .8, sombra=0.12)
        for s in (-1, 1):
            cn.forma(g([(s * 17 * k, 40 * k), (s * 40 * k, 86 * k),
                        (s * 22 * k, 90 * k)]), m.trim, camada,
                     traco=m.traco * .6, sombra=0.2)
    elif arma in ("fuzil", "fuzil_longo"):
        L = 150 * k if arma == "fuzil_longo" else 108 * k
        cn.forma(g(caixa(-11 * k, -16 * k, 22 * k, L)), e, camada,
                 traco=m.traco)
        cn.forma(g(caixa(-20 * k, 16 * k, 40 * k, 22 * k)),
                 escurece(cor, .1), camada, traco=m.traco * .8)
        cn.forma(g(caixa(-6 * k, L - 8 * k, 12 * k, 26 * k)),
                 escurece(e, .2), camada, traco=m.traco * .7)
        if arma == "fuzil_longo":
            cn.forma(g(caixa(-9 * k, 54 * k, 18 * k, 14 * k)), m.vidro,
                     camada, traco=m.traco * .5, sombra=0.1)
    elif arma == "garra":
        for i, a in enumerate((-30, -6, 20)):
            cn.forma(g(move(gira([(-5 * k, 0), (5 * k, 0), (0, 82 * k)],
                                 a), 0, 6 * k)),
                     m.trim, camada, traco=m.traco * .7, sombra=0.22)
    elif arma == "escudo":
        cn.forma(g([(-58 * k, -66 * k), (58 * k, -66 * k),
                    (66 * k, 40 * k), (0, 86 * k), (-66 * k, 40 * k)]),
                 cor, camada, traco=m.traco)
        cn.forma(g([(-30 * k, -34 * k), (30 * k, -34 * k),
                    (34 * k, 24 * k), (0, 50 * k), (-34 * k, 24 * k)]),
                 m.trim, camada, traco=m.traco * .7, sombra=0.2)
    elif arma == "martelo":           # esmaga-bunker, com propulsor
        cn.forma(g(caixa(-8 * k, -20 * k, 16 * k, 130 * k)), e, camada,
                 traco=m.traco)
        cn.forma(g(caixa(-44 * k, 108 * k, 88 * k, 56 * k)), cor, camada,
                 traco=m.traco)
        cn.forma(g(caixa(-44 * k, 108 * k, 88 * k, 16 * k)), "#E8452F",
                 camada, traco=m.traco * .5, sombra=0)
        cn.forma(g(caixa(-26 * k, 164 * k, 52 * k, 24 * k)),
                 escurece(e, .15), camada, traco=m.traco * .8)
    elif arma == "serra":
        cn.forma(g(caixa(-9 * k, -14 * k, 18 * k, 70 * k)), e, camada,
                 traco=m.traco)
        cn.forma(g(elipse(0, 96 * k, 46 * k, 46 * k)), m.trim, camada,
                 traco=m.traco * .8, sombra=0.18)
        for i in range(12):
            a = i * 30
            cn.forma(g(move(gira([(-6 * k, 0), (6 * k, 0), (0, 16 * k)],
                                 a), 46 * k * math.cos(math.radians(a + 90)),
                            96 * k + 46 * k * math.sin(math.radians(a + 90)))),
                     m.trim, camada, traco=0, sombra=0.2)
    elif arma == "rede":
        cn.forma(g(caixa(-12 * k, -12 * k, 24 * k, 46 * k)), e, camada,
                 traco=m.traco)
        for i in range(4):
            cn.linha(g([(-30 * k + i * 20 * k, 40 * k),
                        (-46 * k + i * 30 * k, 120 * k)]), camada,
                     traco=m.traco * .6, cor=e)
        for i in range(3):
            cn.linha(g([(-40 * k, 60 * k + i * 22 * k),
                        (40 * k, 60 * k + i * 22 * k)]), camada,
                     traco=m.traco * .6, cor=e)
    elif arma == "arpeu":
        cn.forma(g(caixa(-10 * k, -12 * k, 20 * k, 62 * k)), e, camada,
                 traco=m.traco)
        cn.forma(g([(-16 * k, 56 * k), (16 * k, 56 * k), (0, 104 * k)]),
                 m.trim, camada, traco=m.traco * .7, sombra=0.2)
    elif arma == "drone":
        for i, (dx, dy) in enumerate(((-58, 72), (46, 104), (-20, 130))):
            cn.forma(g(elipse(dx * k, dy * k, 15 * k, 10 * k)), cor,
                     camada, traco=m.traco * .7, sombra=0.22)
            cn.forma(g(elipse(dx * k, dy * k, 5 * k, 5 * k)), m.vidro,
                     camada, traco=0, sombra=0)


# ================================================================= PERNA
def perna(cn, m, cx, cy_quadril, lado, pe_x=0.0, pe_alto=0.0,
          camada=PERTO, abertura=1.0, w_quadril=70.0, esc=1.0):
    """Perna de dois ossos com o pé onde a pose mandar.

    A silhueta de Knightmare é perna: longa, com a panturrilha cheia e
    o pé pequeno. `pe_x` é onde o pé pousa em relação ao centro do
    corpo, `pe_alto` é o quanto ele está no ar.
    """
    cor = m.base if camada >= PERTO else escurece(m.base, 0.16)
    escuro = m.escuro if camada >= PERTO else escurece(m.escuro, 0.16)
    w = 42.0 * m.larg * m.perna_larg * esc
    q = (cx + lado * w_quadril * .30 * abertura, cy_quadril)
    c = COXA * esc
    ca = CANELA * esc

    reversa = m.perna == "reversa"
    alvo = (cx + pe_x, BASE + H * ANC["tornozelo"] * 0.55 + pe_alto)
    joelho, torn = _ik(q, alvo, c, ca, dobra=(-1 if reversa else 1))

    cn.junta(q[0], q[1], w * .48, camada, escuro)
    _osso(cn, q, joelho, w, w * .80, cor, camada, m.traco)
    cn.junta(joelho[0], joelho[1], w * .46, camada, escuro)
    _osso(cn, joelho, torn, w * .78, w * .56, cor, camada, m.traco)

    # a panturrilha: onde mora o volume da perna
    if m.panturrilha > 0.05:
        _barriga(cn, joelho, torn, w * .70 * m.panturrilha,
                 escurece(cor, .08), camada, m.traco * .8,
                 lado=(-1 if reversa else 1) * lado, cheio=1.0)

    if m.perna == "mangueira":       # BRASA / GRALHA — cabo exposto
        for t in (0.3, 0.55):
            a = (q[0] + (joelho[0] - q[0]) * t, q[1] + (joelho[1] - q[1]) * t)
            cn.forma(elipse(a[0] - lado * w * .5, a[1], w * .18, w * .13),
                     escuro, camada, traco=m.traco * .5, sombra=0.2)
    _pe(cn, m, torn[0], torn[1], lado, camada, cor, w, esc)
    return torn


def _pe(cn, m, px, py, lado, camada, cor, w, esc=1.0):
    e = m.escuro
    t = m.pe
    if t == "patim":                  # landspinner: desliza, não marcha
        cn.forma([(px - w * .46, py), (px + w * .70, py),
                  (px + w * .56, py - w * .46), (px - w * .40, py - w * .46)],
                 cor, camada, traco=m.traco)
        for dx in (-0.22, 0.30):
            cn.forma(elipse(px + w * dx, py - w * .62, w * .26, w * .26),
                     e, camada, traco=m.traco * .7, sombra=0.25)
            cn.forma(elipse(px + w * dx, py - w * .62, w * .10, w * .10),
                     escurece(e, .3), camada, traco=0, sombra=0)
    elif t == "garra":
        cn.forma([(px - w * .34, py), (px + w * .34, py),
                  (px + w * .24, py - w * .34), (px - w * .24, py - w * .34)],
                 cor, camada, traco=m.traco)
        for i, dx in enumerate((-.52, 0, .52)):
            cn.forma([(px + w * dx - w * .12, py - w * .30),
                      (px + w * dx + w * .12, py - w * .30),
                      (px + w * dx + w * .30 * (1 if dx >= 0 else -1),
                       py - w * .86)], m.trim, camada,
                     traco=m.traco * .6, sombra=0.22)
    elif t == "bota":
        cn.forma([(px - w * .52, py - w * .10), (px + w * .82, py - w * .10),
                  (px + w * .74, py - w * .58), (px - w * .44, py - w * .58)],
                 cor, camada, traco=m.traco)
        cn.forma(caixa(px - w * .56, py - w * .80, w * 1.44, w * .24),
                 e, camada, traco=m.traco * .8, sombra=0.25)
    else:                             # chato
        cn.forma(caixa(px - w * .58, py - w * .62, w * 1.34, w * .62),
                 cor, camada, traco=m.traco)


# =============================================================== MOCHILA
def mochila(cn, m, cx, cy, tipo=None, camada=FUNDO, esc=1.0):
    t = tipo or m.mochila
    if t in (None, "nenhuma", ""):
        return
    k = 74.0 * esc * m.larg
    cor, e = m.base, m.escuro

    if t == "escapamento":            # BRASA — chaminé e fumaça chapada
        for s in (-1, 1):
            cn.forma(caixa(cx + s * k * .52 - k * .13, cy, k * .26, k * 1.30),
                     e, camada, traco=m.traco)
            cn.forma(caixa(cx + s * k * .52 - k * .18, cy + k * 1.24,
                           k * .36, k * .16), escurece(e, .2), camada,
                     traco=m.traco * .7)
            for i, (dx, dy, r) in enumerate(((.10, 1.60, .30),
                                             (.34, 1.98, .40),
                                             (.04, 2.40, .52))):
                cn.forma(elipse(cx + s * k * (.52 + dx), cy + k * dy,
                                k * r, k * r * .82, 16),
                         escurece(m.escuro, -0.35), camada,
                         traco=0, sombra=0.18, opacidade=0.55 - i * 0.12)
    elif t == "asas":                 # VESPERTINA — asa de Serafim
        for s in (-1, 1):
            cn.forma([(cx + s * k * .22, cy + k * .10),
                      (cx + s * k * 1.70, cy + k * 1.30),
                      (cx + s * k * 1.52, cy + k * .34),
                      (cx + s * k * .30, cy - k * .30)],
                     m.trim, camada, traco=m.traco, sombra=0.26)
            cn.forma([(cx + s * k * .30, cy - k * .10),
                      (cx + s * k * 1.24, cy + k * .10),
                      (cx + s * k * 1.10, cy - k * .40),
                      (cx + s * k * .34, cy - k * .52)],
                     m.vidro, camada, traco=m.traco * .7, sombra=0.2)
    elif t == "turbina":
        for s in (-1, 1):
            cn.forma(caixa(cx + s * k * .58 - k * .24, cy - k * .10,
                           k * .48, k * 1.06), cor, camada, traco=m.traco)
            cn.forma(elipse(cx + s * k * .58, cy - k * .16, k * .26,
                            k * .16), e, camada, traco=m.traco * .7,
                     sombra=0.2)
    elif t == "jato":                 # mochila a jato — a que o Anuah citou
        cn.forma(caixa(cx - k * .46, cy - k * .10, k * .92, k * .86), cor,
                 camada, traco=m.traco)
        for s in (-1, 1):
            bx = cx + s * k * .92
            cn.forma(caixa(bx - k * .20, cy - k * .62, k * .40, k * 1.24),
                     escurece(cor, .12), camada, traco=m.traco * .9)
            cn.forma(caixa(bx - k * .24, cy + k * .50, k * .48, k * .20),
                     m.trim, camada, traco=m.traco * .6, sombra=0.2)
            cn.forma([(bx - k * .16, cy - k * .62), (bx + k * .16, cy - k * .62),
                      (bx, cy - k * 1.62)],
                     "#F0A040", camada, traco=0, sombra=0, opacidade=0.8)
            cn.forma([(bx - k * .08, cy - k * .62), (bx + k * .08, cy - k * .62),
                      (bx, cy - k * 1.16)],
                     "#FFE9B0", camada, traco=0, sombra=0)
    elif t == "canhoes":
        for s in (-1, 1):
            cn.forma(caixa(cx + s * k * .66 - k * .16, cy + k * .10,
                           k * .32, k * 1.34), e, camada, traco=m.traco)
            cn.forma(caixa(cx + s * k * .66 - k * .26, cy + k * .60,
                           k * .52, k * .30), cor, camada,
                     traco=m.traco * .8, sombra=0.22)
    elif t == "capa":                 # CATEDRAL / CARVAO — manto rasgado
        pts = [(cx - k * .62, cy + k * .72), (cx + k * .62, cy + k * .72),
               (cx + k * 1.46, cy - k * 1.10), (cx + k * 1.62, cy - k * 2.30),
               (cx + k * 1.06, cy - k * 2.06), (cx + k * .62, cy - k * 2.52),
               (cx + k * .16, cy - k * 2.10), (cx - k * .30, cy - k * 2.54),
               (cx - k * .76, cy - k * 2.08), (cx - k * 1.18, cy - k * 2.34),
               (cx - k * 1.34, cy - k * 1.06)]
        cn.forma(pts, escurece(m.base, .34), camada, traco=m.traco,
                 sombra=0.26)
        cn.linha([(cx - k * .30, cy + k * .40), (cx - k * .42, cy - k * 1.80)],
                 camada, traco=m.traco * .6, cor=escurece(m.base, .5))
    elif t == "espinhos":
        for i, (dx, comp, a) in enumerate(((-.70, 1.30, -22), (-.24, 1.66, -8),
                                           (.24, 1.62, 8), (.70, 1.24, 22))):
            cn.forma(cunha(cx + k * dx, cy, k * comp, k * .34, 90 + a),
                     m.trim, camada, traco=m.traco * .8, sombra=0.24)
    elif t == "antena":               # GRALHA — sucata que capta rádio
        cn.forma(caixa(cx - k * .40, cy, k * .80, k * .70), escurece(cor, .2),
                 camada, traco=m.traco)
        cn.linha([(cx + k * .20, cy + k * .60), (cx + k * .86, cy + k * 2.10)],
                 camada, traco=m.traco * .8, cor=e)
        cn.linha([(cx - k * .10, cy + k * .60), (cx - k * .50, cy + k * 1.74)],
                 camada, traco=m.traco * .7, cor=e)
        cn.forma(elipse(cx + k * .86, cy + k * 2.10, k * .13, k * .13),
                 "#E8452F", camada, traco=0, sombra=0)
    elif t == "radar":                # SELO — prato de radar
        cn.forma(caixa(cx - k * .30, cy, k * .60, k * .80), cor, camada,
                 traco=m.traco)
        cn.forma(elipse(cx + k * .50, cy + k * 1.20, k * .78, k * .96, 24,
                        -60, 160), escurece(cor, .06), camada, traco=m.traco,
                 sombra=0.22)
        cn.linha([(cx + k * .10, cy + k * .70), (cx + k * .50, cy + k * 1.20)],
                 camada, traco=m.traco * .8, cor=e)
    elif t == "discos":
        for s in (-1, 1):
            cn.forma(elipse(cx + s * k * .78, cy + k * .50, k * .58,
                            k * .58), escurece(cor, .06), camada,
                     traco=m.traco, sombra=0.24)
            cn.forma(elipse(cx + s * k * .78, cy + k * .50, k * .22,
                            k * .22), e, camada, traco=m.traco * .6,
                     sombra=0.1)
    elif t == "casco":                # ARCO — lastro de pressão
        cn.forma(elipse(cx, cy + k * .50, k * 1.00, k * .78, 24),
                 escurece(cor, .10), camada, traco=m.traco, sombra=0.24)
        for i in range(3):
            cn.forma(elipse(cx - k * .50 + i * k * .50, cy + k * .96,
                            k * .16, k * .12), m.trim, camada,
                     traco=m.traco * .5, sombra=0.2)


def sombra_chao(cn, cx, largura=250, cor="#000000"):
    cn.forma(elipse(cx, BASE - 6, largura * 0.5, 15), cor, FUNDO,
             traco=0, sombra=0, opacidade=0.13)
