# -*- coding: utf-8 -*-
"""
A montagem: gramática de fábrica, poses com peso e o desenho inteiro.

Duas regras de desenho, as duas pedidas pelo Anuah:

  **Nada de capacete repetido entre linhas diferentes.** Cada fábrica
  tem uma cabeça só dela; dentro da casa o que muda é ombreira, perna,
  mochila, arma e pose.

  **Nenhuma casa é o mesmo boneco de outra.** Agora a diferença não
  está só na cor: muda a largura do ombro, a altura do torso, a massa
  da panturrilha, o tamanho da cabeça e a abertura das pernas. Os
  dezesseis chassis lado a lado têm dezesseis silhuetas.

A direção de arte de cada casa saiu das sete licenças que o Anuah
escreveu (Couraçados a Vapor, Serafins Apex, Égides Arcanos, Leviatãs
de Pressão, Arautos do Ermo, Falanges Urbanas, Espectros) mais a
Biomassa Aberrante dos vilões.
"""
import math
from .cena import (Cena, CENTRO, LONGE, PERTO, PLACA, FUNDO, CABECA,
                   escurece, clareia, elipse, caixa)
from . import corpo as C
from .corpo import Molde, y, MEIO, BASE, H, ANC

# --------------------------------------------------------------- paletas
# base, escuro, trim, vidro — as oito casas, sem colidir de cor
PALETA = {
 "BRASA":      ("#B0553B", "#3A2A24", "#E8B45C", "#F2E2BE"),
 "VESPERTINA": ("#5E8FB4", "#25323E", "#F0F2F4", "#9CE4F0"),
 "CATEDRAL":   ("#C9B279", "#3B3421", "#FBF3DA", "#7FD3C0"),
 "ARCO":       ("#3E8C7D", "#1E2F2C", "#DDE9D8", "#B9F0E4"),
 "GRALHA":     ("#C4762C", "#332A20", "#5B6B58", "#F0D18A"),
 "SELO":       ("#3C5580", "#1B2434", "#D8DEE9", "#8FB6F2"),
 "CARVAO":     ("#6B5473", "#221C28", "#A98CB8", "#C9A0F0"),
 "OSSATURA":   ("#A24A5C", "#2B1B21", "#E4D3C0", "#F09090"),
}

# cabeça exclusiva por fábrica
CABECA_DA_CASA = {
 "BRASA": "placa", "VESPERTINA": "crista", "CATEDRAL": "coroa",
 "ARCO": "domo", "GRALHA": "mono", "SELO": "visor",
 "CARVAO": "capuz", "OSSATURA": "cranio",
}

# ------------------------------------------------------------- gramática
# É aqui que mora a silhueta. Os números são proporção, não enfeite:
# ombro_larg abre a linha do ombro, panturrilha enche a perna,
# torso_alt estica o tronco, cabeca_k muda a escala do capacete.
GRAMATICA = {
 # Couraçados a Vapor: largo, baixo, pesado, fumaça saindo das costas
 "BRASA":      dict(torso="remendado", ombro="laje", perna="mangueira",
                    quadril="blocos", pe="bota", mochila="escapamento",
                    larg=1.20, traco=2.5, sujo=True,
                    ombro_larg=1.28, torso_larg=1.14, torso_alt=0.92,
                    braco_larg=1.26, perna_larg=1.22, panturrilha=1.25,
                    cabeca_k=0.88, marca="rebite"),
 # Serafins Apex: alto, estreito, aerodinâmico, cabeça pequena
 "VESPERTINA": dict(torso="estreito", ombro="leque", perna="reversa",
                    quadril="saia", pe="patim", mochila="nenhuma",
                    larg=0.90, traco=1.5,
                    ombro_larg=0.94, torso_larg=0.86, torso_alt=1.10,
                    braco_larg=0.82, perna_larg=0.86, panturrilha=0.95,
                    cabeca_k=0.82, marca="neon"),
 # Égides Arcanos: torso blindado, pauldron, capa, pose de sentinela
 "CATEDRAL":   dict(torso="blindado", ombro="pauldron", perna="coluna",
                    quadril="saia", pe="bota", mochila="capa",
                    larg=1.12, traco=2.0,
                    ombro_larg=1.20, torso_larg=1.08, torso_alt=1.02,
                    braco_larg=1.08, perna_larg=1.22, panturrilha=1.02,
                    cabeca_k=1.02, marca="patina"),
 # Leviatãs de Pressão: casco bojudo, perna curta e grossa, domo
 "ARCO":       dict(torso="casco", ombro="placa", perna="coluna",
                    quadril="liso", pe="chato", mochila="casco",
                    larg=1.14, traco=2.0,
                    ombro_larg=1.06, torso_larg=1.22, torso_alt=0.86,
                    braco_larg=1.14, perna_larg=1.34, panturrilha=1.05,
                    cabeca_k=1.10, marca="craca"),
 # Arautos do Ermo: assimetria severa, sucata, um ombro só
 "GRALHA":     dict(torso="remendado", ombro="gaiola", perna="mangueira",
                    quadril="blocos", pe="chato", mochila="antena",
                    larg=1.06, traco=2.6, sujo=True,
                    ombro_larg=1.14, torso_larg=1.02, torso_alt=0.96,
                    braco_larg=1.10, perna_larg=1.12, panturrilha=0.95,
                    cabeca_k=0.94, assim=0.9, marca="ferrugem"),
 # Falanges Urbanas: bloco, listra de perigo, radar, tudo quadrado
 "SELO":       dict(torso="bloco", ombro="pod", perna="reversa",
                    quadril="saia", pe="patim", mochila="radar",
                    larg=1.06, traco=2.2,
                    ombro_larg=1.12, torso_larg=1.06, torso_alt=0.98,
                    braco_larg=1.02, perna_larg=1.04, panturrilha=1.00,
                    cabeca_k=0.96, marca="listra"),
 # Espectros: encurvado, sem ombreira, manto, perna digitígrada
 "CARVAO":     dict(torso="estreito", ombro="nenhum", perna="reversa",
                    quadril="liso", pe="garra", mochila="capa",
                    larg=0.92, traco=1.6,
                    ombro_larg=0.86, torso_larg=0.84, torso_alt=1.04,
                    braco_larg=0.84, perna_larg=0.84, panturrilha=0.88,
                    cabeca_k=0.92, marca="trapo"),
 # Biomassa Aberrante: orgânico, assimétrico, osso por cima da carne
 "OSSATURA":   dict(torso="organico", ombro="carne", perna="garra",
                    quadril="liso", pe="garra", mochila="espinhos",
                    larg=1.08, traco=1.8,
                    ombro_larg=1.10, torso_larg=1.00, torso_alt=1.06,
                    braco_larg=1.16, perna_larg=1.12, panturrilha=1.10,
                    cabeca_k=1.00, assim=0.8, marca="osso"),
}


def molde(fabrica, **ajustes):
    base, escuro, trim, vidro = PALETA[fabrica]
    g = dict(GRAMATICA[fabrica])
    g["cabeca"] = CABECA_DA_CASA[fabrica]
    g.update(ajustes)
    return Molde(base, escuro, trim, vidro, **g)


# ----------------------------------------------------------------- poses
# Cada pose diz: inclinação do tronco, torção (ombro sai de cima do
# quadril), de que lado está o peso, abertura das pernas, e para cada
# membro um par (ângulo do ombro/quadril, ângulo do cotovelo/joelho).
#
# Cotovelo e joelho são o que faltava: sem eles o membro é um pau
# girado, e é por isso que os bonecos saíam tortos.
# pd/pe agora são (x do pé em relação ao centro, altura do pé no ar).
# Quem resolve joelho e tornozelo é a cinemática inversa — por isso o
# pé pousa no chão mesmo quando a pose abre muito.
# Nenhuma pose levanta os dois braços do mesmo jeito: um braço sempre
# faz alguma coisa e o outro responde. É o que separa "postura" de
# "posição de sentido com os braços para cima".
POSES = {
 # de pé, peso num pé só, um braço solto e o outro meio dobrado
 "parado":   dict(inclina=0, torcao=-4, peso=-1, abertura=1.00,
                  bd=(14, -22), be=(-10, -6), pd=(34, 0), pe=(-38, 0)),
 # lâmina alta de um lado, guarda baixa do outro
 "guarda":   dict(inclina=-3, torcao=12, peso=-1, abertura=1.08,
                  bd=(-46, -86), be=(34, -14), pd=(58, 0), pe=(-54, 0)),
 # investida: braço da arma para trás, o outro aberto para equilibrar
 "avanco":   dict(inclina=10, torcao=-16, peso=1, abertura=1.10,
                  bd=(-70, -48), be=(62, -18), pd=(116, 0), pe=(-96, 26)),
 # golpe vindo de cima, o braço livre abaixado
 "golpe":    dict(inclina=12, torcao=20, peso=1, abertura=1.08,
                  bd=(-148, -28), be=(-34, -44), pd=(98, 0), pe=(-88, 0)),
 # cano apoiado: um braço estende, o outro dobra sob a arma
 "tiro":     dict(inclina=-4, torcao=10, peso=-1, abertura=1.04,
                  bd=(-86, -16), be=(-40, -96), pd=(46, 0), pe=(-74, 0)),
 # no ar, pernas recolhidas, braços atrás
 "voo":      dict(inclina=0, torcao=0, peso=0, abertura=0.86,
                  bd=(40, -38), be=(-24, -18), pd=(70, 150), pe=(-54, 96)),
 # agachado, um braço no chão, o outro recuado
 "espreita": dict(inclina=16, torcao=-10, peso=0, abertura=1.16,
                  bd=(46, -78), be=(-14, -34), pd=(98, 0), pe=(-86, 0),
                  agacha=118),
 # apontando: um braço reto à frente, o outro nas costas
 "ordena":   dict(inclina=-3, torcao=14, peso=-1, abertura=1.02,
                  bd=(-112, -8), be=(26, -16), pd=(38, 0), pe=(-42, 0)),
 # escudo à frente, arma baixa e pronta
 "muralha":  dict(inclina=-5, torcao=-12, peso=0, abertura=1.14,
                  bd=(18, -34), be=(-68, -96), pd=(80, 0), pe=(-80, 0),
                  agacha=42),
 # pés plantados, ombros largos, braços abertos pelo volume do casco
 "pesado":   dict(inclina=3, torcao=8, peso=1, abertura=1.20,
                  bd=(30, -18), be=(-34, -34), pd=(86, 0), pe=(-86, 0),
                  agacha=26),
}

# poses que pedem sombra maior no chão
LARGAS = ("avanco", "golpe", "espreita", "pesado", "muralha")


def monta(fabrica, arma_dir="punho", arma_esq="punho", pose="parado",
          mochila=None, asas=False, esc=1.0, **ajustes):
    """
    Desenha um colosso inteiro e devolve a Cena.

    As asas só entram quando `asas=True`, e o gerador só liga isso a
    partir do Escalão 3 — voar alto é coisa de fim de campanha.
    """
    m = molde(fabrica, **ajustes)
    p = dict(POSES.get(pose, POSES["parado"]))
    cn = Cena(traco_base=m.traco)

    cx = MEIO
    torcao = p["torcao"]
    inclina = p["inclina"]
    peso = p["peso"]

    agacha = p.get("agacha", 0)
    y_quadril = y(ANC["quadril"]) - agacha
    y_cintura = y(ANC["cintura"]) - agacha
    y_topo = y(ANC["ombro"] + 0.030 * m.torso_alt) - agacha
    y_ombro = y(ANC["ombro"]) + (m.torso_alt - 1.0) * H * 0.02 - agacha
    y_cabeca = y(ANC["cabeca"]) + (m.torso_alt - 1.0) * H * 0.03 - agacha

    # o contrapposto: o ombro sai de cima do quadril
    dx_ombro = torcao * 0.55 + inclina * 0.9
    dx_cabeca = dx_ombro * 0.55 + inclina * 0.6

    w_torso = 106.0 * m.larg * m.torso_larg
    w_quadril = 80.0 * m.larg * m.torso_larg

    C.sombra_chao(cn, cx + dx_ombro * .3,
                  250 * m.larg * (1.28 if pose in LARGAS else 1.0))

    # ---- camada 0: o que fica atrás de tudo
    if asas:
        C.mochila(cn, m, cx + dx_ombro * .6, y(0.815), "asas", FUNDO, esc)
    C.mochila(cn, m, cx + dx_ombro * .6, y(0.775),
              mochila or m.mochila, FUNDO, esc)

    # ---- camada 1: membros do lado de lá, um tom mais escuros
    C.ombro(cn, m, cx + dx_ombro, y_ombro, -1, LONGE, 0.92, w_torso)
    C.braco(cn, m, cx + dx_ombro, y_ombro, -1, p["be"][0], p["be"][1],
            arma_esq, LONGE, w_torso, esc)
    C.perna(cn, m, cx, y_quadril + (5 if peso < 0 else -3), -1,
            p["pe"][0], p["pe"][1], LONGE, p["abertura"] * 0.94,
            w_quadril, esc)

    # ---- camada 2/3: corpo, bacia e membros de cá
    C.perna(cn, m, cx, y_quadril + (-3 if peso < 0 else 5), 1,
            p["pd"][0], p["pd"][1], PERTO, p["abertura"], w_quadril, esc)
    C.quadril(cn, m, cx + dx_ombro * .25, y_cintura, CENTRO)
    C.torso(cn, m, cx, y_topo, y_cintura - 6, CENTRO, torcao)

    # ---- camada 4: ombreira e braço da frente
    C.ombro(cn, m, cx + dx_ombro, y_ombro, 1, PLACA, 1.0, w_torso)
    C.braco(cn, m, cx + dx_ombro, y_ombro, 1, p["bd"][0], p["bd"][1],
            arma_dir, PERTO, w_torso, esc)

    # ---- camada 5: a cabeça
    C.cabeca(cn, m, cx + dx_cabeca, y_cabeca, esc, CABECA, inclina)
    return cn
