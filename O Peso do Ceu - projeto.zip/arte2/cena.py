# -*- coding: utf-8 -*-
"""
O motor de arte novo: uma cena, dois renderizadores.

A queixa era que os desenhos estavam abstratos demais. A resposta é
parar de desenhar linha solta e passar a montar peças sólidas: cada
forma é um polígono fechado, pintado chapado e cortado em duas metades
— a que recebe luz e a que não recebe, 20% mais escura. É o "flat
shading" do guia de arquétipos, e é o que faz um vetor plano ler como
volume sem virar gradiente.

A cena é só uma lista de formas com um número de camada. Quem desenha
não sabe se vai virar TikZ (para o livro) ou SVG (para o Obsidian e as
ferramentas de celular) — os dois renderizadores leem a mesma cena.

    CAMADAS (z-index, do fundo para a frente)
    0  acessórios traseiros: mochila, asas, capa, canhões dorsais
    1  membros distantes, um tom mais escuros
    2  torso, bacia e articulações centrais
    3  membros dianteiros
    4  ombreiras, escudos, peitoral
    5  cabeça, viseira, sensores
"""
import math

FUNDO, LONGE, CENTRO, PERTO, PLACA, CABECA = 0, 1, 2, 3, 4, 5

# a luz vem de cima e da esquerda, como em quase todo desenho de mecha
LUZ = (-0.48, 0.877)


# ----------------------------------------------------------------- cor
def hex_para_rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def rgb_para_hex(r, g, b):
    return "#%02X%02X%02X" % (max(0, min(255, int(round(r)))),
                              max(0, min(255, int(round(g)))),
                              max(0, min(255, int(round(b)))))


def escurece(cor, fator):
    """fator 0.20 = 20% mais escuro."""
    r, g, b = hex_para_rgb(cor)
    k = 1.0 - fator
    return rgb_para_hex(r * k, g * k, b * k)


def clareia(cor, fator):
    r, g, b = hex_para_rgb(cor)
    return rgb_para_hex(r + (255 - r) * fator,
                        g + (255 - g) * fator,
                        b + (255 - b) * fator)


# ------------------------------------------------------------ geometria
def centroide(pts):
    x = sum(p[0] for p in pts) / len(pts)
    y = sum(p[1] for p in pts) / len(pts)
    return x, y


def corta_semiplano(pts, ponto, normal):
    """
    Sutherland–Hodgman: devolve a parte do polígono que está do lado
    para onde a normal aponta. É assim que a forma ganha a metade
    iluminada e a metade na sombra sem usar máscara nem gradiente.
    """
    if not pts:
        return []
    px, py = ponto
    nx, ny = normal

    def dentro(p):
        return (p[0] - px) * nx + (p[1] - py) * ny >= 0

    def corte(a, b):
        da = (a[0] - px) * nx + (a[1] - py) * ny
        db = (b[0] - px) * nx + (b[1] - py) * ny
        if abs(db - da) < 1e-9:
            return a
        t = da / (da - db)
        return (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)

    saida = []
    n = len(pts)
    for i in range(n):
        a, b = pts[i], pts[(i + 1) % n]
        ia, ib = dentro(a), dentro(b)
        if ia:
            saida.append(a)
            if not ib:
                saida.append(corte(a, b))
        elif ib:
            saida.append(corte(a, b))
    return saida


def gira(pts, ang, centro=(0, 0)):
    c, s = math.cos(math.radians(ang)), math.sin(math.radians(ang))
    cx, cy = centro
    return [((p[0] - cx) * c - (p[1] - cy) * s + cx,
             (p[0] - cx) * s + (p[1] - cy) * c + cy) for p in pts]


def move(pts, dx, dy):
    return [(p[0] + dx, p[1] + dy) for p in pts]


def escala(pts, k, centro=(0, 0)):
    cx, cy = centro
    return [((p[0] - cx) * k + cx, (p[1] - cy) * k + cy) for p in pts]


def caixa(x, y, w, h):
    """Retângulo pelo canto inferior esquerdo."""
    return [(x, y), (x + w, y), (x + w, y + h), (x, y + h)]


def trapezio(x, y, wb, wt, h):
    """Trapézio centrado em x, base wb embaixo e wt em cima."""
    return [(x - wb / 2, y), (x + wb / 2, y),
            (x + wt / 2, y + h), (x - wt / 2, y + h)]


def elipse(cx, cy, rx, ry, n=28, de=0, ate=360):
    pts = []
    for i in range(n + 1):
        a = math.radians(de + (ate - de) * i / n)
        pts.append((cx + rx * math.cos(a), cy + ry * math.sin(a)))
    return pts


def cunha(x, y, comp, larg, ang):
    """Lâmina/espinho: um triângulo alongado apontando para ang."""
    base = [(-larg / 2, 0), (larg / 2, 0), (0, comp)]
    return move(gira(base, ang - 90), x, y)


# --------------------------------------------------------------- formas
class Forma:
    """Um polígono chapado, com a metade de sombra já calculada."""

    def __init__(self, pts, cor, camada=CENTRO, traco=2.0, sombra=0.20,
                 contorno="#000000", luz=None, fechado=True, opacidade=1.0):
        self.pts = list(pts)
        self.cor = cor
        self.camada = camada
        self.traco = traco
        self.sombra = sombra
        self.contorno = contorno
        self.luz = luz or LUZ
        self.fechado = fechado
        self.opacidade = opacidade

    def metade_escura(self):
        """A parte do polígono virada para longe da luz."""
        if self.sombra <= 0:
            return []
        c = centroide(self.pts)
        # a linha de corte passa pelo centro, perpendicular à luz
        normal = (-self.luz[0], -self.luz[1])
        # desloca um pouco para a sombra pegar menos da metade
        desl = 0.12
        ponto = (c[0] - self.luz[0] * desl * _raio(self.pts, c),
                 c[1] - self.luz[1] * desl * _raio(self.pts, c))
        return corta_semiplano(self.pts, ponto, normal)


def _raio(pts, c):
    return max(math.hypot(p[0] - c[0], p[1] - c[1]) for p in pts) or 1.0


class Linha:
    """Detalhe aberto: painel, ranhura, cabo."""

    def __init__(self, pts, camada=CENTRO, traco=1.0, cor="#000000"):
        self.pts = list(pts)
        self.camada = camada
        self.traco = traco
        self.cor = cor


class Cena:
    def __init__(self, traco_base=2.0):
        self.itens = []
        self.traco_base = traco_base

    def forma(self, pts, cor, camada=CENTRO, traco=None, sombra=0.20,
              contorno="#000000", opacidade=1.0):
        if len(pts) < 3:
            return None
        f = Forma(pts, cor, camada, traco if traco is not None
                  else self.traco_base, sombra, contorno,
                  opacidade=opacidade)
        self.itens.append(f)
        return f

    def linha(self, pts, camada=CENTRO, traco=None, cor="#000000"):
        if len(pts) < 2:
            return None
        l = Linha(pts, camada, traco if traco is not None
                  else self.traco_base * 0.5, cor)
        self.itens.append(l)
        return l

    def junta(self, x, y, r, camada=CENTRO, cor="#2A2A2E"):
        """Articulação: um disco escuro com o eixo marcado."""
        self.forma(elipse(x, y, r, r), cor, camada, sombra=0.25)
        self.forma(elipse(x, y, r * 0.42, r * 0.42), escurece(cor, 0.35),
                   camada, traco=self.traco_base * 0.5, sombra=0)

    def ordenadas(self):
        return sorted(enumerate(self.itens),
                      key=lambda p: (p[1].camada, p[0]))
