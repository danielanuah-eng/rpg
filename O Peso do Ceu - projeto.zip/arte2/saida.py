# -*- coding: utf-8 -*-
"""
Os dois renderizadores da cena: TikZ e SVG.

TikZ é o que entra no livro, nas cartas, nas fichas e no escudo — o
LaTeX desenha em vetor nativo e sai perfeito na impressão. SVG é o que
vai para o Obsidian (que renderiza direto na nota) e para as
ferramentas de celular (inline no HTML, sem baixar nada).

Os dois leem a mesma Cena. Se um desenho mudar, muda nos dois.
"""
import math
from .cena import Forma, Linha, escurece

# a arte é feita num quadro de 800x800 e reduzida na hora de usar
QUADRO = 800.0


# =============================================================== TikZ
def para_tikz(cena, escala_mm=0.05, cores=None):
    """
    Devolve o corpo de um tikzpicture. `cores` recebe as cores usadas,
    para o chamador declarar os \\definecolor uma vez só.
    """
    if cores is None:
        cores = {}
    linhas = []

    def nome_cor(c):
        if c not in cores:
            cores[c] = "c%s" % c.lstrip("#").lower()
        return cores[c]

    def caminho(pts):
        return " -- ".join("(%.2f,%.2f)" % (p[0] * escala_mm,
                                            p[1] * escala_mm) for p in pts)

    for _i, it in cena.ordenadas():
        if isinstance(it, Forma):
            base = nome_cor(it.cor)
            op = ("" if it.opacidade >= 0.999
                  else ", opacity=%.2f" % it.opacidade)
            linhas.append("\\fill[%s%s] %s -- cycle;"
                          % (base, op, caminho(it.pts)))
            esc = it.metade_escura()
            if len(esc) >= 3:
                sombra = nome_cor(escurece(it.cor, it.sombra))
                linhas.append("\\fill[%s%s] %s -- cycle;"
                              % (sombra, op, caminho(esc)))
            if it.traco > 0.01:
                linhas.append("\\draw[%s%s, line width=%.2fpt, "
                              "line join=round] %s -- cycle;"
                              % (nome_cor(it.contorno), op, it.traco,
                                 caminho(it.pts)))
        else:
            linhas.append("\\draw[%s, line width=%.2fpt, line cap=round] %s;"
                          % (nome_cor(it.cor), it.traco, caminho(it.pts)))
    return "\n".join(linhas), cores


def definicoes_tikz(cores):
    """Os \\definecolor de todas as cores que a cena usou."""
    out = []
    for hexa, nome in sorted(cores.items()):
        out.append("\\definecolor{%s}{HTML}{%s}"
                   % (nome, hexa.lstrip("#").upper()))
    return "\n".join(out)


# ================================================================ SVG
def para_svg(cena, largura=800, altura=800, fundo=None, margem=24,
             titulo=None, descricao=None):
    """
    SVG completo e autocontido. O eixo y do desenho aponta para cima
    (como em matemática); o SVG aponta para baixo, então a cena inteira
    entra dentro de um translate/scale que vira o mundo de uma vez.
    """
    p = []
    p.append('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" '
             'width="%d" height="%d" role="img">'
             % (largura, altura, largura, altura))
    if titulo:
        p.append("<title>%s</title>" % _esc(titulo))
    if descricao:
        p.append("<desc>%s</desc>" % _esc(descricao))
    if fundo:
        p.append('<rect width="%d" height="%d" fill="%s"/>'
                 % (largura, altura, fundo))
    # y para cima
    p.append('<g transform="translate(0,%d) scale(1,-1)" '
             'stroke-linejoin="round" stroke-linecap="round">' % altura)

    for _i, it in cena.ordenadas():
        if isinstance(it, Forma):
            d = _d(it.pts, True)
            op = ("" if it.opacidade >= 0.999
                  else ' opacity="%.2f"' % it.opacidade)
            p.append('<path d="%s" fill="%s" stroke="none"%s/>'
                     % (d, it.cor, op))
            esc = it.metade_escura()
            if len(esc) >= 3:
                p.append('<path d="%s" fill="%s" stroke="none"%s/>'
                         % (_d(esc, True), escurece(it.cor, it.sombra), op))
            if it.traco > 0.01:
                p.append('<path d="%s" fill="none" stroke="%s" '
                         'stroke-width="%.2f"%s/>'
                         % (d, it.contorno, it.traco, op))
        else:
            p.append('<path d="%s" fill="none" stroke="%s" '
                     'stroke-width="%.2f"/>' % (_d(it.pts, False), it.cor,
                                                it.traco))
    p.append("</g></svg>")
    return "\n".join(p)


def _d(pts, fechado):
    if not pts:
        return ""
    d = "M %.2f %.2f" % pts[0]
    for x, y in pts[1:]:
        d += " L %.2f %.2f" % (x, y)
    return d + (" Z" if fechado else "")


def _esc(t):
    return (str(t).replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;"))


# =============================================================== JSON
def _simplifica(pts, tol=3.0):
    """Tira ponto que não muda a forma.

    Um círculo sai daqui com 28 pontos; a 150 px de tela, 10 bastam.
    São 132 desenhos indo dentro de um HTML — cada ponto conta.
    """
    if len(pts) < 4:
        return pts
    saida = [pts[0]]
    for i in range(1, len(pts) - 1):
        ax, ay = saida[-1]
        bx, by = pts[i]
        cx, cy = pts[i + 1]
        if (bx - ax) ** 2 + (by - ay) ** 2 < tol * tol:
            continue
        # distância de b à reta a-c
        dx, dy = cx - ax, cy - ay
        L = math.hypot(dx, dy)
        if L < 1e-6:
            continue
        d = abs((bx - ax) * dy - (by - ay) * dx) / L
        if d < tol:
            continue
        saida.append(pts[i])
    saida.append(pts[-1])
    return saida if len(saida) >= 3 else pts


def para_json(cena, paleta=None, tol=0.0):
    """
    Cena em formato compacto, para o navegador redesenhar.

    Inlinar 132 SVGs num HTML dá 3,4 MB e um celular sofre. A mesma
    cena como listas de inteiros dá um sexto disso, e ainda deixa a
    página trocar cor e escala sem gerar nada de novo.

    Formato de cada forma:
        [camada, iCor, traco*10, sombra*100, opacidade*100, x0,y0,x1,y1...]
    Linha aberta vem com camada negativa.
    """
    if paleta is None:
        paleta = {}

    def idx(c):
        if c not in paleta:
            paleta[c] = len(paleta)
        return paleta[c]

    itens = []
    for _i, it in cena.ordenadas():
        pts = []
        bruto = _simplifica(it.pts, tol) if tol else it.pts
        for x, y in bruto:
            pts.append(int(round(x)))
            pts.append(int(round(y)))
        if isinstance(it, Forma):
            itens.append([it.camada, idx(it.cor), int(round(it.traco * 10)),
                          int(round(it.sombra * 100)),
                          int(round(it.opacidade * 100)),
                          idx(it.contorno)] + pts)
        else:
            itens.append([-1, idx(it.cor), int(round(it.traco * 10)), 0, 100,
                          idx(it.cor)] + pts)
    return itens, paleta


JS_RENDER = r"""
// Redesenha uma cena de arte2 em SVG. O corte de sombra é o mesmo
// Sutherland-Hodgman do Python: metade iluminada, metade 20% escura.
const LUZ = [-0.48, 0.877];
function escurece(hex, f){
  const n = parseInt(hex.slice(1), 16), k = 1 - f;
  const r = Math.round(((n>>16)&255)*k), g = Math.round(((n>>8)&255)*k),
        b = Math.round((n&255)*k);
  return '#' + ((1<<24)|(r<<16)|(g<<8)|b).toString(16).slice(1).toUpperCase();
}
function corta(pts, px, py, nx, ny){
  const dentro = p => (p[0]-px)*nx + (p[1]-py)*ny >= 0;
  const corte = (a,b) => {
    const da=(a[0]-px)*nx+(a[1]-py)*ny, db=(b[0]-px)*nx+(b[1]-py)*ny;
    if (Math.abs(db-da) < 1e-9) return a;
    const t = da/(da-db);
    return [a[0]+(b[0]-a[0])*t, a[1]+(b[1]-a[1])*t];
  };
  const out = [];
  for (let i=0;i<pts.length;i++){
    const a=pts[i], b=pts[(i+1)%pts.length], ia=dentro(a), ib=dentro(b);
    if (ia){ out.push(a); if(!ib) out.push(corte(a,b)); }
    else if (ib) out.push(corte(a,b));
  }
  return out;
}
function desenhaCena(itens, paleta, opc){
  opc = opc || {};
  const W = opc.w || 800, H = opc.h || 800;
  let s = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 800" '
        + 'width="100%" height="100%" preserveAspectRatio="xMidYMid meet">'
        + '<g transform="translate(0,800) scale(1,-1)" '
        + 'stroke-linejoin="round" stroke-linecap="round">';
  for (const it of itens){
    const cam=it[0], cor=paleta[it[1]], tr=it[2]/10, som=it[3]/100,
          op=it[4]/100, ctr=paleta[it[5]];
    const pts=[];
    for (let i=6;i<it.length;i+=2) pts.push([it[i], it[i+1]]);
    let d='M '+pts[0][0]+' '+pts[0][1];
    for (let i=1;i<pts.length;i++) d+=' L '+pts[i][0]+' '+pts[i][1];
    const oa = op<0.999 ? ' opacity="'+op+'"' : '';
    if (cam < 0){ s += '<path d="'+d+'" fill="none" stroke="'+cor
                     + '" stroke-width="'+tr+'"'+oa+'/>'; continue; }
    d += ' Z';
    s += '<path d="'+d+'" fill="'+cor+'" stroke="none"'+oa+'/>';
    if (som > 0){
      let cx=0, cy=0;
      for (const p of pts){ cx+=p[0]; cy+=p[1]; }
      cx/=pts.length; cy/=pts.length;
      let r=0;
      for (const p of pts) r=Math.max(r, Math.hypot(p[0]-cx, p[1]-cy));
      const px=cx-LUZ[0]*0.12*r, py=cy-LUZ[1]*0.12*r;
      const esc=corta(pts, px, py, -LUZ[0], -LUZ[1]);
      if (esc.length>=3){
        let e='M '+esc[0][0].toFixed(1)+' '+esc[0][1].toFixed(1);
        for (let i=1;i<esc.length;i++)
          e+=' L '+esc[i][0].toFixed(1)+' '+esc[i][1].toFixed(1);
        s += '<path d="'+e+' Z" fill="'+escurece(cor,som)
           + '" stroke="none"'+oa+'/>';
      }
    }
    if (tr > 0.01)
      s += '<path d="'+d+'" fill="none" stroke="'+ctr
         + '" stroke-width="'+tr+'"'+oa+'/>';
  }
  return s + '</g></svg>';
}
"""
