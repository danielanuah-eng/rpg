# -*- coding: utf-8 -*-
"""
Gente a pé e veículos.

Desenhados na mesma escala do quadro dos colossos, mas ocupando só o
terço de baixo — é o que dá, de graça, a leitura de escala quando as
duas cartas estão lado a lado na mesa.
"""
import math
from .cena import (Cena, caixa, trapezio, elipse, cunha, gira, move,
                   escurece, clareia, FUNDO, LONGE, CENTRO, PERTO, PLACA,
                   CABECA)
from .corpo import y, MEIO, BASE, sombra_chao, Molde

PELE = "#C79A73"
FARDA = "#5A6350"
FARDA2 = "#3E4538"
METAL = "#6B727C"
ESCURO = "#22262B"
VIDRO = "#9CC8E0"


def _pessoa(cn, x, yb, esc=1.0, arma="fuzil", cor=FARDA, capacete=True,
            pose=0.0, camada=PERTO, traco=1.6):
    """Uma pessoa de pé, de corpo inteiro, com arma."""
    k = 150.0 * esc                      # altura da pessoa
    w = k * .17
    cor2 = escurece(cor, .16)

    # pernas
    for lado, cam in ((-1, LONGE), (1, camada)):
        cn.forma(gira(trapezio(x + lado * w * .55, yb, w * .78, w * .92,
                               k * .46), lado * pose * .4,
                      (x + lado * w * .55, yb + k * .46)),
                 cor if lado > 0 else cor2, cam, traco)
        cn.forma([(x + lado * w * .95, yb), (x + lado * w * .95 + w * .70,
                                             yb),
                  (x + lado * w * .95 + w * .70, yb + w * .30),
                  (x + lado * w * .95 - w * .20, yb + w * .30)],
                 ESCURO, cam, traco * .8)
    # tronco
    cn.forma([(x - w * 1.02, yb + k * .44), (x + w * 1.02, yb + k * .44),
              (x + w * 1.16, yb + k * .76), (x - w * 1.16, yb + k * .76)],
             cor, camada, traco)
    cn.forma(caixa(x - w * 1.16, yb + k * .58, w * 2.32, w * .34),
             cor2, camada, traco * .7)
    # braços
    for lado, cam in ((-1, LONGE), (1, camada)):
        cn.forma(gira(trapezio(x + lado * w * 1.28, yb + k * .40,
                               w * .60, w * .68, k * .36),
                      lado * (26 if arma in ("fuzil", "rifle") else 8),
                      (x + lado * w * 1.28, yb + k * .76)),
                 cor if lado > 0 else cor2, cam, traco)
    # cabeça
    cy = yb + k * .84
    cn.forma(elipse(x, cy, w * .62, w * .68, n=18), PELE, PLACA, traco)
    if capacete:
        cn.forma(elipse(x, cy + w * .16, w * .78, w * .62, n=18, de=0,
                        ate=180) + [(x - w * .78, cy + w * .02),
                                    (x + w * .78, cy + w * .02)],
                 cor2, PLACA, traco)
    _arma_gente(cn, x, yb, k, w, arma, camada, traco)


def _arma_gente(cn, x, yb, k, w, arma, camada, traco):
    if arma == "fuzil":
        cn.forma([(x + w * .4, yb + k * .52), (x + w * 2.8, yb + k * .66),
                  (x + w * 2.8, yb + k * .54), (x + w * .4, yb + k * .40)],
                 ESCURO, PLACA, traco * .9)
    elif arma == "lancador":
        cn.forma([(x - w * .6, yb + k * .74), (x + w * 3.0, yb + k * .86),
                  (x + w * 3.0, yb + k * .62), (x - w * .6, yb + k * .50)],
                 METAL, PLACA, traco * .9)
        cn.forma(elipse(x + w * 3.0, yb + k * .74, w * .26, w * .22),
                 "#B04030", PLACA, traco * .7, sombra=0)
    elif arma == "carga":
        cn.forma(caixa(x + w * .6, yb + k * .40, w * .9, w * .9),
                 "#B0863B", PLACA, traco * .8)
        cn.forma(caixa(x + w * .78, yb + k * .40 + w * .9, w * .18, w * .5),
                 ESCURO, PLACA, traco * .5)
    elif arma == "radio":
        cn.forma(caixa(x - w * 1.5, yb + k * .50, w * .6, w * .8),
                 ESCURO, PLACA, traco * .8)
        cn.linha([(x - w * 1.2, yb + k * .50 + w * .8),
                  (x - w * 1.5, yb + k * 1.05)], PLACA, traco * .5)
    elif arma == "ferramenta":
        cn.forma([(x + w * .5, yb + k * .30), (x + w * .9, yb + k * .30),
                  (x + w * .9, yb + k * .86), (x + w * .5, yb + k * .86)],
                 METAL, PLACA, traco * .8)


def pessoa(base=1, esc=1.0, arma="fuzil", capacete=True, **kw):
    cn = Cena(traco_base=1.6)
    sombra_chao(cn, MEIO, 120 * esc)
    _pessoa(cn, MEIO, BASE, esc * 2.2, arma, FARDA, capacete)
    return cn


def grupo(n=5, esc=1.0, arma="fuzil", **kw):
    """Pelotão: um na frente, o resto atrás e mais escuro."""
    cn = Cena(traco_base=1.6)
    sombra_chao(cn, MEIO, 380)
    postos = [(-200, .78, LONGE), (200, .80, LONGE), (-92, .90, CENTRO),
              (108, .92, CENTRO), (0, 1.06, PERTO), (-300, .70, FUNDO),
              (300, .72, FUNDO)]
    for i, (dx, k, cam) in enumerate(postos[:max(3, min(n, 7))]):
        cor = FARDA if cam == PERTO else escurece(FARDA, .10 +
                                                  (0.16 if cam == FUNDO else 0))
        _pessoa(cn, MEIO + dx, BASE, esc * 2.0 * k, arma, cor, True,
                pose=(i % 3) * 6, camada=cam, traco=1.6)
    return cn


def veiculo(tipo="blindado", **kw):
    cn = Cena(traco_base=2.0)
    sombra_chao(cn, MEIO, 400)
    cx = MEIO
    if tipo == "blindado":
        cn.forma([(cx - 300, BASE + 40), (cx + 300, BASE + 40),
                  (cx + 270, BASE + 130), (cx - 250, BASE + 130)],
                 FARDA, CENTRO, 2.0)
        cn.forma([(cx - 130, BASE + 130), (cx + 120, BASE + 130),
                  (cx + 90, BASE + 200), (cx - 100, BASE + 200)],
                 escurece(FARDA, .08), PERTO, 2.0)
        cn.forma([(cx + 80, BASE + 178), (cx + 330, BASE + 190),
                  (cx + 330, BASE + 166), (cx + 80, BASE + 154)],
                 ESCURO, PLACA, 1.8)
        for i in range(6):
            cn.forma(elipse(cx - 250 + i * 100, BASE + 40, 46, 46, n=18),
                     ESCURO, PERTO, 1.8)
            cn.forma(elipse(cx - 250 + i * 100, BASE + 40, 18, 18, n=14),
                     METAL, PERTO, 1.0, sombra=0)
    elif tipo == "caminhao":
        cn.forma(caixa(cx - 300, BASE + 50, 340, 150), escurece(FARDA, .04),
                 CENTRO, 2.0)
        cn.forma([(cx + 40, BASE + 50), (cx + 250, BASE + 50),
                  (cx + 250, BASE + 150), (cx + 150, BASE + 170),
                  (cx + 40, BASE + 170)], FARDA, PERTO, 2.0)
        cn.forma(caixa(cx + 150, BASE + 104, 92, 54), VIDRO, PLACA, 1.6,
                 sombra=.12)
        for dx in (-230, -110, 180):
            cn.forma(elipse(cx + dx, BASE + 50, 52, 52, n=18), ESCURO,
                     PERTO, 1.8)
    elif tipo == "helicoptero":
        yb = y(0.42)
        cn.forma(elipse(cx, yb, 190, 84, n=24), FARDA, CENTRO, 2.0)
        cn.forma([(cx - 170, yb + 20), (cx - 380, yb + 46),
                  (cx - 380, yb + 6), (cx - 168, yb - 16)],
                 escurece(FARDA, .06), CENTRO, 2.0)
        cn.forma(elipse(cx + 110, yb + 10, 78, 54, n=20), VIDRO, PLACA, 1.6,
                 sombra=.12)
        cn.forma(caixa(cx - 340, yb + 34, 24, 96), ESCURO, PERTO, 1.6)
        cn.forma(caixa(cx - 360, yb + 40, 300, 12), ESCURO, PLACA, 1.4)
        cn.forma(caixa(cx - 12, yb + 84, 24, 40), ESCURO, CENTRO, 1.6)
        cn.forma(caixa(cx - 340, yb + 124, 700, 14), ESCURO, PLACA, 1.6)
        for dx in (-120, 120):
            cn.forma(caixa(cx + dx - 8, BASE + 30, 16, 100), METAL, LONGE,
                     1.4)
        cn.forma(caixa(cx - 200, BASE + 22, 400, 18), METAL, LONGE, 1.6)
    elif tipo == "trem":
        cn.forma(caixa(cx - 360, BASE + 54, 500, 170), escurece(FARDA, .10),
                 CENTRO, 2.2)
        cn.forma([(cx + 140, BASE + 54), (cx + 350, BASE + 54),
                  (cx + 350, BASE + 190), (cx + 250, BASE + 224),
                  (cx + 140, BASE + 224)], FARDA, PERTO, 2.2)
        cn.forma(caixa(cx + 244, BASE + 150, 96, 54), VIDRO, PLACA, 1.6,
                 sombra=.12)
        for dx in range(-330, 340, 84):
            cn.forma(elipse(cx + dx, BASE + 54, 40, 40, n=16), ESCURO,
                     PERTO, 1.6)
        cn.forma(caixa(cx - 400, BASE + 20, 800, 14), METAL, LONGE, 1.4)
    elif tipo == "dirigivel":
        yb = y(0.56)
        cn.forma(elipse(cx, yb, 350, 150, n=32), escurece(FARDA, .02),
                 CENTRO, 2.2)
        cn.forma(caixa(cx - 90, yb - 220, 180, 84), FARDA, PERTO, 2.0)
        cn.forma(caixa(cx - 66, yb - 196, 132, 40), VIDRO, PLACA, 1.6,
                 sombra=.12)
        for lado in (-1, 1):
            cn.forma([(cx + lado * 330, yb + 30), (cx + lado * 430, yb + 96),
                      (cx + lado * 424, yb - 34), (cx + lado * 326, yb - 20)],
                     escurece(FARDA, .10), FUNDO, 1.8)
        for dx in (-70, 70):
            cn.linha([(cx + dx, yb - 148), (cx + dx * .6, yb - 136)],
                     CENTRO, 1.2)
    return cn
