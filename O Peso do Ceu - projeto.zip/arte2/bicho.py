# -*- coding: utf-8 -*-
"""
As Fundas: o que sobe do fundo.

Oito planos de corpo, nenhum humanoide. Usam as mesmas primitivas dos
colossos — polígono fechado, sombreamento chapado, contorno preto — para
que uma Funda e um colosso na mesma página pareçam do mesmo jogo, mesmo
sem parecer da mesma espécie.

A paleta é fria e doente de propósito: nada aqui saiu de fábrica.
"""
import math
from .cena import (Cena, caixa, trapezio, elipse, cunha, gira, move,
                   escurece, clareia, FUNDO, LONGE, CENTRO, PERTO, PLACA,
                   CABECA)
from .corpo import y, MEIO, BASE, H, sombra_chao, Molde

# base, escuro, trim (osso/dente), vidro (olho)
PALETA_FUNDA = {
 "rastejante": ("#5C7A6B", "#22302B", "#DCD3B8", "#F2D060"),
 "ereta":      ("#7A5A64", "#2A1E22", "#E6DCC6", "#F06A6A"),
 "nadadora":   ("#4C7286", "#1C2A33", "#D6E4E8", "#8FE0D4"),
 "voadora":    ("#6E6A86", "#25232F", "#E2DCE8", "#C8A0F0"),
 "massa":      ("#6B6350", "#272318", "#D8CCA8", "#B8E060"),
 "torre":      ("#55606E", "#1E242B", "#CFD6DC", "#7FC0F0"),
 "enxame":     ("#7E6440", "#2B2216", "#E0D2AE", "#F09030"),
 "colossal":   ("#5A5F72", "#20232C", "#DCDCE4", "#F05050"),
}


def _m(plano, traco=1.8):
    b, e, t, v = PALETA_FUNDA[plano]
    return Molde(b, e, t, v, traco=traco)


def _olho(cn, m, x, cy, r, camada=PLACA):
    cn.forma(elipse(x, cy, r, r), m.escuro, camada, m.traco * .7, sombra=0)
    cn.forma(elipse(x, cy, r * .58, r * .58), m.vidro, camada,
             m.traco * .5, sombra=0)


def _espinhos(cn, m, pts, comp, camada=FUNDO, n=None):
    """Fileira de espinhos ao longo de uma linha de pontos."""
    n = n or len(pts)
    for i, (px, py) in enumerate(pts):
        f = 0.55 + 0.45 * math.sin(math.pi * i / max(1, len(pts) - 1))
        cn.forma(cunha(px, py, comp * f, comp * .32, 90 + (i - n / 2) * 6),
                 clareia(m.trim, .10), camada, m.traco * .8)


def _perna_org(cn, m, x0, y0, comp, lado, ang, camada, grossura=1.0):
    """Pata articulada em dois segmentos, fina e óssea."""
    w = 26 * grossura
    cotovelo = (x0 + lado * comp * .48 * math.cos(math.radians(ang)),
                y0 + comp * .52)
    pe = (cotovelo[0] + lado * comp * .42, BASE + 6)
    cn.forma([(x0 - w * .5, y0), (x0 + w * .5, y0),
              (cotovelo[0] + w * .42, cotovelo[1]),
              (cotovelo[0] - w * .42, cotovelo[1])],
             m.base, camada, m.traco)
    cn.forma([(cotovelo[0] - w * .38, cotovelo[1]),
              (cotovelo[0] + w * .38, cotovelo[1]),
              (pe[0] + w * .20, pe[1]), (pe[0] - w * .30, pe[1])],
             m.base, camada, m.traco)
    cn.junta(cotovelo[0], cotovelo[1], w * .40, camada, m.escuro)
    for i in (-1, 0, 1):
        cn.forma(cunha(pe[0] + i * w * .26, pe[1], w * .80, w * .28,
                       -70 + i * 22), clareia(m.trim, .05), camada,
                 m.traco * .7)


# ============================================================== PLANOS
def rastejante(cn, m, **kw):
    """Corpo longo e baixo, muitas patas, cauda. Vem por dentro."""
    cx = MEIO
    yb = y(0.30)
    corpo = [(cx - 300, yb - 40), (cx - 180, yb + 58), (cx + 90, yb + 74),
             (cx + 250, yb + 30), (cx + 300, yb - 26), (cx + 150, yb - 68),
             (cx - 160, yb - 72)]
    _espinhos(cn, m, [(cx - 150 + i * 70, yb + 54) for i in range(7)], 88)
    for i, lado in enumerate((-1, -1, 1, 1)):
        _perna_org(cn, m, cx + (-190 + i * 120), yb - 50, 200, lado,
                   30 + i * 12, LONGE if i < 2 else PERTO, 0.9)
    cn.forma(corpo, m.base, CENTRO, m.traco)
    # cauda
    cn.forma([(cx - 290, yb - 10), (cx - 250, yb + 30),
              (cx - 400, yb + 120), (cx - 372, yb + 66)],
             escurece(m.base, .08), CENTRO, m.traco)
    # cabeça sem pescoço
    cn.forma([(cx + 250, yb + 34), (cx + 356, yb + 46), (cx + 384, yb - 4),
              (cx + 300, yb - 54), (cx + 246, yb - 26)],
             m.base, PLACA, m.traco)
    for i in range(6):
        cn.forma(cunha(cx + 262 + i * 22, yb - 40, 34, 14, -84),
                 m.trim, PLACA, m.traco * .6)
    _olho(cn, m, cx + 312, yb + 14, 17)
    _olho(cn, m, cx + 344, yb + 6, 12)


def ereta(cn, m, **kw):
    """Duas pernas, tronco alto, boca grande. A que fica de pé."""
    cx = MEIO
    yq = y(0.44)
    for lado, cam, ab in ((-1, LONGE, .86), (1, PERTO, 1.0)):
        _perna_org(cn, m, cx + lado * 66 * ab, yq, 330, lado, 22, cam, 1.5)
    cn.forma([(cx - 118, yq - 20), (cx - 150, yq + 210),
              (cx - 76, yq + 300), (cx + 86, yq + 300),
              (cx + 156, yq + 196), (cx + 120, yq - 20)],
             m.base, CENTRO, m.traco)
    _espinhos(cn, m, [(cx - 60 + i * 44, yq + 292) for i in range(5)], 96,
              FUNDO)
    # braços curtos
    for lado, cam in ((-1, LONGE), (1, PERTO)):
        cn.forma([(cx + lado * 130, yq + 250), (cx + lado * 212, yq + 176),
                  (cx + lado * 196, yq + 128), (cx + lado * 118, yq + 196)],
                 m.base, cam, m.traco)
        for i in (-1, 0, 1):
            cn.forma(cunha(cx + lado * (200 + i * 12), yq + 140, 62, 20,
                           -80 + i * 24), m.trim, cam, m.traco * .7)
    # cabeça
    cy = yq + 350
    cn.forma([(cx - 92, cy - 44), (cx - 74, cy + 40), (cx + 74, cy + 40),
              (cx + 92, cy - 44), (cx + 34, cy - 86), (cx - 34, cy - 86)],
             m.base, PLACA, m.traco)
    cn.forma(caixa(cx - 78, cy - 46, 156, 22), m.escuro, PLACA, m.traco * .7)
    for i in range(7):
        cn.forma(cunha(cx - 66 + i * 22, cy - 46, 30, 13, -84), m.trim,
                 PLACA, m.traco * .5)
    _olho(cn, m, cx - 40, cy + 6, 15)
    _olho(cn, m, cx + 40, cy + 6, 15)


def nadadora(cn, m, **kw):
    """Fuso, nadadeiras, sem perna nenhuma. Passa por baixo do casco."""
    cx = MEIO
    yb = y(0.42)
    cn.forma(elipse(cx, yb, 300, 108, n=30), m.base, CENTRO, m.traco)
    for lado, cam in ((-1, LONGE), (1, PERTO)):
        cn.forma([(cx - 40, yb + lado * 40), (cx + 120, yb + lado * 30),
                  (cx + 60, yb + lado * 210), (cx - 90, yb + lado * 150)],
                 escurece(m.base, .06), cam, m.traco)
    cn.forma([(cx - 296, yb + 6), (cx - 400, yb + 128),
              (cx - 386, yb - 120), (cx - 292, yb - 10)],
             escurece(m.base, .10), FUNDO, m.traco)
    cn.forma([(cx + 200, yb + 60), (cx + 360, yb + 26), (cx + 386, yb - 26),
              (cx + 230, yb - 78)], m.base, PLACA, m.traco)
    for i in range(8):
        cn.forma(cunha(cx + 224 + i * 20, yb - 60, 28, 12, -86), m.trim,
                 PLACA, m.traco * .5)
    _olho(cn, m, cx + 300, yb + 18, 16)
    _espinhos(cn, m, [(cx - 180 + i * 80, yb + 96) for i in range(6)], 70,
              FUNDO)


def voadora(cn, m, **kw):
    """Asa membranosa e corpo mínimo. Não pousa."""
    cx = MEIO
    yb = y(0.56)
    for lado, cam in ((-1, FUNDO), (1, PLACA)):
        cn.forma([(cx + lado * 40, yb + 60), (cx + lado * 250, yb + 190),
                  (cx + lado * 400, yb + 90), (cx + lado * 330, yb - 40),
                  (cx + lado * 160, yb - 110), (cx + lado * 46, yb - 20)],
                 escurece(m.base, .04) if lado < 0 else m.base, cam, m.traco)
        for i in range(3):
            cn.linha([(cx + lado * 60, yb + 20),
                      (cx + lado * (250 + i * 50), yb + (130 - i * 80))],
                     cam, m.traco * .5)
    cn.forma(elipse(cx, yb, 62, 150, n=24), m.base, CENTRO, m.traco)
    cn.forma([(cx - 40, yb + 130), (cx + 40, yb + 130), (cx + 26, yb + 216),
              (cx - 26, yb + 216)], m.base, PLACA, m.traco)
    _olho(cn, m, cx - 20, yb + 190, 13)
    _olho(cn, m, cx + 20, yb + 190, 13)
    cn.forma([(cx - 20, yb - 140), (cx + 20, yb - 140), (cx + 8, yb - 290),
              (cx - 8, yb - 290)], escurece(m.base, .10), CENTRO, m.traco)


def massa(cn, m, **kw):
    """Não tem forma. Tem tamanho, e fica maior."""
    cx = MEIO
    yb = y(0.34)
    pts = []
    for i in range(22):
        a = 2 * math.pi * i / 22
        r = 250 + 62 * math.sin(a * 3.0) + 34 * math.cos(a * 5.0)
        pts.append((cx + r * math.cos(a), yb + r * .74 * math.sin(a)))
    cn.forma(pts, m.base, CENTRO, m.traco)
    for dx, dy, r in ((-120, 60, 58), (80, 96, 44), (150, -20, 50),
                      (-60, -90, 40), (20, 10, 66)):
        cn.forma(elipse(cx + dx, yb + dy, r, r * .9, n=18),
                 clareia(m.base, .10), PERTO, m.traco * .8)
    for dx, dy in ((-150, 20), (-40, 110), (100, 40), (170, -60), (10, -80)):
        _olho(cn, m, cx + dx, yb + dy, 15)
    for i in range(7):
        a = math.pi * (0.1 + 0.8 * i / 6)
        cn.forma(cunha(cx + 250 * math.cos(a), yb + 190 * math.sin(a),
                       92, 32, math.degrees(a)), m.trim, FUNDO, m.traco * .8)


def torre(cn, m, **kw):
    """Fica parada, cresce para cima e alcança longe."""
    cx = MEIO
    cn.forma([(cx - 210, BASE), (cx + 210, BASE), (cx + 130, y(0.42)),
              (cx + 96, y(0.80)), (cx - 96, y(0.80)), (cx - 130, y(0.42))],
             m.base, CENTRO, m.traco)
    for i in range(5):
        f = 0.16 + i * 0.15
        w = 210 - i * 26
        cn.forma([(cx - w, y(f)), (cx + w, y(f)),
                  (cx + w * .88, y(f + .05)), (cx - w * .88, y(f + .05))],
                 escurece(m.base, .05 + i * .02), PERTO, m.traco * .8)
    cn.forma([(cx - 110, y(0.80)), (cx + 110, y(0.80)), (cx + 58, y(0.98)),
              (cx - 58, y(0.98))], m.base, PLACA, m.traco)
    for lado, cam in ((-1, LONGE), (1, PERTO)):
        cn.forma([(cx + lado * 100, y(0.72)), (cx + lado * 330, y(0.86)),
                  (cx + lado * 346, y(0.76)), (cx + lado * 110, y(0.60))],
                 escurece(m.base, .06), cam, m.traco)
        cn.forma(elipse(cx + lado * 336, y(0.81), 26, 20), m.vidro, cam,
                 m.traco * .7, sombra=0)
    _olho(cn, m, cx, y(0.92), 22)
    _espinhos(cn, m, [(cx - 80 + i * 40, y(0.98)) for i in range(5)], 70,
              FUNDO)


def enxame(cn, m, n=9, **kw):
    """Muitos bichos pequenos. A carta é um deles e o resto é fundo."""
    cx = MEIO
    grandes = [(cx, y(0.30), 1.0), (cx - 210, y(0.20), .62),
               (cx + 220, y(0.22), .66), (cx - 120, y(0.52), .48),
               (cx + 150, y(0.56), .44), (cx + 30, y(0.66), .34)]
    for i, (bx, by, k) in enumerate(grandes[:max(3, min(n, 6))]):
        cam = PERTO if k > .8 else (CENTRO if k > .5 else FUNDO)
        cor = m.base if k > .8 else escurece(m.base, .10 + (1 - k) * .18)
        cn.forma([(bx - 120 * k, by), (bx - 70 * k, by + 76 * k),
                  (bx + 80 * k, by + 70 * k), (bx + 130 * k, by - 10 * k),
                  (bx + 60 * k, by - 62 * k), (bx - 80 * k, by - 56 * k)],
                 cor, cam, m.traco * (0.7 + 0.4 * k))
        for j in (-1, 1):
            cn.forma(cunha(bx + j * 60 * k, by - 50 * k, 90 * k, 30 * k,
                           -74 + j * 26), clareia(m.trim, .05), cam,
                     m.traco * .6)
        cn.forma(elipse(bx + 86 * k, by + 14 * k, 15 * k, 15 * k),
                 m.vidro, cam, m.traco * .5, sombra=0)


def colossal(cn, m, **kw):
    """Grande a ponto de a escala virar assunto. Tem um mecha no pé."""
    cx = MEIO
    yq = y(0.52)
    for lado, cam in ((-1, LONGE), (1, PERTO)):
        cn.forma([(cx + lado * 70, yq), (cx + lado * 230, yq),
                  (cx + lado * 250, BASE + 40), (cx + lado * 60, BASE + 40)],
                 m.base if lado > 0 else escurece(m.base, .12), cam, m.traco)
        cn.forma([(cx + lado * 40, BASE + 44), (cx + lado * 280, BASE + 44),
                  (cx + lado * 300, BASE), (cx + lado * 30, BASE)],
                 escurece(m.base, .06), cam, m.traco)
    cn.forma([(cx - 240, yq - 10), (cx - 280, y(0.86)), (cx - 120, y(0.96)),
              (cx + 130, y(0.96)), (cx + 286, y(0.84)), (cx + 244, yq - 10)],
             m.base, CENTRO, m.traco)
    _espinhos(cn, m, [(cx - 160 + i * 66, y(0.95)) for i in range(6)], 120,
              FUNDO)
    for lado, cam in ((-1, LONGE), (1, PLACA)):
        cn.forma([(cx + lado * 250, y(0.86)), (cx + lado * 420, y(0.70)),
                  (cx + lado * 400, y(0.52)), (cx + lado * 238, y(0.66))],
                 escurece(m.base, .04), cam, m.traco)
    cy = y(1.02)
    cn.forma([(cx - 130, cy - 70), (cx - 100, cy + 40), (cx + 100, cy + 40),
              (cx + 130, cy - 70), (cx + 50, cy - 118), (cx - 50, cy - 118)],
             m.base, PLACA, m.traco)
    for i in range(9):
        cn.forma(cunha(cx - 100 + i * 25, cy - 74, 38, 15, -84), m.trim,
                 PLACA, m.traco * .5)
    _olho(cn, m, cx - 56, cy - 6, 19)
    _olho(cn, m, cx + 56, cy - 6, 19)
    _colossinho(cn, cx - 330, BASE)


def _colossinho(cn, x, yb):
    """Um colosso miúdo no canto, só para dar a escala."""
    k = 0.10
    c = "#3C4450"
    cn.forma(caixa(x - 26 * k * 8, yb, 52 * k * 8, 150 * k * 8), c, PLACA,
             1.0)
    cn.forma(caixa(x - 40 * k * 8, yb + 150 * k * 8, 80 * k * 8, 90 * k * 8),
             c, PLACA, 1.0)
    cn.forma(caixa(x - 18 * k * 8, yb + 244 * k * 8, 36 * k * 8, 40 * k * 8),
             c, PLACA, 1.0)


PLANOS = {
 "rastejante": rastejante, "ereta": ereta, "nadadora": nadadora,
 "voadora": voadora, "massa": massa, "torre": torre,
 "enxame": enxame, "colossal": colossal,
}


def monta_funda(plano, **kw):
    m = _m(plano)
    cn = Cena(traco_base=m.traco)
    sombra_chao(cn, MEIO, 420 if plano in ("massa", "colossal") else 320)
    PLANOS.get(plano, ereta)(cn, m, **kw)
    return cn
