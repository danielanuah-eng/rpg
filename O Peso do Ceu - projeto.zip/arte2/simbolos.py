# -*- coding: utf-8 -*-
"""
Os símbolos das cartas.

Nome distingue, mas nome se lê. Símbolo se reconhece do outro lado da
mesa, de cabeça para baixo, com a carta meio coberta. Cada carta ganha
uma marca composta:

    BRASÃO      a fábrica de onde a coisa saiu (oito, um por casa)
    GLIFO       o que a coisa é: Peça Fixa, Ativa ou Tensa; papel do
                adversário; tipo de item; tipo de dano
    PIPS        o Escalão, em quadradinhos

Tudo desenhado no mesmo motor das figuras, então o mesmo símbolo sai
igual no livro, na carta, na ficha, no Obsidian e no celular.
"""
import math
from .cena import (Cena, caixa, trapezio, elipse, cunha, gira, move,
                   escurece, clareia, CENTRO, PERTO, PLACA)

Q = 100.0        # os símbolos são desenhados num quadro de 100x100


def _cena(traco=6.0):
    return Cena(traco_base=traco)


# ============================================================== BRASÕES
# Oito marcas que não se confundem nem em dois centímetros.
def brasao(fab, cor="#14110E", fundo=None):
    cn = _cena(6.0)
    c, m = Q / 2, Q * 0.42
    if fundo:
        cn.forma(elipse(c, c, m * 1.18, m * 1.18, n=26), fundo, CENTRO,
                 0.0, sombra=0, contorno=fundo)
    fn = {
        "BRASA": _br_brasa, "VESPERTINA": _br_vesp, "CATEDRAL": _br_cat,
        "ARCO": _br_arco, "GRALHA": _br_gral, "SELO": _br_selo,
        "CARVAO": _br_carv, "OSSATURA": _br_oss,
    }.get(fab)
    if fn:
        fn(cn, c, m, cor)
    return cn


def _br_brasa(cn, c, m, k):
    """Bigorna: a fundição."""
    cn.forma([(c - m * .78, c + m * .18), (c + m * .78, c + m * .18),
              (c + m * .52, c - m * .10), (c + m * .22, c - m * .14),
              (c + m * .30, c - m * .66), (c - m * .30, c - m * .66),
              (c - m * .22, c - m * .14), (c - m * .52, c - m * .10)],
             k, CENTRO, 0.0, sombra=0, contorno=k)
    cn.forma([(c - m * .86, c + m * .18), (c + m * .30, c + m * .18),
              (c + m * .86, c + m * .62), (c - m * .86, c + m * .62)],
             k, CENTRO, 0.0, sombra=0, contorno=k)


def _br_vesp(cn, c, m, k):
    """Andorinha: duas asas e um corte."""
    for lado in (-1, 1):
        cn.forma([(c, c + m * .10), (c + lado * m * .96, c + m * .70),
                  (c + lado * m * .60, c - m * .06),
                  (c + lado * m * .86, c - m * .60),
                  (c + lado * m * .16, c - m * .18)],
                 k, CENTRO, 0.0, sombra=0, contorno=k)


def _br_cat(cn, c, m, k):
    """Ogiva: a nave da catedral."""
    cn.forma([(c - m * .62, c - m * .82), (c - m * .62, c + m * .10),
              (c, c + m * .88), (c + m * .62, c + m * .10),
              (c + m * .62, c - m * .82)], k, CENTRO, 0.0, sombra=0,
             contorno=k)
    cn.forma(caixa(c - m * .16, c - m * .40, m * .32, m * .92), "#FFFFFF",
             PERTO, 0.0, sombra=0, contorno="#FFFFFF")
    cn.forma(caixa(c - m * .44, c + m * .06, m * .88, m * .20), "#FFFFFF",
             PLACA, 0.0, sombra=0, contorno="#FFFFFF")


def _br_arco(cn, c, m, k):
    """Âncora de quilha."""
    cn.forma(caixa(c - m * .12, c - m * .82, m * .24, m * 1.40), k, CENTRO,
             0.0, sombra=0, contorno=k)
    cn.forma(caixa(c - m * .56, c + m * .28, m * 1.12, m * .22), k, CENTRO,
             0.0, sombra=0, contorno=k)
    cn.forma(elipse(c, c - m * .50, m * .84, m * .62, n=22, de=200, ate=340)
             + [(c + m * .84, c - m * .30), (c - m * .84, c - m * .30)],
             k, CENTRO, 0.0, sombra=0, contorno=k)
    cn.forma(elipse(c, c - m * .46, m * .54, m * .40, n=20, de=200, ate=340)
             + [(c + m * .54, c - m * .30), (c - m * .54, c - m * .30)],
             "#FFFFFF", PERTO, 0.0, sombra=0, contorno="#FFFFFF")


def _br_gral(cn, c, m, k):
    """Chave de boca torta: o improviso."""
    cn.forma(gira([(c - m * .16, c - m * .86), (c + m * .16, c - m * .86),
                   (c + m * .16, c + m * .42), (c - m * .16, c + m * .42)],
                  18, (c, c)), k, CENTRO, 0.0, sombra=0, contorno=k)
    cn.forma(gira(elipse(c, c + m * .58, m * .46, m * .46, n=20), 18,
                  (c, c)), k, CENTRO, 0.0, sombra=0, contorno=k)
    cn.forma(gira([(c - m * .20, c + m * .52), (c + m * .20, c + m * .52),
                   (c + m * .20, c + m * .96), (c - m * .20, c + m * .96)],
                  18, (c, c)), "#FFFFFF", PERTO, 0.0, sombra=0,
             contorno="#FFFFFF")


def _br_selo(cn, c, m, k):
    """Escudo com um olho: a lei que vê."""
    cn.forma([(c - m * .78, c + m * .74), (c + m * .78, c + m * .74),
              (c + m * .66, c - m * .30), (c, c - m * .92),
              (c - m * .66, c - m * .30)], k, CENTRO, 0.0, sombra=0,
             contorno=k)
    cn.forma(elipse(c, c + m * .16, m * .44, m * .30, n=22), "#FFFFFF",
             PERTO, 0.0, sombra=0, contorno="#FFFFFF")
    cn.forma(elipse(c, c + m * .16, m * .17, m * .17, n=16), k, PLACA,
             0.0, sombra=0, contorno=k)


def _br_carv(cn, c, m, k):
    """Lua cortada: o que não se registra."""
    cn.forma(elipse(c, c, m * .88, m * .88, n=30), k, CENTRO, 0.0, sombra=0,
             contorno=k)
    cn.forma(elipse(c + m * .34, c + m * .18, m * .70, m * .70, n=28),
             "#FFFFFF", PERTO, 0.0, sombra=0, contorno="#FFFFFF")
    cn.forma([(c - m * .96, c - m * .30), (c + m * .96, c + m * .54),
              (c + m * .96, c + m * .28), (c - m * .96, c - m * .56)],
             k, PLACA, 0.0, sombra=0, contorno=k)


def _br_oss(cn, c, m, k):
    """Vértebra: o que veio de dentro de alguma coisa."""
    cn.forma(elipse(c, c, m * .50, m * .42, n=22), k, CENTRO, 0.0, sombra=0,
             contorno=k)
    cn.forma(elipse(c, c, m * .20, m * .16, n=16), "#FFFFFF", PERTO, 0.0,
             sombra=0, contorno="#FFFFFF")
    for i in range(6):
        a = 60 * i
        cn.forma(cunha(c + m * .44 * math.cos(math.radians(a)),
                       c + m * .38 * math.sin(math.radians(a)),
                       m * .52, m * .26, a), k, CENTRO, 0.0, sombra=0,
                 contorno=k)


# =============================================================== GLIFOS
def glifo(nome, cor="#14110E"):
    """Marca pequena do que a carta é."""
    cn = _cena(5.0)
    c, m = Q / 2, Q * 0.40
    fn = GLIFOS.get(nome)
    if fn:
        fn(cn, c, m, cor)
    return cn


def _g_fixa(cn, c, m, k):           # quadrado cheio: sempre ligada
    cn.forma(caixa(c - m * .62, c - m * .62, m * 1.24, m * 1.24), k,
             CENTRO, 0.0, sombra=0, contorno=k)


def _g_ativa(cn, c, m, k):          # raio: custa Estresse
    cn.forma([(c + m * .22, c + m * .90), (c - m * .52, c + m * .04),
              (c - m * .04, c + m * .04), (c - m * .22, c - m * .90),
              (c + m * .52, c - m * .02), (c + m * .04, c - m * .02)],
             k, CENTRO, 0.0, sombra=0, contorno=k)


def _g_tensa(cn, c, m, k):          # losango vazado: liga com Medo
    cn.forma([(c, c + m * .92), (c + m * .82, c), (c, c - m * .92),
              (c - m * .82, c)], k, CENTRO, 0.0, sombra=0, contorno=k)
    cn.forma([(c, c + m * .44), (c + m * .40, c), (c, c - m * .44),
              (c - m * .40, c)], "#FFFFFF", PERTO, 0.0, sombra=0,
             contorno="#FFFFFF")


def _g_fisico(cn, c, m, k):         # punho fechado: massa
    cn.forma(caixa(c - m * .70, c - m * .44, m * 1.40, m * .92), k, CENTRO,
             0.0, sombra=0, contorno=k)
    for i in range(3):
        cn.forma(caixa(c - m * .44 + i * m * .40, c + m * .48, m * .22,
                       m * .32), k, CENTRO, 0.0, sombra=0, contorno=k)


def _g_energia(cn, c, m, k):        # feixe: luz
    cn.forma([(c - m * .92, c - m * .16), (c + m * .52, c - m * .16),
              (c + m * .92, c), (c + m * .52, c + m * .16),
              (c - m * .92, c + m * .16)], k, CENTRO, 0.0, sombra=0,
             contorno=k)
    for i in (-1, 1):
        cn.forma(caixa(c - m * .70, c + i * m * .52, m * .90, m * .14), k,
                 CENTRO, 0.0, sombra=0, contorno=k)


def _g_lacaio(cn, c, m, k):
    for i in (-1, 0, 1):
        cn.forma(elipse(c + i * m * .56, c, m * .24, m * .24, n=14), k,
                 CENTRO, 0.0, sombra=0, contorno=k)


def _g_regular(cn, c, m, k):
    cn.forma(elipse(c, c, m * .62, m * .62, n=22), k, CENTRO, 0.0, sombra=0,
             contorno=k)


def _g_bando(cn, c, m, k):
    for dx, dy in ((-.44, .34), (.44, .34), (0, -.42)):
        cn.forma(elipse(c + dx * m, c + dy * m, m * .34, m * .34, n=16), k,
                 CENTRO, 0.0, sombra=0, contorno=k)


def _g_bruto(cn, c, m, k):
    cn.forma([(c - m * .84, c - m * .58), (c + m * .84, c - m * .58),
              (c + m * .58, c + m * .74), (c - m * .58, c + m * .74)],
             k, CENTRO, 0.0, sombra=0, contorno=k)


def _g_comandante(cn, c, m, k):     # galão
    for i in (0, 1):
        cn.forma([(c - m * .78, c - m * .30 + i * m * .50),
                  (c, c + m * .30 + i * m * .50),
                  (c + m * .78, c - m * .30 + i * m * .50),
                  (c + m * .78, c - m * .62 + i * m * .50),
                  (c, c + m * .02 + i * m * .50),
                  (c - m * .78, c - m * .62 + i * m * .50)],
                 k, CENTRO, 0.0, sombra=0, contorno=k)


def _g_solo(cn, c, m, k):           # estrela cheia
    pts = []
    for i in range(10):
        a = math.radians(90 + i * 36)
        r = m * (.92 if i % 2 == 0 else .40)
        pts.append((c + r * math.cos(a), c + r * math.sin(a)))
    cn.forma(pts, k, CENTRO, 0.0, sombra=0, contorno=k)


def _g_atirador(cn, c, m, k):       # mira
    cn.forma(elipse(c, c, m * .78, m * .78, n=26), k, CENTRO, 0.0, sombra=0,
             contorno=k)
    cn.forma(elipse(c, c, m * .50, m * .50, n=22), "#FFFFFF", PERTO, 0.0,
             sombra=0, contorno="#FFFFFF")
    cn.forma(caixa(c - m * .06, c - m * .98, m * .12, m * 1.96), k, PLACA,
             0.0, sombra=0, contorno=k)
    cn.forma(caixa(c - m * .98, c - m * .06, m * 1.96, m * .12), k, PLACA,
             0.0, sombra=0, contorno=k)


def _g_batedor(cn, c, m, k):        # seta
    cn.forma([(c + m * .92, c), (c - m * .30, c + m * .70),
              (c - m * .06, c), (c - m * .30, c - m * .70)],
             k, CENTRO, 0.0, sombra=0, contorno=k)


def _g_apoio(cn, c, m, k):          # cruz
    cn.forma(caixa(c - m * .22, c - m * .82, m * .44, m * 1.64), k, CENTRO,
             0.0, sombra=0, contorno=k)
    cn.forma(caixa(c - m * .82, c - m * .22, m * 1.64, m * .44), k, CENTRO,
             0.0, sombra=0, contorno=k)


def _g_funda(cn, c, m, k):          # onda com dente
    cn.forma([(c - m * .92, c - m * .10), (c - m * .46, c + m * .44),
              (c, c - m * .10), (c + m * .46, c + m * .44),
              (c + m * .92, c - m * .10), (c + m * .92, c - m * .52),
              (c - m * .92, c - m * .52)], k, CENTRO, 0.0, sombra=0,
             contorno=k)
    for i in range(4):
        cn.forma(cunha(c - m * .66 + i * m * .44, c - m * .52, m * .38,
                       m * .22, -90), k, CENTRO, 0.0, sombra=0, contorno=k)


def _g_gente(cn, c, m, k):          # silhueta de pessoa
    cn.forma(elipse(c, c + m * .58, m * .26, m * .26, n=16), k, CENTRO,
             0.0, sombra=0, contorno=k)
    cn.forma([(c - m * .40, c - m * .86), (c + m * .40, c - m * .86),
              (c + m * .30, c + m * .26), (c - m * .30, c + m * .26)],
             k, CENTRO, 0.0, sombra=0, contorno=k)


def _g_arma(cn, c, m, k):
    cn.forma(gira(caixa(c - m * .10, c - m * .92, m * .20, m * 1.50), 0,
                  (c, c)), k, CENTRO, 0.0, sombra=0, contorno=k)
    cn.forma(caixa(c - m * .52, c + m * .34, m * 1.04, m * .18), k, CENTRO,
             0.0, sombra=0, contorno=k)


def _g_traje(cn, c, m, k):
    cn.forma([(c - m * .66, c + m * .70), (c + m * .66, c + m * .70),
              (c + m * .50, c - m * .86), (c - m * .50, c - m * .86)],
             k, CENTRO, 0.0, sombra=0, contorno=k)
    cn.forma(elipse(c, c + m * .70, m * .26, m * .20, n=16), "#FFFFFF",
             PERTO, 0.0, sombra=0, contorno="#FFFFFF")


def _g_mecanico(cn, c, m, k):       # engrenagem
    pts = []
    for i in range(24):
        a = 2 * math.pi * i / 24
        r = m * (.86 if (i // 2) % 2 == 0 else .60)
        pts.append((c + r * math.cos(a), c + r * math.sin(a)))
    cn.forma(pts, k, CENTRO, 0.0, sombra=0, contorno=k)
    cn.forma(elipse(c, c, m * .26, m * .26, n=16), "#FFFFFF", PERTO, 0.0,
             sombra=0, contorno="#FFFFFF")


def _g_estranho(cn, c, m, k):       # olho aberto
    cn.forma(elipse(c, c, m * .92, m * .54, n=26), k, CENTRO, 0.0, sombra=0,
             contorno=k)
    cn.forma(elipse(c, c, m * .62, m * .34, n=22), "#FFFFFF", PERTO, 0.0,
             sombra=0, contorno="#FFFFFF")
    cn.forma(elipse(c, c, m * .24, m * .24, n=16), k, PLACA, 0.0, sombra=0,
             contorno=k)


def _g_classe(cn, c, m, k):
    cn.forma([(c, c + m * .92), (c + m * .82, c + m * .20),
              (c + m * .50, c - m * .86), (c - m * .50, c - m * .86),
              (c - m * .82, c + m * .20)], k, CENTRO, 0.0, sombra=0,
             contorno=k)


def _g_subclasse(cn, c, m, k):
    cn.forma([(c, c + m * .92), (c + m * .82, c + m * .20),
              (c + m * .50, c - m * .86), (c - m * .50, c - m * .86),
              (c - m * .82, c + m * .20)], k, CENTRO, 0.0, sombra=0,
             contorno=k)
    cn.forma([(c, c + m * .46), (c + m * .42, c + m * .10),
              (c + m * .26, c - m * .44), (c - m * .26, c - m * .44),
              (c - m * .42, c + m * .10)], "#FFFFFF", PERTO, 0.0, sombra=0,
             contorno="#FFFFFF")


def _g_chassi(cn, c, m, k):
    cn.forma([(c - m * .70, c - m * .86), (c + m * .70, c - m * .86),
              (c + m * .70, c + m * .34), (c, c + m * .92),
              (c - m * .70, c + m * .34)], k, CENTRO, 0.0, sombra=0,
             contorno=k)
    cn.forma(caixa(c - m * .28, c - m * .40, m * .56, m * .70), "#FFFFFF",
             PERTO, 0.0, sombra=0, contorno="#FFFFFF")


GLIFOS = {
 "Fixa": _g_fixa, "Ativa": _g_ativa, "Tensa": _g_tensa,
 "Físico": _g_fisico, "Energia": _g_energia,
 "Lacaio": _g_lacaio, "Regular": _g_regular, "Bando": _g_bando,
 "Brutamontes": _g_bruto, "Comandante": _g_comandante, "Solo": _g_solo,
 "Atirador": _g_atirador, "Batedor": _g_batedor, "Apoio": _g_apoio,
 "Funda": _g_funda, "Gente": _g_gente,
 "Arma": _g_arma, "Traje": _g_traje, "Mecânico": _g_mecanico,
 "Estranho": _g_estranho,
 "Classe": _g_classe, "Subclasse": _g_subclasse, "Chassi": _g_chassi,
}


def pips(n, cor="#14110E", de=4):
    """Escalão em quadradinhos: cheios até n, vazios depois."""
    cn = _cena(4.0)
    w, g = Q * 0.17, Q * 0.05
    total = de * w + (de - 1) * g
    x0 = (Q - total) / 2
    for i in range(de):
        x = x0 + i * (w + g)
        if i < n:
            cn.forma(caixa(x, Q * .40, w, w), cor, CENTRO, 0.0, sombra=0,
                     contorno=cor)
        else:
            cn.forma(caixa(x, Q * .40, w, w), "#FFFFFF", CENTRO, 3.0,
                     sombra=0, contorno=cor)
    return cn


def catalogo():
    """Tudo que existe, para a folha de referência do livro."""
    return {
        "brasoes": ["BRASA", "VESPERTINA", "CATEDRAL", "ARCO", "GRALHA",
                    "SELO", "CARVAO", "OSSATURA"],
        "glifos": list(GLIFOS.keys()),
    }
