# -*- coding: utf-8 -*-
"""
A conferência final da segunda edição.

Roda sobre os dados e sobre os quatro PDFs prontos. Não conserta nada:
só diz o que está certo e o que não está, para que ninguém descubra um
número errado com o livro já impresso.

    python3 calc/conferir.py
"""
import os, re, sys, glob, warnings

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
warnings.filterwarnings("ignore")

from dados.fabricas import FABRICAS, ORDEM
from dados.classes import CLASSES, CHASSIS, ANCESTRALIDADES, COMUNIDADES
from dados.adversarios import LINHA, PAPEL, ficha, COLOSSOS, FUNDAS, GENTE
from dados.itens import ARMAS_PILOTO, TRAJES, MECANICOS, ESTRANHOS

RAIZ = os.path.join(os.path.dirname(__file__), "..")
TEX = os.path.join(RAIZ, "tex")

ok, falhas = [], []


def conf(cond, certo, errado):
    (ok if cond else falhas).append(certo if cond else errado)


# ------------------------------------------------------------- as fábricas
conf(len(FABRICAS) == 8 and len(ORDEM) == 8,
     "8 fábricas", "fábricas: %d" % len(FABRICAS))
pecas = sum(len(FABRICAS[k]["pecas"]) for k in ORDEM)
conf(pecas == 160, "160 Peças (20 por fábrica)", "Peças: %d" % pecas)
for k in ORDEM:
    n = len(FABRICAS[k]["pecas"])
    conf(n == 20, None, "%s tem %d Peças" % (k, n))
    tipos = {t for (_n, _no, t, _c, _x) in FABRICAS[k]["pecas"]}
    conf(tipos <= {"Fixa", "Ativa", "Tensa"}, None,
         "%s tem tipo estranho: %s" % (k, tipos))
    conf("Tensa" in tipos, None, "%s não tem nenhuma Peça Tensa" % k)
ok = [x for x in ok if x]
falhas = [x for x in falhas if x]

# ------------------------------------------------------------- pilotos
conf(len(CLASSES) == 8, "8 classes", "classes: %d" % len(CLASSES))
conf(len(CHASSIS) == 16, "16 chassis (2 por fábrica)",
     "chassis: %d" % len(CHASSIS))
conf(all(len(c["subclasses"]) == 2 for c in CLASSES),
     "2 subclasses por classe", "classe sem duas subclasses")
conf(len(ANCESTRALIDADES) == 10, "10 ancestralidades",
     "ancestralidades: %d" % len(ANCESTRALIDADES))
conf(len(COMUNIDADES) == 8, "8 comunidades",
     "comunidades: %d" % len(COMUNIDADES))

nomes_ch = [x[0] for x in CHASSIS]
for c in CLASSES:
    conf(c["chassi"] in nomes_ch, None,
         "classe %s aponta para chassi inexistente: %s" % (c["nome"], c["chassi"]))
    conf(c["fabrica"] in FABRICAS, None,
         "classe %s aponta para fábrica inexistente" % c["nome"])

# ------------------------------------------------------------- adversários
elenco = list(COLOSSOS) + list(FUNDAS) + list(GENTE)
total = len(elenco)
conf(total >= 100, "%d adversários (mínimo 100)" % total,
     "só %d adversários" % total)

ids = [e[0] for e in elenco]
conf(len(ids) == len(set(ids)), "todos os ids são únicos",
     "ids repetidos: %s" % [i for i in set(ids) if ids.count(i) > 1])

por_esc, por_papel, por_fab = {}, {}, {}
for e in elenco:
    por_esc[e[2]] = por_esc.get(e[2], 0) + 1
    por_papel[e[3]] = por_papel.get(e[3], 0) + 1
for c in COLOSSOS:
    por_fab[c[4]] = por_fab.get(c[4], 0) + 1

conf(set(por_esc) == {1, 2, 3, 4}, "os quatro Escalões povoados",
     "Escalões: %s" % sorted(por_esc))
conf(min(por_esc.values()) >= 15,
     "cada Escalão com 15+ adversários: %s" % dict(sorted(por_esc.items())),
     "Escalão magro: %s" % dict(sorted(por_esc.items())))
conf(set(por_papel) <= set(PAPEL), "todos os papéis são válidos",
     "papel inexistente: %s" % (set(por_papel) - set(PAPEL)))
conf(len(por_papel) == 9, "os nove papéis usados",
     "papéis sem ninguém: %s" % (set(PAPEL) - set(por_papel)))
conf(set(por_fab) == set(ORDEM) and min(por_fab.values()) >= 8,
     "colossos por fábrica: %s" % dict(sorted(por_fab.items())),
     "colossos por fábrica: %s" % por_fab)
conf(len(FUNDAS) >= 20, "%d Fundas (kaijus)" % len(FUNDAS),
     "só %d Fundas" % len(FUNDAS))

# a conta de equilíbrio tem de bater com a linha do Escalão
for e in elenco:
    esc, papel = e[2], e[3]
    eva, ma, se, atq, dano, est = ficha(esc, papel)
    base = LINHA[esc]
    mult = PAPEL[papel][0]
    esperado = 1 if mult is None else max(1, int(round(base[6] * mult)))
    conf(est == esperado, None,
         "%s: Estrutura %d, esperado %d" % (e[1], est, esperado))
    conf(eva == base[0] + PAPEL[papel][1], None,
         "%s: Evasão fora da linha" % e[1])
ok = [x for x in ok if x]
falhas = [x for x in falhas if x]
ok.append("a ficha de todos os %d adversários bate com a linha do Escalão"
          % total)

# ------------------------------------------------------------- itens
itens = len(ARMAS_PILOTO) + len(TRAJES) + len(MECANICOS) + len(ESTRANHOS)
conf(itens >= 60, "%d itens (%d armas, %d trajes, %d mecânicos, %d estranhos)"
     % (itens, len(ARMAS_PILOTO), len(TRAJES), len(MECANICOS), len(ESTRANHOS)),
     "só %d itens" % itens)
conf(any("Antimáquina" in str(a) for a in ARMAS_PILOTO),
     "existe arma Antimáquina", "nenhuma arma Antimáquina")

# --------------------------------------------- o que entrou agora
from dados.elite import LINHA_PESADA, ASSINATURA, NOMEADOS   # noqa: E402
from dados.sistemas import PESADAS, TIPOS_DANO               # noqa: E402

conf(len(LINHA_PESADA) == 8 and len(ASSINATURA) == 8,
     "linha pesada e assinatura: um par por fábrica",
     "pesados desbalanceados: %d/%d" % (len(LINHA_PESADA), len(ASSINATURA)))
conf(len(NOMEADOS) >= 10, "%d mechas nomeados com piloto vilão" % len(NOMEADOS),
     "só %d nomeados" % len(NOMEADOS))
conf(all(e[2] >= 3 for e in LINHA_PESADA + ASSINATURA + NOMEADOS),
     "todo pesado é de Escalão 3 ou 4",
     "pesado de Escalão baixo")
conf(all(e[3] in ("Brutamontes", "Comandante", "Solo")
         for e in LINHA_PESADA + ASSINATURA + NOMEADOS),
     "todo pesado é Brutamontes, Comandante ou Solo", "papel leve num pesado")

pes = sum(len(v) for v in PESADAS.values())
conf(pes == 40 and len(PESADAS) == 8,
     "40 Peças pesadas, cinco por fábrica", "Peças pesadas: %d" % pes)
conf(len(TIPOS_DANO) == 2, "dois tipos de dano, Físico e Energia",
     "tipos de dano: %d" % len(TIPOS_DANO))

# asas e voo alto só de Escalão 3 para cima
voadores = [e for e in elenco if isinstance(e[7] if len(e) > 7 else None, dict)
            and (e[7] or {}).get("asas")]
conf(all(e[2] >= 3 for e in voadores),
     "%d voadores, todos de Escalão 3+" % len(voadores),
     "voador de Escalão baixo: %s" % [e[1] for e in voadores if e[2] < 3])

# toda Peça pesada tem o tipo certo e um texto de verdade
ruins = [p[1] for ps in PESADAS.values() for p in ps
         if p[2] not in ("Fixa", "Ativa", "Tensa") or len(p[4]) < 40]
conf(not ruins, "toda Peça pesada tem tipo e texto", "Peças ruins: %s" % ruins)

# ------------------------------------------- tudo isto saiu impresso?
# Uma tabela que não cabe na página não avisa: ela simplesmente some do
# PDF. Esta conferência pega isso.
try:
    import subprocess
    bruto = subprocess.run(["pdftotext", os.path.join(TEX, "livro.pdf"), "-"],
                           capture_output=True, text=True).stdout
    livro = re.sub(r"\s+", " ", bruto).upper()
    ausentes = []
    for grupo, rotulo in [(ARMAS_PILOTO, "arma"), (TRAJES, "traje"),
                          (MECANICOS, "item mecânico"), (ESTRANHOS, "item estranho")]:
        for it in grupo:
            if re.sub(r"\s+", " ", it[0]).upper() not in livro:
                ausentes.append("%s %s" % (rotulo, it[0]))
    for k in ORDEM:
        for pc in FABRICAS[k]["pecas"]:
            if re.sub(r"\s+", " ", pc[1]).upper() not in livro:
                ausentes.append("Peça %s (%s)" % (pc[1], k))
    for e in elenco:
        if re.sub(r"\s+", " ", e[1]).upper() not in livro:
            ausentes.append("adversário %s" % e[1])
    for ch in CHASSIS:
        if ch[0].upper() not in livro:
            ausentes.append("chassi %s" % ch[0])
    conf(not ausentes,
         "tudo que está nos dados aparece impresso no livro",
         "sumiu do PDF (tabela estourada?): %s" % ausentes[:8])
except Exception as erro:
    falhas.append("não deu para ler o texto do livro: %s" % erro)

# ------------------------------------------------------------- retratos
disponiveis = {os.path.basename(p)[:-4]
               for p in glob.glob(os.path.join(TEX, "retratos", "*.tex"))
               if os.path.basename(p) != "cores.tex"}
conf(len(disponiveis) == total,
     "%d retratos, um por adversário" % len(disponiveis),
     "%d retratos para %d adversários" % (len(disponiveis), total))

usados = set()
for arq in glob.glob(os.path.join(TEX, "*.tex")):
    txt = open(arq, encoding="utf-8", errors="ignore").read()
    usados |= set(re.findall(r"\\retrato\{(\w+)\}", txt))
faltando = usados - disponiveis
conf(not faltando, "todo \\retrato chamado existe em tex/retratos/",
     "retratos chamados e inexistentes: %s" % sorted(faltando))

# ------------------------------------------------------------- os PDFs
def pdf_paginas(nome):
    try:
        import pypdf
        return len(pypdf.PdfReader(os.path.join(TEX, nome)).pages)
    except Exception as erro:
        return "erro: %s" % erro


for nome, minimo in [("livro.pdf", 120), ("baralho.pdf", 80),
                     ("fichas.pdf", 17), ("escudo.pdf", 4)]:
    n = pdf_paginas(nome)
    conf(isinstance(n, int) and n >= minimo,
         "%s: %s páginas" % (nome, n),
         "%s: %s (esperado %d+)" % (nome, n, minimo))

# as fichas têm de ser preenchíveis de verdade
try:
    import pypdf
    campos = pypdf.PdfReader(os.path.join(TEX, "fichas.pdf")).get_fields() or {}
    texto = sum(1 for v in campos.values() if v.get("/FT") == "/Tx")
    caixa = sum(1 for v in campos.values() if v.get("/FT") == "/Btn")
    conf(texto > 300 and caixa > 600,
         "fichas: %d campos de texto e %d caixas de marcar, todos editáveis"
         % (texto, caixa),
         "fichas: só %d campos de texto e %d caixas" % (texto, caixa))
    conf(len(campos) == len(set(campos)), "nenhum nome de campo repetido",
         "nomes de campo repetidos nas fichas")
except Exception as erro:
    falhas.append("não deu para ler os campos das fichas: %s" % erro)

# as tabelas não podem estourar a margem
for log, limite in [("livro.log", 4), ("baralho.log", 4),
                    ("fichas.log", 20), ("escudo.log", 2)]:
    caminho = os.path.join(TEX, log)
    if not os.path.exists(caminho):
        falhas.append("falta %s" % log)
        continue
    n = len(re.findall(r"^Overfull",
                       open(caminho, encoding="utf-8", errors="ignore").read(),
                       re.M))
    conf(n <= limite, "%s: %d estouros de margem" % (log, n),
         "%s: %d estouros de margem (limite %d)" % (log, n, limite))

# ------------------------------------------------------------- o veredito
print("\n" + "=" * 68)
print("O PESO DO CÉU — SEGUNDA EDIÇÃO — CONFERÊNCIA")
print("=" * 68)
for x in ok:
    print("  ok   %s" % x)
if falhas:
    print()
    for x in falhas:
        print("  X    %s" % x)
print("-" * 68)
print("%d conferências passaram, %d falharam." % (len(ok), len(falhas)))
sys.exit(1 if falhas else 0)
