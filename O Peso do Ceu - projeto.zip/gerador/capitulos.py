# -*- coding: utf-8 -*-
"""
Converte os capítulos escritos à mão do livro em notas do Obsidian.

As notas geradas a partir dos dados (Peças, chassis, adversários) já
estavam no vault; o que faltava era o texto que eu escrevi direto em
LaTeX — o capítulo do jogo, o do piloto, o do colosso, o de crescer, o
da cena de dez metros e o dos símbolos. Sem eles o vault tinha os
números e não tinha as instruções.

Também escreve as duas notas de tipo de dano, que ficaram como link
quebrado quando Físico e Energia entraram no livro.
"""
import os, re, sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

RAIZ = os.path.join(os.path.dirname(__file__), "..")
TEX = os.path.join(RAIZ, "tex")
SAIDA = os.path.join(RAIZ, "obsidian", "O Peso do Céu", "Regras")
HUB = "🛰️ O Peso do Céu"

CAPITULOS = [
 ("c01-jogo.tex", "📖 O jogo", "como se joga, escalões e o que a mesa precisa"),
 ("c03-piloto.tex", "🎖️ O piloto — o capítulo", "traços, experiências e o corpo"),
 ("c04-colosso.tex", "🤖 O colosso — o capítulo", "encaixes, dano e quando ele cai"),
 ("c12-crescer.tex", "📈 Crescer", "o que se ganha e o que se escolhe"),
 ("c13-mesa.tex", "🎬 A cena de dez metros", "conduzir a mesa, moldes e sortidas"),
 ("a02-simbolos.tex", "🔣 Os símbolos das cartas", "como ler uma carta sem ler"),
]

# ------------------------------------------------------- LaTeX -> Markdown
INLINE = [
 (r"\\termo\{([^{}]*)\}", r"**\1**"),
 (r"\\textbf\{([^{}]*)\}", r"**\1**"),
 (r"\\emph\{([^{}]*)\}", r"*\1*"),
 (r"\\textit\{([^{}]*)\}", r"*\1*"),
 (r"\\dado\{([^{}]*)\}", r"`\1`"),
 (r"\\maq\{([^{}]*)\}", r"*\1*"),
 (r"\\simb\{(\w+)\}\{[0-9.]+\}", r"![[arte/\1.svg|22]]"),
 (r"\\retrato\{(\w+)\}\{[0-9.]+\}", r"![[arte/\1.svg|260]]"),
 (r"\\caixas\{(\d+)\}", r"(\1 caixas)"),
 (r"``([^`']*)''", r'"\1"'),
 (r"\\textbullet\\?", "·"),
 (r"\$\\geq\$", "≥"), (r"\$\\leq\$", "≤"), (r"\$\\times\$", "×"),
 (r"\\%", "%"), (r"\\&", "&"), (r"\\,", " "), (r"\\ ", " "),
 (r"\\quad", "  "), (r"~", " "),
]


def inline(t):
    ant = None
    while ant != t:
        ant = t
        for a, b in INLINE:
            t = re.sub(a, b, t)
    t = t.replace("\\\\", " ")
    return re.sub(r"[ \t]+", " ", t).strip()


def tabela(spec, corpo):
    """pctabela -> tabela de Markdown."""
    ncols = len(re.findall(r"[LCR]\{", spec)) or 2
    linhas = [l for l in re.split(r"\\\\", corpo) if l.strip()]
    saida, cabecalho_feito = [], False
    for l in linhas:
        tem_regra = "\\regra" in l
        l = l.replace("\\regra", "")
        celulas = [inline(c) for c in l.split("&")]
        celulas += [""] * (ncols - len(celulas))
        celulas = celulas[:ncols]
        if not any(celulas):
            continue
        ehcab = "\\cab{" in l
        celulas = [re.sub(r"\\cab\{([^{}]*)\}", r"\1", c) for c in celulas]
        saida.append("| " + " | ".join(celulas) + " |")
        if (ehcab or tem_regra) and not cabecalho_feito:
            saida.append("|" + "---|" * ncols)
            cabecalho_feito = True
    if saida and not cabecalho_feito:
        saida.insert(1, "|" + "---|" * ncols)
        if len(saida) == 1:
            saida.append("|" + "---|" * ncols)
    return "\n".join(saida) + "\n"


def converte(txt):
    # o travessão duplo do LaTeX vira travessão aqui, antes de qualquer
    # tabela existir — senão o "|---|" do Markdown vira "|–-|"
    t = txt.replace("--", "–")

    # ambientes de bloco
    t = re.sub(r"\\begin\{pctabela\}\{((?:[^{}]|\{[^{}]*\})*)\}(.*?)"
               r"\\end\{pctabela\}",
               lambda m: "\n" + tabela(m.group(1), m.group(2)) + "\n",
               t, flags=re.S)
    t = re.sub(r"\\begin\{nota\}(.*?)\\end\{nota\}",
               lambda m: "\n> [!TIP]\n" + "\n".join(
                   "> " + l.strip() for l in inline(m.group(1)).split("\n")
                   if l.strip()) + "\n", t, flags=re.S)
    t = re.sub(r"\\begin\{leia\}(.*?)\\end\{leia\}",
               lambda m: "\n> *" + inline(m.group(1)).replace("\n", " ")
               + "*\n", t, flags=re.S)
    t = re.sub(r"\\begin\{ficha\}(.*?)\\end\{ficha\}",
               lambda m: "\n> [!NOTE]\n" + "\n".join(
                   "> " + l.strip() for l in inline(m.group(1)).split("\n")
                   if l.strip()) + "\n", t, flags=re.S)
    t = re.sub(r"\\begin\{gradecartas\}|\\end\{gradecartas\}", "", t)
    t = re.sub(r"\\begin\{pecacx\}\{([^{}]*)\}\{([^{}]*)\}\{[^{}]*\}",
               r"\n**\1** — *\2*\n", t)
    t = t.replace("\\end{pecacx}", "\n")

    # listas
    t = re.sub(r"\\begin\{itemize\}|\\end\{itemize\}|"
               r"\\begin\{enumerate\}|\\end\{enumerate\}", "", t)
    t = re.sub(r"\\begin\{description\}|\\end\{description\}", "", t)
    t = re.sub(r"\\item\[([^\]]*)\]",
               lambda m: "- **%s.**" % m.group(1).rstrip("."), t)
    t = re.sub(r"\\item\s", "- ", t)

    # títulos
    t = re.sub(r"\\chapter\{([^{}]*)\}", r"# \1", t)
    t = re.sub(r"\\section\{([^{}]*)\}", r"\n## \1", t)
    t = re.sub(r"\\subsection\{([^{}]*)\}", r"\n### \1", t)
    t = re.sub(r"\\barra\{([^{}]*)\}", r"\n### \1", t)
    t = re.sub(r"\\barratopo\{([^{}]*)\}\{([^{}]*)\}", r"\n**\1** — *\2*\n", t)
    t = re.sub(r"\\barrafab\{([^{}]*)\}\{([^{}]*)\}\{[^{}]*\}",
               r"\n### \1 — \2\n", t)
    t = re.sub(r"\\capitular\{(.)\}\{([^{}]*)\}", r"**\1\2**", t)

    # o que sobra
    t = t.replace("\\filete", "\n---\n")
    t = re.sub(r"\\pcnumero\{\d+\}", "", t)
    t = re.sub(r"\\(clearpage|needspace\{[^}]*\}|noindent|par|nobreak|"
               r"vspace\*?\{[^}]*\}|hfill|centering|small|par)\b", "", t)
    for a, b in INLINE:
        t = re.sub(a, b, t)

    # limpeza final
    t = re.sub(r"\\[a-zA-Z@]+\*?(\[[^\]]*\])?(\{[^{}]*\})*", "", t)
    t = re.sub(r"[{}]", "", t)
    t = re.sub(r"[ \t]+", " ", t)
    t = re.sub(r"\n{3,}", "\n\n", t)
    return t.strip()


# ---------------------------------------------------- as duas de dano
DANO = {
 "Físico": ("👊", "Massa e velocidade.", """
Se a coisa que machuca **tem peso**, é Físico. Soco, lâmina, bala,
estilhaço, entulho, queda, um prédio inteiro.

> [!IMPORTANT] Tiro de arma de fogo é Físico
> Mesmo de **Muito Longe**. O que decide não é a distância — é se o que
> chega no casco tem massa. Bala tem.

## O que para Físico

| Defesa | Vale? |
|---|---|
| **Blindagem** (a do chassi) | Sim. É para isso que ela existe. |
| **Blindagem de Energia** | Não. Zero. |
| **Campo de força** | Sim, descontando dos pontos dele. |
| **Escudo absorvente** | Não. Ele só come [[Energia]]. |

## Onde aparece

A maioria das armas do jogo. Punho, espada, martelo, serra, garra,
fuzil, canhão comum, mina de estilhaço, e todo colosso que resolveu
empurrar outro com o ombro.

---

## Links Relacionados
- [[Energia]]
- [[Escala]]
- [[Levar Dano]]
- [[🛰️ O Peso do Céu]]
"""),
 "Energia": ("⚡", "Luz, calor, campo e corrente.", """
Se a coisa que machuca **não tem peso**, é Energia. Laser, plasma,
hádron, arco elétrico, lâmina em ressonância.

> [!IMPORTANT] Laser é Energia mesmo encostado
> Mesmo em **Corpo a corpo**. Vale a mesma regra do [[Físico]], ao
> contrário: o que decide é a natureza da coisa, não a distância.

## O que para Energia

| Defesa | Vale? |
|---|---|
| **Blindagem** (a do chassi) | Não. Chapa não para luz. |
| **Blindagem de Energia** | Sim. Só vem de Peça, nunca de chassi. |
| **Campo de força** | Sim, descontando dos pontos dele. |
| **Escudo absorvente** | Sim — e ainda te devolve recurso. |

## Quem tem Blindagem de Energia

Uma Peça por fábrica, e cada uma cobra o seu preço:

- **Brasa** — [[Chapa Contra Luz]]: Blindagem de Energia 2, mas você
  perde 1 Deslocamento.
- **Vespertina** — [[Véu de Luz]]: 1, e Energia de Longe tem
  desvantagem contra você.
- **Catedral** — [[Manto de Ferro]]: 2, e os aliados em Muito Perto
  ganham 1.
- **Gralha** — [[Gaiola de Faraday]]: 2, que cai 1 a cada dano Físico
  que você leva.
- **Carvão** — [[Manta Fria]]: 1, e você some de todo sensor.
- **Arco** e **Ossatura** não dão Blindagem: dão **escudo absorvente**,
  que é melhor. Ver [[Casco Sifão]] e [[Enxerto Vivo]].

---

## Links Relacionados
- [[Físico]]
- [[Escala]]
- [[Levar Dano]]
- [[🛰️ O Peso do Céu]]
"""),
}


def frente(tipo, categoria, tags, extra=None):
    s = "---\ntipo: %s\ncategoria: %s\ntags:\n" % (tipo, categoria)
    for t in tags:
        s += "  - %s\n" % t
    if extra:
        for k, v in extra.items():
            s += "%s: %s\n" % (k, v)
    s += "jogo: O Peso do Céu\n---\n\n"
    return s


def gerar():
    os.makedirs(SAIDA, exist_ok=True)
    feitas = []

    for arq, nome, linha in CAPITULOS:
        caminho = os.path.join(TEX, arq)
        if not os.path.exists(caminho):
            continue
        corpo = converte(open(caminho, encoding="utf-8").read())
        # o título vira o nome da nota, então sai do corpo
        corpo = re.sub(r"^#[^\n]*\n", "", corpo).strip()
        s = frente("Regra", "Capítulo", ["peso-do-ceu", "regra", "capitulo"])
        s += "# %s\n\n*%s*\n\n---\n\n%s\n" % (nome, linha, corpo)
        s += ("\n---\n\n## Links Relacionados\n- [[📐 As Regras]]\n"
              "- [[%s]]\n" % HUB)
        open(os.path.join(SAIDA, nome + ".md"), "w",
             encoding="utf-8").write(s)
        feitas.append(nome)

    for nome, (emoji, linha, corpo) in DANO.items():
        s = frente("Regra", "Tipo de dano",
                   ["peso-do-ceu", "regra", "dano"])
        s += "# %s %s\n\n*%s*\n\n---\n%s" % (emoji, nome, linha, corpo)
        open(os.path.join(SAIDA, nome + ".md"), "w",
             encoding="utf-8").write(s)
        feitas.append(nome)

    # um índice, para nenhum capítulo nascer órfão no grafo
    caps = [n for (_a, n, _l) in CAPITULOS
            if os.path.exists(os.path.join(SAIDA, n + ".md"))]
    s = frente("Hub", "Capítulo", ["peso-do-ceu", "regra", "capitulo", "moc"])
    s += ("# 📚 Os capítulos escritos\n\n"
          "O texto corrido do livro, capítulo a capítulo — o mesmo que "
          "sai impresso, aqui em nota para poder ser linkado e citado.\n\n"
          "## Em ordem\n\n")
    for n, (_a, _n, linha) in zip(caps, CAPITULOS):
        s += "- **[[%s]]** — %s\n" % (n, linha)
    s += ("\n## Os dois tipos de dano\n\n"
          + "".join("- **[[%s]]** — %s\n" % (n, DANO[n][1]) for n in DANO)
          + "\n---\n\n[[%s|⬅ Voltar ao início]]\n" % HUB)
    open(os.path.join(SAIDA, "📚 Os capítulos escritos.md"), "w",
         encoding="utf-8").write(s)
    feitas.append("📚 Os capítulos escritos")

    print("capítulos e tipos de dano: %d notas" % len(feitas))
    return feitas


if __name__ == "__main__":
    gerar()
