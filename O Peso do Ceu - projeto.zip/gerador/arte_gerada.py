# -*- coding: utf-8 -*-
"""
Emite todas as macros de desenho: um retrato para cada adversário,
mais os emblemas das oito fábricas.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from arte.fabricas import monta as monta_colosso
from arte.funda import monta as monta_funda
from arte.gente import pessoa, grupo, veiculo
from dados.adversarios import COLOSSOS, FUNDAS, GENTE

SAIDA = os.path.join(os.path.dirname(__file__), "..", "tex")

ART_GENTE = {
 "gtSoldado":         ("grupo",   dict(n=6, arma="fuzil")),
 "gtEquipeFenda":     ("grupo",   dict(n=4, arma="carga")),
 "gtAtiradorDeElite": ("pessoa",  dict(arma="rifle", capacete=False, esc=1.9)),
 "gtOficial":         ("pessoa",  dict(arma="radio", capacete=False, esc=1.9)),
 "gtMultidao":        ("grupo",   dict(n=8, arma="nenhuma")),
 "gtPilotoAPe":       ("pessoa",  dict(arma="nenhuma", capacete=True, esc=1.9)),
 "gtBlindado":        ("veiculo", dict(tipo="blindado")),
 "gtLancaFoguete":    ("veiculo", dict(tipo="caminhao")),
 "gtHelicoptero":     ("veiculo", dict(tipo="helicoptero")),
 "gtComboio":         ("veiculo", dict(tipo="caminhao", esc=1.15)),
 "gtTrem":            ("veiculo", dict(tipo="trem")),
 "gtDirigivel":       ("veiculo", dict(tipo="dirigivel")),
 "gtEngenheiro":      ("pessoa",  dict(arma="ferramenta", esc=1.9)),
 "gtInterventor":     ("pessoa",  dict(arma="nenhuma", capacete=False, esc=1.9)),
}


def gerar():
    """Um arquivo por retrato. O TeX carrega só o que a página usa —
    definir os 104 como macro de uma vez estoura a memória dele."""
    pasta = os.path.join(SAIDA, "retratos")
    if not os.path.isdir(pasta):
        os.makedirs(pasta)
    total = 0

    def grava(ident, corpo):
        open(os.path.join(pasta, ident + ".tex"), "w",
             encoding="utf-8").write(corpo)

    for c in COLOSSOS:
        ident, _nome, _esc, _pap, fab, dir_a, esq_a, extras = c[:8]
        grava(ident, monta_colosso(fab, dir_arma=dir_a, esq_arma=esq_a,
                                   **extras))
        total += 1
    for f in FUNDAS:
        ident, _nome, _esc, _pap, plano, params = f[:6]
        grava(ident, monta_funda(plano, **params))
        total += 1
    for g in GENTE:
        ident = g[0]
        tipo, kw = ART_GENTE[ident]
        fn = {"pessoa": pessoa, "grupo": grupo, "veiculo": veiculo}[tipo]
        grava(ident, fn(**kw))
        total += 1

    tam = sum(os.path.getsize(os.path.join(pasta, f))
              for f in os.listdir(pasta))
    print("tex/retratos/: %d arquivos, %.1f MB" % (total, tam / 1e6))


if __name__ == "__main__":
    gerar()
