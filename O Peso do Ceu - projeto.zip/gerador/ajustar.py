# -*- coding: utf-8 -*-
"""
Ajusta a largura das colunas de toda tabela `pctabela` de um arquivo .tex.

O LaTeX não avisa direito quando uma tabela passa da margem: ele só
resmunga "Overfull \\hbox" e imprime por cima do papel. Este passo lê as
larguras declaradas, soma o espaço entre colunas e encolhe tudo
proporcionalmente até caber.

  python3 gerador/ajustar.py tex/escudo.tex 13.6

O segundo argumento é a largura útil em centímetros. Sem ele, usa a
largura da coluna do livro.
"""
import re, sys

# 2 x \tabcolsep por coluna, em cm (\tabcolsep = 6pt)
ENTRE = 2 * 6 * 2.54 / 72.27

CEL = re.compile(r"([LCR])\{([0-9.]+)cm\}")


def ajustar_spec(spec, util):
    celulas = CEL.findall(spec)
    if not celulas:
        return spec, None
    larguras = [float(w) for _, w in celulas]
    total = sum(larguras) + len(larguras) * ENTRE
    if total <= util + 1e-6:
        return spec, None
    sobra = util - len(larguras) * ENTRE
    if sobra <= 0:
        return spec, None
    fator = sobra / sum(larguras)
    novas = [round(w * fator, 2) for w in larguras]
    # a diferença do arredondamento vai para a coluna mais larga
    dif = round(sobra - sum(novas), 2)
    if dif:
        i = novas.index(max(novas))
        novas[i] = round(novas[i] + dif, 2)
    saida, k = [], 0
    for pedaco in re.split(r"([LCR]\{[0-9.]+cm\})", spec):
        if CEL.fullmatch(pedaco):
            saida.append("%s{%0.2fcm}" % (pedaco[0], novas[k]))
            k += 1
        else:
            saida.append(pedaco)
    return "".join(saida), (round(total, 2), round(util, 2))


def ajustar(caminho, util):
    txt = open(caminho, encoding="utf-8").read()
    mudou = []

    def troca(m):
        novo, info = ajustar_spec(m.group(1), util)
        if info:
            mudou.append(info)
        return "\\begin{pctabela}{%s}" % novo

    # o argumento tem chaves dentro — L{4.4cm} — então não serve [^}]*
    txt = re.sub(r"\\begin\{pctabela\}\{((?:[^{}]|\{[^{}]*\})*)\}", troca, txt)
    open(caminho, "w", encoding="utf-8").write(txt)
    return mudou


if __name__ == "__main__":
    alvo = sys.argv[1]
    util = float(sys.argv[2]) if len(sys.argv) > 2 else 15.40
    m = ajustar(alvo, util)
    print("%s: %d tabela(s) encolhida(s) para %0.2f cm" % (alvo, len(m), util))
    for antes, depois in m:
        print("   %0.2f cm -> %0.2f cm" % (antes, depois))
