# -*- coding: utf-8 -*-
"""
Exporta o jogo inteiro para JSON, para as ferramentas de celular.

As duas páginas HTML são arquivos únicos e funcionam sem internet: o
jogo vai embutido dentro delas. Este script é quem prepara o recheio —
dados limpos de LaTeX e só a arte que cada ferramenta precisa.
"""
import sys, os, re, json, unicodedata

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from dados.fabricas import FABRICAS, ORDEM
from dados.classes import CLASSES, CHASSIS, ANCESTRALIDADES, COMUNIDADES
from dados.itens import ARMAS_PILOTO, TRAJES, MECANICOS, ESTRANHOS
from dados.adversarios import LINHA, PAPEL, ficha, COLOSSOS, FUNDAS, GENTE
from dados.elite import LINHA_PESADA, ASSINATURA, NOMEADOS
from dados.chefes import DOM, DOM_DA_CASA, VIRADA, ESCOLTA
from dados.encontros import PADROES
from dados import npcs as NPC
from arte2.monta import monta, molde, POSES
from arte2.cena import Cena
from arte2.corpo import ANC, MEIO, y, H
from arte2 import corpo as C
from arte2.bicho import monta_funda
from arte2.saida import para_json
from arte2.simbolos import brasao, glifo, pips, GLIFOS

RAIZ = os.path.join(os.path.dirname(__file__), "..")
SAIDA = os.path.join(RAIZ, "web")

# LaTeX -> texto/HTML simples
SUBS = [
 (r"\\textbf\{([^{}]*)\}", r"<b>\1</b>"),
 (r"\\termo\{([^{}]*)\}", r"<b>\1</b>"),
 (r"\\emph\{([^{}]*)\}", r"<i>\1</i>"),
 (r"\\textit\{([^{}]*)\}", r"<i>\1</i>"),
 (r"\\dado\{([^{}]*)\}", r"<code>\1</code>"),
 (r"\\maq\{([^{}]*)\}", r"<i>\1</i>"),
 (r"\\textbullet\\?", "·"),
 (r"\$\\times\$", "×"), (r"\$\\geq\$", "≥"), (r"\$\\leq\$", "≤"),
 (r"\\%", "%"), (r"\\&", "&amp;"), (r"\\ ", " "), (r"~", " "),
 (r"\\\\", " "),
]


def t(x):
    if x is None:
        return ""
    x = str(x)
    ant = None
    while ant != x:
        ant = x
        for a, b in SUBS:
            x = re.sub(a, b, x)
    return re.sub(r"[ \t]+", " ", x.replace("--", "–")).strip()


def chave(nome):
    d = unicodedata.normalize("NFD", str(nome))
    d = "".join(c for c in d if unicodedata.category(c) != "Mn")
    return "".join(c for c in d if c.isalnum()).capitalize()


def jogo():
    d = {}
    d["fabricas"] = [{
        "id": k, "nome": t(FABRICAS[k]["nome"]), "linha": t(FABRICAS[k]["linha"]),
        "lema": t(FABRICAS[k]["lema"]), "cor": FABRICAS[k]["cor"],
        "proposta": t(FABRICAS[k]["proposta"]),
        "cultura": t(FABRICAS[k]["cultura"]),
        "estetica": t(FABRICAS[k]["estetica"]),
    } for k in ORDEM]

    def visual(nome, texto):
        """Que peça de desenho esta Peça acende na ficha."""
        s = (str(nome) + " " + str(texto)).lower()
        for chave_, alvo in (
                ("asa", ("mochila", "asas")),
                ("voo", ("mochila", "asas")),
                ("jato", ("mochila", "jato")),
                ("propuls", ("mochila", "jato")),
                ("turbina", ("mochila", "turbina")),
                ("satélit", ("mochila", "radar")),
                ("órbita", ("mochila", "radar")),
                ("antena", ("mochila", "antena")),
                ("mina", ("mochila", "espinhos")),
                ("espinho", ("mochila", "espinhos")),
                ("campo de força", ("mochila", "discos")),
                ("manto", ("mochila", "capa")),
                ("capa", ("mochila", "capa")),
                ("véu", ("mochila", "capa")),
                ("chaminé", ("mochila", "escapamento")),
                ("fornalha", ("mochila", "escapamento")),
                ("lastro", ("mochila", "casco")),
                ("canhão", ("arma", "canhao")),
                ("hádron", ("arma", "hadron")),
                ("drone", ("arma", "drone")),
                ("míssil", ("arma", "pod")),
                ("foguete", ("arma", "pod")),
                ("serra", ("arma", "serra")),
                ("martelo", ("arma", "martelo")),
                ("malho", ("arma", "martelo")),
                ("lâmina", ("arma", "lamina_dupla")),
                ("espada", ("arma", "espada")),
                ("garra", ("arma", "garra")),
                ("arpéu", ("arma", "arpeu")),
                ("rede", ("arma", "rede")),
                ("escudo", ("arma", "escudo")),
                ("fuzil", ("arma", "fuzil")),
                ("rifle", ("arma", "fuzil_longo"))):
            if chave_ in s:
                return {"slot": alvo[0], "peca": alvo[1]}
        return None

    d["pecas"] = [{
        "fabrica": k, "nivel": n, "nome": t(nome), "tipo": tipo,
        "custo": custo, "texto": t(texto), "visual": visual(nome, texto),
        # a Peça exige Escalão: nível 1-1, 2-4, 5-7, 8-10
        "escalao": 1 if n <= 1 else (2 if n <= 2 else (3 if n <= 4 else 4)),
        "nivel_min": {1: 1, 2: 2, 3: 4, 4: 6, 5: 8}.get(n, n),
    } for k in ORDEM for (n, nome, tipo, custo, texto) in FABRICAS[k]["pecas"]]

    d["chassis"] = [{
        "nome": nome, "fabrica": fab, "porte": porte, "estrutura": est,
        "evasao": eva, "lmaior": lma, "lsevero": lse, "blindagem": bli,
        "encaixes": enc, "desloc": des,
        "nucleo": {"nome": t(nuc[0]), "texto": t(nuc[1])},
    } for (nome, fab, porte, est, eva, lma, lse, bli, enc, des, nuc)
        in CHASSIS]

    d["classes"] = [{
        "nome": c["nome"], "fabrica": c["fabrica"], "chassi": c["chassi"],
        "evasao": c["evasao"], "pv": c["pv"], "chamada": t(c["chamada"]),
        "itens": t(c["itens"]),
        "traco": {"nome": t(c["traco"][0]), "texto": t(c["traco"][1])},
        "esperanca": {"nome": t(c["esperanca"][0]),
                      "texto": t(c["esperanca"][1])},
        "subclasses": [{"nome": t(s["nome"]), "linha": t(s["linha"]),
                        "f": t(s["f"]), "e": t(s["e"]), "m": t(s["m"])}
                       for s in c["subclasses"]],
    } for c in CLASSES]

    d["ancestralidades"] = [{
        "nome": a[0], "linha": t(a[1]), "texto": t(a[2]),
        "feats": [{"nome": t(a[3][0]), "texto": t(a[3][1])},
                  {"nome": t(a[4][0]), "texto": t(a[4][1])}],
    } for a in ANCESTRALIDADES]
    d["comunidades"] = [{
        "nome": c[0], "linha": t(c[1]), "texto": t(c[2]),
        "feat": {"nome": t(c[3][0]), "texto": t(c[3][1])},
    } for c in COMUNIDADES]

    def tipo_dano(nome, texto):
        alvo = (str(nome) + " " + str(texto)).lower()
        return "Energia" if any(w in alvo for w in (
            "laser", "plasma", "hádron", "hadron", "feixe", "elétric",
            "eletric", "choque", "arco elétrico", "ressonân")) else "Físico"

    d["itens"] = (
        [{"tipo": "Arma", "nome": t(n), "traco": tr, "alcance": al,
          "dado": dd, "prof": m, "bonus": b, "tag": t(etq), "texto": t(tx),
          "dano": tipo_dano(n, tx),
          "raridade": "Comum"} for (n, tr, al, dd, b, m, etq, tx)
         in ARMAS_PILOTO] +
        [{"tipo": "Traje", "nome": t(n), "blindagem": bl, "lmaior": lm,
          "lsevero": ls, "texto": t(tx), "raridade": "Comum"}
         for (n, bl, lm, ls, tx) in TRAJES] +
        [{"tipo": "Mecânico", "nome": t(n), "fabrica": o, "usos": t(u),
          "texto": t(tx), "raridade": "Incomum"}
         for (n, o, u, tx) in MECANICOS] +
        [{"tipo": "Estranho", "nome": t(n), "raridade": t(r), "texto": t(tx)}
         for (n, r, tx) in ESTRANHOS])

    # as três listas têm formatos diferentes; o deslocamento dos campos
    # de texto é o que muda
    DESL = {"colosso": 8, "funda": 6, "gente": 5}

    # quem é elite, e de que degrau
    CLASSE = {}
    for lista, nome in ((LINHA_PESADA, "pesado"), (ASSINATURA, "assinatura"),
                        (NOMEADOS, "nomeado")):
        for e in lista:
            CLASSE[e[0]] = nome

    def chefia(ident, fab):
        """Dom da casa, escolta e segunda fase — o kit de chefe."""
        cl = CLASSE.get(ident)
        if not cl:
            return {"elite": None}
        d = DOM_DA_CASA.get(fab)
        v = VIRADA.get(ident)
        return {
            "elite": cl,
            "dom": d,
            "dom_nome": DOM[d][0] if d else None,
            "dom_texto": t(DOM[d][3]) if d else None,
            "escolta": ESCOLTA[d][0] if d else None,
            "escolta_texto": t(ESCOLTA[d][1]) if d else None,
            "virada": ({"nome": v[0], "fala": t(v[1]), "texto": t(v[2])}
                       if v else None),
        }

    def adv(e, origem, fab=None, plano=None):
        eva, ma, se, atq, dano, est = ficha(e[2], e[3])
        extras = e[7] if origem == "colosso" else {}
        o = DESL[origem]
        return dict(chefia(e[0], fab), **{
            "id": e[0], "nome": e[1], "escalao": e[2], "papel": e[3],
            "origem": origem, "fabrica": fab, "plano": plano,
            "alcance": e[o], "ataque_nome": t(e[o + 1]),
            "desc": t(e[o + 2]), "motivos": t(e[o + 3]),
            "dano_tipo": (extras or {}).get("tipo", "Físico"),
            "evasao": eva, "lmaior": ma, "lsevero": se, "estrutura": est,
            "ataque": atq, "dano": dano,
            "custo": PAPEL[e[3]][2],
            "tracos": [{"nome": t(f[0]), "tipo": f[1], "texto": t(f[2])}
                       for f in e[o + 4]],
        })

    d["adversarios"] = (
        [adv(c, "colosso", fab=c[4]) for c in COLOSSOS] +
        [adv(f, "funda", plano=f[4]) for f in FUNDAS] +
        [adv(g, "gente") for g in GENTE])

    d["linha_escalao"] = {str(k): {
        "evasao": v[0], "lmaior": v[1], "lsevero": v[2], "ataque": v[3],
        "dados": v[4], "bonus": v[5], "estrutura": v[6]} for k, v in
        LINHA.items()}
    d["papeis"] = {k: {"mult": v[0], "evasao": v[1], "custo": v[2],
                       "texto": t(v[3])} for k, v in PAPEL.items()}

    d["progressao"] = [
     "+1 a dois traços", "+1 Estrutura", "+1 Estresse", "+1 Evasão",
     "+1 encaixe no chassi", "Peça nova", "Licença de fábrica nova",
     "Experiência nova", "Experiência para +3", "Limiares do piloto",
     "Um contato", "Uma marca", "Um bem"]
    # ------------------------------------------------ padrões de encontro
    d["padroes"] = [{"id": p[0], "nome": p[1], "emoji": p[2],
                     "texto": t(p[3]), "regra": p[4]} for p in PADROES]
    d["doms"] = {k: {"nome": v[0], "casa": v[1], "linha": t(v[2]),
                     "texto": t(v[3])} for k, v in DOM.items()}

    # --------------------------------------------------------- gente boa
    d["npcs"] = {
        "tipos": [{"id": x[0], "nome": t(x[1]), "plural": t(x[2]),
                   "oque": t(x[3]), "mesa": t(x[4])} for x in NPC.TIPOS],
        "querer": {k: [t(s) for s in v] for k, v in NPC.QUERER.items()},
        "oferecer": {k: [t(s) for s in v] for k, v in NPC.OFERECER.items()},
        "marca": [t(s) for s in NPC.MARCA],
        "nomes": NPC.NOMES, "sobrenomes": NPC.SOBRENOMES,
        "alcunhas": NPC.ALCUNHAS,
        "lojas": [{"id": l[0], "nome": t(l[1]), "vende": t(l[2]),
                   "tipos": l[3], "min": l[4][0], "max": l[4][1],
                   "regra": t(l[5])} for l in NPC.LOJAS],
        "donos": [t(s) for s in NPC.DONOS_DE_LOJA],
    }

    d["escaloes"] = [
     {"n": 1, "niveis": "1", "prof": 1, "briga": "Uma cidade, uma doca."},
     {"n": 2, "niveis": "2 a 4", "prof": 2, "briga": "Uma frente, um porto."},
     {"n": 3, "niveis": "5 a 7", "prof": 3, "briga": "Uma campanha."},
     {"n": 4, "niveis": "8 a 10", "prof": 4, "briga": "A guerra."}]
    return d


# Cada chassi tem pose e armas próprias: era isto que faltava para eles
# deixarem de ser "o mesmo boneco" na ficha. (pose, arma direita, arma
# esquerda) — dezesseis combinações, nenhuma repetida.
ARTE_DO_CHASSI = {
 "MULA":     ("parado",   "martelo",      "punho"),
 "BIGORNA":  ("muralha",  "martelo",      "escudo"),
 "ANDORINHA": ("avanco",  "espada",       "punho"),
 "FLORETE":  ("guarda",   "espada",       "lamina_dupla"),
 "ARCADA":   ("ordena",   "alabarda",     "punho"),
 "GUARDA":   ("muralha",  "espada",       "escudo"),
 "VAZANTE":  ("tiro",     "canhao",       "punho"),
 "QUILHA":   ("pesado",   "martelo",      "escudo"),
 "REMENDO":  ("espreita", "serra",        "punho"),
 "CARROÇA":  ("pesado",   "martelo",      "rede"),
 "RONDA":    ("tiro",     "fuzil",        "punho"),
 "TORRE":    ("muralha",  "fuzil_longo",  "pod"),
 "SOMBRA":   ("espreita", "lamina_dupla", "punho"),
 "GANCHO":   ("guarda",   "garra",        "arpeu"),
 "COSTELA":  ("avanco",   "garra",        "punho"),
 "CARCAÇA":  ("golpe",    "garra",        "garra"),
}

# Peças que mudam a aparência da máquina. A ficha troca o desenho
# quando o piloto instala uma destas — no aplicativo, não no livro.
MOCHILAS = ["jato", "asas", "canhoes", "discos", "radar", "espinhos",
            "capa", "turbina", "escapamento", "casco", "antena"]
ARMAS_EXTRA = ["espada", "lamina_dupla", "alabarda", "canhao", "hadron",
               "fuzil", "fuzil_longo", "garra", "escudo", "martelo",
               "serra", "rede", "arpeu", "drone", "pod"]


def _comuns(paleta, cenas):
    """Brasões, glifos e pips — as duas ferramentas usam."""
    for fab in ORDEM:
        it, paleta = para_json(brasao(fab), paleta)
        cenas["br" + chave(fab)] = it
    for g in GLIFOS:
        it, paleta = para_json(glifo(g), paleta)
        cenas["gl" + chave(g)] = it
    for k in (1, 2, 3, 4):
        it, paleta = para_json(pips(k), paleta)
        cenas["pip%d" % k] = it
    return paleta


def _fecha(paleta, cenas, **extra):
    cores = [None] * len(paleta)
    for c, i in paleta.items():
        cores[i] = c
    d = {"cores": cores, "cenas": cenas}
    d.update(extra)
    return d


def arte_gerador():
    """Os 132 adversários, para o cartão de cada um mostrar a cara.

    Vai só no Gerador: a Ficha não precisa deles, e separar os dois
    pacotes é o que impede cada HTML de dobrar de tamanho.
    """
    from gerador.arte2_gerada import cena_de
    paleta, cenas = {}, {}
    for e in list(COLOSSOS) + list(FUNDAS) + list(GENTE):
        try:
            cn = cena_de(e[0])
        except Exception:
            cn = None
        if cn is None:
            continue
        it, paleta = para_json(cn, paleta, tol=3.5)
        if it:
            cenas["ad" + e[0]] = it
    paleta = _comuns(paleta, cenas)
    return _fecha(paleta, cenas)


def arte():
    """Só o que a Ficha precisa desenhar."""
    paleta, cenas, kit = {}, {}, {}
    for (nome, fab, porte) in [(c[0], c[1], c[2]) for c in CHASSIS]:
        pose, ad, ae = ARTE_DO_CHASSI.get(
            nome, ("parado", "punho", "punho"))
        k = chave(nome)
        m = molde(fab)
        # o corpo pelado: punho fechado e nenhuma mochila. A ficha
        # monta o resto por cima, conforme o que o piloto instalar.
        it, paleta = para_json(
            monta(fab, "punho", "punho", pose, mochila="nenhuma"), paleta)
        cenas["ch" + k] = it
        kit[k] = {"pose": pose, "arma": ad, "esq": ae,
                  "mochila": m.mochila}
        # onde fica a mão direita deste chassi nesta pose
        p = POSES[pose]
        wt = 106.0 * m.larg * m.torso_larg
        yo = (y(ANC["ombro"]) + (m.torso_alt - 1.0) * H * 0.02
              - p.get("agacha", 0))
        dxo = p["torcao"] * 0.55 + p["inclina"] * 0.9
        tmp = Cena(traco_base=m.traco)
        punho = C.braco(tmp, m, MEIO + dxo, yo, 1, p["bd"][0], p["bd"][1],
                        "punho", 3, wt, 1.0)
        # só a mochila, no lugar certo
        for mo in MOCHILAS:
            cn = Cena(traco_base=m.traco)
            C.mochila(cn, m, MEIO + dxo * .6, y(0.775), mo, 0, 1.0)
            it, paleta = para_json(cn, paleta)
            if it:
                cenas["mo%s.%s" % (k, mo)] = it
        # só a arma, na mão
        for ar in ARMAS_EXTRA:
            cn = Cena(traco_base=m.traco)
            C._arma(cn, m, punho[0], punho[1], 1,
                    p["bd"][0] + p["bd"][1], ar, 3, m.base, 1.0)
            it, paleta = para_json(cn, paleta)
            if it:
                cenas["ar%s.%s" % (k, ar)] = it
    # um bicho por plano de Funda
    for pl in ("rastejante", "ereta", "nadadora", "voadora", "massa",
               "torre", "enxame", "colossal"):
        it, paleta = para_json(monta_funda(pl), paleta)
        cenas["fd" + chave(pl)] = it
    paleta = _comuns(paleta, cenas)
    return _fecha(paleta, cenas, kit=kit)


def gerar():
    os.makedirs(SAIDA, exist_ok=True)
    j, a, g = jogo(), arte(), arte_gerador()
    for nome, obj in (("jogo.json", j), ("arte.json", a),
                      ("arte-gerador.json", g)):
        caminho = os.path.join(SAIDA, nome)
        open(caminho, "w", encoding="utf-8").write(
            json.dumps(obj, ensure_ascii=False, separators=(",", ":")))
        print("  %-12s %6.1f KB" % (nome, os.path.getsize(caminho) / 1024))
    print("  %d Peças · %d chassis · %d adversários · %d itens · %d cenas"
          % (len(j["pecas"]), len(j["chassis"]), len(j["adversarios"]),
             len(j["itens"]), len(a["cenas"])))
    return j, a, g


if __name__ == "__main__":
    gerar()
