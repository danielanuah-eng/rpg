# -*- coding: utf-8 -*-
"""
A nota das ferramentas de mesa.

As duas ferramentas existem em três formas: no ar (Netlify, instalável
como aplicativo), em arquivo único na pasta Rpg (offline, sem site) e
no código deste projeto. Esta nota é o lugar onde o Anuah acha os três
sem precisar lembrar de nada.
"""
import os

RAIZ = os.path.join(os.path.dirname(__file__), "..")
SAIDA = os.path.join(RAIZ, "obsidian", "O Peso do Céu")

SITE = "https://o-peso-do-ceu.netlify.app"

NOTA = """---
tipo: Hub
categoria: Ferramentas
tags:
  - peso-do-ceu
  - ferramenta
  - pwa
jogo: O Peso do Céu
site: %(site)s
---

# 🧰 As ferramentas

Duas ferramentas de celular, feitas para a mesa e não para o escritório.
As duas funcionam **sem internet** depois da primeira abertura.

---

## No ar, para instalar no celular

| Ferramenta | Endereço | Para quê |
|---|---|---|
| **Ficha do Colosso** | [%(site)s/ficha/](%(site)s/ficha/) | Escolher chassi, instalar Peças, subir de nível, guardar as fichas da mesa |
| **Gerador de Desafios** | [%(site)s/gerador/](%(site)s/gerador/) | Adversários e itens já balanceados pelo tamanho do grupo e pelo Escalão |
| *(as duas juntas)* | [%(site)s](%(site)s) | A página que leva às duas |

> [!TIP] Como instalar
> No Android: abra e toque em **Instalar no celular** — ou no menu do
> navegador, *Adicionar à tela inicial*.
> No iPhone: botão de compartilhar do Safari → **Adicionar à Tela de
> Início**.
> Depois disso ela abre em tela cheia, com ícone próprio, e não precisa
> mais de sinal.

## Offline, em arquivo único

Na pasta `Rpg/` do computador, para quando não houver nem rede nem
vontade de instalar nada:

- `O Peso do Céu - Ficha do Colosso.html`
- `O Peso do Céu - Gerador de Desafios.html`

São o mesmo programa, com o jogo inteiro embutido. Dá para mandar por
WhatsApp e abrir no navegador de qualquer um.

---

## O que cada uma sabe

### Ficha do Colosso

- Os **16 chassis** das oito fábricas, com desenho que muda conforme a
  escolha — ver [[🤖 O Colosso]].
- As **120 Peças** com cadeado: o que ainda não dá para instalar aparece
  fechado, com o requisito escrito — ver [[🔩 As Peças]].
- Nível, Escalão, proficiência, Blindagem e limiares calculados sozinhos.
- Aba do piloto: classe, subclasse, traços, Experiências, Esperança.
- Aba de consulta com as regras que mais aparecem na mesa.
- Salva as fichas da mesa; **Exportar tudo** gera um arquivo que outra
  pessoa importa — ver [[Onde ficam os dados salvos]].

### Gerador de Desafios

- Monta briga por **tamanho do grupo × Escalão**, com o autobalanceador
  da conta de [[Montar uma Briga]].
- Os nove **papéis** de adversário, dos Capangas ao Solo.
- Fichas de inimigo salvas, editadas e apagadas ali mesmo, com
  **Exportar tudo** e **Importar** — o mesmo arquivo da Ficha.
- Gera itens pelos mesmos critérios do livro.

---

## Como isso foi feito e como se mexe

A receita inteira — o que faz um site virar aplicativo, como publicar,
como republicar depois de mudar alguma coisa — está em
**[[🏗️ Oficina]]**. O site em si, com endereços, tamanhos e o que tem
dentro: **[[🌐 O site O Peso do Céu]]**.

## Onde o desenho é feito

Toda a arte das duas é vetorial e sai do mesmo motor que imprime o
livro — sem imagem baixada, sem fonte de fora. Ver
[[🤖 Mechas — vocabulário visual]].

---

[[🛰️ O Peso do Céu|⬅ Voltar ao início]]
""" % {"site": SITE}


def gerar():
    os.makedirs(SAIDA, exist_ok=True)
    caminho = os.path.join(SAIDA, "🧰 As ferramentas.md")
    open(caminho, "w", encoding="utf-8").write(NOTA)
    print("Ferramentas: 1 nota")
    return 1


if __name__ == "__main__":
    gerar()
