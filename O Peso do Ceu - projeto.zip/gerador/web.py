# -*- coding: utf-8 -*-
"""
Costura as duas ferramentas de celular num arquivo só cada uma.

O jogo, a arte e o desenhador entram dentro do HTML. O resultado abre
offline, no celular, sem servidor e sem instalar nada — é para ser
baixado uma vez e usado na mesa.
"""
import sys, os, json

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from arte2.saida import JS_RENDER
from gerador import dados_json

RAIZ = os.path.join(os.path.dirname(__file__), "..")
WEB = os.path.join(RAIZ, "web")
SAIDA = os.path.join(RAIZ, "saida")


def montar():
    jogo, arte, arte_ger = dados_json.gerar()
    j = json.dumps(jogo, ensure_ascii=False, separators=(",", ":"))
    a = json.dumps(arte, ensure_ascii=False, separators=(",", ":"))
    ag = json.dumps(arte_ger, ensure_ascii=False, separators=(",", ":"))
    # um </script> dentro do JSON fecharia o bloco antes da hora
    j = j.replace("</", "<\\/")
    a = a.replace("</", "<\\/")
    ag = ag.replace("</", "<\\/")

    os.makedirs(SAIDA, exist_ok=True)
    feitos = []
    for origem, destino in (
        ("ficha.html", "O Peso do Céu - Ficha do Colosso.html"),
        ("gerador.html", "O Peso do Céu - Gerador de Desafios.html"),
    ):
        html = open(os.path.join(WEB, origem), encoding="utf-8").read()
        html = html.replace("/*JOGO*/", j)
        html = html.replace("/*ARTE*/", ag if origem == "gerador.html" else a)
        html = html.replace("/*RENDER*/", JS_RENDER)
        caminho = os.path.join(SAIDA, destino)
        open(caminho, "w", encoding="utf-8").write(html)
        feitos.append(caminho)
        print("  %-42s %6.0f KB" % (destino,
                                    os.path.getsize(caminho) / 1024))
    return feitos


if __name__ == "__main__":
    montar()
