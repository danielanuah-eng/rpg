# -*- coding: utf-8 -*-
"""
Monta o site estático que hospeda as duas ferramentas como PWA.

As duas já são HTML de arquivo único e já rodam offline quando
baixadas. O que este passo acrescenta é o que falta para o celular
tratá-las como *aplicativo*: manifesto, service worker, ícones PNG de
verdade e um botão de instalar. Cada ferramenta vira um app separado,
com ícone próprio na gaveta.

Sai em `site/`, pronto para subir no Netlify.
"""
import sys, os, json, shutil

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from arte2 import monta, bicho
from gerador import pil_arte

RAIZ = os.path.join(os.path.dirname(__file__), "..")
SAIDA = os.path.join(RAIZ, "saida")
SITE = os.path.join(RAIZ, "site")

VERSAO = "3.0.2"

APPS = {
    "ficha": {
        "arquivo": "O Peso do Céu - Ficha do Colosso.html",
        "nome": "O Peso do Céu — Ficha do Colosso",
        "curto": "Ficha do Colosso",
        "desc": "Monte seu mecha: chassi, Peças, níveis e cadeados. "
                "Funciona offline.",
        "tema": "#25323E",
        "fundo": "#EFE7D4",
        "icone_fundo": "#25323E",
    },
    "gerador": {
        "arquivo": "O Peso do Céu - Gerador de Desafios.html",
        "nome": "O Peso do Céu — Gerador de Desafios",
        "curto": "Gerador de Desafios",
        "desc": "Adversários e itens balanceados pelo tamanho e pelo "
                "nível da mesa. Funciona offline.",
        "tema": "#2B1B21",
        "fundo": "#EFE7D4",
        "icone_fundo": "#2B1B21",
    },
}

TAMANHOS = [192, 512]


# ============================================================== ÍCONES
def cena_ficha():
    return monta.monta("VESPERTINA", "espada", "escudo", pose="guarda")


def cena_gerador():
    return bicho.monta_funda("colossal")


CAIXA = {
    "ficha": (300, 600, 500, 800),
    "gerador": (20, 0, 780, 760),
}
CENA = {"ficha": cena_ficha, "gerador": cena_gerador}


def icones(chave, pasta):
    cena = CENA[chave]()
    caixa = CAIXA[chave]
    fundo = APPS[chave]["icone_fundo"]
    feitos = []
    for lado in TAMANHOS:
        # 'any': arte cheia sobre o fundo da casa
        img = pil_arte.render(cena, lado, caixa, fundo=fundo, margem=0.03)
        nome = "icone-%d.png" % lado
        img.save(os.path.join(pasta, nome))
        feitos.append((nome, lado, "any"))
        # 'maskable': o Android corta um círculo; sobra 80% no meio
        img = pil_arte.render(cena, lado, caixa, fundo=fundo, margem=0.30)
        nome = "icone-%d-mascara.png" % lado
        img.save(os.path.join(pasta, nome))
        feitos.append((nome, lado, "maskable"))
    # a maçã não entende maskable e não gosta de transparência
    pil_arte.render(cena, 180, caixa, fundo=fundo,
                    margem=0.12).save(os.path.join(pasta, "apple-touch-icon.png"))
    pil_arte.render(cena, 32, caixa, fundo=fundo,
                    margem=0.03).save(os.path.join(pasta, "favicon.png"))
    return feitos


# ============================================================ MANIFESTO
def manifesto(chave, feitos):
    a = APPS[chave]
    return json.dumps({
        "id": "/%s/" % chave,
        "name": a["nome"],
        "short_name": a["curto"],
        "description": a["desc"],
        "lang": "pt-BR",
        "dir": "ltr",
        "start_url": ".",
        "scope": ".",
        "display": "standalone",
        "display_override": ["standalone", "minimal-ui"],
        "orientation": "portrait",
        "theme_color": a["tema"],
        "background_color": a["fundo"],
        "categories": ["games", "utilities", "entertainment"],
        "icons": [
            {"src": n, "sizes": "%dx%d" % (s, s), "type": "image/png",
             "purpose": p} for n, s, p in feitos
        ],
    }, ensure_ascii=False, indent=2)


# ======================================================= SERVICE WORKER
SW = """// O Peso do Céu — %(curto)s
// Guarda tudo na primeira visita. Depois disso a rede é opcional.
const CACHE = 'peso-%(chave)s-v%(versao)s';
const ARQUIVOS = [
  './', './index.html', './manifest.webmanifest',
  './icone-192.png', './icone-512.png',
  './icone-192-mascara.png', './icone-512-mascara.png',
  './apple-touch-icon.png', './favicon.png'
];

self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE)
      .then(c => c.addAll(ARQUIVOS))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys()
      .then(ks => Promise.all(
        ks.filter(k => k.startsWith('peso-%(chave)s-') && k !== CACHE)
          .map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

// Cache primeiro: a mesa costuma ser num porão sem sinal.
// A rede roda por fora, sem segurar a tela, só para atualizar.
self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  e.respondWith(
    caches.match(e.request).then(achou => {
      const rede = fetch(e.request).then(r => {
        if (r && r.ok && r.type === 'basic') {
          const copia = r.clone();
          caches.open(CACHE).then(c => c.put(e.request, copia));
        }
        return r;
      }).catch(() => achou);
      return achou || rede;
    })
  );
});
"""

# ========================================================= CABEÇA E PÉ
CABECA = """<link rel="manifest" href="manifest.webmanifest">
<meta name="theme-color" content="%(tema)s">
<meta name="color-scheme" content="light">
<meta name="robots" content="noindex, nofollow">
<link rel="icon" href="favicon.png" sizes="32x32">
<link rel="apple-touch-icon" href="apple-touch-icon.png">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-title" content="%(curto)s">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="application-name" content="%(curto)s">
"""

PE = """<style>
#instalarPWA{
  position:fixed; left:50%%; transform:translateX(-50%%);
  bottom:calc(84px + env(safe-area-inset-bottom));
  z-index:9999; display:none; gap:.5em; align-items:center;
  border:0; border-radius:999px; cursor:pointer;
  padding:.62em 1.25em; font:600 .92rem/1 system-ui,sans-serif;
  color:#fff; background:%(tema)s;
  box-shadow:0 6px 22px rgba(0,0,0,.28);
}
#instalarPWA:active{ transform:translateX(-50%%) scale(.97) }
@media print{ #instalarPWA{ display:none !important } }
</style>
<button id="instalarPWA" type="button">⤓ Instalar no celular</button>
<script>
(function(){
  if ('serviceWorker' in navigator) {
    addEventListener('load', function(){
      navigator.serviceWorker.register('sw.js').catch(function(){});
    });
  }
  var guardado = null, botao = document.getElementById('instalarPWA');
  addEventListener('beforeinstallprompt', function(e){
    e.preventDefault(); guardado = e;
    botao.style.display = 'flex';
  });
  botao.onclick = function(){
    if (!guardado) return;
    botao.style.display = 'none';
    guardado.prompt(); guardado = null;
  };
  addEventListener('appinstalled', function(){
    guardado = null; botao.style.display = 'none';
  });
  // já instalado: não oferece de novo
  if (matchMedia('(display-mode: standalone)').matches) {
    botao.style.display = 'none';
  }
})();
</script>
</body>
</html>
"""


def monta_app(chave):
    a = APPS[chave]
    pasta = os.path.join(SITE, chave)
    os.makedirs(pasta, exist_ok=True)

    feitos = icones(chave, pasta)

    html = open(os.path.join(SAIDA, a["arquivo"]), encoding="utf-8").read()
    ctx = dict(a, chave=chave, versao=VERSAO)
    if "</head>" not in html:
        raise SystemExit("%s: sem </head>" % chave)
    html = html.replace("</head>", (CABECA % ctx) + "</head>", 1)
    corte = html.rfind("</body>")
    if corte < 0:
        raise SystemExit("%s: sem </body>" % chave)
    html = html[:corte] + (PE % ctx)

    open(os.path.join(pasta, "index.html"), "w", encoding="utf-8").write(html)
    open(os.path.join(pasta, "manifest.webmanifest"), "w",
         encoding="utf-8").write(manifesto(chave, feitos))
    open(os.path.join(pasta, "sw.js"), "w", encoding="utf-8").write(SW % ctx)
    return len(html)


# =============================================================== O HUB
HUB = """<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>O Peso do Céu — ferramentas de mesa</title>
<meta name="description" content="As duas ferramentas de celular de O Peso do Céu: a Ficha do Colosso e o Gerador de Desafios. Instalam no aparelho e funcionam sem internet.">
<meta name="theme-color" content="#25323E">
<meta name="robots" content="noindex, nofollow">
<link rel="icon" href="ficha/favicon.png" sizes="32x32">
<style>
:root{ --papel:#EFE7D4; --tinta:#14110E; --tinta2:#3A342C;
       --linha:#C9BDA0; --acento:#B0553B }
*{box-sizing:border-box}
html,body{margin:0}
body{
  background:var(--papel); color:var(--tinta); min-height:100vh;
  font:16px/1.55 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;
  padding:clamp(20px,6vw,56px) clamp(16px,5vw,32px);
  display:flex; flex-direction:column; align-items:center;
}
main{width:100%; max-width:760px}
header{text-align:center; margin-bottom:clamp(24px,6vw,44px)}
h1{font-size:clamp(1.5rem,6vw,2.3rem); margin:0 0 .25em;
   letter-spacing:.01em; line-height:1.15}
header p{margin:0; color:var(--tinta2); font-size:clamp(.94rem,3.4vw,1.05rem)}
.cartas{display:grid; gap:clamp(14px,3.5vw,20px);
        grid-template-columns:1fr}
@media(min-width:620px){ .cartas{grid-template-columns:1fr 1fr} }
a.carta{
  display:flex; flex-direction:column; align-items:center; text-align:center;
  gap:.7em; padding:clamp(20px,5vw,28px);
  background:#F6F1E4; border:1px solid var(--linha); border-radius:16px;
  color:inherit; text-decoration:none;
  box-shadow:0 2px 0 var(--linha);
  transition:transform .12s ease, box-shadow .12s ease;
}
a.carta:hover{transform:translateY(-2px); box-shadow:0 6px 18px rgba(0,0,0,.12)}
a.carta:active{transform:translateY(0)}
a.carta img{width:96px;height:96px;border-radius:22%;display:block}
a.carta b{font-size:1.1rem}
a.carta span{color:var(--tinta2); font-size:.92rem}
.dica{
  margin-top:clamp(26px,6vw,40px); padding:clamp(14px,4vw,18px) 18px;
  border-left:3px solid var(--acento); background:#E9E0CA;
  border-radius:0 10px 10px 0; font-size:.92rem; color:var(--tinta2);
  max-width:760px;
}
.dica b{color:var(--tinta)}
footer{margin-top:auto; padding-top:32px; font-size:.82rem; color:#7A7263;
       text-align:center}
</style>
</head>
<body>
<main>
  <header>
    <h1>O Peso do Céu</h1>
    <p>As duas ferramentas de mesa. Abrem no celular, instalam como
       aplicativo e depois disso funcionam sem internet.</p>
  </header>

  <div class="cartas">
    <a class="carta" href="ficha/">
      <img src="ficha/icone-192.png" alt="" width="96" height="96">
      <b>Ficha do Colosso</b>
      <span>Escolher o chassi, instalar Peças, subir de nível e
            guardar as fichas da mesa.</span>
    </a>
    <a class="carta" href="gerador/">
      <img src="gerador/icone-192.png" alt="" width="96" height="96">
      <b>Gerador de Desafios</b>
      <span>Adversários e itens já balanceados pelo tamanho do grupo
            e pelo Escalão.</span>
    </a>
  </div>

  <p class="dica">
    <b>Para instalar:</b> abra uma das duas e toque em
    <i>Instalar no celular</i>. No iPhone é o botão de compartilhar do
    Safari → <i>Adicionar à Tela de Início</i>. Depois de instalada, ela
    abre em tela cheia e não precisa mais de sinal — dá para usar no
    porão, no ônibus e na mesa do amigo.
  </p>

  <footer>Página particular do Anuah · versão %(versao)s</footer>
</main>
</body>
</html>
"""

TOML = """[build]
  publish = "."

[[headers]]
  for = "/*"
  [headers.values]
    X-Robots-Tag = "noindex, nofollow"

# o service worker nunca pode ficar preso em cache
[[headers]]
  for = "/*/sw.js"
  [headers.values]
    Cache-Control = "public, max-age=0, must-revalidate"

[[headers]]
  for = "/*/manifest.webmanifest"
  [headers.values]
    Content-Type = "application/manifest+json; charset=utf-8"
    Cache-Control = "public, max-age=0, must-revalidate"

[[headers]]
  for = "/*/index.html"
  [headers.values]
    Cache-Control = "public, max-age=0, must-revalidate"

[[headers]]
  for = "/*.png"
  [headers.values]
    Cache-Control = "public, max-age=604800"
"""


def gerar():
    if os.path.exists(SITE):
        shutil.rmtree(SITE)
    os.makedirs(SITE)
    for chave in APPS:
        n = monta_app(chave)
        print("  %-9s %6.0f KB" % (chave, n / 1024))
    open(os.path.join(SITE, "index.html"), "w",
         encoding="utf-8").write(HUB.replace("%(versao)s", VERSAO))
    open(os.path.join(SITE, "netlify.toml"), "w",
         encoding="utf-8").write(TOML)
    open(os.path.join(SITE, "robots.txt"), "w",
         encoding="utf-8").write("User-agent: *\nDisallow: /\n")
    total = sum(os.path.getsize(os.path.join(r, f))
                for r, _d, fs in os.walk(SITE) for f in fs)
    n = sum(len(fs) for _r, _d, fs in os.walk(SITE))
    print("Site: %d arquivos · %.1f MB" % (n, total / 1048576.0))


if __name__ == "__main__":
    gerar()
