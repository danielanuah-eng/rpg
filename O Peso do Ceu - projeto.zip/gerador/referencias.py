# -*- coding: utf-8 -*-
"""
A pasta de Referências do vault.

O Anuah pediu que tudo que ele consulta — Percy Jackson, mechas,
Daggerheart e Lancer — passe a morar no Obsidian, para a skill de RPG
poder ler antes de responder. Isto monta essa pasta: as notas de
referência e as 76 imagens de Code Geass que serviram de base visual.
"""
import os, re, shutil, glob

RAIZ = os.path.join(os.path.dirname(__file__), "..")
SAIDA = os.path.join(RAIZ, "obsidian", "Referências")
IMAGENS = "/mnt/user-data/uploads/Rpg/Code geass mechas"

NOTAS = {}


def nota(nome, tipo, categoria, tags, corpo, pai="📚 Referências"):
    s = "---\ntipo: %s\ncategoria: %s\ntags:\n" % (tipo, categoria)
    for t in tags:
        s += "  - %s\n" % t
    s += "---\n\n" + corpo.strip() + "\n"
    if pai:
        s += "\n---\n\n[[%s|⬅ Voltar às referências]]\n" % pai
    NOTAS[nome + ".md"] = s


# ============================================================== MECHAS
def mechas(arquivos):
    # as 76 jpegs ficam onde já moram, em Rpg\Code geass mechas: copiá-las
    # para dentro do vault só dobrava 2 MB de imagem sem ganhar nada
    galeria = ("As %d imagens estão na pasta `Área de Trabalho\\Rpg\\"
               "Code geass mechas` do computador. Ficaram fora do vault "
               "de propósito: são referência particular, pesam e não "
               "entram em nada que o jogo publica." % len(arquivos))
    nota("🤖 Mechas — vocabulário visual", "Referência", "Arte",
         ["referencia", "mecha", "arte", "code-geass"], """
# 🤖 Mechas — vocabulário visual

As %d imagens em `mechas/` são a base visual de [[🛰️ O Peso do Céu]].
Quase todas são **Knightmare Frames** de Code Geass, com algumas de
Lancer no meio. Não são para copiar: são para lembrar as proporções.

## O que se tira delas

| O quê | Como é | Por que importa |
|---|---|---|
| **Cabeça** | Muito pequena — um nono da altura | É o que faz o boneco virar máquina |
| **Cintura** | Estreita, quase um eixo | Separa o peitoral da bacia e dá torção |
| **Perna** | Longuíssima, mais da metade do corpo | A silhueta de Knightmare é perna |
| **Panturrilha** | Cheia, com massa de motor atrás | Onde mora o volume da perna |
| **Pé** | Pequeno, com rolete no tornozelo | O *landspinner*: o mecha desliza, não marcha |
| **Ombreira** | Laje grande e chapada | Segundo maior sinal de fábrica depois da cabeça |
| **Cabine** | Bloco marcado no peito, ejeta por trás | Lembra que tem gente ali dentro |
| **Cor** | Duas ou três chapadas, mais ouro ou branco | Silhueta forte a dois centímetros |

## Como isso virou regra no motor de arte

O desenho do jogo sai de `arte2/`, em Python, e obedece a isto:

- **Sombreamento chapado.** Cada polígono é cortado em duas metades: a
  que pega luz e a que não pega, 20%% mais escura. Nada de gradiente.
- **Seis camadas**, do fundo para a frente: mochila e asas, membros
  distantes (um tom abaixo), torso e bacia, membros da frente,
  ombreiras e peitoral, cabeça.
- **Traço por arquétipo**: 1,5 pt nos cascos finos, 2 pt nos comuns,
  2,5 pt nos industriais.
- **Cabeça exclusiva por fábrica.** Oito cabeças, uma por casa, e nunca
  se repetem entre linhas diferentes — é o que o Anuah pediu. Dentro da
  casa o que muda é ombreira, perna, mochila e pose.
- **Asas só de Escalão 3 para cima.** Voar alto é fim de campanha.

## Os oito cascos do jogo, lado a lado

![[arte/brMilicia.svg|180]] ![[arte/vpAndorinha.svg|180]]
![[arte/ctGuarda.svg|180]] ![[arte/arQuilha.svg|180]]

![[arte/grFerroVelho.svg|180]] ![[arte/slRonda.svg|180]]
![[arte/cvSombra.svg|180]] ![[arte/osCarcaca.svg|180]]

## Galeria de referência

%s

> [!NOTE] Nota de uso
> Estas imagens são material de referência particular do Anuah,
> guardado aqui para consulta. O que sai no livro é desenho original,
> feito do zero pelo motor vetorial do projeto.
""" % (len(arquivos), galeria))


# ============================================================== LANCER
def lancer():
    nota("⚙️ Lancer — o que aproveitar", "Referência", "Sistema",
         ["referencia", "lancer", "mecha", "sistema"], """
# ⚙️ Lancer — o que aproveitar

Fonte: `Rpg/lancer/893500139-Lancer-Livro-Basico.pdf` (tradução PT-BR).
O que O Peso do Céu pegou emprestado, e o que deixou para trás.

## O que entrou

| Do Lancer | Como ficou aqui |
|---|---|
| **Tipos de dano** (cinético, explosivo, energético) | Virou **dois**: [[Físico]] e [[Energia]]. Duas caixas a mesa lembra; três, não. |
| **Licença de fabricante** | Virou a **licença de fábrica**: é dela que vem tudo que a máquina sabe fazer. |
| **Sistemas por fabricante** | Virou as **Peças**, 20 por fábrica, em vez de domínios de magia. |
| **Estrutura separada de PV** | O colosso tem Estrutura; o piloto tem PV. Cair não é morrer. |
| **Implantáveis** (escudo posicionável, armadilha) | Virou drone, boia, mina e campo de força — as Peças pesadas. |
| **Bloqueio de alvo / Invadir** | Virou **marcar** com drone e satélite, sem subsistema eletrônico separado. |
| **Sobrecarga por calor** | Virou **Estresse do piloto**. Não existe calor, carga nem bateria. |

## O que ficou de fora, de propósito

- **Grade e quadrados.** Aqui é teatro da mente, cinco faixas de alcance.
- **Calor, Carga e reator.** Um recurso só: Estresse.
- **Construção de mecha por pontos.** Chassi + encaixes, e pronto.
- **Ações de piloto fora do mecha detalhadas.** Colosso e gente usam a
  mesma regra; muda uma tabela só.

## As nove funções de adversário

O Lancer separa inimigo por papel; aqui isso virou a conta inteira. A
ficha sai de **linha do Escalão × papel**, e é por isso que dá para
inventar um adversário em trinta segundos — ver [[Montar uma Briga]].
""")


# ========================================================== DAGGERHEART
def daggerheart():
    nota("🎲 Daggerheart — a base", "Referência", "Sistema",
         ["referencia", "daggerheart", "sistema"], """
# 🎲 Daggerheart — a base

Fonte: `Rpg/Daggerheart/Daggerheart-Livro-Basico.pdf` e as expansões,
inclusive `DEUS EX MECHA V1.pdf`. É o esqueleto de O Peso do Céu e de
[[🏠 Início|A Noite Mais Densa]].

## O que é igual

- **Dualidade**: 2d12 de cores diferentes mais o traço. Esperança maior,
  Medo maior, iguais é crítico.
- **Esperança e Medo** como moedas da mesa.
- **Experiências** em vez de perícias.
- **Limiares** (Maior e Severo) decidindo quanto se marca.
- **Classe + subclasse**, com Fundação, Especialização e Maestria.
- **Ancestralidade e comunidade** separadas.
- **Adversários com papel** e Ações de Medo.

## O que O Peso do Céu mudou

| Daggerheart | Aqui |
|---|---|
| Domínios com cartas de magia | **Peças de fábrica**: a habilidade vem da máquina, não do piloto |
| Medo como ameaça | **Medo como atenção do mundo** — ver [[O Medo]]. Acende Peças Tensas, dá foco, faz coisa aparecer |
| Armadura como recurso do personagem | **Blindagem do chassi**, e nada mais dá Blindagem de graça |
| Um tipo de dano | **[[Físico]] e [[Energia]]**, com defesas diferentes |
| Morte do personagem | O colosso cai; o piloto sai. Derrota é cara e reversível |

> [!TIP] A regra que mais muda a mesa
> **Falhar com Esperança é o segundo melhor resultado da tabela.** Diga
> isso em voz alta na primeira vez que acontecer, nas duas campanhas.
""")


# ========================================================= PERCY JACKSON
def percy():
    nota("⚡ Percy Jackson — A Noite Mais Densa", "Referência", "Campanha",
         ["referencia", "percy-jackson", "campanha"], """
# ⚡ Percy Jackson — A Noite Mais Densa

A outra campanha do Anuah, já no vault: **[[🏠 Início]]**. Percy Jackson
rodado em Daggerheart, nove capítulos, do Museu de Nova York à Ilha de
Ninguém.

## Onde está cada coisa

- **[[Capítulos]]** — as nove sessões em ordem.
- **[[Protagonistas]]** — a mesa dos seis.
- **[[NPCs do Acampamento]]** e **[[NPCs do Mundo]]**.
- **[[Bestiário e Ameaças]]** — dezoito feras calibradas em Daggerheart.
- **[[Itens e Relíquias]]**, **[[Lore e Profecias]]**,
  **[[Chalés do Acampamento]]**, **[[Regras e Sistema]]**.

## Material de apoio fora do vault

Na pasta `Rpg/Pj/` do computador: os cinco livros, os prompts visuais,
as artes dos deuses, dos chalés, dos líderes e das cenas, e o PDF do
Livro 1 (que é o mesmo linkado pelas notas).

## O que as duas campanhas têm em comum

As duas rodam em Daggerheart, as duas usam Esperança e Medo, e as duas
tratam o Medo como **ritmo**, não como castigo. Uma regra aprendida numa
serve na outra — é por isso que valem estar no mesmo vault.
""")


# ============================================================== O MOC
def moc(arquivos):
    nota("📚 Referências", "Hub", "MOC", ["referencia", "moc", "hub"], """
# 📚 Referências

Tudo que o Anuah consulta quando escreve RPG, num lugar só, para a skill
conseguir ler antes de responder.

---

## Por assunto

- 🤖 **[[🤖 Mechas — vocabulário visual]]** — as %d imagens de Code Geass
  e as regras de proporção que saíram delas.
- ⚙️ **[[⚙️ Lancer — o que aproveitar]]** — o que entrou de Lancer em
  O Peso do Céu, e o que ficou de fora.
- 🎲 **[[🎲 Daggerheart — a base]]** — o esqueleto das duas campanhas.
- ⚡ **[[⚡ Percy Jackson — A Noite Mais Densa]]** — a campanha que já
  está no vault.

## Os dois jogos

- 🛰️ **[[🛰️ O Peso do Céu]]** — mechas, Daggerheart × Lancer.
- 🏠 **[[🏠 Início]]** — A Noite Mais Densa, Percy Jackson × Daggerheart.

## A oficina

- 🏗️ **[[🏗️ Oficina]]** — como fazer um site, como fazer virar
  aplicativo de celular e como pôr no ar. Escrito a partir do que foi
  feito com as ferramentas de mesa.

---

> [!INFO] Para quem lê isto primeiro
> Comece pelo MOC do jogo que interessa. As notas de referência aqui
> explicam **de onde veio** cada regra; as notas do jogo explicam **o
> que a regra é**. Quando as duas discordarem, o jogo manda.
""" % len(arquivos), pai=None)


def gerar():
    arquivos = sorted(glob.glob(os.path.join(IMAGENS, "*.jpeg")))
    if os.path.exists(SAIDA):
        shutil.rmtree(SAIDA)
    os.makedirs(SAIDA, exist_ok=True)

    mechas(arquivos)
    lancer()
    daggerheart()
    percy()
    moc(arquivos)
    for nome, corpo in NOTAS.items():
        open(os.path.join(SAIDA, nome), "w", encoding="utf-8").write(corpo)
    print("Referências: %d notas · %d imagens" % (len(NOTAS), len(arquivos)))
    return len(NOTAS), len(arquivos)


if __name__ == "__main__":
    gerar()
