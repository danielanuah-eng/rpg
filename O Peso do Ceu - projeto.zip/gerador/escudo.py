# -*- coding: utf-8 -*-
"""
O escudo do Mestre: quatro painéis A4 deitados.

Imprima em paisagem, corte na margem e encaixe num escudo de quatro
abas — ou grampeie os quatro no papelão que você já tem. A ordem é a
ordem em que a mesa pergunta: primeiro a rolagem, depois o Medo, depois
a briga, depois o estrago.

Tudo o que está aqui sai dos mesmos arquivos que o livro usa, então o
escudo nunca discorda do livro.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from dados.adversarios import LINHA, PAPEL, ficha, COLOSSOS, FUNDAS, GENTE

SAIDA = os.path.join(os.path.dirname(__file__), "..", "tex")

# largura útil de uma coluna, em cm — A4 deitado, 2 colunas
COL = 13.2

PREAMBULO = r"""\documentclass[10pt]{book}
\input{preambulo}
\geometry{paperwidth=297mm, paperheight=210mm,
          left=9mm, right=9mm, top=9mm, bottom=51mm,
          headsep=0mm, footskip=0mm}
\pagestyle{empty}
\setlength{\parindent}{0pt}
\setlength{\columnsep}{7mm}
\setlength{\columnseprule}{0.4pt}
\renewcommand{\columnseprulecolor}{\color{cinza45}}

% cabeçalho de painel
\newcommand{\painel}[3]{%
  \noindent\colorbox{#3}{\makebox[\dimexpr\linewidth-2\fboxsep\relax][l]{%
    \rotulo\bfseries\fontsize{15}{17}\selectfont\color{papel}%
    \vrule width 0pt height 3.6ex depth 1.4ex\MakeUppercase{#1}\hfill
    {\normalfont\rotulo\fontsize{9}{11}\selectfont\color{papel}%
     \MakeUppercase{#2}}}}\par\vspace{2.6mm}}

% tabela com corpo regulável: os painéis 3 e 4 são mais cheios
\def\tamtab{8.8}\def\leadtab{11.4}
\renewenvironment{pctabela}[1]
  {\par\vspace{1.2mm}\begingroup
   \rotulo\fontsize{\tamtab}{\leadtab}\selectfont
   \noindent\begin{tabular}{#1}}
  {\end{tabular}\endgroup\par\vspace{2.0mm}}
\newcommand{\aperta}{\def\tamtab{7.7}\def\leadtab{9.8}}
\newcommand{\apertamais}{\def\tamtab{7.1}\def\leadtab{9.0}}
\newcommand{\solta}{\def\tamtab{8.8}\def\leadtab{11.4}}

% linha solta de destaque
\newcommand{\dica}[1]{\par\vspace{1mm}\noindent
  {\rotulo\fontsize{8.2}{10.4}\selectfont\color{tinta2}#1}\par\vspace{1.6mm}}

\begin{document}
"""


def rodape(pecas, cor):
    """
    Faixa de arte no pé do painel.

    Vai colada no rodapé por posição absoluta, não por \\vfill: o
    \\vfill empurrava a faixa para a página seguinte quando a arte não
    cabia no que tinha sobrado. A margem de baixo do painel já é grande
    o bastante para receber a faixa sem encostar no texto.
    """
    n = len(pecas)
    larg = 0.97 / n
    s = "\\AddToShipoutPictureFG*{\\AtPageLowerLeft{%\n"
    s += "  \\put(\\LenToUnit{9mm},\\LenToUnit{7mm}){%\n"
    s += "  \\parbox[b][41mm][t]{279mm}{%\n"
    s += "    \\noindent{\\color{%s}\\rule{\\linewidth}{1.2pt}}\\par\\vspace{2.4mm}\n" % cor
    s += "    \\noindent\n"
    for ident, escala, nome, linha in pecas:
        s += ("    \\begin{minipage}[t]{%0.3f\\linewidth}\\centering\n"
              "      \\parbox[b][26mm][b]{\\linewidth}{\\centering"
              "\\retrato{%s}{%0.2f}}\\par\\vspace{1.8mm}\n"
              "      {\\rotulo\\bfseries\\fontsize{7.8}{9.4}\\selectfont "
              "\\MakeUppercase{%s}}\\par\\vspace{0.4mm}\n"
              "      {\\rotulo\\fontsize{7}{8.6}\\selectfont\\color{cinza45} %s}\n"
              "    \\end{minipage}\\hfill\n" % (larg, ident, escala, nome, linha))
    s += "  }}}}\n"
    return s


def tab(spec, cab, linhas, antes=None):
    s = ""
    if antes:
        s += "\\barra{%s}\n" % antes
    s += "\\begin{pctabela}{%s}\n" % spec
    s += " & ".join("\\cab{%s}" % c for c in cab) + " \\\\ \\regra\n"
    for L in linhas:
        s += " & ".join(L) + " \\\\\n"
    s += "\\end{pctabela}\n"
    return s


# ---------------------------------------------------------- painel 1
def painel_rolagem():
    s = "\\painel{A rolagem}{O peso do céu \\textbullet\\ escudo 1 de 4}{tinta}\n"
    s += rodape([("gtPilotoAPe", 0.78, "Gente a pé",
                  "Dois d12 e uma boa razão."),
                 ("vpAndorinha", 0.78, "Colosso leve",
                  "A rolagem é a mesma para os dois."),
                 ("gtOficial", 0.78, "Quem manda",
                  "A Dificuldade é que muda.")], "tinta")
    s += "\\begin{multicols}{2}\n"

    s += tab("L{4.4cm} L{%0.1fcm}" % (COL - 4.8),
             ["O que saiu", "O que significa"],
             [[r"\textbf{Total $\geq$ Dificuldade}", "Conseguiu."],
              [r"\textbf{Total $<$ Dificuldade}", "Não conseguiu."],
              [r"\textbf{Esperança maior}",
               r"\emph{com Esperança}: o jogador ganha \textbf{1 Esperança}."],
              [r"\textbf{Medo maior}",
               r"\emph{com Medo}: \textbf{você} ganha 1 Medo e entra na cena."],
              [r"\textbf{Iguais}",
               r"\textbf{Crítico}: sucesso automático, 1 Esperança e limpa 1 Estresse."]],
             antes="A Dualidade — 2d12 + traço")

    s += ("\\dica{\\textbf{Falhar com Esperança é o segundo melhor resultado "
          "da tabela.} A coisa não saiu e ninguém pagou por isso. Diga em "
          "voz alta na primeira vez que acontecer.}\n")

    s += tab("C{1.5cm} L{%0.1fcm}" % (COL - 2.0),
             ["Custo", "No que o jogador gasta Esperança"],
             [[r"\textbf{1}", r"\textbf{Ajudar}: um aliado que está rolando ganha \dado{+1d6}."],
              [r"\textbf{1}", r"\textbf{Experiência}: soma \textbf{+2}, se couber."],
              [r"\textbf{1}", r"\textbf{Fôlego}: limpa 1 Estresse."],
              [r"\textbf{3}", r"\textbf{Traço de Esperança} da classe."]],
             antes="Esperança — começa em 2, guarda até 6")

    s += "\\columnbreak\n"

    s += tab("C{2.0cm} C{2.0cm} C{2.4cm} L{%0.1fcm}" % (COL - 7.2),
             ["Escalão", "Níveis", "Proficiência", "O tamanho da briga"],
             [[r"\textbf{1º}", "1", "1", "Uma cidade, uma doca, uma estrada."],
              [r"\textbf{2º}", "2 a 4", "2", "Uma frente, um porto, uma fábrica."],
              [r"\textbf{3º}", "5 a 7", "3", "Uma campanha inteira."],
              [r"\textbf{4º}", "8 a 10", "4", "A guerra, e o que existe embaixo dela."]],
             antes="Escalões")

    s += ("\\dica{\\textbf{Proficiência} é quantos dados de dano se rola. "
          "Uma arma \\dado{d8+3} rola \\emph{um} d8 no Escalão 1 e "
          "\\emph{quatro} no Escalão 4, somando o +3 uma vez só.}\n")

    s += tab("C{1.7cm} L{%0.1fcm}" % (COL - 2.2),
             ["Dific.", "Quando usar"],
             [[r"\textbf{10}", "Dá para errar, mas é quase certo. Peça só se a falha "
                               "for interessante."],
              [r"\textbf{13}", "O padrão. Use quando não souber."],
              [r"\textbf{15}", "Difícil: contra treino, pressa ou tempo ruim."],
              [r"\textbf{17}", "Muito difícil: ninguém faz isso sem pagar."],
              [r"\textbf{20}", "Uma vez por campanha."]],
             antes="Dificuldades — quando você precisar inventar uma")

    s += ("\\dica{\\textbf{Se você não sabe o traço, pergunte ao jogador como "
          "ele está fazendo.} A descrição escolhe o traço; você só confirma.}\n")

    s += ("\\barra{O elenco que veio no baralho}\n"
          "{\\rotulo\\fontsize{8.8}{11.4}\\selectfont\n"
          "\\textbf{%d} colossos de fábrica, \\textbf{%d} Fundas e "
          "\\textbf{%d} de gente e veículo: \\textbf{%d} adversários, todos "
          "com carta e retrato. Se faltar um, use a linha do Escalão acima e "
          "escreva dois traços.\\par}\n"
          % (len(COLOSSOS), len(FUNDAS), len(GENTE),
             len(COLOSSOS) + len(FUNDAS) + len(GENTE)))

    s += "\\end{multicols}\n"
    s += "\\clearpage\n"
    return s


# ---------------------------------------------------------- painel 2
def painel_medo():
    s = ("\\painel{O Medo}{A atenção do mundo \\textbullet\\ escudo 2 de 4}"
         "{seloC}\n")
    s += rodape([("slOrbita", 0.78, "Peça Tensa ligada",
                  "Com 4 de Medo na mesa, o satélite responde."),
                 ("fdOlhoFundo", 0.78, "O que apareceu",
                  "Um Medo gasto, e a água abriu."),
                 ("slRonda", 0.78, "O foco dado",
                  "+1d6, e uma pergunta respondida com a verdade.")],
                "seloC")
    s += "\\begin{multicols}{2}\n"

    s += ("\\dica{\\textbf{Medo não é castigo.} É o mundo se inclinando para "
          "ver o que vai acontecer. Quando você tem Medo guardado, a cena "
          "fica maior — e as máquinas dos jogadores \\emph{acordam}. "
          "Você começa a sessão com o que sobrou, até 12, e ganha 1 toda vez "
          "que alguém rola com Medo.}\n")

    s += tab("C{1.5cm} L{%0.1fcm}" % (COL - 2.0),
             ["Custo", "O quê"],
             [[r"\textbf{1}", r"\textbf{Fazer aparecer.} Alguma coisa entra na "
                              r"cena: reforço, testemunha, uma porta que não "
                              r"estava ali, uma chance. Pode ser bom para a mesa."],
              [r"\textbf{1}", r"\textbf{Dar foco.} Entregue 1 Medo a um jogador: "
                              r"ele soma \dado{+1d6} na próxima rolagem. Em troca, "
                              r"você faz uma pergunta sobre o personagem e ele "
                              r"responde com a verdade."],
              [r"\textbf{1}", r"Um adversário age fora da vez dele."],
              [r"\textbf{1}", r"Uma \termo{Contagem} anda um passo."],
              [r"\textbf{2}", r"Uma \termo{Ação de Medo} de um adversário."],
              [r"\textbf{2}", r"\textbf{Ligar um desafio}: começa uma Contagem "
                              r"nova, e a mesa sabe qual."],
              [r"\textbf{3}", r"\textbf{A maré vira}: o que estava longe fica perto."]],
             antes="No que se gasta Medo")

    s += "\\columnbreak\n"

    s += ("\\barra{As Peças Tensas — 4 de Medo}\n"
          "{\\rotulo\\fontsize{8.8}{11.4}\\selectfont\n"
          "Algumas Peças de fábrica são \\termo{Tensas}: não custam nada e "
          "funcionam apenas enquanto você tiver \\textbf{4 ou mais de Medo} — "
          "algumas pedem 6. Você acumula, as máquinas ligam; você gasta, elas "
          "apagam.\\par\\vspace{1.6mm}\n"
          "\\textbf{Você não pode gastar Medo só para desligar uma Peça Tensa.} "
          "Se o gasto tem um efeito na ficção, tudo bem que a Peça apague "
          "junto.\\par}\\vspace{2.5mm}\n")

    s += tab("L{3.2cm} L{%0.1fcm}" % (COL - 3.6),
             ["Quando entrar", "O gatilho"],
             [[r"\textbf{Falhou}", "Qualquer falha é convite."],
              [r"\textbf{Acertou com Medo}", "Acerta e você entra. Não desfaça o "
                                             "acerto; complique o depois."],
              [r"\textbf{Você pagou}", "Entrou porque quis. Faz uma coisa e devolve "
                                       "o holofote."],
              [r"\textbf{Silêncio}", "Ninguém sabe o que fazer: faça aparecer."]],
             antes="Quando o Mestre entra")

    s += tab("C{1.5cm} L{%0.1fcm}" % (COL - 2.0),
             ["Passos", "Contagens que sempre funcionam"],
             [[r"\textbf{4}", "Uma coisa curta: a porta que abre, o trem que chega."],
              [r"\textbf{6}", "Segurar um lugar. A metade traz reforço."],
              [r"\textbf{8}", "A cena inteira: a evacuação, a maré, o resgate."],
              [r"\textbf{12}", "Uma sessão. Diga o número em voz alta."]],
             antes="Contagens")

    s += ("\\dica{\\textbf{Contagem é relógio aberto.} A mesa tem de ver o "
          "número subindo. Uma contagem secreta não faz pressão nenhuma.}\n")

    s += "\\end{multicols}\n"
    s += "\\clearpage\n"
    return s


# ---------------------------------------------------------- painel 3
def painel_combate():
    s = ("\\painel{A briga}{Teatro da mente \\textbullet\\ escudo 3 de 4}"
         "{catC}\n\\aperta\n")
    s += rodape([("ctGuarda", 0.78, "Corpo a corpo",
                  "Encostado. Dá para tocar."),
                 ("arQuilha", 0.78, "Perto",
                  "Uma corrida. O outro lado do pátio."),
                 ("cvSombra", 0.78, "Oculto",
                  "Entulho, fumaça, multidão ou noite."),
                 ("vpFlorete", 0.78, "Longe",
                  "O outro lado do rio. Precisa de arma longa.")],
                "catC")
    s += "\\begin{multicols}{2}\n"

    s += tab("L{3.2cm} L{%0.1fcm}" % (COL - 3.6),
             ["Faixa", "O que é"],
             [[r"\textbf{Corpo a corpo}", "Encostado. Dá para tocar."],
              [r"\textbf{Muito Perto}", "Um passo. Dá para gritar sem rádio."],
              [r"\textbf{Perto}", "Uma corrida. O outro lado do pátio."],
              [r"\textbf{Longe}", "O outro lado do rio. Precisa de arma longa."],
              [r"\textbf{Muito Longe}", "Você vê, e é só."]],
             antes="As cinco faixas — não existe metro")

    s += ("\\dica{\\textbf{Mover não custa ação} se for junto com alguma coisa: "
          "descreva e atravesse uma faixa. Duas ou mais é que gastam a ação — "
          "ou uma só, com Deslocamento 2+.}\n")

    s += tab("L{3.4cm} L{%0.1fcm}" % (COL - 3.8),
             ["Ação", "O que é"],
             [[r"\textbf{Atacar}", r"Role contra a \termo{Evasão} do alvo."],
              [r"\textbf{Atravessar}", "Duas faixas ou mais."],
              [r"\textbf{Usar uma Peça}", "O que ela disser. As Ativas custam Estresse."],
              [r"\textbf{Abrir o Núcleo}", "Uma vez por sortida."],
              [r"\textbf{Ajudar}", r"Um aliado ganha \dado{+1d6}. Custa 1 Esperança."],
              [r"\textbf{Ler a cena}", r"Role \termo{Instinto}; conte uma coisa "
                                       r"verdadeira e útil que ele não sabia."],
              [r"\textbf{Qualquer outra}", "Descreva. Você diz o traço e a Dificuldade."]],
             antes="O que se faz com uma ação")

    s += tab("L{2.6cm} L{%0.1fcm}" % (COL - 3.0),
             ["Condição", "Efeito"],
             [[r"\textbf{Vulnerável}", "Ataques contra ele têm vantagem."],
              [r"\textbf{Restrito}", "Não muda de faixa. Sair gasta uma ação."],
              [r"\textbf{Oculto}", "Não pode ser alvo sem que alguém gaste uma ação "
                                   "achando. Sai ao agir."],
              [r"\textbf{Instável}", "O próximo ataque dele tem desvantagem."],
              [r"\textbf{Inerte}", "Não age. Ataques contra ele acertam sem rolar."]],
             antes="As cinco condições — e só cinco")

    s += tab("L{4.2cm} L{%0.1fcm}" % (COL - 4.6),
             ["Resultado", "O que acontece"],
             [[r"\textbf{Crítico}", "Acerta, o dano sobe um degrau, ganha 1 Esperança "
                                    "e limpa 1 Estresse."],
              [r"\textbf{Acerto com Esperança}", "Dano cheio. Ganha 1 Esperança."],
              [r"\textbf{Acerto com Medo}", "Dano cheio. Você ganha 1 Medo."],
              [r"\textbf{Erro com Esperança}", "Não acerta, mas alguma coisa melhora."],
              [r"\textbf{Erro com Medo}", "Não acerta, e você entra."]],
             antes="Atacar")

    s += tab("L{5.0cm} L{%0.1fcm}" % (COL - 5.4),
             ["Situação", "Regra"],
             [[r"\textbf{Gente atacando colosso}",
               r"Desvantagem, e o dano cai pela \textbf{metade}."],
              [r"\textbf{Arma \termo{Antimáquina}}",
               "Cancela as duas coisas acima: rolagem normal, dano cheio."],
              [r"\textbf{Colosso atacando gente}",
               r"Se acertar, o dano é sempre \textbf{Severo} — salvo se a pessoa "
               r"estiver coberta."],
              [r"\textbf{Gente escondida}",
               r"Uma pessoa a pé conta como \termo{Oculta} de um colosso sempre que "
               r"houver entulho, fumaça, multidão ou noite."]],
             antes="Escala — a única diferença entre colosso e gente")


    s += "\\end{multicols}\n"
    s += "\\clearpage\n"
    return s


# ---------------------------------------------------------- painel 4
def painel_estrago():
    s = ("\\painel{O estrago}{Dano, avaria e elenco \\textbullet\\ escudo 4 de 4}"
         "{brasaC}\n\\apertamais\n")
    s += rodape([("brQuebraLinha", 0.78, "Brutamontes",
                  "Escalão 3 \\textbullet\\ 16 de Estrutura."),
                 ("fdBocarra", 0.78, "Solo — uma Funda",
                  "Escalão 4 \\textbullet\\ 31 de Estrutura."),
                 ("grEnxame", 0.78, "Bando",
                  "Conta como vários. Meio dano na segunda metade."),
                 ("osCarcaca", 0.78, "O que sobrou",
                  "Role 1d6 por Peça: com 4+, ela sobreviveu.")],
                "brasaC")
    s += "\\begin{multicols}{2}\n"

    s += tab("L{4.8cm} C{2.6cm} L{%0.1fcm}" % (COL - 7.8),
             ["O dano foi", "Marca", "E mais"],
             [[r"Abaixo do \textbf{Limiar Maior}", "1 Estrutura", "—"],
              [r"\textbf{Limiar Maior} ou acima", "2 Estrutura", "—"],
              [r"\textbf{Limiar Severo} ou acima", "3 Estrutura",
               r"role a \textbf{Avaria}"]],
             antes="Levar dano — vale para colosso e para gente")

    s += ("\\dica{Antes de marcar, gaste \\textbf{1 Blindagem} para descer um "
          "degrau. Com toda a Estrutura marcada, o colosso cai — e o piloto "
          "sai, sempre.}\n")

    s += tab("C{1.5cm} L{%0.1fcm}" % (COL - 2.0),
             ["1d12", "Resultado"],
             [[r"\textbf{1--4}", r"\textbf{Raspão.} Nada além do dano."],
              [r"\textbf{5--6}", r"\textbf{Tranco.} Fica \termo{Vulnerável} até a "
                                 r"próxima ação e marca 1 Estresse."],
              [r"\textbf{7--8}", r"\textbf{Peça solta.} Uma Peça instalada desliga "
                                 r"até a próxima Parada Longa. Ele escolhe qual."],
              [r"\textbf{9--10}", r"\textbf{Fratura.} Os dois Limiares caem "
                                  r"\textbf{3} até o conserto. Acumula."],
              [r"\textbf{11}", r"\textbf{Núcleo torto.} Fica \termo{Inerte}. "
                               r"Religar custa uma ação e 1 Estresse."],
              [r"\textbf{12+}", r"\textbf{Colapso.} O colosso cai agora. Uma ação "
                                r"para sair."]],
             antes="Avaria — 1d12, +1 por Avaria anterior nesta sortida")

    s += ("\\dica{\\textbf{Parada Curta} limpa 2 Estresse. \\textbf{Parada "
          "Longa} limpa tudo, troca as Peças instaladas e conserta o casco.}\n")

    s += tab("L{3.6cm} C{2.2cm} L{%0.1fcm}" % (COL - 6.2),
             ["O quê", "Dificuldade", "Resultado"],
             [[r"\textbf{Subir}", r"\termo{Agilidade} 15", "Está em cima. O colosso "
                                                           "gasta uma ação para sacudir."],
              [r"\textbf{Plantar carga}", r"\termo{Conhec.} 14",
               r"Estoura na próxima: \dado{4d12+4}, ignorando Blindagem."],
              [r"\textbf{Cortar um cabo}", r"\termo{Finesse} 16",
               "Perde 1 Deslocamento, ou uma Peça, ou os sensores."],
              [r"\textbf{Abrir a cabine}", r"\termo{Força} 18",
               r"Em cima, com o colosso \termo{Inerte} ou \termo{Restrito}."],
              [r"\textbf{Falar}", r"\termo{Presença} 15",
               "Tem gente ali dentro. Às vezes é tudo de que se precisa."]],
             antes="O que uma pessoa a pé faz com uma máquina")


    linhas = []
    for esc in (1, 2, 3, 4):
        eva, ma, se, atq, nd, nb, est = LINHA[esc]
        linhas.append([r"\textbf{%dº}" % esc, str(eva), "%d / %d" % (ma, se),
                       "+%d" % atq, r"\dado{%dd10+%d}" % (nd, nb), str(est)])
    s += tab("C{1.3cm} C{1.5cm} C{2.2cm} C{1.5cm} C{2.6cm} C{%0.1fcm}" % (COL - 9.6),
             ["Esc.", "Evasão", "Limiares", "Ataque", "Dano", "Estrut."],
             linhas,
             antes="A linha do Escalão — monte um adversário em trinta segundos")

    CURTO = {
     "Lacaio": "Cai com qualquer acerto. Vem em grupo de três ou mais.",
     "Batedor": "Chega, morde e sai.",
     "Atirador": "Fica longe. De perto, acaba.",
     "Apoio": "Faz os outros vencerem.",
     "Regular": "A linha. É por ela que se mede tudo.",
     "Bando": "Conta como vários. Meio dano na segunda metade.",
     "Comandante": "Gasta o seu Medo melhor que os outros.",
     "Brutamontes": "Aguenta. Lento e caro de derrubar.",
     "Solo": "Sozinho contra o grupo inteiro.",
    }
    linhas = []
    for nome, (mult, ajd, custo, como) in PAPEL.items():
        como = CURTO.get(nome, como)
        m = "—" if mult is None else ("$\\times$%0.1f" % mult).replace(".0", "")
        a = "—" if ajd == 0 else ("%+d" % ajd)
        linhas.append([r"\textbf{%s}" % nome, str(custo), m, a, como])
    s += tab("L{2.8cm} C{1.2cm} C{1.5cm} C{1.3cm} L{%0.1fcm}" % (COL - 7.6),
             ["Papel", "Pontos", "Estrut.", "Evasão", "O que ele é"],
             linhas,
             antes="Os nove papéis")

    s += ("\\dica{\\textbf{Pontos de Batalha = (3 $\\times$ pilotos) + 2.} "
          "\\textbf{--1} se todos forem de Escalão abaixo do da mesa; "
          "\\textbf{+2} se houver uma Contagem correndo. Lacaio cai com "
          "qualquer acerto.}\n")

    s += ("\\dica{\\textbf{Marcas no adversário:} dano abaixo do Maior "
          "marca \\textbf{1}; no Maior ou acima, \\textbf{2}; no Severo ou "
          "acima, \\textbf{3}.}\n")


    s += "\\end{multicols}\n"
    s += "\\clearpage\n"
    return s


def montar():
    s = PREAMBULO
    s += painel_rolagem()
    s += painel_medo()
    s += painel_combate()
    s += painel_estrago()
    s += "\\end{document}\n"
    open(os.path.join(SAIDA, "escudo.tex"), "w", encoding="utf-8").write(s)
    print("escudo.tex: 4 painéis A4 deitados")


if __name__ == "__main__":
    montar()
