# -*- coding: utf-8 -*-
"""
Um terceiro renderizador da Cena: PIL.

Os dois de arte2/saida.py cospem vetor (TikZ e SVG). Ícone de PWA
precisa ser PNG de verdade — o Android não instala com SVG — e este
contêiner não tem rasterizador de SVG. Então a mesma Cena é desenhada
de novo, agora com polígonos do Pillow, com 4x de supersampling para
a borda não ficar serrilhada.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from PIL import Image, ImageDraw
from arte2.cena import Forma, escurece


def _rgb(c):
    c = c.lstrip("#")
    return tuple(int(c[i:i + 2], 16) for i in (0, 2, 4))


def render(cena, lado, caixa, fundo=None, ss=4, margem=0.0):
    """
    Desenha a cena num PNG quadrado de `lado` px.

    `caixa` é (x0, y0, x1, y1) no mundo da arte (800x800, y para cima):
    é o recorte que vira a imagem. `margem` é uma folga em fração da
    caixa, para o desenho não encostar na borda.
    """
    x0, y0, x1, y1 = caixa
    if margem:
        fx, fy = (x1 - x0) * margem, (y1 - y0) * margem
        x0, y0, x1, y1 = x0 - fx, y0 - fy, x1 + fx, y1 + fy
    larg, alt = x1 - x0, y1 - y0
    k = lado * ss / max(larg, alt)
    # centraliza o recorte dentro do quadrado
    dx = (lado * ss - larg * k) / 2.0
    dy = (lado * ss - alt * k) / 2.0

    def pt(p):
        # y do mundo sobe; y da imagem desce
        return (dx + (p[0] - x0) * k, lado * ss - dy - (p[1] - y0) * k)

    img = Image.new("RGBA", (lado * ss, lado * ss),
                    _rgb(fundo) + (255,) if fundo else (0, 0, 0, 0))
    d = ImageDraw.Draw(img, "RGBA")

    for _i, it in cena.ordenadas():
        pts = [pt(p) for p in it.pts]
        if len(pts) < 2:
            continue
        op = int(round(255 * getattr(it, "opacidade", 1.0)))
        if isinstance(it, Forma):
            d.polygon(pts, fill=_rgb(it.cor) + (op,))
            esc = it.metade_escura()
            if len(esc) >= 3:
                d.polygon([pt(p) for p in esc],
                          fill=_rgb(escurece(it.cor, it.sombra)) + (op,))
            if it.traco > 0.01:
                d.line(pts + [pts[0]], fill=_rgb(it.contorno) + (op,),
                       width=max(1, int(round(it.traco * k / 14.0))),
                       joint="curve")
        else:
            d.line(pts, fill=_rgb(it.cor) + (op,),
                   width=max(1, int(round(it.traco * k / 14.0))),
                   joint="curve")

    return img.resize((lado, lado), Image.LANCZOS)


def com_fundo(img, cor, raio=0.0):
    """Cola a arte sobre um quadrado cheio — ícone 'any' precisa disso."""
    lado = img.size[0]
    base = Image.new("RGBA", (lado, lado), _rgb(cor) + (255,))
    if raio:
        pass  # o Android já arredonda sozinho
    base.alpha_composite(img)
    return base
