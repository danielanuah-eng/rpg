# -*- coding: utf-8 -*-
"""Transforma os dados nos capítulos gerados do livro."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from dados.fabricas import FABRICAS, ORDEM
from dados.classes import CLASSES, CHASSIS, ANCESTRALIDADES, COMUNIDADES
from dados.itens import ARMAS_PILOTO, TRAJES, MECANICOS, ESTRANHOS
from dados.adversarios import COLOSSOS, FUNDAS, GENTE, ficha, LINHA, PAPEL

SAIDA = os.path.join(os.path.dirname(__file__), "..", "tex")
ORD = {1: "1º", 2: "2º", 3: "3º", 4: "4º"}

# um retrato de destaque por fábrica
DESTAQUE = {"BRASA": "brUltimaBrasa", "VESPERTINA": "vpVespertina",
            "CATEDRAL": "ctLegado", "ARCO": "arFossa",
            "GRALHA": "grFrankenstein", "SELO": "slOrbita",
            "CARVAO": "cvCarvao", "OSSATURA": "osVirada"}

ESCOLHAS_NIVEL = [
 ("Some \\textbf{+1} a dois traços diferentes.", 3),
 ("\\textbf{+1 Estrutura} no colosso.", 3),
 ("\\textbf{+1 Estresse}.", 2),
 ("\\textbf{+1 Evasão} — do piloto ou do colosso.", 2),
 ("\\textbf{+1 encaixe} no chassi.", 2),
 ("Uma \\termo{Peça} nova, de fábrica em que você tem licença.", 3),
 ("\\textbf{Licença} de uma fábrica nova.", 2),
 ("Uma \\termo{Experiência} nova, com \\textbf{+2}.", 2),
 ("Suba uma Experiência sua para \\textbf{+3}.", 2),
 ("Suba um degrau nos dois Limiares do piloto.", 2),
 ("\\textbf{Um contato}: alguém no mundo passa a te dever um favor, e a "
  "mesa decide quem é.", 2),
 ("\\textbf{Uma marca}: o seu nome passa a significar alguma coisa num "
  "lugar. Diga onde e o quê.", 2),
 ("\\textbf{Um bem}: uma doca, um galpão, um veículo, uma licença de "
  "porte. É seu, e dá trabalho.", 2),
]


def grava(nome, texto):
    open(os.path.join(SAIDA, nome), "w", encoding="utf-8").write(texto)
    print("  %-26s %6d bytes" % (nome, len(texto.encode("utf-8"))))


# ============================================================== FÁBRICAS

def gerar_fabricas():
    s = "% gerado — não editar à mão\n"
    for k in ORDEM:
        f = FABRICAS[k]
        s += "\n\\clearpage\n\\section{%s}\n" % f["nome"]
        s += ("\\noindent{\\rotulo\\fontsize{8.5}{10}\\selectfont"
              "\\color{%s}\\MakeUppercase{%s}}\\par\\vspace{1.6mm}\n"
              % (f["cor"], f["linha"]))
        s += "\\begin{leia}\n%s\n\\end{leia}\n\n" % f["lema"]
        s += ("\\noindent\\begin{minipage}[t]{0.605\\linewidth}\\vspace{0pt}\n"
              "%s\\par\\vspace{2mm}\n%s\n\\end{minipage}\\hfill\n"
              % (f["proposta"], f["cultura"]))
        s += ("\\begin{minipage}[t]{0.355\\linewidth}\\vspace{0pt}\\centering\n"
              "\\retrato{%s}{1.50}\\\\[1.5mm]\n"
              "{\\rotulo\\fontsize{6.8}{8.4}\\selectfont\\color{cinza45}"
              "UM CASCO DA CASA}\n\\end{minipage}\\par\\vspace{2.5mm}\n"
              % DESTAQUE[k])
        s += "\\textbf{No olho.} %s\n\n" % f["estetica"]
        s += "\\barrafab{As quinze Peças}{%s}{%s}\n" % (k, f["cor"])
        s += "\\begin{gradecartas}\n"
        for (niv, nome, tipo, custo, texto) in f["pecas"]:
            if tipo == "Fixa":
                etq = "Nível %d \\textbullet\\ Fixa" % niv
            elif tipo == "Ativa":
                etq = "Nível %d \\textbullet\\ %d Estresse" % (niv, custo)
            else:
                etq = "Nível %d \\textbullet\\ Medo %d+" % (niv, custo)
            s += "\\begin{pecacx}{%s}{%s}{%s}\n%s\n\\end{pecacx}\n\n" % (
                nome, etq, f["cor"], texto)
        s += "\\end{gradecartas}\n"
    grava("gerado-fabricas.tex", s)


# =============================================================== CLASSES

def gerar_classes():
    s = "% gerado\n"
    for c in CLASSES:
        s += "\n\\needspace{8\\baselineskip}\n\\section{%s}\n" % c["nome"]
        s += ("\\noindent{\\rotulo\\fontsize{8.5}{10}\\selectfont"
              "\\color{cinza45}\\MakeUppercase{Licença de fábrica: %s "
              "\\textbullet\\ Chassi de partida: %s}}\\par\\vspace{1.5mm}\n"
              % (FABRICAS[c["fabrica"]]["nome"], c["chassi"]))
        s += "\\begin{leia}\n%s\n\\end{leia}\n\n" % c["chamada"]
        s += "\\begin{pctabela}{C{2.6cm} C{2.6cm} L{9.0cm}}\n"
        s += ("\\cab{Evasão} & \\cab{PV} & \\cab{Na cabine} \\\\ \\regra\n")
        s += "\\textbf{%d} & \\textbf{%d} & %s \\\\\n" % (
            c["evasao"], c["pv"], c["itens"])
        s += "\\end{pctabela}\n\n"
        s += "\\barra{%s \\textbullet\\ traço de classe}\n%s\n\n" % (
            c["traco"][0], c["traco"][1])
        s += "\\barra{%s \\textbullet\\ 3 Esperança}\n%s\n\n" % (
            c["esperanca"][0], c["esperanca"][1])
        s += "\\subsection{As duas subclasses}\n"
        for sc in c["subclasses"]:
            s += "\\begin{ficha}\n\\barratopo{%s}{%s}\n" % (sc["nome"], sc["linha"])
            s += "\\begin{description}\n"
            s += "\\item[Fundação — nível 1] %s\n" % sc["f"]
            s += "\\item[Especialização — nível 5] %s\n" % sc["e"]
            s += "\\item[Maestria — nível 8] %s\n" % sc["m"]
            s += "\\end{description}\n\\end{ficha}\n\n"
        s += "\\filete\n"
    grava("gerado-classes.tex", s)


# ================================================================== POVO

def gerar_povo():
    s = "% gerado\n\\section{Ancestralidades}\n"
    s += ("De onde o seu corpo veio. Escolha uma e fique com as duas "
          "características, ou pegue a primeira de uma e a segunda de "
          "outra — é assim que se faz uma pessoa de fronteira.\n\n")
    for (nome, linha, texto, a, b) in ANCESTRALIDADES:
        s += "\\needspace{6\\baselineskip}\n\\subsection{%s}\n" % nome
        s += "\\emph{%s}\\par\\vspace{1.4mm}\n%s\\par\\vspace{1.8mm}\n" % (
            linha, texto)
        s += "\\begin{ficha}\n\\begin{description}\n"
        s += "\\item[%s] %s\n\\item[%s] %s\n" % (a[0], a[1], b[0], b[1])
        s += "\\end{description}\n\\end{ficha}\n\n"
    s += "\\filete\n\\clearpage\n\\section{Comunidades}\n"
    s += "Onde você foi criado, e o que isso te deu de graça. Uma só.\n\n"
    for (nome, linha, texto, feat) in COMUNIDADES:
        s += "\\needspace{6\\baselineskip}\n\\subsection{%s}\n" % nome
        s += "\\emph{%s}\\par\\vspace{1.4mm}\n%s\\par\\vspace{1.8mm}\n" % (
            linha, texto)
        s += "\\begin{ficha}\n%s\n\\end{ficha}\n\n" % feat
    s += "\\filete\n"
    grava("gerado-povo.tex", s)


# ============================================================== CHASSIS

def gerar_chassis():
    s = "% gerado\n"
    s += ("Dezesseis chassis, dois por fábrica. O chassi define a "
          "\\termo{Blindagem}, e é a única coisa no jogo que define — "
          "nenhuma Peça dá Blindagem de graça, com uma exceção por "
          "fábrica.\n\n")
    s += "\\begin{pctabela}{L{2.5cm} L{2.3cm} C{1.5cm} C{1.4cm} C{1.4cm} C{1.9cm} C{1.7cm} C{1.4cm}}\n"
    s += ("\\cab{Chassi} & \\cab{Fábrica} & \\cab{Porte} & \\cab{Estrut.} & "
          "\\cab{Evasão} & \\cab{Limiares} & \\cab{Blind.} & \\cab{Enc.} "
          "\\\\ \\regra\n")
    for c in CHASSIS:
        (nome, fab, porte, est, eva, lma, lse, bli, enc, des, nuc) = c
        s += "\\textbf{%s} & %s & %s & %d & %d & %d\\,/\\,%d & %d & %d \\\\\n" % (
            nome, fab.capitalize(), porte, est, eva, lma, lse, bli, enc)
    s += "\\end{pctabela}\n\n"
    for c in CHASSIS:
        (nome, fab, porte, est, eva, lma, lse, bli, enc, des, nuc) = c
        s += "\\begin{ficha}\n"
        s += "\\barrafab{%s}{%s \\textbullet\\ %s}{%s}\n" % (
            nome, FABRICAS[fab]["nome"], porte, FABRICAS[fab]["cor"])
        s += ("\\textbf{Estrutura} %d \\quad \\textbf{Evasão} %d \\quad "
              "\\textbf{Limiares} %d/%d \\quad \\textbf{Blindagem} %d \\quad "
              "\\textbf{Encaixes} %d \\quad \\textbf{Deslocamento} %d"
              "\\par\\vspace{1.4mm}\n" % (est, eva, lma, lse, bli, enc, des))
        s += "\\textbf{Núcleo — %s.} %s\n" % (nuc[0], nuc[1])
        s += "\\end{ficha}\n\n"
    grava("gerado-chassis.tex", s)


# ================================================================ ITENS

def gerar_itens():
    s = "% gerado\n\\section{Armas de piloto}\n"
    s += ("Uma pessoa atacando um colosso rola com \\textbf{desvantagem} e "
          "causa \\textbf{metade} do dano — a não ser que a arma seja "
          "\\termo{Antimáquina}.\n\n")
    s += "\\begin{pctabela}{L{3.2cm} L{2.0cm} L{2.0cm} C{1.4cm} C{0.8cm} L{4.2cm}}\n"
    s += ("\\cab{Arma} & \\cab{Traço} & \\cab{Alcance} & \\cab{Dano} & "
          "\\cab{Mãos} & \\cab{Detalhe} \\\\ \\regra\n")
    for (n, tr, al, d, b, m, etq, tx) in ARMAS_PILOTO:
        bon = "+%d" % b if b else ""
        nome = "\\textbf{%s}" % n
        if etq:
            nome += " {\\scriptsize\\emph{(%s)}}" % etq
        s += "%s & %s & %s & \\dado{%s%s} & %d & %s \\\\\n" % (
            nome, tr, al, d, bon, m, tx)
    s += "\\end{pctabela}\n\n\\barra{O que se veste}\n"
    s += "\\begin{pctabela}{L{3.6cm} C{1.8cm} C{2.2cm} L{6.4cm}}\n"
    s += ("\\cab{Traje} & \\cab{Blindagem} & \\cab{Limiares} & \\cab{Detalhe} "
          "\\\\ \\regra\n")
    for (n, bl, lm, ls, tx) in TRAJES:
        s += "\\textbf{%s} & %d & %d\\,/\\,%d & %s \\\\\n" % (n, bl, lm, ls, tx)
    s += "\\end{pctabela}\n\\filete\n"

    s += "\\section{Itens mecânicos}\n"
    s += ("Coisas que se compra numa doca e que cabem na cabine. O que "
          "tiver \\emph{usos} acaba; o resto não.\n\n")
    # 28 linhas não cabem numa página: tem de ser tabela longa
    s += "\\begin{pclonga}{L{3.8cm} L{2.2cm} L{1.9cm} L{5.6cm}}\n"
    s += ("\\cab{Item} & \\cab{Origem} & \\cab{Usos} & \\cab{Efeito} "
          "\\\\ \\regra\n\\endhead\n")
    for (n, o, u, tx) in MECANICOS:
        s += "\\textbf{%s} & %s & %s & %s \\\\\n" % (
            n, o.capitalize() if o != "—" else "—", u, tx)
    s += "\\end{pclonga}\n\\filete\n"

    s += "\\section{As coisas estranhas}\n"
    s += ("Ninguém sabe explicar nenhuma delas, e a maioria veio de dentro "
          "de alguma coisa que estava morta. Use uma por arco de campanha; "
          "duas se a mesa estiver gostando.\n\n")
    s += "\\begin{gradecartas}\n"
    for (n, r, tx) in ESTRANHOS:
        s += "\\begin{pecacx}{%s}{%s}{ossC}\n%s\n\\end{pecacx}\n\n" % (n, r, tx)
    s += "\\end{gradecartas}\n\\filete\n"
    grava("gerado-itens.tex", s)


# =========================================================== ADVERSÁRIOS

def _bloco_adv(ident, nome, esc, papel, alcance, arma, desc, motivos,
               feats, etiqueta):
    eva, ma, se, atq, dano, est = ficha(esc, papel)
    s = "\\needspace{11\\baselineskip}\n\\begin{ficha}\n"
    s += "\\barratopo{%s}{%s \\textbullet\\ %s \\textbullet\\ Escalão %s}\n" % (
        nome, etiqueta, papel, ORD[esc])
    s += "\\noindent\\begin{minipage}[t]{0.33\\linewidth}\\vspace{0pt}\\centering\n"
    s += "\\retrato{%s}{1.15}\n\\end{minipage}\\hfill\n" % ident
    s += "\\begin{minipage}[t]{0.645\\linewidth}\\vspace{0pt}\n"
    s += ("{\\normalfont\\fontsize{8.8}{11}\\selectfont %s}"
          "\\par\\vspace{1.4mm}\n" % desc)
    s += ("{\\rotulo\\fontsize{7.4}{9.4}\\selectfont\\color{cinza45}"
          "\\MakeUppercase{Motivos}}\\par{\\normalfont\\itshape"
          "\\fontsize{8.4}{10.4}\\selectfont %s}\\par\\vspace{1.6mm}\n"
          % motivos)
    s += "\\begin{pctabela}{C{1.25cm} C{1.75cm} C{1.25cm} C{1.5cm} C{1.75cm}}\n"
    s += ("\\cab{Evasão} & \\cab{Limiares} & \\cab{Estrut.} & \\cab{Ataque} & "
          "\\cab{Dano} \\\\ \\regra\n")
    s += "\\textbf{%d} & \\textbf{%d\\,/\\,%d} & \\textbf{%d} & \\textbf{+%d} & \\dado{%s} \\\\\n" % (
        eva, ma, se, est, atq, dano)
    s += "\\end{pctabela}\n"
    s += "\\textbf{%s} \\textbullet\\ %s\n\\end{minipage}\n\n\\vspace{1.4mm}\n" % (
        arma, alcance)
    s += "\\begin{description}\n"
    for (fn, ft, fx) in feats:
        s += "\\item[%s — %s] %s\n" % (fn, ft, fx)
    s += "\\end{description}\n\\end{ficha}\n\n"
    return s


def gerar_adversarios():
    s = "% gerado\n"
    s += "\\barra{As linhas de cada Escalão}\n"
    s += "\\begin{pctabela}{C{1.6cm} C{1.7cm} C{2.2cm} C{1.7cm} C{2.2cm} C{2.4cm}}\n"
    s += ("\\cab{Escalão} & \\cab{Evasão} & \\cab{Limiares} & \\cab{Ataque} & "
          "\\cab{Dano} & \\cab{Estrutura} \\\\ \\regra\n")
    for e in (1, 2, 3, 4):
        eva, ma, se, atq, nd, nb, est = LINHA[e]
        s += "\\textbf{%s} & %d & %d\\,/\\,%d & +%d & \\dado{%dd10+%d} & %d \\\\\n" % (
            ORD[e], eva, ma, se, atq, nd, nb, est)
    s += "\\end{pctabela}\n\n\\barra{O papel muda a linha}\n"
    s += "\\begin{pctabela}{L{2.8cm} C{2.2cm} C{1.7cm} C{1.6cm} L{5.4cm}}\n"
    s += ("\\cab{Papel} & \\cab{Estrutura} & \\cab{Evasão} & \\cab{Custo} & "
          "\\cab{Como se usa} \\\\ \\regra\n")
    for p, (mult, dev, custo, como) in PAPEL.items():
        m = "1 caixa" if mult is None else ("\\texttimes\\,%s" %
                                            ("%.1f" % mult).replace(".", ","))
        s += "\\textbf{%s} & %s & %s & %d & %s \\\\\n" % (
            p, m, ("%+d" % dev) if dev else "—", custo, como)
    s += "\\end{pctabela}\n"

    atual = None
    for c in COLOSSOS:
        (ident, nome, esc, papel, fab, _d, _e, _x,
         alcance, arma, desc, motivos, feats) = c
        if fab != atual:
            atual = fab
            s += "\n\\clearpage\n\\section{Colossos da %s}\n" % FABRICAS[fab]["nome"]
        s += _bloco_adv(ident, nome, esc, papel, alcance, arma, desc,
                        motivos, feats, FABRICAS[fab]["nome"].split()[0])

    s += "\n\\clearpage\n\\section{As Fundas}\n"
    s += ("Não têm lado, não negociam e não param. Uma Funda numa cena de "
          "guerra muda o assunto: de repente os dois exércitos têm o mesmo "
          "problema.\n\n")
    for f in FUNDAS:
        (ident, nome, esc, papel, _pl, _pa, alcance, arma, desc,
         motivos, feats) = f
        s += _bloco_adv(ident, nome, esc, papel, alcance, arma, desc,
                        motivos, feats, "Funda")

    s += "\n\\clearpage\n\\section{Gente e veículo}\n"
    s += ("Lembre da regra de escala: gente atacando colosso rola com "
          "desvantagem e causa metade do dano, a não ser que esteja com "
          "arma \\termo{Antimáquina} — e várias destas estão.\n\n")
    for g in GENTE:
        (ident, nome, esc, papel, _des, alcance, arma, desc,
         motivos, feats) = g
        s += _bloco_adv(ident, nome, esc, papel, alcance, arma, desc,
                        motivos, feats, "Linha")
    grava("gerado-adversarios.tex", s)


# =========================================================== PROGRESSÃO

def gerar_progressao():
    s = "% gerado\n"
    s += ("Ao subir de nível, escolha \\textbf{duas} opções. Uma opção com "
          "duas caixas só pode ser escolhida duas vezes dentro do mesmo "
          "Escalão; ao entrar num Escalão novo, as caixas zeram.\n\n")
    s += "\\begin{pctabela}{L{11.6cm} C{2.6cm}}\n"
    s += "\\cab{Opção} & \\cab{Cabe} \\\\ \\regra\n"
    for (t, v) in ESCOLHAS_NIVEL:
        s += "%s & \\caixas{%d} \\\\\n" % (t, v)
    s += "\\end{pctabela}\n\n"
    s += "\\barra{O que vem de graça}\n"
    s += "\\begin{pctabela}{C{1.6cm} C{2.0cm} L{10.6cm}}\n"
    s += "\\cab{Nível} & \\cab{Escalão} & \\cab{Automático} \\\\ \\regra\n"
    auto = {1: "Começo. Proficiência 1.",
            2: "Proficiência 2. Uma Experiência nova, com +2.",
            5: "Proficiência 3. Especialização da subclasse. "
               "Uma Experiência nova. Zere as caixas.",
            8: "Proficiência 4. Maestria da subclasse. "
               "Uma Experiência nova. Zere as caixas."}
    esc_de = {1: 1, 2: 2, 3: 2, 4: 2, 5: 3, 6: 3, 7: 3, 8: 4, 9: 4, 10: 4}
    for n in range(1, 11):
        s += "\\textbf{%d} & %s & %s \\\\\n" % (n, ORD[esc_de[n]],
                                                auto.get(n, "—"))
    s += "\\end{pctabela}\n"
    grava("gerado-progressao.tex", s)


if __name__ == "__main__":
    print("gerando capítulos:")
    gerar_fabricas()
    gerar_classes()
    gerar_povo()
    gerar_chassis()
    gerar_itens()
    gerar_adversarios()
    gerar_progressao()
    print("pronto.")
