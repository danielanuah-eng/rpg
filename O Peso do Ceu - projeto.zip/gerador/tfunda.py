import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from arte.funda import PLANOS, monta
from arte.volume import ESTILOS

corpo = ""
for k in PLANOS:
    corpo += "\\newcommand{\\f%s}{%%\n%s}\n\n" % (k.capitalize(), monta(k))
grade = ""
for i, k in enumerate(PLANOS):
    grade += ("\\begin{minipage}[b]{0.245\\textwidth}\\centering\n"
              "\\begin{tikzpicture}[scale=0.44]\\f%s\\end{tikzpicture}\\\\[2mm]\n"
              "{\\sffamily\\footnotesize %s}\\end{minipage}%%\n" % (k.capitalize(), k))
    grade += "\\\\[8mm]\n" if (i+1) % 4 == 0 else "\\hfill\n"
doc = (r"""\documentclass[11pt]{article}
\usepackage{fontspec}\usepackage{xcolor}\usepackage{tikz}\usetikzlibrary{calc}
\usepackage[a4paper,margin=10mm]{geometry}
\definecolor{tinta}{HTML}{111111}
""" + ESTILOS + corpo + r"""
\pagestyle{empty}\setlength{\parindent}{0pt}
\begin{document}\noindent
""" + grade + r"""
\end{document}
""")
open(os.path.join(os.path.dirname(__file__), "..", "tex", "tf.tex"), "w",
     encoding="utf-8").write(doc)
print("tf.tex escrito")
