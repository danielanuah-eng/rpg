# -*- coding: utf-8 -*-
"""Prova do motor de volume: um colosso simples, só para ver se tem peso."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from arte.volume import (bloco, extrusao, cilindro, domo, hachura, sombra_chao,
                         rebites, veneziana, painel, olho, visor, cabo,
                         espelho, ESTILOS)

def teste():
    s = ""
    s += sombra_chao(0.15, -3.62, 1.95, 0.42)

    # ---- pernas -------------------------------------------------------
    for lado in (-1, 1):
        L = lado
        # coxa
        s += extrusao([(L*0.26, -0.10), (L*0.80, -0.14), (L*0.92, -1.30),
                       (L*0.34, -1.24)][::L], 0.52, base=3)
        # joelho
        s += extrusao([(L*0.32, -1.22), (L*0.94, -1.28), (L*0.90, -1.66),
                       (L*0.30, -1.60)][::L], 0.58, base=4)
        # canela
        s += extrusao([(L*0.34, -1.62), (L*0.86, -1.68), (L*0.74, -2.94),
                       (L*0.38, -2.88)][::L], 0.48, base=2)
        s += veneziana(L*0.44 if L > 0 else -0.78, -2.70, 0.34, 0.42, 4)
        # tornozelo e pé
        s += extrusao([(L*0.26, -2.86), (L*0.84, -2.92), (L*0.92, -3.26),
                       (L*0.18, -3.20)][::L], 0.56, base=4)
        s += extrusao([(L*0.14, -3.20), (L*0.98, -3.26), (L*1.08, -3.52),
                       (L*0.06, -3.46)][::L], 0.66, base=3)
        s += rebites((L*0.24, -3.38), (L*0.96, -3.42), 4)

    # ---- quadril ------------------------------------------------------
    s += extrusao([(-0.96, 0.44), (0.96, 0.44), (1.04, -0.12), (-1.04, -0.12)],
                  0.70, base=3)
    s += painel(-0.32, -0.04, 0.64, 0.42, "tonD")

    # ---- torso --------------------------------------------------------
    s += extrusao([(-1.02, 2.16), (1.02, 2.16), (0.96, 1.36), (0.38, 0.56),
                   (-0.38, 0.56), (-0.96, 1.36)], 0.82, base=2)
    s += painel(-0.86, 1.46, 0.72, 0.62)
    s += painel(0.14, 1.46, 0.72, 0.62)
    s += veneziana(-0.80, 1.52, 0.60, 0.48, 4)
    s += veneziana(0.20, 1.52, 0.60, 0.48, 4)
    s += rebites((-0.92, 2.06), (0.92, 2.06), 9)
    # núcleo
    s += extrusao([(-0.32, 1.38), (0.32, 1.38), (0.38, 0.88), (-0.38, 0.88)],
                  0.30, base=4)
    s += "  \\fill[tinta] (0,1.14) circle (0.17);\n"
    s += "  \\fill[tonA] (0,1.14) circle (0.095);\n"
    s += "  \\fill[tinta] (0,1.14) circle (0.032);\n"
    s += "  \\draw[luz] (-0.06,1.20) arc (140:210:0.12);\n"

    # ---- cabeça -------------------------------------------------------
    s += extrusao([(-0.20, 2.14), (0.20, 2.14), (0.17, 2.34), (-0.17, 2.34)],
                  0.24, base=4)
    s += extrusao([(-0.30, 2.30), (0.30, 2.30), (0.34, 2.62), (0.20, 2.76),
                   (-0.20, 2.76), (-0.34, 2.62)], 0.46, base=1)
    s += visor(-0.26, 2.46, 0.52, 0.16)
    # crista
    s += extrusao([(-0.06, 2.76), (0.06, 2.76), (0.30, 3.24), (0.14, 3.22)],
                  0.16, base=3)

    # ---- ombreiras ----------------------------------------------------
    for lado in (-1, 1):
        L = lado
        s += extrusao([(L*0.92, 2.14), (L*1.86, 1.98), (L*1.76, 1.22),
                       (L*0.94, 1.34)][::L], 0.74, base=2 if L < 0 else 3)
        s += rebites((L*1.04, 2.02), (L*1.70, 1.90), 4)
    # aletas
    for lado in (-1, 1):
        L = lado
        s += extrusao([(L*1.48, 2.06), (L*3.00, 2.82), (L*3.06, 2.62),
                       (L*1.54, 1.90)][::L], 0.22, base=2)

    # ---- braços -------------------------------------------------------
    for lado in (-1, 1):
        L = lado
        s += extrusao([(L*1.06, 1.32), (L*1.58, 1.22), (L*1.50, 0.44),
                       (L*1.12, 0.54)][::L], 0.46, base=3)
        s += extrusao([(L*1.08, 0.28), (L*1.62, 0.20), (L*1.70, -0.70),
                       (L*1.16, -0.62)][::L], 0.58, base=2)
        s += painel(L*1.20 if L > 0 else -1.54, -0.42, 0.34, 0.38, "tonD")
        s += extrusao([(L*1.12, -0.62), (L*1.66, -0.68), (L*1.70, -0.96),
                       (L*1.14, -0.90)][::L], 0.50, base=4)
    s += cabo((-1.02, 1.28), (-0.62, 0.72), 0.18)
    s += cabo((1.02, 1.28), (0.62, 0.72), 0.18)
    return s


if __name__ == "__main__":
    corpo = teste()
    doc = (r"""\documentclass[11pt]{article}
\usepackage{fontspec}
\usepackage{xcolor}
\usepackage{tikz}
\usetikzlibrary{calc}
\usepackage[a4paper,margin=12mm]{geometry}
\definecolor{tinta}{HTML}{111111}
\definecolor{papel}{HTML}{EFE7D6}
""" + ESTILOS + r"""
\pagestyle{empty}
\begin{document}
\noindent\begin{tikzpicture}[scale=1.55]
""" + corpo + r"""
\end{tikzpicture}
\end{document}
""")
    open(os.path.join(os.path.dirname(__file__), "..", "tex",
                      "tvol.tex"), "w", encoding="utf-8").write(doc)
    print("tex/tvol.tex escrito")
