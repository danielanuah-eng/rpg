# -*- coding: utf-8 -*-
"""
A pasta Oficina do vault: como fazer um site virar aplicativo e como
pôr no ar.

O Anuah pediu que tudo que aprendemos publicando as duas ferramentas
ficasse guardado no Obsidian — a receita e os sites. Isto escreve essa
seção: dez notas, do que é um PWA até o comando exato que publica, com
os tropeços anotados para não se repetirem.

Nada aqui é teoria genérica: é o que foi realmente feito em
`gerador/pwa.py` e no Netlify, com os números e os erros de verdade.
"""
import os

RAIZ = os.path.join(os.path.dirname(__file__), "..")
SAIDA = os.path.join(RAIZ, "Oficina")   # ajustado em gerar()

SITE = "https://o-peso-do-ceu.netlify.app"
SITE_ID = "9d833aba-32b9-44c4-af6e-4b4c67c240df"
DATA = "2026-09-22"

NOTAS = {}


def nota(nome, tipo, categoria, tags, corpo, pai="🏗️ Oficina"):
    s = "---\ntipo: %s\ncategoria: %s\ntags:\n" % (tipo, categoria)
    for t in tags:
        s += "  - %s\n" % t
    s += "atualizado: %s\n---\n\n" % DATA
    s += corpo.strip() + "\n"
    if pai:
        s += "\n---\n\n[[%s|⬅ Voltar à Oficina]]\n" % pai
    NOTAS[nome + ".md"] = s


# ==================================================================== MOC
def moc():
    nota("🏗️ Oficina", "Hub", "MOC",
         ["oficina", "moc", "hub", "site", "pwa"], """
# 🏗️ Oficina

Como fazer um site, como fazer esse site virar **aplicativo de celular**
e como pôr no ar. Escrito a partir do que foi feito de verdade com as
duas ferramentas de [[🛰️ O Peso do Céu]] — com os tropeços anotados,
que é a parte que costuma faltar em tutorial.

---

## O que está no ar agora

- 🌐 **[[🌐 O site O Peso do Céu]]** — endereços, o que tem dentro,
  quanto pesa, como foi montado.

## Entender

- 📱 **[[O que faz um site virar aplicativo]]** — as quatro peças de um
  PWA e o que cada celular exige.
- 📄 **[[O manifesto]]** — o cartão de identidade do aplicativo.
- 🛰️ **[[O service worker]]** — o que faz funcionar sem internet.
- 🎨 **[[Ícones de aplicativo]]** — tamanhos, máscara e zona segura.
- 💾 **[[Onde ficam os dados salvos]]** — o cofre é preso ao endereço.

## Fazer

- 🚀 **[[Publicar no Netlify]]** — o caminho inteiro, inclusive o que
  travou e como foi destravado.
- ♻️ **[[Republicar depois de mexer]]** — o ciclo curto de atualização.
- 📋 **[[Receita — do zero ao ar]]** — a lista de conferência, para
  repetir em qualquer projeto.

---

> [!TIP] A regra que resume tudo
> Um site vira aplicativo com **quatro arquivos** (página, manifesto,
> service worker, ícones) e **um endereço https**. O resto é enfeite.
""", pai=None)


# ============================================================ O QUE É PWA
def oque():
    nota("O que faz um site virar aplicativo", "Manual", "PWA",
         ["oficina", "pwa", "site", "celular"], """
# 📱 O que faz um site virar aplicativo

**PWA** (*Progressive Web App*) é um site que o celular aceita instalar:
ganha ícone na gaveta, abre em tela cheia sem barra de navegador e
funciona sem internet. Não passa por loja, não precisa de aprovação, não
precisa de conta de desenvolvedor.

## As quatro peças

| Peça | Arquivo | Para quê |
|---|---|---|
| **A página** | `index.html` | O programa em si |
| **O manifesto** | `manifest.webmanifest` | Nome, ícone, cor, tela cheia — ver [[O manifesto]] |
| **O service worker** | `sw.js` | Guarda tudo no aparelho — ver [[O service worker]] |
| **Os ícones** | `icone-192.png`, `icone-512.png` | O desenho na tela de início — ver [[Ícones de aplicativo]] |

E uma condição que não é arquivo: **tem que estar em `https://`**. Um
arquivo aberto do disco (`file://`) nunca instala, porque service worker
só roda em endereço seguro. É por isso que precisou do Netlify — ver
[[Publicar no Netlify]].

## O que cada celular exige

**Android (Chrome)** — mostra o convite de instalar quando existem
manifesto com `name`, `icons` de 192 e 512, `start_url` e
`display: standalone`, mais um service worker com tratador de `fetch`.
Cumprido isso, a página recebe o evento `beforeinstallprompt` e dá para
oferecer um botão próprio. É o que o nosso faz:

```js
addEventListener('beforeinstallprompt', function (e) {
  e.preventDefault();          // segura o convite feio do navegador
  guardado = e;                // guarda para usar no nosso botão
  botao.style.display = 'flex';
});
botao.onclick = function () { guardado.prompt(); };
```

**iPhone (Safari)** — não tem convite nem evento. O usuário faz pelo
botão de compartilhar → **Adicionar à Tela de Início**. O Safari lê
`apple-touch-icon` e `apple-mobile-web-app-title`, e ignora quase tudo
do manifesto. Por isso o cabeçalho leva as duas coisas, manifesto e
metatags da Apple.

**Computador** — Chrome e Edge instalam pelo ícone na barra de endereço.

## O que o usuário ganha de fato

- Ícone próprio, sem barra de navegador, sem abas.
- Abre sem sinal — no porão, no ônibus, na mesa do amigo.
- Atualiza sozinho quando você republica, sem ninguém baixar nada.
- Zero instalação de loja, zero permissão de sistema.

## O que ele **não** ganha

- Não aparece na Play Store nem na App Store.
- No iPhone, notificação só funciona se o app tiver sido **instalado**
  na tela de início, e com limites.
- O armazenamento é do navegador e pode ser limpo — ver
  [[Onde ficam os dados salvos]].
""")


# =============================================================== MANIFESTO
def manifesto():
    nota("O manifesto", "Manual", "PWA",
         ["oficina", "pwa", "manifesto", "site"], """
# 📄 O manifesto

Um JSON pequeno que diz ao celular **que aplicativo é esse**. Fica ao
lado da página e é apontado no `<head>`:

```html
<link rel="manifest" href="manifest.webmanifest">
```

## O nosso, campo por campo

```json
{
  "id": "/ficha/",
  "name": "O Peso do Céu — Ficha do Colosso",
  "short_name": "Ficha do Colosso",
  "description": "Monte seu mecha: chassi, Peças, níveis e cadeados.",
  "lang": "pt-BR",
  "start_url": ".",
  "scope": ".",
  "display": "standalone",
  "display_override": ["standalone", "minimal-ui"],
  "orientation": "portrait",
  "theme_color": "#25323E",
  "background_color": "#EFE7D4",
  "icons": [ … ]
}
```

| Campo | O que faz | Cuidado |
|---|---|---|
| `id` | Identidade fixa do app | Sem ele, mudar a `start_url` cria um app *novo* na gaveta |
| `name` | Nome na instalação e no splash | |
| `short_name` | Nome embaixo do ícone | Máximo ~12 caracteres, senão o Android corta |
| `start_url` | Onde abre ao tocar no ícone | `"."` = a pasta da página; relativo é mais seguro que absoluto |
| `scope` | Até onde o app "é o app" | Link fora do escopo abre no navegador, não dentro do app |
| `display` | `standalone` tira a barra do navegador | `fullscreen` tira até a barra de status; exagero para ferramenta de mesa |
| `theme_color` | Cor da barra de status | Escura, para o texto branco do sistema aparecer |
| `background_color` | Cor da tela de abertura | Igual ao fundo real da página, senão pisca |

## O truque dos dois aplicativos num site só

Ficha e Gerador são **dois aplicativos separados**, instaláveis
independentes, no mesmo endereço. O que separa é a pasta:

```
/ficha/     index.html · manifest.webmanifest · sw.js · ícones
/gerador/   index.html · manifest.webmanifest · sw.js · ícones
/           index.html  (a página que leva às duas)
```

Cada pasta tem `id`, `scope` e `start_url` próprios, então o celular
entende que são dois. Quem instala a Ficha não leva o Gerador junto.

## Servir com o tipo certo

O manifesto precisa sair como `application/manifest+json`. No Netlify
isso vai no `netlify.toml`:

```toml
[[headers]]
  for = "/*/manifest.webmanifest"
  [headers.values]
    Content-Type = "application/manifest+json; charset=utf-8"
    Cache-Control = "public, max-age=0, must-revalidate"
```

> [!WARNING] Erro que custa tempo
> Manifesto em cache longo é dor de cabeça: você troca o nome ou o
> ícone e o celular continua mostrando o antigo por dias. Ele e o
> `sw.js` sempre com `max-age=0, must-revalidate`.
""")


# ========================================================== SERVICE WORKER
def sw():
    nota("O service worker", "Manual", "PWA",
         ["oficina", "pwa", "service-worker", "offline"], """
# 🛰️ O service worker

Um arquivo de JavaScript que o navegador roda **fora da página**, como
um porteiro entre o aplicativo e a rede. É ele que faz funcionar sem
internet: na primeira visita guarda tudo, depois serve do bolso.

## Os três momentos

```js
// 1. INSTALAR — guarda a lista de arquivos
self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE)
    .then(c => c.addAll(ARQUIVOS))
    .then(() => self.skipWaiting()));
});

// 2. ATIVAR — joga fora as versões velhas
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys()
    .then(ks => Promise.all(ks
      .filter(k => k.startsWith('peso-ficha-') && k !== CACHE)
      .map(k => caches.delete(k))))
    .then(() => self.clients.claim()));
});

// 3. BUSCAR — decide de onde vem cada arquivo
self.addEventListener('fetch', e => { … });
```

## A estratégia que escolhemos: cache primeiro

```js
e.respondWith(
  caches.match(e.request).then(achou => {
    const rede = fetch(e.request).then(r => {
      if (r && r.ok && r.type === 'basic') {
        const copia = r.clone();
        caches.open(CACHE).then(c => c.put(e.request, copia));
      }
      return r;
    }).catch(() => achou);
    return achou || rede;     // devolve o guardado na hora
  })
);
```

Lê-se: **responde do bolso imediatamente**, e em paralelo pergunta à
rede e atualiza o bolso para a próxima vez. A tela nunca espera a
internet. Para uma ferramenta de mesa isso é o certo — a mesa costuma
ser num porão sem sinal. Para um site de notícias seria o contrário.

> [!NOTE] Por que `r.clone()`
> Uma resposta só pode ser lida uma vez. Sem o clone, ou a página
> recebe o arquivo, ou o cache guarda — nunca os dois.

## A versão no nome do cache

```js
const CACHE = 'peso-ficha-v3.0.1';
```

Trocar essa string é o que força a atualização: o `install` guarda tudo
de novo com o nome novo, o `activate` apaga os caches antigos com o
mesmo prefixo. **Se você republicar sem mexer na versão, o celular pode
continuar com a página velha.** Ver [[Republicar depois de mexer]].

## A armadilha do próprio sw.js

O navegador também guarda o `sw.js`. Se ele ficar em cache longo, o
celular nunca descobre que existe versão nova — e aí nada atualiza,
para sempre. Por isso:

```toml
[[headers]]
  for = "/*/sw.js"
  [headers.values]
    Cache-Control = "public, max-age=0, must-revalidate"
```

## Registrar

```js
if ('serviceWorker' in navigator) {
  addEventListener('load', function () {
    navigator.serviceWorker.register('sw.js').catch(function () {});
  });
}
```

Caminho **relativo** (`'sw.js'`, não `'/sw.js'`): é isso que prende o
alcance do porteiro à pasta `/ficha/` ou `/gerador/`, e é o que deixa os
dois aplicativos conviverem no mesmo endereço sem um comer o outro.

O `.catch()` vazio é de propósito: se o registro falhar — aba anônima,
navegador antigo — o aplicativo continua funcionando, só que online.
""")


# ================================================================= ÍCONES
def icones():
    nota("Ícones de aplicativo", "Manual", "PWA",
         ["oficina", "pwa", "icone", "arte"], """
# 🎨 Ícones de aplicativo

## O que precisa existir

| Arquivo | Tamanho | `purpose` | Para quê |
|---|---|---|---|
| `icone-192.png` | 192×192 | `any` | Gaveta de aplicativos |
| `icone-512.png` | 512×512 | `any` | Tela de abertura, loja de atalhos |
| `icone-192-mascara.png` | 192×192 | `maskable` | Android recortando em círculo |
| `icone-512-mascara.png` | 512×512 | `maskable` | idem |
| `apple-touch-icon.png` | 180×180 | — | iPhone |
| `favicon.png` | 32×32 | — | Aba do navegador |

**PNG, sempre.** SVG não instala no Android.

## `any` × `maskable` — a zona segura

O Android recorta o ícone na forma do sistema do usuário: círculo,
quadrado arredondado, gota. Um ícone `any` recortado perde as beiradas.
Um ícone `maskable` é desenhado já contando com isso: o desenho ocupa só
os **80% do meio**, e os 20% de fora são fundo sacrificável.

Por isso geramos duas versões do mesmo desenho, mudando só a folga:

```python
# 'any': arte cheia sobre o fundo da casa
pil_arte.render(cena, lado, caixa, fundo=fundo, margem=0.03)
# 'maskable': o Android corta; sobra 80% no meio
pil_arte.render(cena, lado, caixa, fundo=fundo, margem=0.30)
```

> [!WARNING] Fundo transparente não
> Ícone `any` com fundo transparente vira uma mancha preta ou branca
> dependendo do tema do celular. Sempre sobre cor chapada.

## De onde saem os nossos

Não são imagem baixada: saem do **mesmo motor vetorial que imprime o
livro**, em `arte2/`. Como o contêiner não tem rasterizador de SVG,
foi escrito um terceiro renderizador da mesma `Cena`, agora em Pillow —
`gerador/pil_arte.py` — que desenha os polígonos direto em PNG com 4× de
supersampling para a borda não serrilhar.

- **Ficha**: a cabeça do chassi de Vespertina em pose de guarda,
  recortada no quadro `(300, 600)–(500, 800)`, sobre `#25323E`.
- **Gerador**: uma Funda colossal com a pessoinha do lado — a escala
  lida de relance —, sobre `#2B1B21`.

Duas casas diferentes, duas cores diferentes: na gaveta do celular dá
para saber qual é qual sem ler o nome. Ver
[[🤖 Mechas — vocabulário visual]].

## Teste rápido

Olhe o ícone **a 48 pixels**. Se não der para dizer o que é, está
detalhado demais. Silhueta e duas cores ganham de qualquer desenho
bonito que vira borrão.
""")


# =============================================================== PUBLICAR
def publicar():
    nota("Publicar no Netlify", "Manual", "Publicação",
         ["oficina", "netlify", "publicacao", "site"], """
# 🚀 Publicar no Netlify

O Netlify hospeda site estático de graça, com `https` automático — que é
a condição para instalar como aplicativo. O projeto é
**`o-peso-do-ceu`**, id `%(id)s`.

## O caminho curto (quando dá)

O Netlify aceita **arrastar uma pasta ou um `.zip`** para a área de
*deploy manually* na página de Deploys do projeto. Trinta segundos, sem
instalar nada. É o caminho para qualquer atualização feita à mão.

## O caminho automático

O comando oficial, que sobe a pasta inteira e devolve o endereço:

```
npx -y @netlify/mcp@latest --site-id <id> --proxy-path "<url-de-credencial>"
```

A `--proxy-path` carrega a credencial e **vale pouco tempo** — tem que
ser gerada na hora, pelo Netlify, a cada publicação. Não adianta guardar
a de ontem.

## O que travou, e como foi destravado

Vale anotar porque vai acontecer de novo:

| Obstáculo | O que era | Saída |
|---|---|---|
| A rede do ambiente do Claude bloqueia `netlify.com`, `claudeusercontent.com` e o registro do npm | Política de saída da organização | Rodar no computador do Anuah, não no contêiner |
| O navegador embutido do Claude não está logado no Netlify | Sessão separada do Brave | Não dava para usar a interface por ali |
| O controle de computador só enxerga navegadores, não clica neles | Restrição de segurança da ferramenta | Sobrou o Explorador de Arquivos, que aceita clique |
| Não havia Node no computador | `npx` não existia — é o mesmo motivo do Desktop Commander viver em `retrying` | Um `.bat` que baixa um **Node portátil** e roda o comando |

O resultado foi **`Publicar site no Netlify.bat`**, na Área de Trabalho:

1. baixa `node-v22.11.0-win-x64.zip` de `nodejs.org` (~34 MB) para
   `_publicar_peso\\node\\` — **sem instalar nada no sistema**;
2. descompacta `Rpg\\site.zip` em `_publicar_peso\\site\\`;
3. roda o `npx` acima dentro dessa pasta;
4. escreve tudo em `_publicar_peso\\log.txt` e um `pronto.txt` no fim.

Um duplo-clique e pronto. O log é o que se lê para saber como foi — a
janela preta some sozinha.

> [!TIP] O Node portátil resolve mais do que isso
> Com `_publicar_peso\\node\\` no lugar, qualquer ferramenta de linha de
> comando em JavaScript passa a rodar. É o mesmo buraco que deixava o
> Desktop Commander sem subir.

## Uma pegadinha do Netlify: login de equipe

O projeto nasceu com **SSO obrigatório em todos os contextos** — o
endereço abria uma tela de login em vez do site, o que mataria a
instalação no celular. O ajuste é deixar o login só para os *previews*:

> Project configuration → Access control → *Visitor access* →
> **Team-only** apenas em *non-production*.

Depois disso o endereço de produção abre para qualquer um com o link.

## Conferir que ficou de pé

Vale checar, não presumir:

- a página abre e o título está certo;
- `manifest.webmanifest` responde e o `name` é o esperado;
- `navigator.serviceWorker.getRegistration()` devolve algo;
- `icone-512.png` responde `200` com `image/png`.
""" % {"id": SITE_ID})


# ============================================================== REPUBLICAR
def republicar():
    nota("Republicar depois de mexer", "Manual", "Publicação",
         ["oficina", "netlify", "publicacao", "receita"], """
# ♻️ Republicar depois de mexer

O ciclo curto, para quando mudar alguma coisa nas ferramentas.

## Os passos

1. **Mexer no que for** — `web/ficha.html`, `web/gerador.html` ou os
   dados do jogo.
2. **Subir a versão** em `gerador/pwa.py`:
   ```python
   VERSAO = "3.0.2"
   ```
   É isso que troca o nome do cache do service worker e obriga os
   celulares a pegarem a página nova. **Esquecer disso é o erro nº 1** —
   você publica, olha no celular e continua vendo o de ontem.
3. **Remontar**:
   ```
   python3 gerador/web.py     # costura os dois HTML de arquivo único
   python3 gerador/pwa.py     # monta site/ com manifesto, sw e ícones
   ```
4. **Empacotar** `site/` num `.zip` e mandar para o computador.
5. **Publicar** — duplo-clique no `.bat`, ou arrastar o zip na página de
   Deploys. Ver [[Publicar no Netlify]].

## Como a atualização chega no celular

Não é preciso reinstalar. Na primeira vez que o aplicativo abrir com
internet, o service worker novo é baixado, guarda tudo com o nome de
cache novo e assume no lugar do velho. Quem estava offline continua com
a versão antiga até pegar sinal — o que é o comportamento certo.

> [!WARNING] O que **não** se perde
> Republicar não apaga ficha nenhuma. Os dados ficam no armazenamento do
> aparelho, separados do código — ver [[Onde ficam os dados salvos]].
> O que pode se perder é o contrário: mudar o formato dos dados salvos
> sem migrar o que já estava lá.
""")


# ================================================================= DADOS
def dados():
    nota("Onde ficam os dados salvos", "Manual", "Dados",
         ["oficina", "pwa", "dados", "backup", "ferramenta"], """
# 💾 Onde ficam os dados salvos

As fichas que os jogadores montam e os inimigos que você salva no
Gerador ficam no **armazenamento do navegador, no aparelho** —
`localStorage`. Nada vai para servidor nenhum.

| Ferramenta | Chave |
|---|---|
| Ficha do Colosso | `pesodoceu.fichas.v1` |
| Gerador de Desafios | `pesodoceu.gerador.v1` |

## As três regras que importam

**1. Ficam salvos.** Fecha o aplicativo, desliga o celular, volta
semanas depois: está lá. Republicar o site troca o código e **não toca
nos dados**.

**2. São individuais.** Por aparelho e por navegador. O celular do
jogador guarda as fichas dele; o seu guarda as suas; um não vê o outro.
Nem eu vejo.

**3. O cofre é preso ao endereço.** Esta é a que pega todo mundo:

- o site `%(site)s` e o HTML solto na pasta `Rpg\\` são **dois cofres
  diferentes** — ficha salva num não aparece no outro;
- o aplicativo instalado e a aba do mesmo site **dividem o mesmo cofre**.

## O que apaga

- Limpar "dados de navegação" / "dados do site" no navegador.
- Aba anônima — não guarda nada desde o começo.
- **iPhone**: o Safari limpa o armazenamento de site não visitado há
  ~7 dias. **Instalar na Tela de Início escapa dessa regra** — é o
  motivo prático para instalar em vez de só abrir. No Android não existe
  esse prazo.

## Backup de verdade

As **duas** ferramentas têm **Exportar tudo** e **Importar**, e o
arquivo é o mesmo nos dois lados: `peso-do-ceu-AAAA-MM-DD.json`, com as
fichas de colosso **e** as fichas de inimigo juntas.

```json
{
  "peso_do_ceu": 1,
  "quando": "2026-09-22T21:40:00.000Z",
  "fichas":   [ … ],
  "inimigos": [ … ]
}
```

Funciona porque as duas dividem o mesmo armazenamento quando abertas do
mesmo endereço: exportar pela Ficha ou pelo Gerador dá o mesmo arquivo.

Três garantias do importador:

- **Soma, nunca substitui.** Ninguém perde o que já tinha ao importar.
- **Aceita o formato antigo**, de quando só a Ficha exportava.
- **Saneia o que entra.** Ficha incompleta, de versão velha ou editada
  à mão tem os buracos tapados antes de encostar na tela — fábrica que
  não existe mais volta para a primeira, nível fora de 1–10 é
  corrigido, listas faltando viram listas vazias. O mesmo vale para o
  que já estava guardado no aparelho.

> [!TIP] Conveniência não é backup
> O armazenamento do navegador é conveniência. Exportar de vez em quando
> — e antes de trocar de celular — é o que evita choro.
""" % {"site": SITE})


# ================================================================ RECEITA
def receita():
    nota("Receita — do zero ao ar", "Manual", "Publicação",
         ["oficina", "receita", "pwa", "site", "netlify"], """
# 📋 Receita — do zero ao ar

Lista de conferência para repetir em qualquer projeto, não só neste.

## 1. A página

- [ ] Um `index.html` que funciona sozinho, sem servidor.
- [ ] `<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">`
- [ ] Nada de recurso vindo de fora que você não controle.

## 2. As peças de aplicativo

- [ ] `manifest.webmanifest` com `id`, `name`, `short_name`, `start_url`,
      `scope`, `display: standalone`, `theme_color`, `background_color`,
      `icons` — ver [[O manifesto]].
- [ ] Ícones 192 e 512, em `any` **e** `maskable`, mais
      `apple-touch-icon` de 180 — ver [[Ícones de aplicativo]].
- [ ] `sw.js` com versão no nome do cache — ver [[O service worker]].
- [ ] No `<head>`: `link rel="manifest"`, `theme-color`,
      `apple-touch-icon`, `apple-mobile-web-app-capable`,
      `apple-mobile-web-app-title`.
- [ ] Registro do service worker e botão de instalar no fim do `<body>`.

## 3. Os cabeçalhos do servidor

- [ ] `sw.js`, `manifest.webmanifest` e `index.html` com
      `Cache-Control: max-age=0, must-revalidate`.
- [ ] Imagens podem ter cache longo.
- [ ] `X-Robots-Tag: noindex` se for material particular — o nosso é.

## 4. Publicar

- [ ] Criar o projeto no Netlify.
- [ ] Subir a pasta (zip arrastado ou o `.bat`) — ver
      [[Publicar no Netlify]].
- [ ] **Conferir o controle de acesso**: se estiver *team-only* em todos
      os contextos, o endereço pede login e o celular não instala.

## 5. Conferir no ar

- [ ] Página abre, título certo.
- [ ] Manifesto responde com o `name` esperado.
- [ ] Service worker registrado.
- [ ] Ícone 512 responde `200 image/png`.
- [ ] Abre no celular e oferece instalar.
- [ ] Depois de instalado: desligar o wi-fi e abrir de novo.

## 6. Anotar

- [ ] Endereço e id do projeto na nota do site.
- [ ] Versão publicada.
- [ ] O que mudou.

> [!NOTE] Sobre pôr no ar material particular
> Endereço do Netlify é público para quem tem o link. `noindex` mantém
> fora do Google, mas não é segredo. Para material realmente fechado,
> use senha de site (*Password protection*) ou não publique.
""")


# ================================================================== O SITE
def o_site():
    nota("🌐 O site O Peso do Céu", "Site", "Publicação",
         ["oficina", "site", "pwa", "ferramenta", "peso-do-ceu"], """
# 🌐 O site O Peso do Céu

As duas ferramentas de mesa, no ar e instaláveis. Publicado em **%(data)s**, versão **3.0.2**.

## Endereços

| | Endereço |
|---|---|
| A página que leva às duas | [%(site)s](%(site)s) |
| Ficha do Colosso | [%(site)s/ficha/](%(site)s/ficha/) |
| Gerador de Desafios | [%(site)s/gerador/](%(site)s/gerador/) |

Projeto no Netlify: `o-peso-do-ceu` · id `%(id)s`
Painel: `app.netlify.com/projects/o-peso-do-ceu`

## O que tem dentro

```
index.html                 3,5 KB   a página que leva às duas
netlify.toml                        cabeçalhos de cache e noindex
robots.txt                          fora dos buscadores
ficha/
  index.html             410,0 KB   a ferramenta + o jogo inteiro embutido
  manifest.webmanifest
  sw.js                    1,3 KB
  icone-192.png · icone-512.png
  icone-192-mascara.png · icone-512-mascara.png
  apple-touch-icon.png · favicon.png
gerador/
  index.html             404,6 KB
  … as mesmas peças
```

**21 arquivos, 1,1 MB** no total. Os dois `index.html` são grandes
porque levam o jogo dentro: 222 KB de dados (fábricas, Peças, chassis,
adversários com dom e segunda fase, itens, padrões de encontro, tabelas
de NPC) e 134 KB de arte vetorial em formato compacto. Nada é baixado de
fora — nem fonte, nem imagem, nem biblioteca.

## Como é montado

Quem monta é `gerador/pwa.py`, a partir dos dois HTML de arquivo único
que saem de `gerador/web.py`. Ele injeta o cabeçalho de PWA, acrescenta
o botão de instalar e o registro do service worker, gera os ícones com
o motor de arte e escreve o `netlify.toml`. Um comando, e a pasta
`site/` fica pronta para subir.

Ver [[Publicar no Netlify]] e [[Republicar depois de mexer]].

## Conferido no ar

- Manifesto servido, 4 ícones, `display: standalone`, nas duas.
- Service worker registrado nas duas.
- Arte desenhando (7 SVG na Ficha, 4 no Gerador).
- Lista de fábricas preenchida.
- O endereço abre sem pedir login.
- Os nove [[🎯 Padrões de encontro|padrões]] montam briga coerente: em
  doze sorteios de cada um, nenhum bicho marchando ao lado de fardado
  fora do padrão que pede isso.
- As oito abas de [[🧑 Gente do lado de cá|gente]] sorteiam, e loja
  sorteia estoque de verdade.

## Fora do ar, em arquivo único

Na pasta `Rpg\\` do computador estão as mesmas duas ferramentas em um
arquivo só cada — para mandar por WhatsApp ou usar sem internet nenhuma:
`O Peso do Céu - Ficha do Colosso.html` e
`O Peso do Céu - Gerador de Desafios.html`.

Lembrando que são **cofres de dados separados** do site — ver
[[Onde ficam os dados salvos]].

---

Ver também: [[🧰 As ferramentas]] · [[🛰️ O Peso do Céu]]
""" % {"site": SITE, "id": SITE_ID, "data": "22 de setembro de 2026"})


def gerar(destino=None):
    global SAIDA
    SAIDA = destino or os.path.join(RAIZ, "obsidian", "Oficina")
    NOTAS.clear()
    moc()
    oque()
    manifesto()
    sw()
    icones()
    publicar()
    republicar()
    dados()
    receita()
    o_site()
    os.makedirs(SAIDA, exist_ok=True)
    for nome, corpo in NOTAS.items():
        open(os.path.join(SAIDA, nome), "w", encoding="utf-8").write(corpo)
    print("Oficina: %d notas" % len(NOTAS))
    return len(NOTAS)


if __name__ == "__main__":
    gerar()
