# -*- coding: utf-8 -*-
"""
Gera os retratos dos 132 adversários no motor novo.

Sai em dois formatos, da mesma cena:
  tex/retratos/<id>.tex      TikZ, para livro, cartas, fichas e escudo
  obsidian/arte/<id>.svg     SVG, para o vault e as ferramentas de celular

Além dos retratos, escreve tex/retratos/cores.tex com todos os
\\definecolor de uma vez — são 132 desenhos dividindo a mesma paleta, e
declarar cor repetida 132 vezes estoura a memória do TeX.
"""
import sys, os, hashlib, json, unicodedata

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from dados.adversarios import COLOSSOS, FUNDAS, GENTE
from arte2.monta import monta, POSES
from arte2.bicho import monta_funda, PLANOS
from arte2 import gente as G
from arte2.saida import para_tikz, definicoes_tikz, para_svg
from arte2.simbolos import brasao, glifo, pips, GLIFOS

RAIZ = os.path.join(os.path.dirname(__file__), "..")
TEX = os.path.join(RAIZ, "tex", "retratos")
SVG = os.path.join(RAIZ, "obsidian", "arte")
ESCALA_TIKZ = 0.042           # 800 unidades -> ~33 mm

# o vocabulário antigo de armas não bate com o novo; isto traduz
ARMA = {
 "punho": "punho", "espada": "espada", "lanca": "alabarda",
 "canhao": "canhao", "fuzil": "fuzil", "garra": "garra",
 "garrao": "garra", "escudo": "escudo", "martelo": "martelo",
 "serra": "serra", "arpeu": "arpeu", "rede": "rede",
 "lamina_dupla": "lamina_dupla", "hadron": "hadron", "drone": "drone",
 "alabarda": "alabarda", "pod": "pod", "fuzil_longo": "fuzil_longo",
}

# pose por papel: o papel diz o que a máquina faz, e a pose mostra
POSE_POR_PAPEL = {
 "Lacaio":      ["parado", "tiro", "espreita"],
 "Batedor":     ["avanco", "espreita", "tiro"],
 "Atirador":    ["tiro", "ordena", "muralha"],
 "Apoio":       ["ordena", "parado", "muralha"],
 "Regular":     ["parado", "guarda", "tiro", "avanco"],
 "Bando":       ["avanco", "espreita", "pesado"],
 "Comandante":  ["ordena", "guarda", "muralha"],
 "Brutamontes": ["muralha", "pesado", "golpe", "guarda"],
 "Solo":        ["golpe", "avanco", "voo", "ordena", "pesado"],
}


def chave_ascii(nome):
    """Nome de arquivo sem acento: o \\input do LaTeX não gosta deles."""
    sem = unicodedata.normalize("NFD", nome)
    sem = "".join(c for c in sem if unicodedata.category(c) != "Mn")
    return "".join(c for c in sem if c.isalnum()).capitalize()


def _escolhe(ident, opcoes):
    """Escolha estável: o mesmo id sempre dá a mesma pose."""
    h = int(hashlib.md5(ident.encode("utf-8")).hexdigest()[:8], 16)
    return opcoes[h % len(opcoes)]


def pose_de(ident, papel, esc, extras):
    if extras.get("pose"):
        return extras["pose"]
    op = POSE_POR_PAPEL.get(papel, ["parado"])
    # voar só de Escalão 3 para cima
    if esc < 3:
        op = [p for p in op if p != "voo"] or ["parado"]
    return _escolhe(ident, op)


def tem_asas(esc, extras):
    """Asas e voo alto são material de fim de campanha."""
    return bool(extras.get("asas")) and esc >= 3


ART_GENTE = {
 "gtSoldado": ("grupo", dict(n=5, arma="fuzil")),
 "gtOficial": ("pessoa", dict(arma="radio")),
 "gtAtiradorDeElite": ("pessoa", dict(arma="fuzil", capacete=False)),
 "gtLancaFoguete": ("pessoa", dict(arma="lancador")),
 "gtEngenheiro": ("pessoa", dict(arma="ferramenta", capacete=False)),
 "gtEquipeFenda": ("grupo", dict(n=3, arma="carga")),
 "gtPilotoAPe": ("pessoa", dict(arma="carga", capacete=False)),
 "gtMultidao": ("grupo", dict(n=7, arma="")),
 "gtInterventor": ("pessoa", dict(arma="radio")),
 "gtBlindado": ("veiculo", dict(tipo="blindado")),
 "gtComboio": ("veiculo", dict(tipo="caminhao")),
 "gtHelicoptero": ("veiculo", dict(tipo="helicoptero")),
 "gtTrem": ("veiculo", dict(tipo="trem")),
 "gtDirigivel": ("veiculo", dict(tipo="dirigivel")),
}


def cena_de(ident):
    """A cena de um adversário qualquer, pelo id."""
    for c in COLOSSOS:
        if c[0] == ident:
            (_i, _n, esc, papel, fab, ad, ae, extras) = c[:8]
            return monta(fab, ARMA.get(ad, "punho"), ARMA.get(ae, "punho"),
                         pose_de(ident, papel, esc, extras),
                         mochila=extras.get("mochila"),
                         asas=tem_asas(esc, extras))
    for f in FUNDAS:
        if f[0] == ident:
            plano, params = f[4], (f[5] or {})
            return monta_funda(plano, **params)
    for g in GENTE:
        if g[0] == ident:
            tipo, kw = ART_GENTE.get(ident, ("pessoa", {}))
            return {"pessoa": G.pessoa, "grupo": G.grupo,
                    "veiculo": G.veiculo}[tipo](**kw)
    raise KeyError(ident)


def gerar():
    os.makedirs(TEX, exist_ok=True)
    os.makedirs(SVG, exist_ok=True)
    for f in os.listdir(TEX):
        if f.endswith(".tex"):
            os.remove(os.path.join(TEX, f))

    cores, n, bytes_tex = {}, 0, 0
    todos = ([c[0] for c in COLOSSOS] + [f[0] for f in FUNDAS]
             + [g[0] for g in GENTE])
    for ident in todos:
        cn = cena_de(ident)
        corpo, cores = para_tikz(cn, ESCALA_TIKZ, cores)
        open(os.path.join(TEX, ident + ".tex"), "w",
             encoding="utf-8").write(corpo)
        bytes_tex += len(corpo)
        open(os.path.join(SVG, ident + ".svg"), "w",
             encoding="utf-8").write(para_svg(cn, titulo=ident))
        n += 1

    # símbolos: brasões, glifos e pips, no mesmo arquivo de cores
    os.makedirs(os.path.join(TEX, "sim"), exist_ok=True)
    simbolos = []
    for fab in ("BRASA", "VESPERTINA", "CATEDRAL", "ARCO", "GRALHA",
                "SELO", "CARVAO", "OSSATURA"):
        simbolos.append(("br" + fab.capitalize(), brasao(fab), 0.16))
    for nome in GLIFOS:
        chave = "gl" + chave_ascii(nome)
        simbolos.append((chave, glifo(nome), 0.13))
    for k in (1, 2, 3, 4):
        simbolos.append(("pip%d" % k, pips(k), 0.13))
    for chave, cn, escl in simbolos:
        corpo, cores = para_tikz(cn, escl, cores)
        open(os.path.join(TEX, "sim", chave + ".tex"), "w",
             encoding="utf-8").write(corpo)
        open(os.path.join(SVG, chave + ".svg"), "w",
             encoding="utf-8").write(para_svg(cn, 100, 100, titulo=chave))

    open(os.path.join(TEX, "cores.tex"), "w",
         encoding="utf-8").write(definicoes_tikz(cores) + "\n")

    print("retratos: %d (%.1f MB de TikZ) · símbolos: %d · cores: %d"
          % (n, bytes_tex / 1e6, len(simbolos), len(cores)))
    return n


if __name__ == "__main__":
    gerar()
