# -*- coding: utf-8 -*-
"""
O baralho: Peças, itens, personagem e um cartão ilustrado por adversário.

Dois formatos:
  pequeno  68 x 88 mm, seis por folha  — Peças, itens, classe, povo
  grande   90 x 130 mm, quatro por folha — adversários, com retrato grande
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from dados.fabricas import FABRICAS, ORDEM
from dados.classes import CLASSES, CHASSIS, ANCESTRALIDADES, COMUNIDADES
from dados.itens import ARMAS_PILOTO, TRAJES, MECANICOS, ESTRANHOS
from dados.adversarios import COLOSSOS, FUNDAS, GENTE, ficha

SAIDA = os.path.join(os.path.dirname(__file__), "..", "tex")
ORD = {1: "1º", 2: "2º", 3: "3º", 4: "4º"}

PREAMBULO = r"""\documentclass[11pt]{book}
\input{preambulo}
\geometry{a4paper, left=7mm, right=7mm, top=10mm, bottom=10mm,
          headsep=0mm, footskip=0mm}
\pagestyle{empty}
\setlength{\parindent}{0pt}\setlength{\parskip}{0pt}
\setlength{\topskip}{0pt}

\newlength{\cl}\setlength{\cl}{68mm}
\newlength{\ch}\setlength{\ch}{88mm}
\newlength{\clg}\setlength{\clg}{90mm}
\newlength{\chg}\setlength{\chg}{130mm}

% --- carta pequena: x, y, cor, nome, etiqueta, custo, corpo
\newcommand{\cartaP}[8]{%
  \begin{scope}[shift={(#1,#2)}]
    \fill[papel] (0,0) rectangle (\cl,\ch);
    \draw[tinta, line width=0.9pt] (0,0) rectangle (\cl,\ch);
    \fill[#3] (0,\ch) rectangle (\cl,\ch-9mm);
    \fill[#3!22!papel] (0,\ch-9mm) rectangle (\cl,\ch-15mm);
    \node[anchor=north west, text=papel, inner sep=0pt,
          font=\rotulo\bfseries\fontsize{10}{11}\selectfont]
      at (2.6mm,\ch-2.6mm) {\MakeUppercase{#4}};
    \node[anchor=north east, text=papel, inner sep=0pt,
          font=\rotulo\fontsize{6.8}{8}\selectfont]
      at (\cl-2.6mm,\ch-3.0mm) {\MakeUppercase{#5}};
    \node[anchor=north west, inner sep=0pt, text=tinta,
          font=\rotulo\bfseries\fontsize{7.4}{9}\selectfont]
      at (16mm,\ch-10.4mm) {\MakeUppercase{#6}};
    \node[anchor=north west, inner sep=0pt,
          text width=\dimexpr\cl-6mm\relax, align=justify,
          font=\fontsize{8.2}{10.4}\selectfont]
      at (3mm,\ch-17mm) {#7};
    \node[anchor=west, inner sep=0pt] at (2.8mm,\ch-12.4mm) {#8};
    \node[anchor=south east, inner sep=0pt,
          font=\rotulo\fontsize{5.4}{6.4}\selectfont, color=cinza45]
      at (\cl-2.4mm,1.9mm) {O PESO DO CÉU};
  \end{scope}}

% --- carta grande de adversário: x, y, cor, nome, etiqueta, retrato,
%     linha de ficha, corpo
\newcommand{\cartaG}[9]{%
  \begin{scope}[shift={(#1,#2)}]
    \fill[papel] (0,0) rectangle (\clg,\chg);
    \draw[tinta, line width=0.9pt] (0,0) rectangle (\clg,\chg);
    \fill[#3] (0,\chg) rectangle (\clg,\chg-9.5mm);
    \node[anchor=north west, text=papel, inner sep=0pt,
          font=\rotulo\bfseries\fontsize{11}{12}\selectfont]
      at (3mm,\chg-2.6mm) {\MakeUppercase{#4}};
    \node[anchor=north east, text=papel, inner sep=0pt,
          font=\rotulo\fontsize{6.8}{8}\selectfont]
      at (\clg-3mm,\chg-3.2mm) {\MakeUppercase{#5}};
    % janela da arte
    \fill[#3!20!papel] (2.5mm,\chg-62mm) rectangle (\clg-2.5mm,\chg-10.5mm);
    \fill[#3!42!papel] (2.5mm,\chg-62mm) rectangle (\clg-2.5mm,\chg-53mm);
    \fill[#3!8!papel] (2.5mm,\chg-24mm) rectangle (\clg-2.5mm,\chg-10.5mm);
    \draw[tinta, line width=0.45pt]
      (2.5mm,\chg-62mm) rectangle (\clg-2.5mm,\chg-10.5mm);
    \node[inner sep=0pt] at (\clg/2,\chg-36.5mm) {#6};
    % ficha
    \node[anchor=north, inner sep=0pt, font=\rotulo\fontsize{7.6}{9.4}\selectfont]
      at (\clg/2,\chg-64mm) {#7};
    \draw[tinta, line width=0.4pt]
      (3mm,\chg-73mm) -- (\clg-3mm,\chg-73mm);
    \node[anchor=north west, inner sep=0pt,
          text width=\dimexpr\clg-7mm\relax, align=justify,
          font=\fontsize{7.6}{9.6}\selectfont]
      at (3.5mm,\chg-75mm) {#8};
    % fita de símbolos, na faixa escura do pé da arte: ali sempre sobra
    % espaço, e a marca fica na mesma altura em todas as cartas
    \node[anchor=west, inner sep=0pt] at (4mm,\chg-57.5mm) {#9};
    \node[anchor=south east, inner sep=0pt,
          font=\rotulo\fontsize{5.4}{6.4}\selectfont, color=cinza45]
      at (\clg-2.6mm,2.6mm) {O PESO DO CÉU};
  \end{scope}}

\newcommand{\folha}[1]{\noindent\begin{tikzpicture}[baseline=0pt]#1%
  \end{tikzpicture}\par\clearpage}

\begin{document}
"""


# --------------------------------------------------------- os símbolos
# Nome se lê; símbolo se reconhece do outro lado da mesa. Toda carta
# leva uma fita: quem fez, o que é, com o que machuca e o Escalão.
BRASAO = {"BRASA": "brBrasa", "VESPERTINA": "brVespertina",
          "CATEDRAL": "brCatedral", "ARCO": "brArco", "GRALHA": "brGralha",
          "SELO": "brSelo", "CARVAO": "brCarvao", "OSSATURA": "brOssatura"}


def _sem_acento(nome):
    import unicodedata
    d = unicodedata.normalize("NFD", nome)
    d = "".join(c for c in d if unicodedata.category(c) != "Mn")
    return "".join(c for c in d if c.isalnum()).capitalize()


def marca(*partes):
    """Fita de símbolos. Cada parte é um nome de arquivo, ou None."""
    fora = []
    for p in partes:
        if not p:
            continue
        esc = 0.32 if p.startswith("br") else (0.62 if p.startswith("pip")
                                              else 0.35)
        fora.append("\\simb{%s}{%.2f}" % (p, esc))
    return "\\,".join(fora)


def glifo_de(nome):
    return "gl" + _sem_acento(nome) if nome else None


def pagina(cartas, macro="cartaP"):
    if macro == "cartaP":
        cols, lin, dx, dy, alt = 3, 3, 65.0, 90.0, 88.0
        cols, lin, dx, dy, alt = 2, 3, 92.0, 90.0, 88.0
    else:
        cols, lin, dx, dy, alt = 2, 2, 94.0, 132.0, 130.0
    por = cols * lin
    s = ""
    for i in range(0, len(cartas), por):
        bloco = cartas[i:i + por]
        corpo = ""
        for j, c in enumerate(bloco):
            x = (j % cols) * dx
            y = -((j // cols) + 1) * dy + (dy - alt)
            corpo += "\\%s{%.2fmm}{%.2fmm}{%s}%%\n" % (
                macro, x, y, "}{".join(c))
        s += "\\folha{%%\n%s}\n\n" % corpo
    return s


def divisoria(titulo, linha, cor="tinta"):
    return ("\\vspace*{\\fill}\\begin{center}\n"
            "{\\displayf\\bfseries\\fontsize{30}{34}\\selectfont\\color{%s} %s}"
            "\\\\[4mm]\n{\\color{%s}\\rule{80mm}{1.4pt}}\\\\[4mm]\n"
            "{\\rotulo\\fontsize{9.5}{12}\\selectfont %s}\n"
            "\\end{center}\\vspace*{\\fill}\\clearpage\n\n"
            % (cor, titulo, cor, linha))


def montar():
    s = PREAMBULO
    s += ("\\vspace*{24mm}\\begin{center}\n"
          "{\\displayf\\bfseries\\fontsize{34}{38}\\selectfont O PESO DO CÉU}"
          "\\\\[4mm]{\\color{tinta}\\rule{92mm}{1.6pt}}\\\\[5mm]\n"
          "{\\rotulo\\fontsize{13}{16}\\selectfont O BARALHO}\\\\[14mm]\n"
          "\\retrato{grFrankenstein}{2.20}\\\\[12mm]\n"
          "{\\rotulo\\fontsize{8.4}{11}\\selectfont\\color{cinza45}\n"
          "PEÇAS · ITENS · PERSONAGEM · ADVERSÁRIOS}\n"
          "\\end{center}\\clearpage\n\n")
    total = 0

    # ---------------------------------------------------------- Peças
    s += divisoria("As Peças", "160 cartas · vinte por fábrica · "
                   "é com elas que se monta a máquina")
    for k in ORDEM:
        f = FABRICAS[k]
        cartas = []
        for (niv, nome, tipo, custo, texto) in f["pecas"]:
            if tipo == "Fixa":
                cst = "Fixa \\textbullet\\ sem custo"
            elif tipo == "Ativa":
                cst = "Ativa \\textbullet\\ %d Estresse" % custo
            else:
                cst = "Tensa \\textbullet\\ Medo %d ou mais" % custo
            cartas.append((f["cor"], nome,
                           "%s \\textbullet\\ N%d" % (k.capitalize(), niv),
                           cst, texto,
                           marca(BRASAO[k], glifo_de(tipo))))
        s += pagina(cartas)
        total += len(cartas)

    # ---------------------------------------------------------- itens
    s += divisoria("Os itens", "armas, trajes, ferramenta de doca e as "
                   "coisas que ninguém explica")
    cartas = []
    for (n, tr, al, d, b, m, etq, tx) in ARMAS_PILOTO:
        bon = "+%d" % b if b else ""
        sub = "%s \\textbullet\\ %s \\textbullet\\ \\dado{%s%s} \\textbullet\\ %d mão" % (
            tr, al, d, bon, m)
        if etq:
            sub += " \\textbullet\\ %s" % etq
        dano_tipo = "Energia" if any(
            w in (n + " " + tx).lower()
            for w in ("laser", "plasma", "hádron", "hadron", "feixe",
                      "elétric", "eletric", "choque", "arco")) else "Físico"
        sub += " \\textbullet\\ %s" % dano_tipo
        cartas.append(("tinta", n, "Arma de piloto", sub, tx,
                       marca("glArma", glifo_de(dano_tipo))))
    for (n, bl, lm, ls, tx) in TRAJES:
        cartas.append(("tinta", n, "Traje",
                       "Blindagem %d \\textbullet\\ Limiares %d/%d" % (bl, lm, ls),
                       tx, marca("glTraje")))
    for (n, o, u, tx) in MECANICOS:
        cor = FABRICAS[o]["cor"] if o in FABRICAS else "tinta"
        cartas.append((cor, n, "Item mecânico",
                       "%s \\textbullet\\ %s" % (
                           o.capitalize() if o != "—" else "sem origem", u), tx,
                       marca(BRASAO.get(o), "glMecanico")))
    for (n, r, tx) in ESTRANHOS:
        cartas.append(("ossC", n, "Coisa estranha", r, tx,
                       marca("glEstranho")))
    s += pagina(cartas)
    total += len(cartas)

    # ------------------------------------------------------ personagem
    s += divisoria("O personagem", "classes, subclasses, ancestralidades, "
                   "comunidades e chassis")
    cartas = []
    for c in CLASSES:
        f = FABRICAS[c["fabrica"]]
        corpo = ("\\emph{%s}\\par\\vspace{1.2mm}\n"
                 "\\textbf{Evasão %d \\textbullet\\ PV %d \\textbullet\\ chassi %s}"
                 "\\par\\vspace{1.2mm}\n\\textbf{%s.} %s\\par\\vspace{1mm}\n"
                 "\\textbf{%s (3 Esperança).} %s"
                 % (c["chamada"], c["evasao"], c["pv"], c["chassi"],
                    c["traco"][0], c["traco"][1],
                    c["esperanca"][0], c["esperanca"][1]))
        cartas.append((f["cor"], c["nome"], "Classe",
                       "Licença: %s" % f["nome"], corpo,
                       marca(BRASAO[c["fabrica"]], "glClasse")))
    for c in CLASSES:
        f = FABRICAS[c["fabrica"]]
        for sc in c["subclasses"]:
            corpo = ("\\emph{%s}\\par\\vspace{1.2mm}\n"
                     "\\textbf{Fundação.} %s\\par\\vspace{1mm}\n"
                     "\\textbf{Especialização (5).} %s\\par\\vspace{1mm}\n"
                     "\\textbf{Maestria (8).} %s"
                     % (sc["linha"], sc["f"], sc["e"], sc["m"]))
            cartas.append((f["cor"], sc["nome"], "Subclasse",
                           c["nome"], corpo,
                           marca(BRASAO[c["fabrica"]], "glSubclasse")))
    for (nome, linha, texto, a, b) in ANCESTRALIDADES:
        corpo = ("\\emph{%s}\\par\\vspace{1.2mm}\n"
                 "\\textbf{%s.} %s\\par\\vspace{1mm}\n\\textbf{%s.} %s"
                 % (linha, a[0], a[1], b[0], b[1]))
        cartas.append(("tinta", nome, "Ancestralidade",
                       "duas características", corpo, marca("glGente")))
    for (nome, linha, texto, feat) in COMUNIDADES:
        cartas.append(("tinta", nome, "Comunidade", "uma característica",
                       "\\emph{%s}\\par\\vspace{1.2mm}\n%s" % (linha, feat),
                       marca("glGente")))
    for c in CHASSIS:
        (nome, fab, porte, est, eva, lma, lse, bli, enc, des, nuc) = c
        corpo = ("{\\rotulo\\fontsize{7.4}{9.2}\\selectfont "
                 "ESTRUTURA \\textbf{%d} \\textbullet\\ EVASÃO \\textbf{%d} "
                 "\\textbullet\\ LIMIARES \\textbf{%d/%d}\\par "
                 "BLINDAGEM \\textbf{%d} \\textbullet\\ ENCAIXES "
                 "\\textbf{%d} \\textbullet\\ DESLOC. \\textbf{%d}}"
                 "\\par\\vspace{1.4mm}\n\\textbf{Núcleo — %s.} %s"
                 % (est, eva, lma, lse, bli, enc, des, nuc[0], nuc[1]))
        cartas.append((FABRICAS[fab]["cor"], nome, "Chassi %s" % porte,
                       FABRICAS[fab]["nome"], corpo,
                       marca(BRASAO[fab], "glChassi")))
    s += pagina(cartas)
    total += len(cartas)

    # ----------------------------------------------------- adversários
    s += divisoria("Os adversários", "%d cartas ilustradas · colossos, " % (len(COLOSSOS)+len(FUNDAS)+len(GENTE)) +
                   "Fundas, gente e veículo")
    cartas = []

    def linha_ficha(esc, papel):
        eva, ma, se, atq, dano, est = ficha(esc, papel)
        return ("EVASÃO \\textbf{%d} \\ \\textbullet\\ \\ LIMIARES "
                "\\textbf{%d/%d} \\ \\textbullet\\ \\ ESTRUTURA \\textbf{%d}"
                "\\\\[0.6mm] ATAQUE \\textbf{+%d} \\ \\textbullet\\ \\ DANO "
                "\\dado{%s}" % (eva, ma, se, est, atq, dano))

    def corpo_adv(desc, motivos, feats, arma, alcance):
        t = "%s\\par\\vspace{1mm}\n" % desc
        t += ("{\\rotulo\\fontsize{6.6}{8}\\selectfont\\color{cinza45} "
              "MOTIVOS}\\ \\emph{%s}\\par\\vspace{1mm}\n" % motivos)
        t += "\\textbf{%s} \\textbullet\\ %s\\par\\vspace{1mm}\n" % (arma, alcance)
        for (fn, ft, fx) in feats:
            t += "\\textbf{%s — %s.} %s\\par\\vspace{0.7mm}\n" % (fn, ft, fx)
        return t

    for c in COLOSSOS:
        (ident, nome, esc, papel, fab, _d, _e, _x,
         alcance, arma, desc, motivos, feats) = c
        tipo = (_x or {}).get("tipo", "Físico")
        cartas.append((FABRICAS[fab]["cor"], nome,
                       "%s \\textbullet\\ Escalão %s \\textbullet\\ %s"
                       % (papel, ORD[esc], tipo),
                       "\\retrato{%s}{1.40}" % ident,
                       linha_ficha(esc, papel),
                       corpo_adv(desc, motivos, feats, arma, alcance),
                       marca(BRASAO[fab], glifo_de(papel), glifo_de(tipo),
                             "pip%d" % esc)))
    for f in FUNDAS:
        (ident, nome, esc, papel, _pl, _pa, alcance, arma, desc,
         motivos, feats) = f
        cartas.append(("ossC", nome,
                       "Funda \\textbullet\\ %s \\textbullet\\ Escalão %s"
                       % (papel, ORD[esc]),
                       "\\retrato{%s}{1.40}" % ident,
                       linha_ficha(esc, papel),
                       corpo_adv(desc, motivos, feats, arma, alcance),
                       marca("glFunda", glifo_de(papel), "pip%d" % esc)))
    for g in GENTE:
        (ident, nome, esc, papel, _des, alcance, arma, desc,
         motivos, feats) = g
        cartas.append(("tinta", nome,
                       "%s \\textbullet\\ Escalão %s" % (papel, ORD[esc]),
                       "\\retrato{%s}{1.40}" % ident,
                       linha_ficha(esc, papel),
                       corpo_adv(desc, motivos, feats, arma, alcance),
                       marca("glGente", glifo_de(papel), "pip%d" % esc)))
    s += pagina(cartas, macro="cartaG")
    total += len(cartas)

    s += "\\end{document}\n"
    open(os.path.join(SAIDA, "baralho.tex"), "w", encoding="utf-8").write(s)
    print("baralho.tex: %d cartas" % total)


if __name__ == "__main__":
    montar()
