# -*- coding: utf-8 -*-
"""
Despeja O Peso do Céu dentro de um vault do Obsidian.

Uma nota por coisa: cada fábrica, cada Peça, cada classe, cada chassi,
cada ancestralidade, cada comunidade, cada um dos 132 adversários, cada
item e cada regra. Tudo com Propriedades no padrão do vault do Anuah
(tipo / categoria / tags / pdf_page), o mesmo cartão de "Fonte no PDF
Original" apontando para a página certa do livro, wikilinks entre as
notas e um MOC por pasta.

    python3 gerador/obsidian.py

Sai em obsidian/O Peso do Céu/, pronto para arrastar para o vault.
"""
import sys, os, re, json, shutil, unicodedata, subprocess

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from dados.fabricas import FABRICAS, ORDEM
from dados.classes import CLASSES, CHASSIS, ANCESTRALIDADES, COMUNIDADES
from dados.itens import ARMAS_PILOTO, TRAJES, MECANICOS, ESTRANHOS
from dados.adversarios import (LINHA, PAPEL, ficha, COLOSSOS, FUNDAS, GENTE)

RAIZ = os.path.join(os.path.dirname(__file__), "..")
LIVRO = os.path.join(RAIZ, "tex", "livro.pdf")
SAIDA = os.path.join(RAIZ, "obsidian", "O Peso do Céu")
PDF_NOME = "O-Peso-do-Ceu-Livro.pdf"

HUB = "🛰️ O Peso do Céu"
ARTE = "arte"          # pasta das imagens dentro da pasta do jogo


def figura(ident, legenda=""):
    """Embute o SVG do adversário na nota. O Obsidian renderiza direto."""
    if not ident:
        return ""
    s = "![[%s/%s.svg]]\n" % (ARTE, ident)
    if legenda:
        s += "*%s*\n" % legenda
    return s + "\n"
ORD = {1: "1º", 2: "2º", 3: "3º", 4: "4º"}


# ------------------------------------------------------------ LaTeX -> md
SUBS = [
    (r"\\textbf\{([^{}]*)\}", r"**\1**"),
    (r"\\termo\{([^{}]*)\}", r"**\1**"),
    (r"\\emph\{([^{}]*)\}", r"*\1*"),
    (r"\\textit\{([^{}]*)\}", r"*\1*"),
    (r"\\dado\{([^{}]*)\}", r"`\1`"),
    (r"\\maq\{([^{}]*)\}", r"*\1*"),
    (r"\\textbullet\\?", "·"),
    (r"\$\\times\$", "×"),
    (r"\$\\geq\$", "≥"),
    (r"\$\\leq\$", "≤"),
    (r"\\%", "%"),
    (r"\\&", "&"),
    (r"\\ ", " "),
    (r"~", " "),
    (r"\\\\", "\n"),
]


def md(t):
    """Converte o LaTeX das fontes para Markdown de Obsidian."""
    if t is None:
        return ""
    t = str(t)
    anterior = None
    while anterior != t:                       # aninhamentos
        anterior = t
        for a, b in SUBS:
            t = re.sub(a, b, t)
    t = t.replace("--", "–")
    t = re.sub(r"[ \t]+", " ", t)
    return t.strip()


def titulo(nome):
    """MILÍCIA -> Milícia; QUEBRA-LINHA -> Quebra-Linha."""
    pequenas = {"de", "da", "do", "das", "dos", "e", "a", "o", "em", "no", "na"}
    partes = re.split(r"(\s+|-)", nome.lower())
    saida, primeira = [], True
    for p in partes:
        if not p.strip() or p == "-":
            saida.append(p)
            continue
        if p in pequenas and not primeira:
            saida.append(p)
        else:
            saida.append(p[0].upper() + p[1:])
        primeira = False
    return "".join(saida)


def limpo(nome):
    """Tira do nome de arquivo o que o Obsidian usa em links."""
    return re.sub(r'[#|^\[\]:%*?"<>/\\]', "", nome).strip()


# ------------------------------------------------------- índice de páginas
def indice_paginas():
    cache = "/tmp/paginas.json"
    if os.path.exists(cache):
        paginas = json.load(open(cache))
    else:
        paginas = []
        n = 1
        while True:
            r = subprocess.run(["pdftotext", "-f", str(n), "-l", str(n),
                                LIVRO, "-"], capture_output=True, text=True)
            if r.returncode != 0 or n > 400:
                break
            paginas.append(r.stdout)
            n += 1
        json.dump(paginas, open(cache, "w"))
    return [unicodedata.normalize("NFC", p) for p in paginas]


PAGINAS = indice_paginas()
# o pdftotext quebra nomes longos no meio das células de tabela, então
# procuramos também numa versão achatada de cada página
PLANAS = [re.sub(r"\s+", " ", p) for p in PAGINAS]


def pagina_de(*alvos):
    """
    Primeira página do livro em que o nome aparece sozinho numa linha.
    Cai para 'aparece em qualquer lugar' se não achar, e para None.
    """
    alvos = [unicodedata.normalize("NFC", a).strip() for a in alvos if a]
    for i, txt in enumerate(PAGINAS):
        linhas = [l.strip() for l in txt.split("\n")]
        for a in alvos:
            if a in linhas or a.upper() in linhas:
                return i + 1
    for i, txt in enumerate(PLANAS):
        alto = txt.upper()
        for a in alvos:
            if a.upper() in alto:
                return i + 1
    # nome quebrado entre duas linhas
    for i, txt in enumerate(PLANAS):
        alto = txt.upper()
        for a in alvos:
            if re.search(r"\s+".join(re.escape(x) for x in a.upper().split()),
                         alto):
                return i + 1
    return None


# ------------------------------------------------------------- escrita
ARQUIVOS = {}     # caminho relativo -> conteúdo
NOMES = {}        # nome de nota -> quantas vezes apareceu


def frente(tipo, categoria, tags, pag=None, extra=None):
    s = "---\ntipo: %s\ncategoria: %s\ntags:\n" % (tipo, categoria)
    for t in tags:
        s += "  - %s\n" % t
    if extra:
        for k, v in extra.items():
            s += "%s: %s\n" % (k, v)
    if pag:
        s += "pdf_page: %d\n" % pag
    s += "jogo: O Peso do Céu\n---\n\n"
    return s


def fonte(pag, legenda):
    if not pag:
        return ""
    return ("> [!INFO] Fonte no PDF Original\n"
            "> 📖 **[[%s#page=%d|Consultar Texto Original no PDF "
            "(Página %d) — %s]]**\n\n" % (PDF_NOME, pag, pag, legenda))


def rodape(*links):
    s = "\n---\n\n## Links Relacionados\n"
    for l in links:
        if l:
            s += "- [[%s]]\n" % l
    s += "- [[%s]]\n" % HUB
    return s


def nota(pasta, nome, conteudo):
    caminho = os.path.join(pasta, limpo(nome) + ".md") if pasta else \
              limpo(nome) + ".md"
    ARQUIVOS[caminho] = conteudo


# =========================================================== AS FÁBRICAS
EMOJI_FAB = {"BRASA": "🔥", "VESPERTINA": "🕊️", "CATEDRAL": "⛪", "ARCO": "⚓",
             "GRALHA": "🔧", "SELO": "🛡️", "CARVAO": "🌑", "OSSATURA": "🦴"}

CUSTO_TXT = {0: "não custa nada", 1: "1 Estresse", 2: "2 Estresse",
             3: "3 Estresse"}


def txt_peca(niv, nome, tipo, custo, texto):
    if tipo == "Fixa":
        etq = "Fixa · sempre ligada"
    elif tipo == "Ativa":
        etq = "Ativa · %s" % CUSTO_TXT.get(custo, "%d Estresse" % custo)
    else:
        etq = "Tensa · liga com %d+ de Medo na mesa" % (custo or 4)
    return etq


def fabricas():
    for k in ORDEM:
        f = FABRICAS[k]
        pag = pagina_de(f["nome"], k)
        nome_nota = titulo(f["nome"])
        s = frente("Fábrica", "Fábrica", ["peso-do-ceu", "fabrica",
                                          "fabrica/" + k.lower()], pag)
        s += "# %s %s\n\n" % (EMOJI_FAB[k], nome_nota)
        s += fonte(pag, "A fábrica %s" % nome_nota)
        s += "*%s*\n\n" % md(f["linha"])
        s += "> %s\n\n---\n\n" % md(f["lema"])
        s += "## A proposta\n\n%s\n\n" % md(f["proposta"])
        s += "## A cultura\n\n%s\n\n" % md(f["cultura"])
        s += "## No olho\n\n%s\n\n---\n\n" % md(f["estetica"])

        s += "## Os chassis da casa\n\n"
        for ch in CHASSIS:
            if ch[1] == k:
                s += ("- [[%s]] — %s · Estrutura %d · Evasão %d · "
                      "Blindagem %d · %d encaixes\n"
                      % (nome_chassi[ch[0]], ch[2], ch[3], ch[4],
                         ch[7], ch[8]))
        s += "\n## A classe licenciada\n\n"
        for c in CLASSES:
            if c["fabrica"] == k:
                s += "- [[%s]] — %s\n" % (nome_classe[c["nome"]], md(c["chamada"]))

        s += "\n## As quinze Peças\n\n"
        for niv in (1, 2, 3, 4, 5):
            linha = [p for p in f["pecas"] if p[0] == niv]
            if not linha:
                continue
            s += "**Nível %d**\n\n" % niv
            for (n, nome, tipo, custo, texto) in linha:
                s += "- [[%s]] — *%s*\n" % (nome_peca[(k, nome)],
                                            txt_peca(n, nome, tipo, custo, texto))
            s += "\n"
        s += rodape("⚙️ As Fábricas", "🔩 As Peças")
        nota("Fábricas", nome_nota, s)

        # uma nota por Peça
        for (niv, nome, tipo, custo, texto) in f["pecas"]:
            p2 = pagina_de(nome) or pag
            etq = txt_peca(niv, nome, tipo, custo, texto)
            t = frente("Peça", "Peça de fábrica",
                       ["peso-do-ceu", "peca", "peca/" + tipo.lower(),
                        "fabrica/" + k.lower()], p2,
                       {"nivel": niv, "fabrica": nome_fabrica[k],
                        "custo_estresse": custo})
            t += "# %s\n\n" % nome_peca[(k, nome)]
            t += fonte(p2, "Peça %s (%s)" % (nome, f["nome"]))
            t += "*Nível %d · %s · [[%s]]*\n\n---\n\n" % (
                niv, etq, nome_fabrica[k])
            t += "%s\n" % md(texto)
            if tipo == "Tensa":
                t += ("\n> [!WARNING] Peça Tensa\n"
                      "> Não custa nada, mas só funciona enquanto o Mestre "
                      "tiver **%d ou mais de Medo**. Ele não pode gastar Medo "
                      "só para desligar a Peça — mas se o gasto tem efeito na "
                      "ficção, ela apaga junto. Ver [[O Medo]].\n" % (custo or 4))
            elif tipo == "Ativa":
                t += ("\n> [!NOTE] Peça Ativa\n"
                      "> Usar é uma ação e custa **%s**. Quem paga é o corpo "
                      "do piloto — ver [[Estresse]].\n" % CUSTO_TXT.get(
                          custo, "%d Estresse" % custo))
            t += rodape(nome_fabrica[k], "🔩 As Peças")
            nota("Peças", nome_peca[(k, nome)], t)


# ============================================================ OS CHASSIS
def chassis():
    for ch in CHASSIS:
        (nome, fab, porte, est, eva, lma, lse, bli, enc, desl, nucleo) = ch
        pag = pagina_de(nome)
        s = frente("Chassi", "Colosso",
                   ["peso-do-ceu", "chassi", "fabrica/" + fab.lower()], pag,
                   {"porte": porte, "fabrica": nome_fabrica[fab],
                    "estrutura": est, "evasao": eva, "blindagem": bli,
                    "encaixes": enc})
        s += "# %s\n\n" % nome_chassi[nome]
        s += fonte(pag, "Chassi %s" % nome)
        s += "*%s · porte %s · [[%s]]*\n\n---\n\n" % (
            titulo(nome), porte, nome_fabrica[fab])
        s += "| | |\n|---|---|\n"
        s += "| **Estrutura** | %d |\n" % est
        s += "| **Evasão** | %d |\n" % eva
        s += "| **Limiares** | %d / %d |\n" % (lma, lse)
        s += "| **Blindagem** | %d |\n" % bli
        s += "| **Encaixes** | %d |\n" % enc
        s += "| **Deslocamento** | %d |\n\n" % desl
        s += "## Núcleo — %s\n\n%s\n\n" % (md(nucleo[0]), md(nucleo[1]))
        s += ("> [!TIP] Uma vez por sortida\n"
              "> Abrir o Núcleo é uma ação e só acontece uma vez por "
              "sortida. Ver [[O Combate]].\n")
        usado = [nome_classe[c["nome"]] for c in CLASSES if c["chassi"] == nome]
        if usado:
            s += "\n## Quem começa nele\n\n"
            for u in usado:
                s += "- [[%s]]\n" % u
        s += rodape(nome_fabrica[fab], "🤖 O Colosso")
        nota(os.path.join("Colossos", "Chassis"), nome_chassi[nome], s)


# ============================================================ AS CLASSES
def classes():
    for c in CLASSES:
        pag = pagina_de(c["nome"])
        nome_nota = nome_classe[c["nome"]]
        s = frente("Classe", "Piloto",
                   ["peso-do-ceu", "classe", "fabrica/" + c["fabrica"].lower()],
                   pag, {"fabrica": nome_fabrica[c["fabrica"]],
                         "chassi_inicial": nome_chassi[c["chassi"]],
                         "evasao": c["evasao"], "pv": c["pv"]})
        s += "# %s\n\n" % nome_nota
        s += fonte(pag, "A classe %s" % nome_nota)
        s += "*Licença de fábrica: [[%s]] · chassi de partida: [[%s]]*\n\n" % (
            nome_fabrica[c["fabrica"]], nome_chassi[c["chassi"]])
        s += "> %s\n\n---\n\n" % md(c["chamada"])
        s += "**Evasão %d · PV %d**\n\n" % (c["evasao"], c["pv"])
        s += "**Na cabine.** %s\n\n---\n\n" % md(c["itens"])
        s += "## %s — traço, sempre ligado\n\n%s\n\n" % (
            md(c["traco"][0]), md(c["traco"][1]))
        s += "## %s — 3 Esperança\n\n%s\n\n---\n\n" % (
            md(c["esperanca"][0]), md(c["esperanca"][1]))
        s += "## As duas subclasses\n\n"
        for sc in c["subclasses"]:
            s += "### %s\n\n*%s*\n\n" % (md(sc["nome"]), md(sc["linha"]))
            s += "- **Fundação (nível 1).** %s\n" % md(sc["f"])
            s += "- **Especialização (nível 5).** %s\n" % md(sc["e"])
            s += "- **Maestria (nível 8).** %s\n\n" % md(sc["m"])
        s += rodape(nome_fabrica[c["fabrica"]], nome_chassi[c["chassi"]],
                    "🎖️ O Piloto", "Subir de Nível")
        nota(os.path.join("Pilotos", "Classes"), nome_nota, s)


# ======================================================= ANCESTRALIDADES
def povo():
    for a in ANCESTRALIDADES:
        nome, linha, texto, fa, fb = a
        pag = pagina_de(nome)
        n = titulo(nome)
        s = frente("Ancestralidade", "Piloto",
                   ["peso-do-ceu", "ancestralidade", "povo"], pag)
        s += "# %s\n\n" % nome_anc[nome]
        s += fonte(pag, "Ancestralidade %s" % n)
        s += "*%s*\n\n---\n\n%s\n\n---\n\n" % (md(linha), md(texto))
        s += "## O que ela dá\n\n"
        s += "- **%s.** %s\n" % (md(fa[0]), md(fa[1]))
        s += "- **%s.** %s\n" % (md(fb[0]), md(fb[1]))
        s += rodape("🧬 Ancestralidades", "🎖️ O Piloto")
        nota(os.path.join("Pilotos", "Povo"), nome_anc[nome], s)

    for c in COMUNIDADES:
        nome, linha, texto, feat = c
        pag = pagina_de(nome)
        n = titulo(nome)
        s = frente("Comunidade", "Piloto",
                   ["peso-do-ceu", "comunidade", "povo"], pag)
        s += "# %s\n\n" % nome_com[nome]
        s += fonte(pag, "Comunidade %s" % n)
        s += "*%s*\n\n---\n\n%s\n\n---\n\n" % (md(linha), md(texto))
        s += "## O que ela dá\n\n- **%s.** %s\n" % (md(feat[0]), md(feat[1]))
        s += rodape("🏘️ Comunidades", "🎖️ O Piloto")
        nota(os.path.join("Pilotos", "Povo"), nome_com[nome], s)


# ============================================================= OS ITENS
def itens():
    for (nome, traco, alcance, dado, prof, bonus, tag, desc) in ARMAS_PILOTO:
        pag = pagina_de(nome)
        s = frente("Item", "Arma de piloto",
                   ["peso-do-ceu", "item", "arma"], pag,
                   {"traco": traco, "alcance": alcance})
        s += "# %s\n\n" % nome_item[nome]
        s += fonte(pag, "Arma %s" % nome)
        linha = "*%s · %s · `%s+%d`*" % (traco, alcance, dado, bonus)
        if tag:
            linha += "  \n**%s**" % md(tag)
        s += linha + "\n\n---\n\n%s\n" % md(desc)
        if tag and "Antim" in str(tag):
            s += ("\n> [!IMPORTANT] Antimáquina\n"
                  "> Cancela o debuff de gente contra colosso: rolagem "
                  "normal e dano cheio. Ver [[Escala]].\n")
        s += rodape("🎒 Itens e Equipamento")
        nota("Itens", nome_item[nome], s)

    for (nome, bli, lma, lse, desc) in TRAJES:
        pag = pagina_de(nome)
        s = frente("Item", "Traje", ["peso-do-ceu", "item", "traje"], pag,
                   {"blindagem": bli})
        s += "# %s\n\n" % nome_item[nome]
        s += fonte(pag, "Traje %s" % nome)
        s += "*Blindagem %d · limiares %d / %d*\n\n---\n\n%s\n" % (
            bli, lma, lse, md(desc))
        s += rodape("🎒 Itens e Equipamento")
        nota("Itens", nome_item[nome], s)

    for (nome, fab, usos, desc) in MECANICOS:
        pag = pagina_de(nome)
        # alguns itens não saíram de fábrica nenhuma
        da_casa = fab in FABRICAS
        tags = ["peso-do-ceu", "item", "mecanico"]
        extra = {"usos": usos}
        if da_casa:
            tags.append("fabrica/" + fab.lower())
            extra["fabrica"] = nome_fabrica[fab]
        s = frente("Item", "Mecânico", tags, pag, extra)
        s += "# %s\n\n" % nome_item[nome]
        s += fonte(pag, "Item mecânico %s" % nome)
        origem = ("saiu da [[%s]]" % nome_fabrica[fab]) if da_casa \
                 else "de fábrica nenhuma — acha-se em qualquer doca"
        s += "*%s · %s*\n\n---\n\n%s\n" % (usos, origem, md(desc))
        s += rodape(nome_fabrica[fab] if da_casa else None,
                    "🎒 Itens e Equipamento")
        nota("Itens", nome_item[nome], s)

    for (nome, raridade, desc) in ESTRANHOS:
        pag = pagina_de(nome)
        s = frente("Item", "Estranho",
                   ["peso-do-ceu", "item", "estranho"], pag,
                   {"raridade": raridade})
        s += "# %s\n\n" % nome_item[nome]
        s += fonte(pag, "Item estranho %s" % nome)
        s += "*%s · ninguém sabe de onde veio*\n\n---\n\n%s\n" % (
            raridade, md(desc))
        s += rodape("🎒 Itens e Equipamento")
        nota("Itens", nome_item[nome], s)


# ======================================================== OS ADVERSÁRIOS
def bloco_adv(nome_nota, nome, esc, papel, alcance, arma, desc, motivos,
              feats, pag, categoria, tags, extra, origem, pasta, sobre,
              ident_arte=None):
    eva, ma, se, atq, dano, est = ficha(esc, papel)
    s = frente("Adversário", categoria, tags, pag, extra)
    s += "# %s\n\n" % nome_nota
    s += figura(ident_arte, titulo(nome))
    s += fonte(pag, "%s — ficha e traços" % titulo(nome))
    s += "*%s · Escalão %s%s*\n\n" % (papel, ORD[esc], sobre)
    s += "> %s\n\n---\n\n" % md(desc)
    s += "## Ficha\n\n| | |\n|---|---|\n"
    s += "| **Evasão** | %d |\n" % eva
    s += "| **Limiares** | %d / %d |\n" % (ma, se)
    s += "| **Estrutura** | %d |\n" % est
    s += "| **Ataque** | +%d |\n" % atq
    s += "| **Dano** | `%s` |\n" % dano
    s += "| **%s** | %s |\n\n" % (md(arma), alcance)
    s += "**Motivos.** *%s*\n\n---\n\n" % md(motivos)
    s += "## Traços\n\n"
    for (fn, ft, fx) in feats:
        s += "### %s — %s\n\n%s\n\n" % (md(fn), md(ft), md(fx))
    s += ("> [!NOTE] Marcas\n"
          "> Dano abaixo de %d marca **1**; de %d para cima, **2**; de %d "
          "para cima, **3**. %s\n" % (ma, ma, se, PAPEL[papel][3]))
    s += rodape(origem, "☠️ Adversários", "Montar uma Briga")
    nota(pasta, nome_nota, s)


def adversarios():
    for c in COLOSSOS:
        (ident, nome, esc, papel, fab, _d, _e, _x, alcance, arma, desc,
         motivos, feats) = c
        bloco_adv(nome_adv[ident], nome, esc, papel, alcance, arma, desc,
                  motivos, feats, pagina_de(nome), "Colosso de fábrica",
                  ["peso-do-ceu", "adversario", "colosso",
                   "fabrica/" + fab.lower(), "escalao/%d" % esc],
                  {"escalao": esc, "papel": papel,
                   "fabrica": nome_fabrica[fab]},
                  nome_fabrica[fab],
                  os.path.join("Adversários", "Colossos de Fábrica"),
                  " · [[%s]]" % nome_fabrica[fab], ident)

    for f in FUNDAS:
        (ident, nome, esc, papel, plano, _pa, alcance, arma, desc,
         motivos, feats) = f
        bloco_adv(nome_adv[ident], nome, esc, papel, alcance, arma, desc,
                  motivos, feats, pagina_de(nome), "Funda",
                  ["peso-do-ceu", "adversario", "funda", "kaiju",
                   "escalao/%d" % esc],
                  {"escalao": esc, "papel": papel, "plano": plano},
                  "🌊 As Fundas",
                  os.path.join("Adversários", "Fundas"),
                  " · Funda", ident)

    for g in GENTE:
        (ident, nome, esc, papel, _des, alcance, arma, desc,
         motivos, feats) = g
        bloco_adv(nome_adv[ident], nome, esc, papel, alcance, arma, desc,
                  motivos, feats, pagina_de(nome), "Gente e veículo",
                  ["peso-do-ceu", "adversario", "gente",
                   "escalao/%d" % esc],
                  {"escalao": esc, "papel": papel},
                  "☠️ Adversários",
                  os.path.join("Adversários", "Gente e Veículos"),
                  " · gente a pé ou veículo", ident)


# ================================================================ REGRAS
REGRAS = [
 ("A Dualidade", "🎲", "regra", """
Some os dois d12 e o traço que couber. Compare com a **Dificuldade**, ou com a
**Evasão** do alvo.

| O que saiu | O que significa |
|---|---|
| **Total ≥ Dificuldade** | Você conseguiu. |
| **Total < Dificuldade** | Você não conseguiu. |
| **Esperança maior** | *com Esperança*: ganhe **1 Esperança**. |
| **Medo maior** | *com Medo*: o Mestre ganha **1 Medo**. |
| **Os dois iguais** | **Crítico**: sucesso automático, ganhe 1 Esperança e limpe 1 Estresse. |

> [!TIP] Falhar com Esperança é bom
> A coisa não saiu, mas você não pagou por isso: o Mestre não ganha nada e você
> ganha um marcador. É o segundo melhor resultado da tabela, e muita mesa demora
> a perceber.

## Dificuldades, quando o Mestre precisa inventar uma

| Dificuldade | Quando usar |
|---|---|
| **10** | Quase certo. Peça só se a falha for interessante. |
| **13** | O padrão. Use quando não souber. |
| **15** | Difícil: contra treino, pressa ou tempo ruim. |
| **17** | Muito difícil: ninguém faz isso sem pagar. |
| **20** | Uma vez por campanha. |
"""),
 ("Esperança", "✨", "regra", """
Começa em **2**, guarda até **6**.

| Custo | No que se gasta |
|---|---|
| **1** | **Ajudar**: um aliado que está rolando ganha `+1d6`. |
| **1** | **Experiência**: some **+2**, se ela couber. |
| **1** | **Fôlego**: limpe 1 Estresse. |
| **3** | **Traço de Esperança** da sua classe. |

Ver também [[Experiências]].
"""),
 ("O Medo", "🌑", "regra", """
> [!IMPORTANT] Medo não é castigo
> É o mundo se inclinando para ver o que vai acontecer. Quando o Mestre tem Medo
> guardado, a cena fica maior: coisas aparecem, desafios começam, gente entra —
> e as máquinas dos jogadores *acordam*. Um Mestre que só usa Medo para machucar
> está usando errado.

O Mestre começa a sessão com o que sobrou, até **12**, e ganha 1 toda vez que
alguém rola com Medo.

| Custo | O quê |
|---|---|
| **1** | **Fazer aparecer.** Alguma coisa entra na cena: reforço, testemunha, uma porta que não estava ali, uma chance. Pode ser bom para a mesa. Muitas vezes é. |
| **1** | **Dar foco.** Entregue 1 Medo a um jogador: ele soma `+1d6` na próxima rolagem. Em troca, o Mestre faz uma pergunta sobre o personagem e o jogador responde com a verdade. |
| **1** | Um adversário age fora da vez dele. |
| **1** | Uma **Contagem** anda um passo. |
| **2** | Uma **Ação de Medo** de um adversário. |
| **2** | **Ligar um desafio**: começa uma Contagem nova, e a mesa sabe qual. |
| **3** | **A maré vira**: o que estava longe fica perto. |

## As Peças Tensas

Algumas Peças de fábrica são **Tensas**: não custam nada e funcionam apenas
enquanto o Mestre tiver **4 ou mais de Medo** — algumas pedem 6.

O Mestre *não pode* gastar Medo só para desligar uma Peça Tensa. Se o gasto tem
um efeito na ficção, tudo bem que a Peça apague junto.

## Contagens

| Passos | Para quê |
|---|---|
| **4** | Uma coisa curta: a porta que abre, o trem que chega. |
| **6** | Segurar um lugar. A metade traz reforço. |
| **8** | A cena inteira: a evacuação, a maré, o resgate. |
| **12** | Uma sessão. Diga o número em voz alta. |

Contagem é relógio aberto: a mesa tem de ver o número subindo.
"""),
 ("Estresse", "💢", "regra", """
O piloto tem **6 Estresse**. É o único custo da máquina: não existe calor, não
existe carga, não existe bateria. As Peças **Ativas** das fábricas custam
Estresse, e é o corpo do piloto que paga.

- **Parada Curta** limpa 2.
- **Parada Longa** limpa tudo, troca as Peças instaladas e conserta o casco.

Com todo o Estresse marcado você fica **Vulnerável** e não pode marcar mais — o
que significa que a próxima coisa que pediria Estresse vai pedir outra coisa.
"""),
 ("Experiências", "🧭", "regra", """
Uma frase curta sobre o que já te aconteceu: *"Cresci numa doca"*, *"Fui do
outro lado por três anos"*. Você começa com duas, valendo **+2**, e ganha mais
subindo de nível. Gaste 1 [[Esperança]] para usar.

> [!TIP] Experiência não é perícia
> Não faça uma lista de habilidades; faça uma lista de coisas que aconteceram
> com você. As primeiras se gastam, as segundas rendem a campanha inteira.
"""),
 ("O Combate", "⚔️", "regra", """
**Não existe tabuleiro e não existe iniciativa.** Existe o holofote, que passa de
mão em mão, e existem cinco faixas de alcance. Colosso e gente usam as mesmas
regras; a diferença está em [[Escala]].

## O teatro da mente

No começo da cena, o Mestre diz em voz alta **três a cinco coisas que existem
ali**: a passarela, o guindaste, o canal, a fila de gente, o prédio que já está
caindo. Isso é o mapa inteiro.

- Cada personagem está **em** uma dessas coisas, ou **entre** duas.
- Distância se mede em **faixas de alcance**, não em metros.
- **Mover não custa ação** se você estiver indo fazer alguma coisa. Atravessar
  duas ou mais faixas é que custa a ação inteira — ou uma só, com Deslocamento 2+.

| Faixa | O que é |
|---|---|
| **Corpo a corpo** | Encostado. Dá para tocar. |
| **Muito Perto** | Um passo. Dá para gritar sem rádio. |
| **Perto** | Uma corrida. O outro lado do pátio. |
| **Longe** | O outro lado do rio. Precisa de arma longa. |
| **Muito Longe** | Você vê, e é só. |

## O holofote

Quem age é quem tem o holofote. Terminou, passa para outro jogador — nunca de
volta para quem acabou de agir. O Mestre entra quando alguém falha, quando um
sucesso sai com Medo, ou quando paga Medo para entrar. Faz uma coisa e devolve.

## O que se faz com uma ação

| Ação | O que é |
|---|---|
| **Atacar** | Role contra a **Evasão** do alvo. |
| **Atravessar** | Duas faixas ou mais. |
| **Usar uma Peça** | O que ela disser. As Ativas custam [[Estresse]]. |
| **Abrir o Núcleo** | Uma vez por sortida. |
| **Ajudar** | Um aliado ganha `+1d6`. Custa 1 [[Esperança]]. |
| **Ler a cena** | Role **Instinto**; o Mestre conta uma coisa verdadeira e útil. |
| **Qualquer outra** | Descreva. O Mestre diz o traço e a Dificuldade. |

## Atacar

| Resultado | O que acontece |
|---|---|
| **Crítico** | Acerta, o dano sobe um degrau, ganha 1 Esperança e limpa 1 Estresse. |
| **Acerto com Esperança** | Dano cheio. Ganhe 1 Esperança. |
| **Acerto com Medo** | Dano cheio. O Mestre ganha 1 Medo. |
| **Erro com Esperança** | Não acerta, mas alguma coisa melhora. |
| **Erro com Medo** | Não acerta, e o Mestre entra. |
"""),
 ("Condições", "🩹", "regra", """
Cinco, e só cinco. O que não couber aqui é ficção, não regra.

| Condição | Efeito |
|---|---|
| **Vulnerável** | Ataques contra você têm vantagem. |
| **Restrito** | Você não muda de faixa. Sair gasta uma ação. |
| **Oculto** | Não pode ser alvo sem que alguém gaste uma ação te achando. Sai ao agir, salvo se a Peça disser outra coisa. |
| **Instável** | O seu próximo ataque tem desvantagem. |
| **Inerte** | Você não age. Ataques contra você acertam sem rolar. |
"""),
 ("Escala", "📏", "regra", """
Colosso e gente usam exatamente as mesmas regras, o mesmo holofote e as mesmas
faixas. O que muda é isto, e nada mais:

| Situação | Regra |
|---|---|
| **Gente atacando colosso** | Desvantagem, e o dano cai pela **metade**. |
| **Arma Antimáquina** | Cancela as duas coisas acima: rolagem normal, dano cheio. |
| **Colosso atacando gente** | Se acertar, o dano é sempre **Severo** — a não ser que a pessoa esteja coberta. |
| **Gente escondida de colosso** | Uma pessoa a pé conta como **Oculta** sempre que houver entulho, fumaça, multidão ou noite. |

## O que uma pessoa a pé faz com uma máquina

| O quê | Dificuldade | Resultado |
|---|---|---|
| **Subir** | Agilidade 15 | Você está em cima. Ele gasta uma ação para te sacudir. |
| **Plantar carga** | Conhecimento 14 | Uma ação, em cima. Estoura na sua próxima: `4d12+4`, ignorando Blindagem. |
| **Cortar um cabo** | Finesse 16 | O colosso perde 1 Deslocamento, ou uma Peça, ou os sensores. |
| **Abrir a cabine** | Força 18 | Em cima, com o colosso **Inerte** ou **Restrito**. |
| **Falar** | Presença 15 | Tem gente ali dentro. Às vezes é tudo de que se precisa. |
"""),
 ("Levar Dano", "🛠️", "regra", """
| O dano foi | Você marca | E mais |
|---|---|---|
| Abaixo do **Limiar Maior** | 1 Estrutura | — |
| **Limiar Maior** ou acima | 2 Estrutura | — |
| **Limiar Severo** ou acima | 3 Estrutura | role a [[Avaria]] |

Antes de marcar, gaste **1 Blindagem** para descer um degrau. Com toda a
Estrutura marcada, o colosso cai.

## Quando o colosso cai

- **O piloto sai.** Sempre. Uma ação para abandonar a cabine, e depois disso você
  é uma pessoa de carne no meio de uma briga de máquinas — o que é uma cena, não
  um fim.
- **O chassi volta.** Numa doca, com uma Parada Longa e alguma negociação. É
  caro; não é o fim da campanha.
- **As Peças, nem sempre.** Role `1d6` por Peça instalada: com 4 ou mais, ela
  sobreviveu. As outras ficaram no campo, e alguém vai achar.
"""),
 ("Avaria", "💥", "regra", """
`1d12`, somando **+1 por Avaria anterior nesta sortida**.

| 1d12 | Resultado |
|---|---|
| **1–4** | **Raspão.** Nada além do dano. |
| **5–6** | **Tranco.** Você fica **Vulnerável** até a sua próxima ação e marca 1 Estresse. |
| **7–8** | **Peça solta.** Uma Peça instalada desliga até a próxima Parada Longa. Você escolhe qual. |
| **9–10** | **Fratura.** Os dois Limiares caem **3** até o conserto. Acumula. |
| **11** | **Núcleo torto.** O colosso fica **Inerte**. Religar custa uma ação e 1 Estresse. |
| **12+** | **Colapso.** O colosso cai agora. Você tem uma ação para sair. |
"""),
 ("Montar uma Briga", "🎯", "regra", """
**Pontos de Batalha = (3 × número de pilotos) + 2.**

| Custo | O que compra |
|---|---|
| **1** | Um Lacaio. |
| **2** | Um Batedor, um Atirador ou um Apoio. |
| **3** | Um Regular. |
| **4** | Um Bando ou um Comandante. |
| **5** | Um Brutamontes. |
| **10** | Um Solo. |

**−1 ponto** se todos forem de Escalão abaixo do da mesa. **+2** se houver uma
Contagem correndo.

## A linha do Escalão

Cada Escalão tem uma linha fixa; cada papel multiplica a Estrutura e mexe na
Evasão. Dá para inventar um adversário novo em trinta segundos.

| Escalão | Evasão | Limiares | Ataque | Dano | Estrutura |
|---|---|---|---|---|---|
| **1º** | 11 | 6 / 13 | +2 | `1d10+5` | 5 |
| **2º** | 13 | 10 / 19 | +4 | `2d10+6` | 7 |
| **3º** | 15 | 13 / 26 | +6 | `3d10+7` | 9 |
| **4º** | 17 | 17 / 32 | +8 | `4d10+9` | 11 |

## Os nove papéis

| Papel | Pontos | Estrutura | Evasão | O que ele é |
|---|---|---|---|---|
"""),
 ("Subir de Nível", "📈", "regra", """
Duas escolhas por nível. As caixas zeram a cada Escalão novo.

- +1 a dois traços
- +1 Estrutura
- +1 Estresse
- +1 Evasão
- +1 encaixe
- Peça nova
- Licença nova
- Experiência nova
- Experiência para +3
- Limiares do piloto
- **Um contato** — alguém que atende quando você chama
- **Uma marca** — uma reputação que abre e fecha portas
- **Um bem** — uma coisa no mundo que é sua

**Automático:** Proficiência 2 no nível 2, 3 no 5, 4 no 8. Especialização no 5,
Maestria no 8. Experiência nova nos níveis 2, 5 e 8.

## Escalões

| Escalão | Níveis | Proficiência | O tamanho da briga |
|---|---|---|---|
| **1º** | 1 | 1 | Uma cidade, uma doca, uma estrada. |
| **2º** | 2 a 4 | 2 | Uma frente, um porto, uma fábrica. |
| **3º** | 5 a 7 | 3 | Uma campanha inteira. |
| **4º** | 8 a 10 | 4 | A guerra, e o que existe embaixo dela. |

**Proficiência** é quantos dados de dano você rola. Uma arma `d8+3` rola *um* d8
no Escalão 1 e *quatro* no Escalão 4, somando o +3 uma vez só.
"""),
]


FRASE_REGRA = {
 "A Dualidade": "A Dualidade",
 "Esperança": "guarda até",
 "O Medo": "a atenção do mundo",
 "Estresse": "não existe calor",
 "Experiências": "não é perícia",
 "O Combate": "EXISTE TABULEIRO",
 "Condições": "Cinco, e só cinco",
 "Escala": "a única diferença",
 "Levar Dano": "Levar dano",
 "Avaria": "somando 1 por Avaria",
 "Montar uma Briga": "Pontos de Batalha =",
 "Subir de Nível": "Experiência nova",
}


def pagina_frase(frase, minimo=5):
    """Procura a frase pulando o sumário das primeiras páginas."""
    f = re.sub(r"\s+", " ", frase).lower()
    for i, t in enumerate(PLANAS):
        if i + 1 >= minimo and f in t.lower():
            return i + 1
    return None


def regras():
    for (nome, emoji, cat, corpo) in REGRAS:
        pag = pagina_frase(FRASE_REGRA.get(nome, nome))
        s = frente("Regra", "Sistema", ["peso-do-ceu", "regra"], pag)
        s += "# %s %s\n\n" % (emoji, nome_regra[nome])
        s += fonte(pag, nome)
        s += corpo.strip() + "\n"
        if nome == "Montar uma Briga":
            for p, (mult, ajd, custo, como) in PAPEL.items():
                m = "—" if mult is None else ("×%g" % mult)
                a = "—" if ajd == 0 else "%+d" % ajd
                s += "| **%s** | %d | %s | %s | %s |\n" % (p, custo, m, a, como)
            s += "\n"
        s += rodape("📐 As Regras")
        nota("Regras", nome_regra[nome], s)


# ================================================================== MOCs
def moc(pasta, nome, emoji, titulo_txt, intro, secoes, pai=None):
    s = frente("Hub", "MOC", ["peso-do-ceu", "moc", "hub"])
    s += "# %s %s\n\n%s\n\n---\n\n" % (emoji, titulo_txt, intro)
    for cabeca, links in secoes:
        if not links:
            continue
        s += "## %s\n\n" % cabeca
        for l in links:
            s += "- %s\n" % l
        s += "\n"
    s += "---\n\n[[%s|⬅ Voltar]]\n" % (pai or HUB)
    nota(pasta, nome, s)


# ============================================================== os nomes
# Tudo passa por aqui antes para que nenhum nome de nota se repita — nem
# entre si, nem com o que já existe no vault do Anuah.
EXISTENTES = set()


def registrar():
    global nome_fabrica, nome_peca, nome_chassi, nome_anc, nome_com
    global nome_item, nome_adv, nome_regra
    usados = set(EXISTENTES)

    def unico(base, sufixo):
        n = limpo(base)
        if n not in usados:
            usados.add(n)
            return n
        n2 = limpo("%s (%s)" % (base, sufixo))
        k = 2
        while n2 in usados:
            n2 = limpo("%s (%s %d)" % (base, sufixo, k))
            k += 1
        usados.add(n2)
        return n2

    nome_fabrica = {k: unico(titulo(FABRICAS[k]["nome"]), "fábrica")
                    for k in ORDEM}
    # a classe vem antes do chassi: várias compartilham o nome, e é a
    # classe que o jogador procura primeiro
    nome_classe = {c["nome"]: unico(titulo(c["nome"]), "classe")
                   for c in CLASSES}
    nome_chassi = {ch[0]: unico(titulo(ch[0]), "chassi") for ch in CHASSIS}
    nome_peca = {}
    for k in ORDEM:
        for (_n, nome, _t, _c, _x) in FABRICAS[k]["pecas"]:
            nome_peca[(k, nome)] = unico(nome, "peça")
    nome_anc = {a[0]: unico(titulo(a[0]), "ancestralidade")
                for a in ANCESTRALIDADES}
    nome_com = {c[0]: unico(titulo(c[0]), "comunidade") for c in COMUNIDADES}
    nome_item = {}
    for grupo in (ARMAS_PILOTO, TRAJES, MECANICOS, ESTRANHOS):
        for it in grupo:
            nome_item[it[0]] = unico(it[0], "item")
    nome_adv = {}
    for e in list(COLOSSOS) + list(FUNDAS) + list(GENTE):
        nome_adv[e[0]] = unico(titulo(e[1]), "adversário")
    nome_regra = {r[0]: unico(r[0], "regra") for r in REGRAS}
    globals()["nome_classe"] = nome_classe
    return nome_classe


def montar(existentes=()):
    EXISTENTES.update(existentes)
    registrar()

    fabricas()
    chassis()
    classes()
    povo()
    itens()
    adversarios()
    regras()

    # ---------------------------------------------------------- os MOCs
    moc("Fábricas", "⚙️ As Fábricas", "⚙️", "As oito fábricas",
        "Oito casas que constroem colossos, e oito maneiras diferentes de "
        "achar que uma máquina deve ser. A licença de fábrica é de onde vem "
        "tudo o que o seu colosso sabe fazer: as **Peças** estão aqui, não "
        "em domínios.",
        [("As oito casas",
          ["**[[%s]]** — *%s*" % (nome_fabrica[k], md(FABRICAS[k]["linha"]))
           for k in ORDEM]),
         ("Ver também", ["[[🔩 As Peças]]", "[[🤖 O Colosso]]",
                         "[[☠️ Adversários]]"])])

    secoes = []
    for k in ORDEM:
        secoes.append((nome_fabrica[k],
                       ["[[%s]] — Nível %d · %s"
                        % (nome_peca[(k, n)], niv,
                           txt_peca(niv, n, t, c, x))
                        for (niv, n, t, c, x) in FABRICAS[k]["pecas"]]))
    moc("Peças", "🔩 As Peças", "🔩", "As 120 Peças",
        "Quinze Peças por fábrica. **Fixa** está sempre ligada; **Ativa** "
        "custa [[Estresse]] e uma ação; **Tensa** não custa nada mas só "
        "funciona enquanto o Mestre tiver Medo guardado — ver [[O Medo]].\n\n"
        "Uma Peça por encaixe do chassi. Troca-se numa doca ou numa Parada "
        "Longa.", secoes, pai="⚙️ As Fábricas")

    moc("Pilotos", "🎖️ O Piloto", "🎖️", "O piloto",
        "A pessoa dentro da cabine. Poucas mecânicas de propósito: o que "
        "varia é classe, subclasse, armas e equipamento — e o que o colosso "
        "sabe fazer vem da fábrica, não do piloto.",
        [("As oito classes",
          ["**[[%s]]** — licença [[%s]] · *%s*"
           % (nome_classe[c["nome"]], nome_fabrica[c["fabrica"]], md(c["chamada"]))
           for c in CLASSES]),
         ("De onde você veio", ["[[🧬 Ancestralidades]]", "[[🏘️ Comunidades]]"]),
         ("Ver também", ["[[Subir de Nível]]", "[[Experiências]]",
                         "[[🎒 Itens e Equipamento]]"])])

    moc(os.path.join("Pilotos", "Povo"), "🧬 Ancestralidades", "🧬",
        "As dez ancestralidades",
        "De que gente você veio. Cada uma dá duas coisas.",
        [("As dez", ["**[[%s]]** — *%s*" % (nome_anc[a[0]], md(a[1]))
                     for a in ANCESTRALIDADES])], pai="🎖️ O Piloto")

    moc(os.path.join("Pilotos", "Povo"), "🏘️ Comunidades", "🏘️",
        "As oito comunidades",
        "Onde você cresceu. Cada uma dá uma coisa.",
        [("As oito", ["**[[%s]]** — *%s*" % (nome_com[c[0]], md(c[1]))
                      for c in COMUNIDADES])], pai="🎖️ O Piloto")

    por_fab = {}
    for ch in CHASSIS:
        por_fab.setdefault(ch[1], []).append(ch)
    moc("Colossos", "🤖 O Colosso", "🤖", "O colosso",
        "Dezesseis cascos, dois por fábrica. O chassi é a base: ele diz "
        "quanta **Blindagem** você tem, quantos encaixes, e qual é o truque "
        "que a máquina faz uma vez por sortida. O chassi define a Blindagem "
        "— nenhuma Peça dá Blindagem de graça, com uma exceção por fábrica.",
        [(nome_fabrica[k],
          ["[[%s]] — %s · Estrutura %d · Evasão %d · Blindagem %d · "
           "%d encaixes" % (nome_chassi[ch[0]], ch[2], ch[3], ch[4],
                            ch[7], ch[8])
           for ch in por_fab[k]]) for k in ORDEM] +
        [("Ver também", ["[[🔩 As Peças]]", "[[Levar Dano]]", "[[Avaria]]"])])

    def lista_adv(fonte_, chave=None):
        saida = []
        for e in fonte_:
            eva, ma, se, atq, dano, est = ficha(e[2], e[3])
            saida.append("[[%s]] — %s · Escalão %s · Estrutura %d"
                         % (nome_adv[e[0]], e[3], ORD[e[2]], est))
        return saida

    secoes_adv = []
    for k in ORDEM:
        secoes_adv.append((nome_fabrica[k],
                           lista_adv([c for c in COLOSSOS if c[4] == k])))
    secoes_adv.append(("🌊 As Fundas — os kaijus", lista_adv(FUNDAS)))
    secoes_adv.append(("Gente e veículos", lista_adv(GENTE)))
    secoes_adv.append(("Ver também", ["[[Montar uma Briga]]", "[[Escala]]",
                                      "[[Levar Dano]]"]))
    moc("Adversários", "☠️ Adversários", "☠️",
        "Os %d adversários" % (len(COLOSSOS) + len(FUNDAS) + len(GENTE)),
        "Sessenta e quatro colossos de fábrica, vinte e seis **Fundas** — o "
        "que sobe do fundo — e quatorze de gente e veículo. Toda ficha sai "
        "da linha do Escalão vezes o papel, então dá para inventar mais sem "
        "quebrar nada: ver [[Montar uma Briga]].", secoes_adv)

    moc("Adversários", "🌊 As Fundas", "🌊", "As Fundas",
        "Não são máquinas e não vieram de fábrica nenhuma. Sobem do fundo, "
        "e ninguém combinou com elas as regras que o resto do mundo segue.",
        [("Por Escalão", [])] , pai="☠️ Adversários")
    # refaz a das Fundas com as seções por Escalão
    secoes_f = []
    for esc in (1, 2, 3, 4):
        secoes_f.append(("Escalão %s" % ORD[esc],
                         lista_adv([f for f in FUNDAS if f[2] == esc])))
    moc("Adversários", "🌊 As Fundas", "🌊", "As Fundas",
        "Não são máquinas e não vieram de fábrica nenhuma. Sobem do fundo, "
        "e ninguém combinou com elas as regras que o resto do mundo segue.",
        secoes_f, pai="☠️ Adversários")

    moc("Itens", "🎒 Itens e Equipamento", "🎒", "Itens e equipamento",
        "Armas para o piloto, trajes, ferramentas de fábrica e as coisas "
        "que ninguém sabe explicar.",
        [("Armas de piloto",
          ["[[%s]] — %s · %s · `%s+%d`%s"
           % (nome_item[a[0]], a[1], a[2], a[3], a[5],
              (" · **%s**" % md(a[6])) if a[6] else "")
           for a in ARMAS_PILOTO]),
         ("Trajes",
          ["[[%s]] — Blindagem %d · limiares %d / %d"
           % (nome_item[t[0]], t[1], t[2], t[3]) for t in TRAJES]),
         ("Mecânicos",
          ["[[%s]] — %s%s"
           % (nome_item[m[0]], m[2],
              (" · [[%s]]" % nome_fabrica[m[1]]) if m[1] in FABRICAS else "")
           for m in MECANICOS]),
         ("Estranhos",
          ["[[%s]] — %s" % (nome_item[e[0]], e[1]) for e in ESTRANHOS])])

    moc("Regras", "📐 As Regras", "📐", "As regras",
        "O sistema inteiro, em doze notas. Dois d12, cinco faixas de "
        "alcance, cinco condições e nenhum tabuleiro.",
        [("A rolagem", ["[[%s]]" % nome_regra[n] for n in
                        ("A Dualidade", "Esperança", "O Medo", "Estresse",
                         "Experiências")]),
         ("A briga", ["[[%s]]" % nome_regra[n] for n in
                      ("O Combate", "Condições", "Escala", "Levar Dano",
                       "Avaria")]),
         ("A mesa", ["[[%s]]" % nome_regra[n] for n in
                     ("Montar uma Briga", "Subir de Nível")])])

    # ------------------------------------------------------- o hub geral
    s = frente("Hub", "Início", ["peso-do-ceu", "moc", "hub", "inicio"], 1)
    s += "# 🛰️ O Peso do Céu\n"
    s += "### RPG de mechas — Daggerheart × Lancer · terceira edição\n\n"
    s += fonte(1, "Capa e sumário")
    s += ("Dois d12, oito fábricas e uma máquina que só sabe fazer o que a "
          "fábrica dela ensinou. Combate no teatro da mente, sem tabuleiro. "
          "O Medo do Mestre não serve para machucar: serve para acender as "
          "coisas.\n\n---\n\n")
    s += "## 🧭 Navegação\n\n"
    s += ("- ⚙️ **[[⚙️ As Fábricas]]** — as oito casas e a licença que "
          "define o seu colosso.\n"
          "- 🔩 **[[🔩 As Peças]]** — as 120 Peças, Fixas, Ativas e Tensas.\n"
          "- 🎖️ **[[🎖️ O Piloto]]** — as oito classes, ancestralidades e "
          "comunidades.\n"
          "- 🤖 **[[🤖 O Colosso]]** — os dezesseis chassis e o que cada "
          "Núcleo faz.\n"
          "- ☠️ **[[☠️ Adversários]]** — os 132 adversários, com as "
          "**[[🌊 As Fundas|Fundas]]** no meio.\n"
          "- 🎒 **[[🎒 Itens e Equipamento]]** — 69 itens, dos mecânicos aos "
          "estranhos.\n"
          "- 📐 **[[📐 As Regras]]** — o sistema inteiro em doze notas.\n"
          "- 📚 **[[📚 Os capítulos escritos]]** — o texto corrido do "
          "livro, capítulo a capítulo.\n"
          "- 🎯 **[[🎯 Padrões de encontro]]** — quem aparece junto com "
          "quem, e por quê.\n"
          "- 👑 **[[👑 Chefes — dom e segunda fase]]** — o que faz um "
          "Solo virar chefe.\n"
          "- 🧑 **[[🧑 Gente do lado de cá]]** — os NPCs que não são "
          "para derrubar.\n"
          "- 🎨 **[[🎨 Direção de arte]]** — como as oito casas se "
          "desenham, e por quê.\n"
          "- 🧰 **[[🧰 As ferramentas]]** — a ficha e o gerador, no celular.\n"
          "\n---\n\n")
    s += "## ⚡ Guia rápido de mesa\n\n"
    s += ("[[A Dualidade]] · [[O Medo]] · [[O Combate]] · [[Escala]] · "
          "[[Condições]] · [[Levar Dano]] · [[Avaria]] · "
          "[[Montar uma Briga]]\n\n---\n\n")
    s += "## 📊 O que existe aqui\n\n"
    s += ("| | |\n|---|---|\n"
          "| Fábricas | 8 |\n| Peças | 120 |\n| Classes | 8 (16 subclasses) |\n"
          "| Chassis | 16 |\n| Ancestralidades | 10 |\n| Comunidades | 8 |\n"
          "| Adversários | %d (%d Fundas) |\n| Itens | %d |\n"
          % (len(COLOSSOS) + len(FUNDAS) + len(GENTE), len(FUNDAS),
             len(ARMAS_PILOTO) + len(TRAJES) + len(MECANICOS) + len(ESTRANHOS)))
    s += "\n"
    s += ("> [!TIP] Consulta rápida\n"
          "> Toda nota tem `pdf_page` nas Propriedades e um link para a "
          "página exata do livro. Os `tags` seguem um vocabulário fechado: "
          "`peso-do-ceu`, `fabrica/<nome>`, `escalao/<1-4>`, `peca/<tipo>`.\n")
    nota("", HUB, s)


def gravar():
    if os.path.exists(SAIDA):
        shutil.rmtree(SAIDA)
    for caminho, conteudo in ARQUIVOS.items():
        destino = os.path.join(SAIDA, caminho)
        os.makedirs(os.path.dirname(destino), exist_ok=True)
        open(destino, "w", encoding="utf-8").write(conteudo)
    if os.path.exists(LIVRO):
        shutil.copy(LIVRO, os.path.join(SAIDA, PDF_NOME))
    # as imagens: os SVGs saem de gerador/arte2_gerada.py
    origem_arte = os.path.join(RAIZ, "obsidian", "arte")
    if os.path.exists(origem_arte):
        destino = os.path.join(SAIDA, ARTE)
        os.makedirs(destino, exist_ok=True)
        for f in os.listdir(origem_arte):
            shutil.copy(os.path.join(origem_arte, f),
                        os.path.join(destino, f))
    print("%d notas em %s" % (len(ARQUIVOS), SAIDA))
    return len(ARQUIVOS)


if __name__ == "__main__":
    existentes = []
    if len(sys.argv) > 1 and os.path.exists(sys.argv[1]):
        existentes = [l.strip() for l in open(sys.argv[1], encoding="utf-8")
                      if l.strip()]
    montar(existentes)
    gravar()
