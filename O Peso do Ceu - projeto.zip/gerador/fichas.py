# -*- coding: utf-8 -*-
"""
As fichas: duas folhas A4 por classe, com campos preenchíveis no PDF.

Tudo que é linha para escrever é um campo de formulário de verdade —
dá para preencher no computador, salvar e imprimir depois. As caixinhas
de marcar também. E há duas janelas grandes reservadas para a imagem do
piloto e a do colosso.
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from dados.classes import CLASSES, CHASSIS
from dados.fabricas import FABRICAS

SAIDA = os.path.join(os.path.dirname(__file__), "..", "tex")

PREAMBULO = r"""\documentclass[11pt]{book}
\input{preambulo}
\geometry{a4paper, left=10mm, right=10mm, top=8mm, bottom=8mm,
          headsep=0mm, footskip=0mm}
\pagestyle{empty}
\setlength{\parindent}{0pt}
\setlength{\topskip}{0pt}

% ------------------------------------------------ formulário (hyperref)
\renewcommand{\LayoutTextField}[2]{#2}
\renewcommand{\LayoutChoiceField}[2]{#2}
\renewcommand{\LayoutCheckField}[2]{#2}
\def\corcampo{0.894 0.855 0.761}

\tikzset{
  fio2/.style   = {tinta, line width=0.4pt},
  traco2/.style = {tinta, line width=0.8pt},
}

% --------------------------------------------------------- peças da ficha
\newcommand{\bloco}[6]{%
  \draw[traco2] (#1,#2) rectangle ({#1+#3},{#2-#4});
  \fill[#6] (#1,#2) rectangle ({#1+#3},{#2-5.6});
  \node[anchor=west, text=papel, inner sep=0pt,
        font=\rotulo\bfseries\fontsize{7.8}{9}\selectfont]
    at ({#1+1.8},{#2-2.9}) {\MakeUppercase{#5}};}

\newcommand{\rotl}[3]{%
  \node[anchor=north west, inner sep=0pt,
        font=\rotulo\fontsize{5.6}{6.8}\selectfont, color=cinza45]
    at (#1,#2) {\MakeUppercase{#3}};}

\newcommand{\rotb}[3]{%
  \node[anchor=north west, inner sep=0pt,
        font=\rotulo\bfseries\fontsize{6.6}{8}\selectfont]
    at (#1,#2) {\MakeUppercase{#3}};}

\newcommand{\txt}[4]{%
  \node[anchor=north west, inner sep=0pt, text width=#3mm, align=justify,
        font=\fontsize{6.6}{8.2}\selectfont] at (#1,#2) {#4};}

% campo de texto: x, y (canto sup. esq.), largura mm, altura mm, nome, rótulo
\newcommand{\campo}[6]{%
  \node[anchor=north west, inner sep=0pt] at (#1,#2)
    {\TextField[name=#5, width=#3mm, height=#4mm, bordercolor={},
       backgroundcolor=\corcampo, charsize=8pt, borderwidth=0]{}};
  \draw[fio2, color=cinza45] (#1,{#2-#4}) -- ({#1+#3},{#2-#4});
  \rotl{#1}{{#2-#4-0.4}}{#6}}

% campo de várias linhas
\newcommand{\campom}[6]{%
  \node[anchor=north west, inner sep=0pt] at (#1,#2)
    {\TextField[name=#5, width=#3mm, height=#4mm, multiline=true,
       bordercolor={}, backgroundcolor=\corcampo, charsize=8pt,
       borderwidth=0]{}};
  \rotl{#1}{{#2-#4-0.4}}{#6}}

% quadrinho de valor com campo dentro
\newcommand{\quadro}[4]{%
  \draw[traco2] ({#1-5.5},{#2+5.5}) rectangle ({#1+5.5},{#2-5.5});
  \node[anchor=north west, inner sep=0pt] at ({#1-5},{#2+4.5})
    {\TextField[name=#3, width=10mm, height=9mm, align=1, bordercolor={},
       backgroundcolor={}, charsize=13pt, borderwidth=0]{}};
  \node[anchor=north, inner sep=0pt, text width=22mm, align=center,
        font=\rotulo\bfseries\fontsize{5.8}{7}\selectfont]
    at (#1,{#2-6.3}) {\MakeUppercase{#4}};}

% caixa solta de marcar
\newcommand{\marca}[3]{%
  \node[anchor=south west, inner sep=0pt] at (#1,#2)
    {\CheckBox[name=#3, width=3.2mm, height=3.2mm, bordercolor={0 0 0},
       backgroundcolor={}, borderwidth=0.4]{}};}

% rótulo do trilho
\newcommand{\rottrilho}[3]{%
  \node[anchor=east, inner sep=0pt,
        font=\rotulo\bfseries\fontsize{6.4}{7.6}\selectfont]
    at (#1,#2) {\MakeUppercase{#3}};}

% janela de imagem
\newcommand{\janela}[5]{%
  \draw[tinta, line width=0.7pt, dash pattern=on 1.6mm off 1.2mm]
    (#1,#2) rectangle ({#1+#3},{#2-#4});
  \node[anchor=south, inner sep=0pt, color=cinza45,
        font=\rotulo\fontsize{6.2}{7.6}\selectfont]
    at ({#1+#3/2},{#2-#4+1.6}) {\MakeUppercase{#5}};}

\newcommand{\folha}[1]{\noindent\begin{tikzpicture}[x=1mm,y=1mm,
  baseline=0pt, every node/.style={inner sep=0pt}]#1\end{tikzpicture}%
  \par\clearpage}

\begin{document}
\begin{Form}
"""

TRACOS = ["Agilidade", "Força", "Finesse", "Instinto", "Presença",
          "Conhecimento"]


def trilho(x, y, n, rotulo, prefixo):
    """Fileira de n caixas de marcar, com o rótulo à esquerda."""
    s = "\\rottrilho{%0.1f}{%0.1f}{%s}\n" % (x - 1.6, y, rotulo)
    for i in range(n):
        s += "\\marca{%0.1f}{%0.1f}{%s%d}\n" % (x + i * 4.4, y - 1.6,
                                                prefixo, i + 1)
    return s

ESCOLHAS = [
 "+1 a dois traços", "+1 Estrutura", "+1 Estresse", "+1 Evasão",
 "+1 encaixe", "Peça nova", "Licença nova", "Experiência nova",
 "Experiência para +3", "Limiares do piloto", "Um contato",
 "Uma marca", "Um bem",
]


def folha_piloto(c, i):
    f = FABRICAS[c["fabrica"]]
    p = "p%d" % i
    s = ""
    s += "\\fill[%s] (0,277) rectangle (190,264);\n" % f["cor"]
    s += ("\\node[anchor=west, text=papel, font=\\displayf\\bfseries"
          "\\fontsize{19}{21}\\selectfont] at (3,270.5) {%s};\n" % c["nome"])
    s += ("\\node[anchor=east, text=papel, font=\\rotulo"
          "\\fontsize{7.2}{9}\\selectfont] at (187,272.6) "
          "{O PESO DO CÉU \\textbullet\\ FICHA DO PILOTO};\n")
    s += ("\\node[anchor=east, text=papel, font=\\rotulo"
          "\\fontsize{7.2}{9}\\selectfont] at (187,267.2) "
          "{LICENÇA: %s};\n" % f["nome"].upper())

    # identificação
    s += "\\campo{0}{259}{60}{6}{%snome}{nome do piloto}\n" % p
    s += "\\campo{63}{259}{42}{6}{%sanc}{ancestralidade}\n" % p
    s += "\\campo{108}{259}{42}{6}{%scom}{comunidade}\n" % p
    s += "\\campo{153}{259}{37}{6}{%sniv}{nível e escalão}\n" % p

    # traços
    s += "\\bloco{0}{247}{110}{40}{Os seis traços}{tinta}\n"
    for k, t in enumerate(TRACOS):
        x = 15 + (k % 3) * 34
        y = 232 - (k // 3) * 17
        s += "\\quadro{%d}{%d}{%str%d}{%s}\n" % (x, y, p, k, t)

    # corpo
    s += "\\bloco{114}{247}{76}{40}{O corpo}{tinta}\n"
    s += "\\quadro{130}{233}{%seva}{Evasão}\n" % p
    s += "\\quadro{152}{233}{%slma}{L. maior}\n" % p
    s += "\\quadro{174}{233}{%slse}{L. severo}\n" % p
    s += trilho(124, 221, 7, "PV", p + "pv")
    s += trilho(124, 215.5, 6, "Estr.", p + "es")
    s += trilho(124, 210, 6, "Esp.", p + "esp")

    # janela de imagem
    s += "\\bloco{0}{204}{62}{78}{O piloto}{tinta}\n"
    s += "\\janela{4}{195}{54}{64}{cole, desenhe ou imprima aqui}\n"

    # experiências
    s += "\\bloco{66}{204}{124}{36}{Experiências}{tinta}\n"
    for k in range(4):
        x = 70 + (k % 2) * 62
        y = 195 - (k // 2) * 14
        s += "\\campo{%d}{%d}{56}{6}{%sexp%d}{+2}\n" % (x, y, p, k)

    # traços de classe
    s += "\\bloco{66}{166}{124}{40}{Traços de classe}{%s}\n" % f["cor"]
    s += "\\rotb{69}{158}{%s — sempre ligado}\n" % c["traco"][0]
    s += "\\txt{69}{154}{118}{%s}\n" % c["traco"][1]
    s += "\\rotb{69}{145}{%s — 3 Esperança}\n" % c["esperanca"][0]
    s += "\\txt{69}{141}{118}{%s}\n" % c["esperanca"][1]

    # subclasses
    s += "\\bloco{0}{122}{190}{64}{A subclasse — marque uma}{tinta}\n"
    for k, sc in enumerate(c["subclasses"]):
        x = 3 + k * 95
        s += "\\marca{%d}{110.4}{%ssub%d}\n" % (x, p, k)
        s += ("\\node[anchor=north west, font=\\rotulo\\bfseries"
              "\\fontsize{9}{10.5}\\selectfont] at (%d,116) {%s};\n"
              % (x + 5, sc["nome"]))
        s += ("\\node[anchor=north west, font=\\itshape\\fontsize{6.4}{8}"
              "\\selectfont, color=cinza45] at (%d,111.4) {%s};\n"
              % (x + 5, sc["linha"]))
        s += "\\rotb{%d}{105}{Fundação — 1}\n" % x
        s += "\\txt{%d}{101.4}{86}{%s}\n" % (x, sc["f"])
        s += "\\rotb{%d}{88}{Especialização — 5}\n" % x
        s += "\\txt{%d}{84.4}{86}{%s}\n" % (x, sc["e"])
        s += "\\rotb{%d}{72}{Maestria — 8}\n" % x
        s += "\\txt{%d}{68.4}{86}{%s}\n" % (x, sc["m"])
    s += "\\draw[fio2] (95,116) -- (95,60);\n"

    # no corpo
    s += "\\bloco{0}{54}{92}{36}{No corpo}{tinta}\n"
    s += "\\campo{4}{45}{84}{6}{%sarm1}{arma}\n" % p
    s += "\\campo{4}{36}{84}{6}{%sarm2}{arma}\n" % p
    s += "\\campo{4}{27}{84}{6}{%straje}{traje — blindagem e limiares}\n" % p

    # itens
    s += "\\bloco{96}{54}{94}{36}{Itens e dívidas}{tinta}\n"
    s += "\\campom{100}{45}{86}{24}{%sitens}{}\n" % p

    s += ("\\node[anchor=north west, font=\\rotulo\\fontsize{5.8}{7.2}"
          "\\selectfont, color=cinza45, text width=182mm] at (4,14) "
          "{PV %d \\ \\textbullet\\ \\ EVASÃO %d \\ \\textbullet\\ \\ "
          "CHASSI DE PARTIDA: %s \\ \\textbullet\\ \\ NA CABINE: %s};\n"
          % (c["pv"], c["evasao"], c["chassi"], c["itens"]))
    return s


def folha_maquina(c, i):
    f = FABRICAS[c["fabrica"]]
    p = "m%d" % i
    ch = next((x for x in CHASSIS if x[0] == c["chassi"]), CHASSIS[0])
    s = ""
    s += "\\fill[%s] (0,277) rectangle (190,264);\n" % f["cor"]
    s += ("\\node[anchor=west, text=papel, font=\\displayf\\bfseries"
          "\\fontsize{19}{21}\\selectfont] at (3,270.5) {O COLOSSO};\n")
    s += ("\\node[anchor=east, text=papel, font=\\rotulo"
          "\\fontsize{7.2}{9}\\selectfont] at (187,270.5) "
          "{%s \\textbullet\\ FICHA DA MÁQUINA};\n" % c["nome"].upper())

    s += "\\campo{0}{259}{60}{6}{%schassi}{chassi}\n" % p
    s += "\\campo{63}{259}{42}{6}{%sfab}{fábrica}\n" % p
    s += "\\campo{108}{259}{42}{6}{%sporte}{porte}\n" % p
    s += "\\campo{153}{259}{37}{6}{%slic}{outras licenças}\n" % p

    # números
    s += "\\bloco{0}{247}{110}{26}{Os números da máquina}{tinta}\n"
    for k, (nome, campo) in enumerate([("Evasão", "eva"), ("L. maior", "lma"),
                                       ("L. severo", "lse"), ("Blindagem", "bli"),
                                       ("Encaixes", "enc"), ("Desloc.", "des")]):
        s += "\\quadro{%d}{233}{%s%s}{%s}\n" % (14 + k * 17, p, campo, nome)

    # trilhos
    s += "\\bloco{114}{247}{76}{26}{Os trilhos}{tinta}\n"
    s += trilho(130, 235, 12, "Estrut.", p + "est")
    s += trilho(130, 227.5, 6, "Blind.", p + "bl")

    # janela de imagem
    s += "\\bloco{0}{218}{62}{76}{O colosso}{tinta}\n"
    s += "\\janela{4}{209}{54}{62}{cole, desenhe ou imprima aqui}\n"

    # peças instaladas
    s += "\\bloco{66}{218}{124}{76}{As Peças instaladas}{%s}\n" % f["cor"]
    for k in range(7):
        s += "\\campo{70}{%0.1f}{116}{6}{%speca%d}{}\n" % (208 - k * 9.2, p, k)
    s += ("\\node[anchor=north west, font=\\rotulo\\fontsize{5.6}{7}"
          "\\selectfont, color=cinza45] at (70,145) "
          "{UMA PEÇA POR ENCAIXE \\textbullet\\ TROCA-SE NUMA DOCA OU "
          "PARADA LONGA \\textbullet\\ FIXA / ATIVA (ESTRESSE) / "
          "TENSA (MEDO)};\n")

    # núcleo
    s += "\\bloco{0}{138}{92}{32}{Núcleo do chassi}{tinta}\n"
    s += ("\\txt{4}{130}{84}{\\textbf{%s.} %s}\n" % (ch[10][0], ch[10][1]))
    s += trilho(28, 112, 2, "Usado", p + "nuc")

    # avarias
    s += "\\bloco{96}{138}{94}{32}{Avarias desta sortida}{tinta}\n"
    s += trilho(124, 129, 6, "1d12 +", p + "av")
    s += "\\campo{100}{123}{86}{6}{%savt1}{}\n" % p
    s += "\\campo{100}{114}{86}{6}{%savt2}{}\n" % p

    # progressão
    s += "\\bloco{0}{104}{190}{72}{Subir de nível — duas escolhas por nível}{tinta}\n"
    for k, t in enumerate(ESCOLHAS):
        col = k // 7
        lin = k % 7
        x = 4 + col * 96
        y = 94 - lin * 8.6
        for j in range(3):
            s += "\\marca{%0.1f}{%0.1f}{%sesc%dx%d}\n" % (x + j * 4.4, y - 1.6, p, k, j)
        s += ("\\node[anchor=north west, font=\\fontsize{6.6}{8}"
              "\\selectfont, text width=76mm] at (%0.1f,%0.1f) {%s};\n"
              % (x + 14.5, y + 3.4, t))
    s += ("\\node[anchor=north west, font=\\rotulo\\fontsize{5.6}{7}"
          "\\selectfont, color=cinza45, text width=86mm] at (100,46) "
          "{AUTOMÁTICO: PROFICIÊNCIA 2 NO NÍVEL 2, 3 NO 5, 4 NO 8. "
          "ESPECIALIZAÇÃO NO 5, MAESTRIA NO 8. EXPERIÊNCIA NOVA NOS "
          "NÍVEIS 2, 5 E 8. AS CAIXAS ZERAM A CADA ESCALÃO NOVO.};\n")

    # notas
    s += "\\bloco{0}{28}{190}{26}{A máquina, do lado de fora}{tinta}\n"
    s += "\\campom{4}{20}{182}{15}{%snotas}{}\n" % p
    return s


def montar():
    s = PREAMBULO
    s += ("\\vspace*{30mm}\\begin{center}\n"
          "{\\displayf\\bfseries\\fontsize{34}{38}\\selectfont O PESO DO CÉU}"
          "\\\\[4mm]{\\color{tinta}\\rule{92mm}{1.6pt}}\\\\[5mm]\n"
          "{\\rotulo\\fontsize{13}{16}\\selectfont AS FICHAS}\\\\[14mm]\n"
          "\\retrato{slOrbita}{2.20}\\\\[12mm]\n"
          "{\\rotulo\\fontsize{8.4}{11}\\selectfont\\color{cinza45}\n"
          "UMA POR CLASSE \\ \\textbullet\\ \\ DUAS FOLHAS \\ \\textbullet\\ \\ "
          "TODOS OS CAMPOS SÃO PREENCHÍVEIS NO PDF}\\\\[3mm]\n"
          "{\\rotulo\\fontsize{7.6}{10}\\selectfont\\color{cinza45}\n"
          "ABRA NUM LEITOR DE PDF QUE ACEITE FORMULÁRIO E DIGITE DIRETO.\\\\\n"
          "AS DUAS JANELAS TRACEJADAS SÃO PARA A IMAGEM DO PILOTO E A DO "
          "COLOSSO.}\n\\end{center}\\clearpage\n\n")
    for i, c in enumerate(CLASSES):
        s += "\\folha{%%\n%s}\n\n" % folha_piloto(c, i)
        s += "\\folha{%%\n%s}\n\n" % folha_maquina(c, i)
    s += "\\end{Form}\n\\end{document}\n"
    open(os.path.join(SAIDA, "fichas.tex"), "w", encoding="utf-8").write(s)
    print("fichas.tex: %d classes, %d folhas" % (len(CLASSES), len(CLASSES) * 2))


if __name__ == "__main__":
    montar()
