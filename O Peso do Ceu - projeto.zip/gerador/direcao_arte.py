# -*- coding: utf-8 -*-
"""
A direção de arte, do jeito que o Anuah escreveu.

Ele mandou sete licenças e uma linha de vilões, cada uma com
personalidade, filtro de refinamento e prompts de IA de imagem. As
sete encaixaram exatamente nas oito casas do jogo — o que não é
coincidência: ele escreveu pensando nelas.

Estas notas guardam o material inteiro, em português, com os prompts
originais em inglês preservados. Servem para duas coisas: alimentar o
motor vetorial (que lê silhueta, assimetria, postura e assinatura) e
ficar prontos caso ele queira gerar imagem de verdade noutro lugar.
"""
import os

RAIZ = os.path.join(os.path.dirname(__file__), "..")
SAIDA = os.path.join(RAIZ, "obsidian", "O Peso do Céu", "Arte")

NOTAS = {}


def nota(nome, tipo, categoria, tags, corpo, voltar="🎨 Direção de arte"):
    s = "---\ntipo: %s\ncategoria: %s\ntags:\n" % (tipo, categoria)
    for t in tags:
        s += "  - %s\n" % t
    s += "jogo: O Peso do Céu\n---\n\n" + corpo.strip() + "\n"
    if voltar:
        s += "\n---\n\n[[%s|⬅ Voltar à direção de arte]]\n" % voltar
    NOTAS[nome + ".md"] = s


# ============================================================== LICENÇAS
# (casa, licença, personalidade, filtro, [(variação, prompt)])
LICENCAS = [
 ("BRASA", "⚙️ Couraçados a Vapor", "Dieselpunk",
  "Brutais, proletários e incansáveis. Estas máquinas cheiram a óleo "
  "diesel, suor e carvão. Não há elegância, apenas força bruta e força "
  "de trabalho convertida em máquina de guerra.",
  "Texturas de metal enferrujado, fumaça volumétrica espessa e rebites "
  "marcados. Evitar superfícies polidas.",
  [("O Quebra-Linhas · martelo",
    "Character design of a bulky dieselpunk mech holding a massive iron "
    "sledgehammer, thick black smoke billowing from twin exhaust pipes on "
    "its back, heavy riveted iron armor, weathered metal texture with soot "
    "stains, glowing red optical visor, dramatic rim lighting, gritty "
    "industrial aesthetic, 8k resolution, concept art --ar 2:3"),
   ("O Pugilista · punhos",
    "Character design of a heavyweight dieselpunk brawler mech with "
    "oversized reinforced gauntlets, aggressive boxing stance, thick armor "
    "plates bolted together, hydraulic joints hissing steam, worn iron and "
    "brass materials, oil leaks, underground fight club lighting, raw "
    "mechanical power --ar 2:3"),
   ("O Incinerador · lança-chamas",
    "Character design of a heavy dieselpunk mech firing a massive "
    "flamethrower, intense orange fire illuminating the dark metallic hull, "
    "large fuel tanks strapped to its back, scorched and blackened iron "
    "armor, heat distortion in the air, aggressive and intimidating "
    "posture, cinematic lighting --ar 2:3")]),

 ("VESPERTINA", "🕊️ Serafins Apex", "Neo-SciFi",
  "Elitistas, velozes e precisos. Parecem anjos caídos da estratosfera. "
  "O design é hostil em sua perfeição.",
  "Aerodinâmica, painéis brancos imaculados de compósito cerâmico e "
  "iluminação de neon emissivo cortando as sombras.",
  [("Dançarino de Lâminas · espadachim",
    "Character design of a sleek, agile futuristic mecha wielding a glowing "
    "yellow energy sword, pristine white ceramic armor plating, slender and "
    "aerodynamic build, dynamic combat pose, sharp angular lines, neon "
    "glowing accents, bright clear sky background, high-tech evangelion "
    "style, masterpiece --ar 2:3"),
   ("O Olho de Deus · sniper",
    "Character design of a sleek white futuristic sniper mecha aiming a long "
    "high-tech rifle, stealthy yet elegant posture, advanced optical sensors "
    "on the head unit, pristine aerodynamic armor panels, subtle glowing "
    "energy lines, cold and calculating aura, studio lighting, "
    "hyper-detailed --ar 2:3"),
   ("O Arcanjo · alado",
    "Character design of an angelic high-tech mecha hovering with glowing "
    "energy wings and multiple fin thrusters, dual wielding sleek energy "
    "blades, pristine white armor, ethereal and intimidating presence, "
    "bright celestial lighting, sci-fi fantasy fusion, sharp elegant "
    "edges --ar 2:3")]),

 ("CATEDRAL", "🛡️ Égides Arcanos", "Fantasia tecnomágica",
  "Zelotes devotos a códigos antigos. Suas máquinas são relíquias "
  "passadas de geração em geração, tratadas como templos sagrados "
  "ambulantes.",
  "Misturar tropos de fantasia medieval (capas, escudos, alabardas) com "
  "juntas robóticas pesadas. Pátina antiga e runas brilhantes.",
  [("Guarda Real · alabarda",
    "Character design of a medieval paladin-style mecha wielding a giant "
    "halberd, heavy ornate plate armor made of dull steel and bronze, "
    "standing in a gothic arched hall, imposing and stoic, glowing visor "
    "under a knight's cowl, ancient robotic guardian, cinematic "
    "shadows --ar 2:3"),
   ("Defensor do Fogo Sagrado · escudo de luz",
    "Character design of a magical knight mecha projecting a large glowing "
    "orange energy shield with runic patterns, wielding a flaming sword, "
    "heavy reinforced crusader armor, dynamic defensive pose, magical sparks "
    "floating in the air, dark background with bright warm rim light, sci-fi "
    "fantasy --ar 2:3"),
   ("Senhor da Guerra · lança e capa",
    "Character design of a commander mecha wearing a tattered dark cape, "
    "holding a long spear and a heavy decorated physical shield, horned "
    "knight helmet, ancient rusted silver armor with gold trim, "
    "battle-hardened veteran, grimdark fantasy robot, highly detailed "
    "textures --ar 2:3")]),

 ("ARCO", "⚓ Leviatãs de Pressão", "Náuticos",
  "Pragmáticos e claustrofóbicos. Adaptados ao ambiente mais inóspito do "
  "planeta. Movimentam-se com a força de um maremoto.",
  "Texturas molhadas, reflexos nos visores de vidro esféricos, cracas "
  "presas ao metal e paleta verde/azul profundo.",
  [("O Torrente · jato d'água",
    "Character design of an aquatic deep-sea mecha shooting a high-pressure "
    "water jet from its arm cannon, sleek hydrodynamic green armor, thick "
    "glass dome for a head with a pilot visible inside, underwater "
    "environment with bubbles, wet metallic textures, marine biology "
    "sci-fi --ar 2:3"),
   ("O Escafandrista · martelo hidráulico",
    "Character design of a heavy deep-sea diving suit mecha wielding a "
    "massive cylindrical hydraulic hammer, thick robust green armor plates, "
    "large bolts, heavy spherical glass helmet, exploring ocean depths, "
    "murky water lighting, industrial underwater engineering, highly "
    "detailed --ar 2:3"),
   ("O Submarino Vivo · propulsores",
    "Character design of a bulky aquatic mecha with glowing blue dual "
    "thrusters propelling it underwater, massive spherical torso with thick "
    "glass viewport, short heavy utility arms, hydrodynamic green hull, deep "
    "sea exploration vehicle, cinematic bioluminescent lighting --ar 2:3")]),

 ("GRALHA", "🪚 Arautos do Ermo", "Sucateiros",
  "Caóticos, instáveis e cruéis. O design reflete desespero; se quebrou, "
  "eles consertam com arame farpado e peças de inimigos caídos.",
  "Forçar assimetria severa. Ferrugem profunda, fiação exposta, sinais de "
  "trânsito usados como armadura e armas improvisadas.",
  [("O Açougueiro · serra",
    "Character design of a post-apocalyptic scavenger mecha wielding a "
    "bloody circular saw blade, heavily rusted mismatched armor, exposed "
    "roll cage, asymmetrical skeletal robot arm, chaotic mad max style, "
    "rusted brown and red paint, dirty and gritty, wasteland "
    "survivor --ar 2:3"),
   ("O Caçador de Recompensas · rede",
    "Character design of a scrap-built wasteland mecha throwing a metal "
    "capture net, constructed from old car parts and rusted industrial "
    "scrap, asymmetrical glowing yellow eye, patched together aesthetic, "
    "chaotic scavenger robot, dusty wasteland environment, highly detailed "
    "weathering --ar 2:3"),
   ("O Frenético · espinhos",
    "Character design of a brutal raider mecha covered in welded metal "
    "spikes, wielding a rusty mace, patched green and red armor with "
    "graffiti, intimidating and savage posture, crude mechanical repairs, "
    "post-apocalyptic villain robot, aggressive lighting, rusty grunge "
    "texture --ar 2:3")]),

 ("SELO", "🚧 Falanges Urbanas", "Industriais / táticos",
  "Frios, burocráticos e militarizados. Foram feitos para controlar greves "
  "e proteger corporações. São padronizados, mas marcados pelas cicatrizes "
  "da selva de concreto.",
  "Padrões de segurança (listras amarelas e brancas), luzes estroboscópicas "
  "de sirene, decalques numéricos e design quadrado/funcional.",
  [("Controle de Distúrbios · contenção",
    "Character design of an industrial riot-control mecha throwing a "
    "weighted net, bold yellow and white hazard paint scheme with black "
    "stripes, heavily armored blocky chassis, glowing blue visor, urban "
    "police robot, modular tactical gear, worn paint on the edges, "
    "utilitarian sci-fi --ar 2:3"),
   ("O Coordenador · radar",
    "Character design of a heavy tactical mecha equipped with a large radar "
    "dish and communication antennas on its back, blocky industrial yellow "
    "and white armor, standing guard in an urban environment, military-grade "
    "sensors, robust and stationary posture, realistic sci-fi concept "
    "art --ar 2:3"),
   ("SWAT Pesada · artilharia",
    "Character design of a heavily armed police mecha aiming dual cannons "
    "with a bright red laser sight, blocky yellow and white armor with "
    "numbers \"51\" and \"29\" painted on the shoulders, aggressive tactical "
    "stance, urban pacifier unit, hard-surface modeling style, dramatic "
    "shadows --ar 2:3")]),

 ("CARVAO", "🌑 Espectros", "Furtivos",
  "Fatais e niilistas. Eles não lutam, eles executam. As máquinas parecem "
  "estar sempre famintas e escondidas nas sombras, cobertas de trapos para "
  "quebrar a silhueta.",
  "Tons escuros foscos, capuzes ou mantos sobre metal, garras "
  "proeminentes, postura encurvada e animalesca.",
  [("A Sombra Cibernética · lâminas duplas",
    "Character design of a stealth assassin mecha with matte black armor, "
    "dual curved wrist blades, agile and menacing ninja-like posture, "
    "slender dark chassis, glowing red slit visor, dark alleyway background, "
    "sleek but deadly, high-tech rogue, shadowy lighting --ar 2:3"),
   ("O Carniçal de Aço · garras e manto",
    "Character design of a creepy scavenger mecha wearing a tattered brown "
    "cloak draped over its head and shoulders, long metallic razor claws, "
    "hunched predatory posture, matte dark grey armor hiding in the shadows, "
    "mysterious and lethal rogue robot, grimdark sci-fi, eerie "
    "atmosphere --ar 2:3"),
   ("O Carrasco · machado e capuz",
    "Character design of an executioner mecha wearing a hooded dark cloak, "
    "holding a massive bloody rusted battleaxe, dark metallic armor "
    "underneath the fabric, ominous and terrifying presence, standing in a "
    "dark misty street, grim reaper motif, heavy shadows, conceptual "
    "art --ar 2:3")]),

 ("OSSATURA", "🩸 Biomassa Aberrante", "Mutantes / horror corporal",
  "Uma amálgama agonizante de carne, osso e ódio puro. Estes não são robôs, "
  "são pesadelos biológicos.",
  "A IA tentará suavizá-los, virando monstro genérico; o segredo é a "
  "assimetria doentia e a textura de tendões expostos fundidos a "
  "exoesqueletos de osso.",
  [("O Estripador · foice de carne",
    "Character design of a horrific biomechanical mutant monster, "
    "asymmetrical body with one massive scythe-like fleshy claw, exposed "
    "muscle fibers, glowing orange organic core in its chest, grotesque "
    "chitinous armor plates, body horror, terrifying and aggressive, "
    "visceral textures, dark fantasy sci-fi --ar 2:3"),
   ("O Arauto de Osso · esqueleto encouraçado",
    "Character design of a terrifying skeletal mutant wielding a jagged bone "
    "axe, thick calcified bone armor over exposed red muscle, jagged bone "
    "spikes protruding from its back, hollow eye sockets with glowing red "
    "lights, undead biomechanical nightmare, brutal and gory aesthetic, "
    "highly detailed dark fantasy --ar 2:3"),
   ("O Behemoth Aberrante · colosso de tentáculos",
    "Character design of a massive grotesque flesh behemoth monster, right "
    "arm split into multiple terrifying whipping tentacles, thick pulsing "
    "muscular mass covered in spiky bone plates, glowing orange organic eyes "
    "peeking through fleshy crevices, overwhelming and monstrous presence, "
    "extreme body horror, cinematic dark lighting --ar 2:3")]),
]

# o que o motor vetorial realmente leva de cada casa
ASSINATURA = {
 "BRASA": "escapamento com fumaça chapada, rebite, laje de ombro, "
          "cabeça de caldeira com visor em fenda vermelha",
 "VESPERTINA": "aleta de ombro, quilha no peito, crista dupla na cabeça, "
               "corpo estreito e alto",
 "CATEDRAL": "capa esfarrapada, pauldron com borda de ouro, peitoral em "
             "cruz, elmo com chifres e grade",
 "ARCO": "domo de vidro com o piloto visível, casco bojudo, cracas no "
         "aro, perna curta e grossa",
 "GRALHA": "assimetria severa (um ombro tem, o outro não), gaiola de "
           "vergalhão, mono-olho que corre no trilho, antena torta",
 "SELO": "listra de perigo, pod de mísseis no ombro, prato de radar nas "
         "costas, tudo quadrado",
 "CARVAO": "capuz sobre metal, manto largo, sem ombreira, garra no lugar "
           "do pé, postura encurvada",
 "OSSATURA": "costelas por cima da carne, núcleo pulsando no peito, placa "
             "de osso no ombro, dentes",
}

VILOES = [
 ("👤 NPCs vilões", "Comandantes e pilotos rivais",
  "Estética de anime cyberpunk e space opera. Uniformes militares "
  "assimétricos, modificações cibernéticas visíveis e expressões de "
  "superioridade ou insanidade.",
  [("O Ás Arrogante · Piloto Fantasma",
    "O clássico rival de anime. Traje de piloto de alta pressão cheio de "
    "fivelas soltas, olhar afiado, postura relaxada mas perigosa.",
    "Character design of a cocky anime mecha ace pilot, wearing a sleek "
    "asymmetrical high-tech pressure suit with loose straps, sharp angular "
    "facial features, confident smirk, standing in a mecha hangar, dramatic "
    "neon lighting, classic 90s anime aesthetic, high quality --ar 2:3"),
   ("A Cientista Sádica · Arquiteta da Carne",
    "A mente por trás das abominações biomecânicas. Jaleco impecável sobre "
    "exoesqueleto tático; metade do rosto coberta por um visor de análise "
    "médica que brilha.",
    "Character design of a sinister female anime scientist, wearing a "
    "pristine white lab coat over dark tactical gear, asymmetrical "
    "cybernetic glowing visor covering one eye, holding a datapad, cold "
    "calculating expression, sterile laboratory background, cyberpunk anime "
    "style --ar 2:3")]),
 ("🤖 Robôs inimigos", "Bucha de canhão e esquadrões de elite",
  "Design funcional, utilitário e intimidador. Silhuetas grossas para "
  "infantaria e linhas predatórias para elite. Bebe do Zaku e de forças de "
  "segurança corporativa.",
  [("Infantaria pesada · Peão Mono-Olho",
    "O mecha produzido em massa. Blindagem arredondada e um sensor óptico "
    "central que varre o horizonte. Coberto de poeira e desgaste.",
    "Concept art of a mass-produced enemy grunt mecha in anime style, bulky "
    "rounded green and grey armor, single glowing red mono-eye sensor, "
    "holding a standard issue massive assault rifle, dusty battlefield "
    "weathering, realistic military mecha design, dynamic patrol "
    "pose --ar 2:3"),
   ("Perseguidor reverso · Gafanhoto Tático",
    "Unidade de emboscada. Pernas de articulação reversa para saltos "
    "imensos, chassi leve e camuflagem óptica falhando.",
    "Sleek reverse-jointed quadruped enemy mecha, dark grey camouflage "
    "armor, active camo glitching effect, equipped with a long sniper "
    "barrel, crouching on a ruined building edge, predatory insectoid "
    "silhouette, high-tech anime aesthetic, cinematic lighting --ar 2:3")]),
 ("💥 Arsenal inimigo", "Armamento pesado",
  "Armas cruas, brutais e perigosas até para quem as usa. Cabos expostos, "
  "superaquecimento e calibres exagerados.",
  [("Colmeia Balística · pod de ombro",
    "Casulo montado no ombro que se abre em dezenas de micro-mísseis. "
    "Quadrado, industrial, com sinais de alerta em vermelho.",
    "Close up concept art of a massive anime mecha shoulder-mounted missile "
    "pod open and firing, dozens of micro-missiles launching with twisting "
    "smoke trails (Itano circus style), heavy blocky industrial design, red "
    "warning decals, dynamic action shot --ar 16:9"),
   ("Esmaga-Bunker · martelo de fissura térmica",
    "Martelo de cerâmica e tungstênio com propulsores atrás da cabeça. A "
    "zona de impacto fica permanentemente incandescente.",
    "Giant brutalist mecha rocket-hammer, heavy thrusters attached to the "
    "back of the hammer head, glowing red-hot impact surface, thick metal "
    "cables and hydraulic pistons, dark industrial aesthetic, detailed anime "
    "weapon design --ar 16:9")]),
 ("☣️ Monstros inimigos", "Aberrações e chefes",
  "Criaturas que mesclam biologia grotesca com restos de tecnologia "
  "devorada. Não usam armas; seus corpos são as armas.",
  [("Sabujo Biomecânico · Cão de Sucata",
    "Fera quadrúpede do tamanho de um tanque. Pernas de carne esfolada "
    "fundidas a rodas de trator e mandíbula de metal rasgado.",
    "Terrifying quadruped biomechanical hound monster, ripped muscle and "
    "exposed bone fused with rusted tank treads and metal scrap, grotesque "
    "metallic jaw, glowing feral eyes, aggressive running pose, cyberpunk "
    "body horror, anime monster concept art --ar 2:3"),
   ("Titã Incubador · Matriarca Aberrante",
    "Abominação colossal e lenta. O casco traseiro é a carcaça de uma nave "
    "caída fundida a carne pulsante; do ventre caem drones orgânicos.",
    "Colossal biomechanical kaiju boss, grotesque fusion of a crashed "
    "spaceship hull and pulsing fleshy biomass, multiple gross organic sacs "
    "dropping small parasitic drones, huge asymmetric limbs, cinematic dark "
    "anime style, terrifying scale and atmosphere --ar 2:3")]),
]


def moc():
    linhas = []
    for casa, lic, genero, pers, filtro, _v in LICENCAS:
        linhas.append("| **%s** | %s | %s | %s |"
                      % (casa.capitalize(), lic, genero, ASSINATURA[casa]))
    nota("🎨 Direção de arte", "Hub", "Arte",
         ["peso-do-ceu", "arte", "moc", "hub", "direcao-de-arte"], """
# 🎨 Direção de arte

Sete licenças e uma linha de vilões, escritas pelo Anuah. As sete
encaixaram **exatamente** nas oito casas do jogo — o que não é acaso:
ele escreveu pensando nelas.

| Casa | Licença | Gênero | O que o desenho leva |
|---|---|---|---|
%s

---

## As notas

- 🏭 **[[🏭 As sete licenças]]** — personalidade, filtro de refinamento e
  os prompts originais de cada casa.
- 🩸 **[[🩸 Vilões, inimigos e monstros]]** — NPCs rivais, robôs de linha,
  arsenal pesado e as aberrações.
- ⚙️ **[[⚙️ Como o motor desenha]]** — o que o desenho vetorial consegue
  levar de tudo isso, e o que não consegue.

---

> [!WARNING] O limite, dito na cara
> Os prompts são para **IA de imagem**: ferrugem, fumaça volumétrica,
> fibra muscular, rim light. O motor do jogo desenha **vetor chapado**.
> O que ele leva é **silhueta, assimetria, postura, proporção e o
> elemento-assinatura**. Textura, não.

Ver também: [[🤖 Mechas — vocabulário visual]] · [[🏗️ Oficina]]
""" % "\n".join(linhas), voltar=None)


def licencas():
    blocos = []
    for casa, lic, genero, pers, filtro, vars_ in LICENCAS:
        b = ["## %s → **%s**\n" % (lic, casa.capitalize()),
             "*%s*\n" % genero, pers + "\n",
             "> [!TIP] Filtro de refinamento\n> %s\n" % filtro,
             "**No motor:** %s\n" % ASSINATURA[casa],
             "### Variações\n"]
        for nome, prompt in vars_:
            b.append("**%s**\n\n```text\n%s\n```\n" % (nome, prompt))
        blocos.append("\n".join(b))
    nota("🏭 As sete licenças", "Referência", "Arte",
         ["peso-do-ceu", "arte", "direcao-de-arte", "mecha"], """
# 🏭 As sete licenças

O material como o Anuah escreveu, casa por casa: personalidade, filtro
de refinamento e os prompts originais em inglês — que é o padrão das
IAs de arte e por isso ficaram como estavam.

---

%s""" % "\n---\n\n".join(blocos))


def viloes():
    blocos = []
    for titulo, sub, direcao, itens in VILOES:
        b = ["## %s\n" % titulo, "*%s*\n" % sub,
             "**Direção:** %s\n" % direcao]
        for nome, desc, prompt in itens:
            b.append("### %s\n\n%s\n\n```text\n%s\n```\n"
                     % (nome, desc, prompt))
        blocos.append("\n".join(b))
    nota("🩸 Vilões, inimigos e monstros", "Referência", "Arte",
         ["peso-do-ceu", "arte", "direcao-de-arte", "vilao", "bestiario"],
         """
# 🩸 Vilões, inimigos e monstros

A outra metade do material: quem pilota contra a mesa, o que vem em
massa, o que eles carregam e o que rasteja.

O **Peão Mono-Olho** virou a cabeça `mono` da [[⚙️ As Fábricas|Gralha]];
o **Gafanhoto Tático** virou a perna reversa mais a pose `espreita`; a
**Colmeia Balística** virou a ombreira `pod` do Selo; o
**Esmaga-Bunker** virou o martelo com propulsor.

---

%s""" % "\n---\n\n".join(blocos))


def motor():
    nota("⚙️ Como o motor desenha", "Regra", "Arte",
         ["peso-do-ceu", "arte", "motor", "vetor"], """
# ⚙️ Como o motor desenha

Vetor chapado, em Python, em `arte2/`. A mesma **cena** sai em três
formatos: TikZ para o livro, SVG para o vault e JSON compacto para o
aplicativo. Se o desenho muda, muda nos três.

## As cinco regras que não se quebram

**1. Capacete exclusivo por fábrica.** Oito cabeças, uma por casa, e
nunca se repetem entre linhas diferentes. Dentro da casa varia
ombreira, perna, mochila, arma e pose — a cabeça nunca.

**2. Membro de dois ossos.** Braço tem cotovelo; perna tem joelho. A
primeira versão girava o braço inteiro num pivô só, e era isso que
fazia o cotovelo sair do lugar.

**3. A perna resolve por cinemática inversa.** A pose diz **onde o pé
pousa**; o joelho se acha sozinho. Sem isso o pé flutua acima do chão
assim que a pose abre.

**4. Contrapposto.** O ombro sai de cima do quadril e o peso fica num
pé só. Sem isso todo boneco fica em posição de sentido.

**5. Silhueta por casa.** A diferença entre as fábricas é
**proporção**, não cor: largura de ombro, massa de panturrilha, altura
de torso, tamanho de cabeça.

## Como o volume aparece sem gradiente

Cada polígono é cortado em duas metades — a que pega luz e a que não
pega, 20% mais escura. A luz vem de cima e da esquerda. É o *flat
shading* do guia de arquétipos.

## As seis camadas

| # | O quê |
|---|---|
| 0 | mochila, asas, capa, canhões dorsais |
| 1 | membros distantes, um tom mais escuros |
| 2 | torso e bacia |
| 3 | membros dianteiros |
| 4 | ombreiras, escudos, peitoral |
| 5 | cabeça, viseira, sensores |

## Só no aplicativo

A [[🧰 As ferramentas|Ficha do Colosso]] monta o desenho na hora:
corpo do chassi + mochila + arma, conforme as Peças instaladas.
**51 das 160 Peças** trocam o desenho — equipou asas, o colosso ganha
asas. Isso não entra no livro.

## Regras de conteúdo

- **Asas e voo alto só do Escalão 3 para cima.** Voar é fim de campanha.
- **Cada chassi tem pose e armas próprias** — dezesseis combinações,
  nenhuma repetida.
- **Pose por papel** nos adversários: Brutamontes se planta, Batedor
  agacha, Atirador mira, Comandante aponta.
""")


def gerar():
    NOTAS.clear()
    moc()
    licencas()
    viloes()
    motor()
    os.makedirs(SAIDA, exist_ok=True)
    for nome, corpo in NOTAS.items():
        open(os.path.join(SAIDA, nome), "w", encoding="utf-8").write(corpo)
    print("Direção de arte: %d notas" % len(NOTAS))
    return len(NOTAS)


if __name__ == "__main__":
    gerar()
