# -*- coding: utf-8 -*-
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from arte.fabricas import GRAMATICA, monta
from arte.volume import ESTILOS

ARMAS = {"BRASA": ("martelo", "punho"), "VESPERTINA": ("espada", "escudo"),
         "CATEDRAL": ("lanca", "escudo"), "ARCO": ("canhao", "arpeu"),
         "GRALHA": ("serra", "garra"), "SELO": ("rede", "fuzil"),
         "CARVAO": ("espada", "arpeu"), "OSSATURA": ("garrao", "garra")}
EXTRA = {"CATEDRAL": dict(tem_capa=True), "SELO": dict(tem_antena=True),
         "VESPERTINA": dict(tem_asas=True)}

corpo = ""
for k in GRAMATICA:
    d, e = ARMAS[k]
    corpo += "\\newcommand{\\m%s}{%%\n%s}\n\n" % (
        k.capitalize(), monta(k, dir_arma=d, esq_arma=e, **EXTRA.get(k, {})))

grade = ""
for i, k in enumerate(GRAMATICA):
    grade += ("\\begin{minipage}[b]{0.245\\textwidth}\\centering\n"
              "\\begin{tikzpicture}[scale=0.52]\\m%s\\end{tikzpicture}\\\\[2mm]\n"
              "{\\sffamily\\footnotesize %s}\\end{minipage}%%\n" % (k.capitalize(), k))
    grade += "\\\\[7mm]\n" if (i+1) % 4 == 0 else "\\hfill\n"

doc = (r"""\documentclass[11pt]{article}
\usepackage{fontspec}\usepackage{xcolor}\usepackage{tikz}
\usetikzlibrary{calc}
\usepackage[a4paper,margin=10mm]{geometry}
\definecolor{tinta}{HTML}{111111}
""" + ESTILOS + corpo + r"""
\pagestyle{empty}\setlength{\parindent}{0pt}
\begin{document}\noindent
""" + grade + r"""
\end{document}
""")
open(os.path.join(os.path.dirname(__file__), "..", "tex", "t8.tex"),
     "w", encoding="utf-8").write(doc)
print("t8.tex escrito")
