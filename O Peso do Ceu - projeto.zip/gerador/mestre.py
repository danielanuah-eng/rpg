# -*- coding: utf-8 -*-
"""
As três notas de mesa que nasceram do gerador.

Padrões de encontro, chefes e gente do bem saíram primeiro como
ferramenta e depois viraram regra. As notas são geradas dos mesmos
dados que a ferramenta lê, para nunca discordarem dela.
"""
import sys, os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from dados.encontros import PADROES
from dados.chefes import DOM, DOM_DA_CASA, VIRADA, ESCOLTA
from dados.elite import NOMEADOS, ASSINATURA
from dados import npcs as NPC
from gerador.dados_json import t

RAIZ = os.path.join(os.path.dirname(__file__), "..")
SAIDA = os.path.join(RAIZ, "obsidian", "O Peso do Céu", "Mestre")

NOTAS = {}


def nota(nome, tipo, categoria, tags, corpo):
    s = "---\ntipo: %s\ncategoria: %s\ntags:\n" % (tipo, categoria)
    for g in tags:
        s += "  - %s\n" % g
    s += "jogo: O Peso do Céu\n---\n\n" + corpo.strip() + "\n"
    s += "\n---\n\n[[🛰️ O Peso do Céu|⬅ Voltar ao início]]\n"
    NOTAS[nome + ".md"] = s


# ============================================================== PADRÕES
def padroes():
    linhas = []
    for pid, nome, emoji, txt, R in PADROES:
        origem = {"colosso": "máquina de fábrica", "gente": "gente sem máquina",
                  "funda": "Funda"}
        de = ", ".join(origem[o] for o in R.get("origens", []))
        eixo = R.get("eixo")
        eixo_txt = {"pesado": "um da linha pesada", "assinatura":
                    "uma Assinatura de fábrica", "nomeado": "um Nomeado",
                    None: "ninguém — a briga não tem eixo"}.get(eixo, eixo)
        linhas.append(
            "### %s %s\n\n%s\n\n"
            "| | |\n|---|---|\n"
            "| **Quem entra** | %s |\n"
            "| **Uma casa só** | %s |\n"
            "| **Quem organiza** | %s |\n"
            "| **Escolta do dom** | %s |\n\n"
            "> [!TIP] Na mesa\n> %s\n"
            % (emoji, nome, t(txt), de,
               "sim" if R.get("casa_unica") else "não", eixo_txt,
               "sim" if R.get("escolta") else "não", t(R.get("nota", ""))))

    nota("🎯 Padrões de encontro", "Regra", "Mestre",
         ["peso-do-ceu", "mestre", "encontro", "briga"], """
# 🎯 Padrões de encontro

Adversário não é ingrediente solto. Bicho do fundo do mar não marcha ao
lado de fuzileiro fardado — e quando isso acontece na mesa, a cena não
quer dizer nada.

Um **padrão** é a receita da formação: de onde os adversários saem, se
são todos da mesma casa, quem manda e o que enche a linha. O
[[🧰 As ferramentas|Gerador de Desafios]] monta dentro dessas regras, e
você pode montar à mão do mesmo jeito.

> [!INFO] A ordem de montagem
> 1. Conte os **Pontos de Batalha** — ver [[Montar uma Briga]].
> 2. Escolha o padrão. Ele é a resposta a *por que essa gente está
>    junta*.
> 3. Ponha o **eixo** primeiro: é quem organiza a formação.
> 4. Gaste o que sobrou enchendo a linha com quem o padrão permite.

---

%s""" % "\n".join(linhas))


# =============================================================== CHEFES
def chefes():
    ordem = ["BRASA", "VESPERTINA", "CATEDRAL", "ARCO", "GRALHA", "SELO",
             "CARVAO", "OSSATURA"]
    tab = ["| Casa | Dom | O que é |", "|---|---|---|"]
    corpos = []
    for casa in ordem:
        d = DOM_DA_CASA[casa]
        nome, _c, linha, texto = DOM[d]
        tab.append("| %s | **%s** | %s |" % (casa.capitalize(), nome,
                                             t(linha)))
        esc = ESCOLTA[d]
        corpos.append("### %s — %s\n\n%s\n\n**Escolta: %s.** %s\n"
                      % (nome, casa.capitalize(), t(texto), esc[0], t(esc[1])))

    nomes = {e[0]: e[1] for e in NOMEADOS}
    casas = {e[0]: e[4] for e in NOMEADOS}
    vir = []
    for ident, (fase, fala, texto) in VIRADA.items():
        vir.append("### %s → **%s**\n\n*%s*\n\n%s\n\n"
                   "<small>%s · dom da casa: **%s**</small>\n"
                   % (nomes.get(ident, ident), fase, t(fala), t(texto),
                      casas.get(ident, ""),
                      DOM[DOM_DA_CASA[casas.get(ident, "BRASA")]][0]))

    nota("👑 Chefes — dom e segunda fase", "Regra", "Mestre",
         ["peso-do-ceu", "mestre", "chefe", "adversario"], """
# 👑 Chefes — dom e segunda fase

Um Solo com números altos não é chefe: é uma parede que demora. Chefe é
o que **muda a briga no meio dela**. Duas coisas dão isso.

## O dom da casa

A marca da fábrica levada ao limite. Todo chefe daquela casa carrega o
dom dela, e é o que o grupo aprende a contornar na segunda vez que
enfrenta alguém de lá.

%s

---

%s

---

## A virada

Quando a Estrutura do Nomeado cai **pela metade**, ele deixa de fazer o
que vinha fazendo e passa a fazer outra coisa. Não é mais dano: é outro
problema.

> [!WARNING] Como rodar
> A virada é **de graça** e acontece na hora, no meio do turno se for
> preciso. Narre antes de rolar qualquer coisa. Guarde 2 Medo para
> ela — o susto vale o gasto.

Os oito de **Assinatura** têm só o dom: são linha de fábrica, não
personagem. Os doze **Nomeados** têm os dois.

%s""" % ("\n".join(tab), "\n".join(corpos), "\n".join(vir)))


# ================================================================ GENTE
def gente():
    blocos = []
    for tid, nome, plural, oque, mesa in NPC.TIPOS:
        q = NPC.QUERER[tid]
        o = NPC.OFERECER[tid]
        linhas = ["| d6 | O que quer | O que oferece |", "|---|---|---|"]
        for i in range(6):
            linhas.append("| %d | %s | %s |" % (i + 1, t(q[i]), t(o[i])))
        blocos.append("### %s\n\n%s\n\n**Na mesa.** %s\n\n%s\n"
                      % (plural, t(oque), t(mesa), "\n".join(linhas)))

    lojas = ["| Loja | Vende | Itens | Regra da casa |", "|---|---|---|---|"]
    for lid, nome, vende, tipos, faixa, regra in NPC.LOJAS:
        lojas.append("| **%s** | %s | %d a %d | %s |"
                     % (t(nome), t(vende), faixa[0], faixa[1], t(regra)))

    marcas = "\n".join("%d. %s" % (i + 1, t(m))
                       for i, m in enumerate(NPC.MARCA))

    nota("🧑 Gente do lado de cá", "Regra", "Mestre",
         ["peso-do-ceu", "mestre", "npc", "gente"], """
# 🧑 Gente do lado de cá

Quem o grupo encontra e não precisa derrubar. O gerador sabia inventar
quem bate; faltava quem recebe, quem vende, quem manda e quem só estava
ali.

> [!TIP] A regra inteira
> NPC do bem quase nunca rola dado. O que faz o sujeito existir são três
> linhas: **o que quer**, **o que oferece** e **a marca**. Sorteie as
> três e ele está pronto — o resto se inventa falando.

Está no [[🧰 As ferramentas|Gerador de Desafios]], aba **Gente**.

---

## Os oito tipos

%s

---

## Lojas

Loja tem estoque, dono e uma regra da casa que o grupo descobre da pior
forma. O estoque sai dos [[🎒 Itens e Equipamento|itens]] do jogo.

%s

**O dono:** %s

---

## Marcas

A marca é o que a mesa lembra na semana seguinte. Role 1d18 ou escolha.

%s""" % ("\n".join(blocos), "\n".join(lojas),
         " · ".join(t(d) for d in NPC.DONOS_DE_LOJA), marcas))


def gerar():
    NOTAS.clear()
    padroes()
    chefes()
    gente()
    os.makedirs(SAIDA, exist_ok=True)
    for nome, corpo in NOTAS.items():
        open(os.path.join(SAIDA, nome), "w", encoding="utf-8").write(corpo)
    print("Mestre: %d notas" % len(NOTAS))
    return len(NOTAS)


if __name__ == "__main__":
    gerar()
