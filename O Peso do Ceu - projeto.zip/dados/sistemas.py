# -*- coding: utf-8 -*-
"""
Os Sistemas: dano de Físico e de Energia, e as Peças pesadas.

Duas coisas novas entram aqui.

A primeira é o **tipo de dano**, no espírito do Daggerheart e do Lancer:
toda arma é Física ou de Energia, e existem defesas que só servem
contra um dos dois. Tiro de arma de fogo é Físico mesmo sendo à
distância; laser é Energia mesmo encostado.

A segunda são as **Peças pesadas** — cinco por fábrica, dos Escalões
altos: drones, satélite, minas, campo de força e escudo de energia. É o
material que faz a máquina de Escalão 3 e 4 parecer outra coisa, e é
onde moram as asas, que agora só existem de Escalão 3 para cima.
"""

# ====================================================== TIPOS DE DANO
TIPOS_DANO = [
 ("Físico", "F",
  "Massa e velocidade: soco, lâmina, bala, estilhaço, queda, um prédio. "
  "Se a coisa que machuca tem peso, é Físico — e tiro de arma de fogo é "
  "Físico mesmo sendo de longe."),
 ("Energia", "E",
  "Luz, calor, campo e corrente: laser, plasma, hádron, arco elétrico, "
  "lâmina vibratória em ressonância. Se a coisa que machuca não tem "
  "peso, é Energia — e é Energia mesmo encostado no casco."),
]

REGRA_DANO = r"""
Toda arma tem um tipo: \termo{Físico} ou \termo{Energia}. Está escrito
na carta, ao lado do dano. Quem não tem nenhum dos dois marcado é
Físico.

\begin{pctabela}{L{4.4cm} L{10.6cm}}
\cab{Como saber} & \cab{Regra de bolso} \\ \regra
\textbf{Tem peso?} & Então é \termo{Físico}. Bala, lâmina, punho,
estilhaço, entulho. \\
\textbf{Não tem peso?} & Então é \termo{Energia}. Laser, plasma,
hádron, corrente, calor. \\
\textbf{Está em dúvida?} & É Físico. A dúvida sempre cai para o lado
mais comum. \\
\end{pctabela}

\textbf{Por que isso importa.} Blindagem para Físico e Blindagem para
Energia são coisas diferentes, e quase nenhuma máquina tem as duas.
Uma frente inteira se decide por quem descobriu primeiro com o que o
outro atira.

\begin{pctabela}{L{4.6cm} L{10.4cm}}
\cab{Defesa} & \cab{O que faz} \\ \regra
\textbf{Blindagem} & Sem sobrenome, vale contra \termo{Físico}. É o que
o chassi dá. \\
\textbf{Blindagem de Energia} & Só contra \termo{Energia}. Vem de Peça,
nunca de chassi. \\
\textbf{Campo de força} & Barra os dois, mas tem uma conta de quanto
aguenta, e cai quando zera. \\
\textbf{Escudo absorvente} & Come o dano de \termo{Energia} e devolve
em forma de recurso para você. \\
\end{pctabela}

\begin{nota}
\textbf{Não crie um terceiro tipo.} A vontade vai bater — fogo, ácido,
som, frio. Resista: descreva o que quiser e escolha um dos dois. Duas
caixas é o que a mesa consegue lembrar sem consultar.
\end{nota}
"""

# ============================================== AS PEÇAS PESADAS
# (nível, nome, tipo, custo, texto) — o mesmo formato das outras Peças.
# Nível 3 a 5: é material de Escalão 2 para cima, e as asas só de 3.
PESADAS = {

 "BRASA": [
  (3, "Semeadora de Fundo", "Ativa", 1,
   r"Uma ação: espalhe \textbf{três minas} em uma faixa à sua escolha "
   r"até \termo{Perto}. Quem entrar ou sair daquela faixa detona uma e "
   r"sofre \dado{2d10} \termo{Físico} por Proficiência, e fica "
   r"\termo{Instável}. Você enxerga as suas minas; o resto do mundo, "
   r"não. Elas duram a cena."),
  (3, "Chapa Contra Luz", "Fixa", 0,
   r"\textbf{Blindagem de Energia 2.} A Brasa resolveu o problema do "
   r"laser do jeito que resolve tudo: colocando mais chapa, e uma manta "
   r"cerâmica no meio. Pesa. Você perde \textbf{1 Deslocamento}."),
  (4, "Fornalha Aberta", "Ativa", 2,
   r"Uma ação: o casco abre as chaminés e queima. Todo mundo em "
   r"\termo{Muito Perto} sofre \dado{3d10} \termo{Energia} por "
   r"Proficiência e fica \termo{Instável}. Você marca 1 Estresse a mais "
   r"e fica \termo{Vulnerável} até a sua próxima ação — de dentro "
   r"também esquenta."),
  (4, "Martelo de Queda", "Ativa", 2,
   r"Uma ação: caia de cima de qualquer coisa em um alvo até "
   r"\termo{Perto}. \dado{4d10} \termo{Físico} por Proficiência, o alvo "
   r"fica \termo{Restrito} e o chão daquela faixa vira terreno difícil "
   r"para todo mundo, inclusive você."),
  (5, "A Última Brasa", "Tensa", 6,
   r"Enquanto o Mestre tiver \textbf{6 ou mais de Medo}: quando a sua "
   r"Estrutura chegar a zero, o colosso \emph{não cai}. Ele fica de pé "
   r"com 1 de Estrutura até o fim da cena, e todo ataque seu causa "
   r"\dado{+2d10}. No fim da cena ele cai, e não tem conserto de campo: "
   r"é doca ou é sucata."),
 ],

 "VESPERTINA": [
  (3, "Enxame de Vista", "Ativa", 1,
   r"Uma ação: solte \textbf{dois drones de visão}. Enquanto estiverem "
   r"no ar, você vê a cena de cima: \textbf{+2} em rolagens para "
   r"perceber e mirar, ninguém fica \termo{Oculto} de você, e aliados "
   r"em \termo{Perto} somam \textbf{+1} no primeiro ataque do turno. Um "
   r"acerto de área derruba os dois."),
  (3, "Véu de Luz", "Fixa", 0,
   r"\textbf{Blindagem de Energia 1.} O casco tem uma camada de esmalte "
   r"difusor. Além disso, ataques de \termo{Energia} de \termo{Longe} "
   r"ou mais contra você têm desvantagem."),
  (4, "Passo de Andorinha", "Ativa", 1,
   r"Uma reação, quando você for alvo: mude uma faixa de alcance antes "
   r"da rolagem. Se isso tirar você do alcance da arma, o ataque não "
   r"acontece — e o atacante fica \termo{Instável}."),
  (5, "Asa de Fim de Tarde", "Fixa", 0,
   r"\textbf{Requer Escalão 3.} O colosso abre asas e passa a voar "
   r"alto: você ignora terreno, atravessa \textbf{duas faixas} sem "
   r"gastar ação, e ataques corpo a corpo contra você têm desvantagem "
   r"enquanto estiver no ar. Em compensação, no ar você não tem "
   r"cobertura de nada: ataques de \termo{Longe} contra você têm "
   r"vantagem."),
  (5, "Lâmina de Ressonância", "Ativa", 2,
   r"Uma ação: o seu próximo ataque corpo a corpo é \termo{Energia} em "
   r"vez de \termo{Físico}, ignora \termo{Blindagem} comum e causa "
   r"\dado{+2d10}. Contra quem tem Blindagem de Energia, não ignora "
   r"nada — e aí você vai descobrir na hora."),
 ],

 "CATEDRAL": [
  (3, "Vitral", "Ativa", 1,
   r"Uma ação: levante um \textbf{campo de força} de \textbf{10 pontos} "
   r"numa faixa à sua escolha até \termo{Perto}. Ele barra "
   r"\termo{Físico} e \termo{Energia} igualmente, para os dois lados, "
   r"descontando do total até zerar. Enquanto estiver de pé, ninguém "
   r"atravessa aquela faixa sem gastar uma ação."),
  (3, "Manto de Ferro", "Fixa", 0,
   r"\textbf{Blindagem de Energia 2.} Aliados em \termo{Muito Perto} de "
   r"você também contam com \textbf{Blindagem de Energia 1}. A Catedral "
   r"não constrói máquina que salve só o piloto."),
  (4, "Ordem de Parada", "Ativa", 2,
   r"Uma ação: escolha até três adversários em \termo{Perto}. Cada um "
   r"perde a próxima ação, ou o Mestre gasta \textbf{1 Medo} por "
   r"adversário que quiser salvar. Isso é uma ordem, e ordens são "
   r"ouvidas mesmo por quem não obedece."),
  (5, "Abóbada", "Tensa", 4,
   r"Enquanto o Mestre tiver \textbf{4 ou mais de Medo}: um domo de luz "
   r"cobre a sua faixa. Nada de fora acerta nada de dentro sem passar "
   r"por você primeiro — todo ataque vindo de fora muda de alvo para o "
   r"seu colosso. Você escolhe quando ela cai."),
  (5, "Lança de Campanário", "Ativa", 3,
   r"Uma ação, uma vez por cena: um feixe atravessa em linha reta até "
   r"\termo{Muito Longe}. \dado{5d10} \termo{Energia} por Proficiência "
   r"em tudo no caminho, ignorando cobertura e campo de força. Depois "
   r"disso o seu Núcleo fica frio: nada de Peça Ativa até a próxima "
   r"Parada."),
 ],

 "ARCO": [
  (3, "Casco Sifão", "Fixa", 0,
   r"\textbf{Escudo absorvente.} Quando você sofrer dano de "
   r"\termo{Energia}, reduza em \textbf{3} e \textbf{limpe 1 Estresse}. "
   r"O casco do Arco foi feito para engolir descarga elétrica de "
   r"tempestade de mar aberto; laser é a mesma conta."),
  (3, "Boia de Escuta", "Ativa", 1,
   r"Uma ação: largue uma boia na cena. Enquanto estiver lá, você sabe "
   r"onde está todo mundo naquela faixa e na vizinha, mesmo por parede, "
   r"fumaça ou água. Quem destruir a boia revela a própria posição."),
  (4, "Enchente", "Ativa", 2,
   r"Uma ação: a sua faixa e a vizinha alagam. Todo mundo lá, menos "
   r"você e quem você escolher, fica \termo{Instável} e perde 1 "
   r"Deslocamento até o fim da cena. Quem já estava \termo{Restrito} "
   r"começa a se afogar — coisa de uma cena inteira para resolver."),
  (5, "Lastro Solto", "Ativa", 2,
   r"Uma ação: afunde até a cintura e fique imóvel. Até você sair, "
   r"\textbf{Blindagem +3} contra os dois tipos, você não pode ser "
   r"empurrado nem derrubado por nada, e todo ataque seu de "
   r"\termo{Longe} soma \textbf{+2}. Sair custa uma ação."),
  (5, "Fossa", "Tensa", 4,
   r"\textbf{Requer Escalão 3.} Enquanto o Mestre tiver \textbf{4 ou "
   r"mais de Medo}: o seu colosso pode andar por baixo. Você some da "
   r"cena e reaparece em qualquer faixa, uma vez por rodada, sem gastar "
   r"ação. Enquanto estiver embaixo, ninguém te acerta — e você não "
   r"acerta ninguém."),
 ],

 "GRALHA": [
  (3, "Ninhada", "Ativa", 1,
   r"Uma ação: solte \textbf{três drones de ataque} feitos de sucata. "
   r"Cada um ataca com \textbf{+4} e causa \dado{1d10} \termo{Físico} "
   r"por Proficiência, no seu turno, sem gastar a sua ação. Qualquer "
   r"acerto derruba um. Você não conserta: constrói outro na Parada."),
  (3, "Gaiola de Faraday", "Fixa", 0,
   r"\textbf{Blindagem de Energia 2}, feita de barra de ferro e arame. "
   r"É feia, funciona, e some metade quando alguém acerta \termo{Físico} "
   r"em você: cada vez que sofrer dano Físico, a Blindagem de Energia "
   r"cai 1 até a próxima Parada."),
  (4, "Improviso de Doca", "Ativa", 2,
   r"Uma ação: invente uma Peça agora. Escolha uma Peça de nível 3 ou "
   r"menos \emph{de qualquer fábrica} e use uma vez, nesta cena, como se "
   r"tivesse licença. Depois disso ela quebra e você marca 1 Estresse a "
   r"mais. Uma vez por sortida."),
  (5, "Campo Remendado", "Ativa", 2,
   r"Uma ação: um \textbf{campo de força} de \textbf{6 pontos} em volta "
   r"de você e de um aliado à escolha. Ele barra os dois tipos. Toda vez "
   r"que ele absorver dano, role \dado{1d6}: com 1, cai agora."),
  (5, "Frankenstein", "Tensa", 4,
   r"Enquanto o Mestre tiver \textbf{4 ou mais de Medo}: toda vez que um "
   r"colosso cair na cena — aliado, inimigo, tanto faz — você ganha "
   r"\textbf{+2 Estrutura} e uma arma dele até o fim da cena. Não há "
   r"limite, e é exatamente isso que assusta."),
 ],

 "SELO": [
  (3, "Chamada de Órbita", "Ativa", 2,
   r"Uma ação: marque um alvo em qualquer faixa e comece uma "
   r"\termo{Contagem de 3} que só anda no seu turno. Quando fechar, cai "
   r"do céu: \dado{6d10} \termo{Energia} por Proficiência no alvo e "
   r"metade em todo mundo na mesma faixa. O alvo sabe que foi marcado — "
   r"o ponto vermelho é visível, e é de propósito."),
  (3, "Malha de Drones", "Ativa", 1,
   r"Uma ação: dois \textbf{drones de visão} sobem e ficam. Ninguém fica "
   r"\termo{Oculto} de ninguém na sua faixa e na vizinha, e todo aliado "
   r"que atacar um alvo que você marcou soma \textbf{+2}. Vale para os "
   r"dois lados: o inimigo também enxerga."),
  (4, "Cerco", "Ativa", 2,
   r"Uma ação: espalhe \textbf{quatro minas de choque} em duas faixas. "
   r"Quem pisar sofre \dado{2d10} \termo{Energia} por Proficiência e "
   r"fica \termo{Restrito} até gastar uma ação. As minas do Selo "
   r"prendem em vez de matar, porque o Selo prefere prender."),
  (5, "Cúpula do Selo", "Ativa", 3,
   r"Uma ação: \textbf{campo de força} de \textbf{15 pontos} cobrindo a "
   r"sua faixa. Barra os dois tipos, vindo de fora — de dentro sai "
   r"normal. É a peça que segura uma evacuação inteira, e todo mundo na "
   r"frente sabe quando um Selo abre a cúpula."),
  (5, "Olho de Cima", "Tensa", 6,
   r"\textbf{Requer Escalão 3.} Enquanto o Mestre tiver \textbf{6 ou "
   r"mais de Medo}: uma vez por rodada, anule um ataque contra você ou "
   r"contra um aliado em qualquer faixa. O satélite viu antes. O Mestre "
   r"escolhe o que o mundo perde de vista em troca."),
 ],

 "CARVAO": [
  (3, "Mina Fantasma", "Ativa", 1,
   r"Uma ação: plante \textbf{duas minas} que ninguém vê, nem com "
   r"sensor, nem com drone. \dado{3d10} \termo{Físico} por Proficiência "
   r"e o alvo fica \termo{Vulnerável}. Elas ficam na cena até alguém "
   r"pisar, mesmo que a cena acabe."),
  (3, "Manta Fria", "Fixa", 0,
   r"\textbf{Blindagem de Energia 1.} Além disso, você não aparece em "
   r"nenhum sensor, drone ou satélite: para ser achado, alguém precisa "
   r"olhar com o olho e gastar uma ação."),
  (4, "Corta-Linha", "Ativa", 2,
   r"Uma ação contra um alvo em \termo{Muito Perto}: desligue uma Peça "
   r"dele até a próxima Parada Longa, à sua escolha, e todo campo de "
   r"força dele cai agora. Não causa dano nenhum, e é pior."),
  (5, "Sombra Longa", "Ativa", 2,
   r"Uma ação: fique \termo{Oculto} mesmo à vista, em campo aberto, sob "
   r"holofote. Sair do Oculto para atacar dá \dado{+3d10} no primeiro "
   r"golpe, e você continua Oculto se ninguém sobreviver para contar."),
  (5, "Frequência Vazia", "Tensa", 4,
   r"Enquanto o Mestre tiver \textbf{4 ou mais de Medo}: toda arma de "
   r"\termo{Energia} na cena, de qualquer lado, falha com 1--2 em "
   r"\dado{1d6}. Inclusive as suas. O Carvão vende isso como defesa e "
   r"usa como chantagem."),
 ],

 "OSSATURA": [
  (3, "Enxerto Vivo", "Fixa", 0,
   r"\textbf{Escudo absorvente.} Dano de \termo{Energia} contra você é "
   r"reduzido em \textbf{4}, e a cada vez que isso acontecer o casco "
   r"recupera \textbf{1 Estrutura}. A coisa que virou o seu colosso "
   r"gostava de laser."),
  (3, "Cria de Bolso", "Ativa", 1,
   r"Uma ação: solte \textbf{dois drones de ataque} que não são drones. "
   r"Cada um ataca com \textbf{+5}, causa \dado{1d10} \termo{Físico} por "
   r"Proficiência, e se alimenta: cada vez que um acerta, ele ganha +1 "
   r"de dano até o fim da cena. Eles não voltam sozinhos."),
  (4, "Costela Aberta", "Ativa", 2,
   r"Uma ação: marque 2 Estresse para ganhar \textbf{+3 Estrutura} e "
   r"\dado{+2d10} em todo ataque até o fim da cena. Quando a cena "
   r"acabar, role \dado{1d6}: com 1 ou 2, uma Peça instalada some — "
   r"o casco comeu."),
  (5, "Campo de Carne", "Tensa", 4,
   r"Enquanto o Mestre tiver \textbf{4 ou mais de Medo}: um "
   r"\textbf{campo de força} orgânico de \textbf{8 pontos} fica de pé "
   r"sozinho em volta de você, e se recompõe em 3 pontos no começo de "
   r"cada rodada. Barra os dois tipos. Ninguém, nem o Anel, sabe "
   r"explicar como."),
  (5, "A Virada", "Ativa", 3,
   r"Uma ação, uma vez por sortida: escolha uma \termo{Funda} ou um "
   r"colosso de Ossatura na cena. Ele para de lutar contra você e passa "
   r"a lutar do seu lado até o fim da cena. Quando acabar, o Mestre "
   r"ganha \textbf{3 Medo} — e alguma coisa lembrou do seu rosto."),
 ],
}


def todas_pesadas():
    """Lista plana, para conferência."""
    return [(fab,) + p for fab, ps in PESADAS.items() for p in ps]
