# -*- coding: utf-8 -*-
"""
Gente do lado de cá: quem o grupo encontra e não precisa matar.

O gerador de desafios sabia inventar quem bate. Faltava quem recebe,
quem vende, quem manda e quem só estava ali. Isto é o material dessa
outra metade — oito tipos, cada um com o que quer, o que oferece e a
marca que faz a mesa lembrar dele na semana seguinte.

A ficha é de propósito magra. NPC do bem quase nunca rola dado; quando
rola, uma linha basta. O que importa é **querer**, **oferecer** e
**marca** — é isso que faz o sujeito existir.
"""

# ================================================================= NOMES
NOMES = [
 "Ivo", "Neuza", "Dario", "Cida", "Aurélio", "Jandira", "Rubem",
 "Perpétua", "Otávio", "Iracema", "Genaro", "Lurdes", "Waldemar",
 "Zuleica", "Anselmo", "Divina", "Bento", "Marlene", "Aparício",
 "Terezinha", "Nestor", "Dulce", "Sebastião", "Cleide", "Adauto",
 "Rosalina", "Hermes", "Glória", "Fausto", "Benedita",
]

SOBRENOMES = [
 "Rennó", "Bastos", "Quintela", "Salles", "Amorim", "Corrêa",
 "Vilela", "Peçanha", "Tavares", "Nogueira", "Macedo", "Furtado",
 "Ribas", "Coutinho", "Assunção", "Dantas", "Frota", "Mesquita",
 "Vasques", "Serra", "Leitão", "Brandão", "Paiva", "Cordeiro",
 "Azenha", "Malta", "Sampaio", "Rebouças", "Godoi", "Teixeira",
]

ALCUNHAS = [
 "Meia-Noite", "Pé de Ferro", "Caneco", "Sete", "Lanterna", "Cabo",
 "Dedo", "Tico", "Mão Fria", "Boa Noite", "Régua", "Vinte",
 "Fivela", "Chumbo", "Prego", "Quinze", "Terço", "Rabicho",
]


# ================================================================= TIPOS
# (id, nome, plural, o que é, como resolver na mesa)
TIPOS = [
 ("capitao", "Capitã ou capitão", "Capitães",
  "Quem responde por uma frente, uma doca ou uma linha. Tem gente "
  "debaixo dela e alguém em cima cobrando.",
  "Rola como Regular de Escalão 2 se precisar: Evasão 11, ataque "
  "\\dado{+3}. Mas o que ela faz de verdade é **dar ordem** — e a "
  "ordem vale mais do que a arma."),

 ("rei", "Regente", "Regentes",
  "Quem assina. Pode ser rei, pode ser presidente de junta, pode ser a "
  "dona da fábrica. O nome muda; a caneta é a mesma.",
  "Não rola. Se um regente precisou rolar dado, alguma coisa já deu "
  "muito errado — e aí ele é um Apoio de Escalão 1 com dez guardas."),

 ("cavaleiro", "Cavaleira de mecha", "Cavaleiros de mecha",
  "Piloto juramentado. Tem colosso próprio, nome no casco e um voto "
  "que explica por que ela não usa aquilo para ganhar dinheiro.",
  "Usa uma ficha de colosso igual à dos jogadores, no Escalão da mesa. "
  "Se entrar numa briga do lado do grupo, conta como mais um piloto — "
  "e tire 3 Pontos de Batalha do orçamento do inimigo."),

 ("vendedor", "Vendedora ambulante", "Vendedores",
  "Carrega o estoque nas costas ou numa carroça. Aparece onde tem "
  "gente e some quando começa o tiro.",
  "Não rola. Tem de dois a quatro itens e um preço que não é dinheiro: "
  "é favor, é informação, é carona."),

 ("loja", "Loja", "Lojas",
  "Ponto fixo, com nome na porta e uma pessoa atrás do balcão que "
  "conhece todo mundo da rua.",
  "Não rola. Tem estoque, tem dono e tem uma regra da casa que o grupo "
  "vai descobrir da pior forma."),

 ("soldado", "Soldada ou soldado", "Soldados",
  "Fardado. Faz turno, recebe atrasado e não escolheu o lado — "
  "escolheu o emprego.",
  "Lacaio de Escalão 1: Evasão 9, 1 de Estrutura, ataque \\dado{+1}. "
  "Em grupo de cinco ou mais, trate como um Regular só e resolva numa "
  "rolagem."),

 ("protetor", "Protetora do reino", "Protetores do reino",
  "O corpo que existe para uma coisa só: que aquilo continue de pé. "
  "Guarda de muralha, guarda de represa, guarda de arquivo.",
  "Brutamontes de Escalão 2 quando defende o que jurou; Regular de "
  "Escalão 1 em qualquer outro lugar. A diferença é o lugar, não a "
  "pessoa."),

 ("povo", "Gente da rua", "População",
  "Quem mora ali. Não vai lutar, não vai fugir a tempo e sabe coisa "
  "que ninguém perguntou.",
  "Não rola. Serve para duas coisas: saber e atrapalhar. As duas "
  "valem uma cena inteira."),
]


# ================================================================ QUERER
# o que cada tipo quer — é o que dá o que fazer
QUERER = {
 "capitao": [
  "Que a frente aguente mais três dias, e ninguém pergunte por quê.",
  "O nome de quem vendeu a posição dela na semana passada.",
  "Trocar dezoito recrutas por seis que saibam atirar.",
  "Que o superior dela seja transferido para longe, vivo.",
  "Um colosso — qualquer um — antes da próxima maré.",
  "Enterrar os dela com o nome certo na lápide.",
 ],
 "rei": [
  "Que a fábrica pare de mandar mais do que ele pediu.",
  "Um herdeiro que não seja o que ele tem.",
  "O contrato antigo de volta, com o selo original.",
  "Que ninguém descubra de onde veio o dinheiro da represa.",
  "Alguém de fora, sem dívida com nenhuma casa, para julgar uma coisa.",
  "Terminar o mandato sem assinar a guerra.",
 ],
 "cavaleiro": [
  "Cumprir um voto que já não faz sentido para mais ninguém.",
  "Encontrar quem pilotava a máquina que matou o instrutor dela.",
  "Peça de reposição que a casa dela parou de fabricar.",
  "Ser dispensada do juramento sem desonra.",
  "Um duelo limpo, com testemunha, contra alguém que a mesa conhece.",
  "Provar que a casa errou — e continuar servindo depois disso.",
 ],
 "vendedor": [
  "Passar pelo posto sem abrir a carroça.",
  "Vender o que não devia ter comprado.",
  "Uma escolta até a próxima cidade, e volta.",
  "Saber quem anda comprando o mesmo que ele, e por quê.",
  "Recuperar o que ficou penhorado na doca.",
  "Um freguês que pague em coisa e não em promessa.",
 ],
 "loja": [
  "Que a rua volte a ter movimento.",
  "Que aquela dívida específica suma do livro.",
  "Um fornecedor novo, porque o antigo morreu.",
  "Que ninguém descubra o que tem no fundo do depósito.",
  "Passar o ponto e sair da cidade antes do inverno.",
  "Que a filha assuma o balcão e não o colosso.",
 ],
 "soldado": [
  "Receber os três meses atrasados.",
  "Uma baixa médica que segure de pé numa auditoria.",
  "Ser transferido para perto de casa.",
  "Que ninguém conte o que ele viu na doca.",
  "Comer quente uma vez.",
  "Que a guerra acabe antes do turno dele.",
 ],
 "protetor": [
  "Fechar o portão e não ter que explicar a ninguém.",
  "Mais três pessoas na escala, ou duas que prestem.",
  "Que a coisa que ela guarda seja finalmente retirada dali.",
  "Saber o que tem dentro do que ela guarda há dezoito anos.",
  "Uma ordem por escrito, assinada, para poder desobedecer a outra.",
  "Morrer no posto, e que isso conte para alguma coisa.",
 ],
 "povo": [
  "Que o grupo vá embora antes que a briga chegue na casa dele.",
  "Notícia de alguém que saiu e não voltou.",
  "Que alguém pague o telhado que a última briga levou.",
  "Contar a história toda para quem escute até o fim.",
  "Vender uma coisa que não é dele.",
  "Só atravessar a rua.",
 ],
}


# ================================================================= MARCA
# a marca é o que a mesa lembra na semana seguinte
MARCA = [
 "Fala baixo e faz todo mundo se calar para ouvir.",
 "Nunca olha para o colosso, só para o piloto.",
 "Tem uma queimadura de Energia no pescoço, mal curada.",
 "Chama todo mundo pelo sobrenome, inclusive as crianças.",
 "Ri antes de dar má notícia, e só percebe depois.",
 "Guarda tudo em caderninho e não confia em nada que não esteja lá.",
 "Perdeu dois dedos e usa a mão assim mesmo, sem esconder.",
 "Fala de si na terceira pessoa quando está com medo.",
 "Cheira a óleo de motor por baixo do perfume.",
 "Repete a última palavra de quem fala com ela.",
 "Anda com um rádio velho ligado no canal errado, de propósito.",
 "Não senta de costas para a porta. Nunca.",
 "Chora com facilidade e continua falando do mesmo jeito.",
 "Tem uma peça de colosso no bolso, e não diz de qual.",
 "Corrige o nome das fábricas quando alguém erra.",
 "Dorme de botina. Diz que é por causa da maré.",
 "Fala português e mais uma língua que ninguém ali reconhece.",
 "Oferece comida antes de perguntar qualquer coisa.",
]


# =============================================================== OFERECER
OFERECER = {
 "capitao": [
  "Passagem livre pela frente dela, uma vez, sem registro.",
  "Um pelotão de seis para uma hora, e ela não pergunta para quê.",
  "O mapa das posições que ela devia ter destruído.",
  "Munição de cabine, quanto couber no bolso.",
  "Abrigo dentro do perímetro por uma noite.",
  "O nome verdadeiro de quem deu a ordem.",
 ],
 "rei": [
  "Uma licença de fábrica no papel timbrado dele.",
  "Perdão para uma coisa já feita, com selo.",
  "Acesso ao arquivo fechado, com alguém olhando.",
  "Dinheiro, que resolve menos do que o grupo espera.",
  "Um título que abre porta em três cidades.",
  "Que ele não assine a ordem de captura por mais dez dias.",
 ],
 "cavaleiro": [
  "Entra numa briga do lado do grupo. Uma.",
  "Treino: um traço +1 até o fim do arco.",
  "A Peça que ela carrega de reserva.",
  "Testemunho dela vale em qualquer foro da Catedral.",
  "Leva o grupo por dentro de uma linha fechada.",
  "O casco antigo dela, que ainda anda.",
 ],
 "vendedor": [
  "Dois itens do estoque pelo preço de um favor.",
  "Fiado, com juros que não são em dinheiro.",
  "Onde estava, o que viu e quem estava junto.",
  "Um item estranho que ele não sabe o que é.",
  "Conserto de campo: limpa 2 de Estrutura, uma vez.",
  "Esconde o grupo na carroça por um posto.",
 ],
 "loja": [
  "Estoque aberto, preço de casa.",
  "Encomenda que chega em três dias, se o grupo voltar.",
  "O que ficou penhorado por alguém que não voltou.",
  "O fundo do depósito, e o que houver lá.",
  "Recado guardado e entregue a quem o grupo disser.",
  "Crédito na praça: o nome do grupo passa a valer ali.",
 ],
 "soldado": [
  "A senha do turno da noite.",
  "Olha para o outro lado por dez minutos.",
  "O que todo mundo no quartel comenta e ninguém confirma.",
  "Uma farda extra, do tamanho errado.",
  "Deserta e vai junto, se alguém pedir direito.",
  "Chave do portão dos fundos, que ele devia ter devolvido.",
 ],
 "protetor": [
  "Deixa passar, uma vez, e assume a culpa depois.",
  "Segura a faixa dele por uma rodada inteira, contra qualquer coisa.",
  "A planta do lugar, decorada há dezoito anos.",
  "O que ele guarda — mas só se o grupo levar embora de vez.",
  "Abrigo atrás da muralha, com comida.",
  "O nome de quem construiu aquilo, e onde a pessoa mora.",
 ],
 "povo": [
  "A história inteira, com os nomes certos.",
  "Onde fica a passagem que não está no mapa.",
  "Guarda uma coisa do grupo, e guarda mesmo.",
  "Comida quente e um lugar no chão.",
  "Grita quando alguém chegar. É mais útil do que parece.",
  "Uma coisa que ele achou na rua depois da última briga.",
 ],
}


# ================================================================= LOJAS
# (id, nome, o que vende, tipos de item, quantos, regra da casa)
LOJAS = [
 ("doca", "Casa de doca", "Peça de colosso e conserto de campo",
  ["Mecânico"], (3, 5),
  "Não fia para quem chega de colosso. Quem chega a pé, fia."),
 ("armaria", "Armaria de esquina", "Arma de cabine e munição",
  ["Arma"], (3, 5),
  "Arma sai destravada só com nome no livro. O livro some às terças."),
 ("alfaiate", "Alfaiataria de voo", "Traje, macacão e remendo",
  ["Traje"], (2, 4),
  "Mede o piloto inteiro antes de vender. Guarda as medidas."),
 ("ferro", "Ferro-velho", "O que cair de máquina, misturado",
  ["Mecânico", "Arma", "Estranho"], (4, 7),
  "Preço por peso, não por peça. Ninguém pergunta de onde veio."),
 ("botica", "Botica de porto", "Coisa estranha que funciona",
  ["Estranho"], (2, 4),
  "Só vende um item estranho por pessoa por lua. Ela conta as luas."),
 ("feira", "Feira", "Um pouco de tudo, nada garantido",
  ["Arma", "Traje", "Mecânico", "Estranho"], (4, 8),
  "O preço muda conforme a cara do freguês, e ela lê cara muito bem."),
]

DONOS_DE_LOJA = [
 "herdou do pai e odeia o ramo",
 "é ex-piloto e não fala sobre isso",
 "tem um filho preso numa frente",
 "compra informação melhor do que vende ferro",
 "está de saída e liquida tudo",
 "não é o dono de verdade, e sabe disso",
]
