# -*- coding: utf-8 -*-
"""
O elenco: colossos das oito fábricas, Fundas e gente.

As fichas não são escritas à mão. Cada Escalão tem uma linha fixa; cada
papel multiplica a Estrutura e mexe na Evasão. O Mestre inventa um
adversário novo em trinta segundos: escolhe Escalão, escolhe papel, lê a
linha, escreve dois traços.

LINHA DO ESCALÃO
    esc   Evasão   Limiares   Ataque   Dano        Estrutura
     1      11       6/13       +2     1d10+5          5
     2      13      10/19       +4     2d10+6          7
     3      15      13/26       +6     3d10+7          9
     4      17      17/32       +8     4d10+9         11
"""

LINHA = {1: (11,  6, 13, 2, 1, 5,  5),
         2: (13, 10, 19, 4, 2, 6,  7),
         3: (15, 13, 26, 6, 3, 7,  9),
         4: (17, 17, 32, 8, 4, 9, 11)}

PAPEL = {
 "Lacaio":      (None, -2, 1,  "Cai com qualquer acerto. Vem em grupo de três ou mais."),
 "Batedor":     (0.6, +2, 2,   "Chega, morde e sai. Difícil de acertar."),
 "Atirador":    (0.6,  0, 2,   "Fica longe. Se deixarem chegar perto, acaba."),
 "Apoio":       (0.8,  0, 2,   "Não vence sozinho. Faz os outros vencerem."),
 "Regular":     (1.0,  0, 3,   "A linha. É por ela que se mede tudo."),
 "Bando":       (1.2,  0, 4,   "Conta como vários. O dano cai pela metade na segunda metade da Estrutura."),
 "Comandante":  (1.4,  0, 4,   "Gasta o Medo do Mestre melhor que os outros."),
 "Brutamontes": (1.8, -1, 5,   "Aguenta. Lento e caro de derrubar."),
 "Solo":        (2.8, +1, 10,  "Sozinho contra o grupo inteiro."),
}


def ficha(esc, papel, dev=0, dest=0):
    eva, ma, se, atq, nd, nb, est = LINHA[esc]
    mult, ajd, _custo, _como = PAPEL[papel]
    eva += ajd + dev
    estrutura = 1 if mult is None else max(1, int(round(est * mult))) + dest
    return (eva, ma, se, atq, "%dd10+%d" % (nd, nb), estrutura)


# ---------------------------------------------------------------- elenco
# COLOSSOS: (id, NOME, esc, papel, fábrica, arma_dir, arma_esq, extras,
#            alcance, nome do ataque, descrição, motivos, [(traço, tipo, texto)])

COLOSSOS = [
# ---------------------------------------------------------- BRASA (8)
 ("brMilicia", "MILÍCIA", 1, "Lacaio", "BRASA", "punho", "punho", {},
  "Perto", "Fuzil requisitado",
  "Casco de fábrica com tinta nova por cima da tinta velha. Quem está "
  "dentro aprendeu a pilotar em seis semanas.",
  "Cumprir a ordem · não ficar sozinho · voltar",
  [("Grupo de Três", "Passiva", "Milícias vêm em três ou mais. Dano que "
    "sobra de derrubar uma passa para a seguinte."),
   ("Recuar", "Reação", "Quando a primeira cai, as outras ficam "
    "\\termo{Instáveis} até a próxima ação delas.")]),

 ("brMula", "MULA", 1, "Regular", "BRASA", "martelo", "punho", {},
  "Corpo a corpo", "Marreta de serviço",
  "O casco mais vendido do continente. Feio, lento, e ainda de pé.",
  "Aguentar · empurrar · terminar o turno",
  [("Chapa em Cima de Chapa", "Passiva", "Reduz em um degrau o primeiro "
    "dano que sofre em cada cena."),
   ("Empurra", "Ação de Medo", "Gaste 1 Medo: joga um alvo uma faixa de "
    "alcance para longe e o deixa \\termo{Instável}.")]),

 ("brGuincho", "GUINCHO", 1, "Apoio", "BRASA", "arpeu", "arpeu", {},
  "Longe", "Gancho duplo",
  "Máquina de doca convertida às pressas. Dois braços de guincho e "
  "nenhuma arma de verdade.",
  "Puxar · levantar · tirar alguém de debaixo de alguma coisa",
  [("Reboque", "Ação", "Arrasta um alvo \\termo{Restrito} duas faixas de "
    "alcance, ou tira um aliado caído da cena."),
   ("Solda", "Ação", "Limpa 2 Estrutura de um adversário que alcance.")]),

 ("brBigorna", "BIGORNA", 2, "Brutamontes", "BRASA", "martelo", "escudo", {},
  "Corpo a corpo", "Punho de fundição",
  "Chapa em cima de chapa, sem uma única concessão à velocidade.",
  "Ficar de pé · segurar a porta · nunca correr",
  [("Não Cai", "Passiva", "Não pode ser empurrado, puxado, derrubado nem "
    "movido por efeito nenhum."),
   ("Marreta", "Ação de Medo", "Gaste 2 Medo: o dano é rolado duas vezes, "
    "fica com o maior, e o alvo voa duas faixas.")]),

 ("brFornalha", "FORNALHA", 2, "Brutamontes", "BRASA", "canhao", "punho",
  {"cabeca": "crania"},
  "Muito Perto", "Lança-chamas de assalto",
  "Uma caldeira com pernas. Chega perto, esquenta tudo e fica lá.",
  "Negar espaço · queimar o que não sai · aguentar",
  [("Setor Quente", "Passiva", "Quem começa a ação em Muito Perto dela "
    "marca 1 Estresse."),
   ("Sopro", "Ação de Medo", "Gaste 2 Medo: todos em Muito Perto sofrem o "
    "dano dela, aliados inclusive.")]),

 ("brQuebraLinha", "QUEBRA-LINHA", 3, "Brutamontes", "BRASA", "lanca", "punho",
  {"torso": "blindado"},
  "Muito Perto", "Aríete de encaixe",
  "Desenhado para uma coisa só: atravessar uma formação pelo meio.",
  "Abrir o meio · não desviar · chegar no que está atrás",
  [("Nada no Caminho", "Passiva", "Atravessa parede, barricada e cobertura "
    "como se não existissem."),
   ("Rompe", "Ação de Medo", "Gaste 3 Medo: atravessa a cena em linha reta. "
    "Cada colosso no caminho sofre o dano e fica \\termo{Instável}.")]),

 ("brCapataz", "CAPATAZ", 3, "Comandante", "BRASA", "martelo", "arpeu",
  {"ombro": "bloco"},
  "Perto", "Marreta e apito",
  "Vinte anos de turno. Sabe exatamente quanto vale cada um dos seus e "
  "quanto vale perder um.",
  "Terminar o serviço · não perder ninguém · ganhar devagar",
  [("Turno", "Ação", "Dois adversários que o ouçam agem imediatamente."),
   ("Todo Mundo Junto", "Ação de Medo", "Gaste 2 Medo: todos os "
    "adversários da cena agem uma vez.")]),

 ("brUltimaBrasa", "A ÚLTIMA BRASA", 4, "Solo", "BRASA", "martelo", "escudo",
  {"torso": "blindado", "ombro": "escapamento"},
  "Corpo a corpo", "Marreta de fundição",
  "O protótipo que a Brasa nunca vendeu, pilotado pela mesma pessoa há "
  "trinta e um anos. As duas coisas estão gastas do mesmo jeito.",
  "Ficar de pé até o fim · levar alguém junto · não pedir nada",
  [("Não Acaba", "Passiva", "Quando marcaria a última Estrutura, marca "
    "metade e continua. Uma vez por cena."),
   ("Ferro Velho de Guerra", "Passiva", "Reduz todo dano em um degrau "
    "enquanto tiver mais da metade da Estrutura."),
   ("Agarra", "Ação de Medo", "Gaste 3 Medo: agarra um colosso. Os dois "
    "ficam \\termo{Restritos} e o alvo sofre o dano dela a cada ação, até "
    "alguém cair.")]),

# ------------------------------------------------------ VESPERTINA (8)
 ("vpAluno", "ALUNO", 1, "Lacaio", "VESPERTINA", "espada", "punho", {},
  "Corpo a corpo", "Lâmina de treino",
  "Casco de academia com as armas destravadas por alguém que não devia.",
  "Provar alguma coisa · não decepcionar · sobreviver à primeira",
  [("Formação", "Passiva", "Enquanto houver outro Aluno na cena, todos "
    "somam \\textbf{+2} de Evasão."),
   ("Primeiro Dia", "Reação", "Quando um Aluno cai, os outros ficam "
    "\\termo{Vulneráveis} até a próxima ação deles.")]),

 ("vpBatedor", "BATEDOR", 1, "Batedor", "VESPERTINA", "espada", "arpeu", {},
  "Perto", "Lâmina curta",
  "Casco leve, patim gasto, nenhuma blindagem. Existe para chegar antes "
  "e contar.",
  "Ver · contar · não brigar",
  [("Rápido", "Passiva", "Atravessa duas faixas de alcance por ação."),
   ("Foi Embora", "Reação", "Quando é atingido, muda de posição "
    "imediatamente, sem gastar ação.")]),

 ("vpAndorinha", "ANDORINHA", 2, "Batedor", "VESPERTINA", "espada", "espada",
  {"ombro": "leque"},
  "Perto", "Corte de passagem",
  "Casco de academia, piloto de academia, e um jeito de atravessar a "
  "cena que parece ensaiado. Foi.",
  "Chegar primeiro · cortar e sair · não ser tocada",
  [("Rasante", "Passiva", "Fica \\termo{Oculta} sempre que atravessa duas "
    "faixas de alcance ou mais."),
   ("Passa e Corta", "Ação de Medo", "Gaste 2 Medo: atravessa a cena "
    "atacando cada alvo no caminho.")]),

 ("vpFlorete", "FLORETE", 2, "Regular", "VESPERTINA", "espada", "escudo", {},
  "Corpo a corpo", "Estocada",
  "Duelista de contrato. Não pertence a exército nenhum e está aqui por "
  "causa de uma pessoa específica.",
  "Encontrar quem procura · lutar limpo até não valer a pena · vencer",
  [("Guarda", "Passiva", "Ataques corpo a corpo contra ele têm "
    "desvantagem."),
   ("Escolhe Um", "Ação de Medo", "Gaste 2 Medo: declara um duelo. Os dois "
    "somam \\textbf{+2} um contra o outro e têm desvantagem contra "
    "qualquer outra pessoa.")]),

 ("vpEstilete", "ESTILETE", 3, "Batedor", "VESPERTINA", "espada", "garra",
  {"cabeca": "monoocular", "ombro": "leque"},
  "Corpo a corpo", "Duas lâminas",
  "Manto sem insígnia, sem número e sem registro. Não existe papel que "
  "diga que ele esteve aqui.",
  "Uma pessoa · uma cena · nenhuma testemunha",
  [("Sem Registro", "Passiva", "Não pode ser marcado, travado nem "
    "identificado. Sensor nenhum o encontra."),
   ("Sentença", "Ação de Medo", "Gaste 3 Medo: contra um alvo com metade "
    "ou menos da Estrutura, acerta sem rolagem e causa uma Avaria.")]),

 ("vpAurora", "AURORA", 3, "Apoio", "VESPERTINA", "fuzil", "escudo",
  {"ombro": "leque"},
  "Longe", "Fuzil de marcação",
  "Casco de comando de esquadrão. Voa alto, fala pouco e sabe onde "
  "todo mundo está.",
  "Manter a formação viva · ver primeiro · não ser vista",
  [("Marcação", "Ação", "Marca um alvo: todos os ataques contra ele somam "
    "\\textbf{+2 por Proficiência} até o fim da cena."),
   ("Cobertura", "Reação", "Quando um aliado em Longe sofreria dano, "
    "reduz um degrau.")]),

 ("vpVespertina", "VESPERTINA", 4, "Solo", "VESPERTINA", "espada", "escudo",
  {"ombro": "leque", "torso": "estreito"},
  "Muito Perto", "Lança do serviço pessoal",
  "Casco branco de última geração, manto e um nome que os soldados dos "
  "dois lados conhecem.",
  "Terminar a guerra do jeito dela · proteger uma pessoa · não perder",
  [("Aletas", "Passiva", "Voa. Não existe terreno, altura nem cobertura "
    "para ela."),
   ("Guarda Alta", "Passiva", "A primeira vez em cada cena que sofreria "
    "dano, não sofre."),
   ("Três Tempos", "Ação de Medo", "Gaste 3 Medo: age três vezes "
    "seguidas, sem passar o holofote.")]),

 ("vpLeque", "LEQUE", 4, "Comandante", "VESPERTINA", "espada", "espada",
  {"ombro": "leque"},
  "Corpo a corpo", "Par de lâminas",
  "Comanda um esquadrão de seis e nunca perdeu nenhum. Isso é um "
  "problema, porque ela sabe.",
  "Trazer todos de volta · ser obedecida · não ser a primeira a cair",
  [("Esquadrão", "Passiva", "Todo aliado em até Longe soma \\textbf{+1} "
    "de Evasão e de ataque."),
   ("Em Formação", "Ação de Medo", "Gaste 2 Medo: três aliados agem "
    "imediatamente, um de cada vez.")]),

# -------------------------------------------------------- CATEDRAL (8)
 ("ctGuarnicao", "GUARNIÇÃO", 1, "Regular", "CATEDRAL", "canhao", "escudo", {},
  "Longe", "Canhão de torre",
  "O casco padrão de defesa de instalação. Não persegue ninguém: fica.",
  "Segurar o portão · avisar o comando · não sair do lugar",
  [("Posto Fixo", "Passiva", "Não muda de lugar. Em troca, tem "
    "\\textbf{+3} de Limiar Maior."),
   ("Alarme", "Ação de Medo", "Gaste 1 Medo: chegam duas Milícias.")]),

 ("ctSargento", "SARGENTO", 1, "Comandante", "CATEDRAL", "espada", "escudo", {},
  "Perto", "Espada de serviço",
  "Vinte anos de farda. Sabe exatamente quanto vale cada um dos seus.",
  "Manter a formação · não perder ninguém · ganhar devagar",
  [("Formar", "Ação", "Todo adversário em Perto ganha \\textbf{+2} de "
    "Evasão até a próxima ação dele."),
   ("Avançar!", "Ação de Medo", "Gaste 2 Medo: todos os adversários "
    "perto dele agem uma vez, agora.")]),

 ("ctGuarda", "GUARDA", 2, "Regular", "CATEDRAL", "lanca", "escudo", {},
  "Muito Perto", "Lança de encaixe",
  "Casco de choque com quatro metros de haste. Serve para manter as "
  "coisas à distância de um braço.",
  "Furar a formação · chegar ao comandante · não deixar ninguém colar",
  [("Alcance", "Passiva", "Ataca em Muito Perto sem dar reação ao alvo."),
   ("Investida", "Ação de Medo", "Gaste 1 Medo: atravessa duas faixas e "
    "ataca ao chegar, com vantagem.")]),

 ("ctTenente", "TENENTE", 2, "Comandante", "CATEDRAL", "espada", "escudo",
  {"tem_capa": True},
  "Perto", "Espada de comando",
  "Manto curto, casco de fundição boa e uma carreira inteira apostada "
  "nesta missão.",
  "Vencer com a tropa viva · provar alguma coisa · ser promovido",
  [("Ordem", "Ação", "Dois adversários em até Longe agem imediatamente."),
   ("Escudo Humano", "Reação", "Quando seria atingido, um adversário em "
    "Muito Perto leva no lugar.")]),

 ("ctArcada", "ARCADA", 3, "Brutamontes", "CATEDRAL", "canhao", "escudo",
  {"torso": "blindado"},
  "Longe", "Bateria de casco",
  "Doze metros de chapa do Estado, com brasão pintado no peito e um "
  "canhão que já derrubou prédio.",
  "Ser visto · ser obedecido · encerrar o assunto",
  [("Brasão", "Passiva", "Enquanto estiver de pé, todo adversário aliado "
    "tem \\textbf{+1} de Evasão."),
   ("Abóbada", "Ação de Medo", "Gaste 3 Medo: um domo cobre a posição "
    "dela por uma cena. Nada de fora acerta nada de dentro.")]),

 ("ctCapitao", "CAPITÃO", 3, "Comandante", "CATEDRAL", "lanca", "escudo",
  {"tem_capa": True},
  "Muito Perto", "Lança de estandarte",
  "Manto, lança e o direito de decidir quem morre hoje. Usa esse "
  "direito com cuidado, o que o torna pior.",
  "Vencer a campanha, não a briga · gastar o mínimo · sair com a tropa",
  [("Dobra a Linha", "Ação", "Três adversários em até Longe agem "
    "imediatamente, um de cada vez."),
   ("Retirada Ordenada", "Ação de Medo", "Gaste 3 Medo: todos os "
    "adversários saem da cena intactos, levando o que vieram buscar.")]),

 ("ctLegado", "LEGADO", 4, "Solo", "CATEDRAL", "lanca", "escudo",
  {"tem_capa": True, "torso": "blindado"},
  "Corpo a corpo", "Lança e escudo de estandarte",
  "Não é um piloto: é uma instituição com pernas. Está em serviço há "
  "mais tempo que a maioria dos exércitos que enfrentou.",
  "Manter a ordem antiga · não recuar um metro · ser o último",
  [("Estandarte", "Passiva", "Todo adversário em campo soma \\textbf{+1} "
    "de ataque e não pode fugir."),
   ("Não Cai", "Passiva", "Quando marcaria a última Estrutura, marca "
    "metade e continua. Uma vez por cena."),
   ("Ordem Final", "Ação de Medo", "Gaste 4 Medo: todo adversário em "
    "campo age uma vez, na ordem que o Mestre quiser.")]),

 ("ctCampanario", "CAMPANÁRIO", 4, "Atirador", "CATEDRAL", "canhao", "canhao",
  {"torso": "blindado", "perna": "nenhuma"},
  "Muito Longe", "Tubos de sítio",
  "Sem pernas: quatro macacos hidráulicos e vinte e quatro tubos. Levou "
  "duas horas para se montar ali.",
  "Cobrir o mapa · não deixar ninguém parado · não ser alcançado",
  [("Assentado", "Passiva", "Não se move. Desmontar e montar leva uma "
    "cena inteira."),
   ("Barragem", "Ação de Medo", "Gaste 3 Medo: três alvos à escolha "
    "sofrem o dano dele ao mesmo tempo.")]),

# ------------------------------------------------------------ ARCO (8)
 ("arVazante", "VAZANTE", 1, "Regular", "ARCO", "canhao", "arpeu", {},
  "Longe", "Canhão de convés",
  "Casco anfíbio de patrulha portuária. Passa metade do turno na água e "
  "metade no cais.",
  "Interditar · abordar · não deixar sair do porto",
  [("Anfíbio", "Passiva", "Água não é terreno difícil, e ele fica "
    "submerso indefinidamente."),
   ("Interditado", "Ação de Medo", "Gaste 2 Medo: um trecho de água fica "
    "fechado. Quem entrar sofre o dano dele automaticamente.")]),

 ("arMergulho", "MERGULHO", 1, "Batedor", "ARCO", "garra", "garra",
  {"perna": "nenhuma"},
  "Corpo a corpo", "Garras de fundo",
  "Casco selado, sem pernas, com quatro propulsores de água. Em terra é "
  "uma piada; na água, não.",
  "Puxar para o fundo · esperar embaixo · nunca sair da água",
  [("Só na Água", "Passiva", "Fora da água não se move e rola tudo com "
    "desvantagem. Dentro, \\textbf{+2} de Evasão."),
   ("Puxa", "Ação de Medo", "Gaste 2 Medo: leva um alvo para o fundo. Sem "
    "casco selado, o alvo marca 1 Estrutura por cena.")]),

 ("arBoia", "BOIA", 2, "Atirador", "ARCO", "canhao", "canhao",
  {"perna": "nenhuma"},
  "Muito Longe", "Tubos de superfície",
  "Plataforma ancorada no meio do canal. É uma bateria com casco de "
  "barco.",
  "Não sair do lugar · cobrir a água inteira · afundar por último",
  [("Ancorada", "Passiva", "Não se move. \\textbf{+3} nos dois Limiares."),
   ("Cortina", "Ação de Medo", "Gaste 2 Medo: cobre duas faixas de "
    "alcance de fogo. Quem estiver lá sofre o dano e fica "
    "\\termo{Instável}.")]),

 ("arDraga", "DRAGA", 2, "Regular", "ARCO", "canhao", "garra",
  {"perna": "coluna"},
  "Longe", "Canhão de lama",
  "Boca de sucção capaz de esvaziar um canal. Foi máquina de porto até "
  "três meses atrás.",
  "Revolver o fundo · encher tudo de lodo · trabalhar",
  [("Lodo", "Ação", "Enche um lugar de lodo: vira terreno difícil e "
    "ninguém fica \\termo{Oculto} lá."),
   ("Suga", "Ação de Medo", "Gaste 2 Medo: um alvo em Longe é puxado até "
    "Muito Perto e fica \\termo{Restrito}.")]),

 ("arGuardaCosta", "GUARDA-COSTA", 3, "Regular", "ARCO", "canhao", "escudo", {},
  "Longe", "Bateria de convés",
  "Casco de guarda costeira pesado, com casco duplo e reputação de "
  "nunca voltar sem o que foi buscar.",
  "Apreender · rebocar · entregar no porto",
  [("Casco Duplo", "Passiva", "Reduz em um degrau todo dano vindo de "
    "Longe ou mais longe."),
   ("Arrasto", "Ação de Medo", "Gaste 2 Medo: reboca um alvo "
    "\\termo{Restrito} para fora da cena.")]),

 ("arQuilha", "QUILHA", 3, "Brutamontes", "ARCO", "martelo", "escudo", {},
  "Corpo a corpo", "Martelo de pressão",
  "Casco de fundo profundo adaptado para terra. Anda devagar porque "
  "pesa o que um navio pesa.",
  "Chegar · não parar · afundar o chão",
  [("Peso de Lastro", "Passiva", "Não pode ser movido. O chão onde ele "
    "pisa vira terreno difícil para os outros."),
   ("Afunda", "Ação de Medo", "Gaste 2 Medo: o chão em Muito Perto cede. "
    "Todos lá ficam \\termo{Restritos}.")]),

 ("arFossa", "FOSSA", 4, "Solo", "ARCO", "garra", "rede",
  {"perna": "nenhuma", "torso": "selado"},
  "Muito Perto", "Braços de pressão",
  "Casco de mergulho profundo, feito para ir a lugares de onde não se "
  "volta. Voltou.",
  "Levar para baixo · esperar · não ser visto subindo",
  [("Pressão", "Passiva", "Quem estiver em Muito Perto marca 1 Estresse "
    "por ação. O casco deles range."),
   ("Escuro", "Passiva", "Está sempre \\termo{Oculto} dentro d'água, e "
    "sair e voltar não custa ação."),
   ("Leva", "Ação de Medo", "Gaste 3 Medo: agarra um alvo e desce. Os "
    "dois saem da cena por uma cena inteira.")]),

 ("arMare", "MARÉ", 4, "Comandante", "ARCO", "canhao", "arpeu",
  {"torso": "selado"},
  "Longe", "Bateria de esquadra",
  "Comanda tudo que flutua em trezentos quilômetros de costa, e "
  "raramente precisa disparar para provar isso.",
  "Controlar o canal · cobrar pedágio · afundar só quem insistir",
  [("Esquadra", "Passiva", "Todo adversário na água soma \\textbf{+2} de "
    "ataque e de Evasão."),
   ("Enchente", "Ação de Medo", "Gaste 3 Medo: a água sobe. A cena "
    "inteira vira terreno difícil para quem não tem casco selado.")]),
]


# --------------------------------------------------------------- GRALHA
COLOSSOS += [
 ("grFerroVelho", "FERRO-VELHO", 1, "Apoio", "GRALHA", "serra", "garra", {},
  "Corpo a corpo", "Machado de desmanche",
  "Vive do que cai. Chega depois da briga, ou no fim dela, e leva.",
  "Recolher · remendar · nunca ser o primeiro a entrar",
  [("Cata Peça", "Ação", "Quando um colosso cai perto, ganha "
    "\\textbf{+3} de Estrutura e uma arma nova."),
   ("Remendo", "Ação de Medo", "Gaste 2 Medo: um adversário caído nesta "
    "cena levanta com metade da Estrutura.")]),

 ("grTratorista", "TRATORISTA", 1, "Brutamontes", "GRALHA", "garra", "punho",
  {"perna": "mangueira"},
  "Corpo a corpo", "Garra de carga",
  "Máquina de obra com chapa parafusada por cima. Não foi feita para "
  "brigar, mas pesa quarenta toneladas.",
  "Empurrar · derrubar parede · abrir caminho",
  [("Peso Morto", "Passiva", "Não pode ser empurrado, puxado nem "
    "derrubado."),
   ("Passa Por Cima", "Ação de Medo", "Gaste 2 Medo: atravessa em linha "
    "reta. Todos no caminho sofrem o dano e ficam \\termo{Instáveis}.")]),

 ("grSerrador", "SERRADOR", 2, "Regular", "GRALHA", "serra", "serra", {},
  "Corpo a corpo", "Discos gêmeos",
  "Duas serras de desmanche de três metros. Foi adaptado por alguém com "
  "pressa e sem medo.",
  "Cortar até chegar no meio · não parar · levar a peça",
  [("Corta-Casco", "Passiva", "Ignora toda a Blindagem."),
   ("Trava na Junta", "Ação de Medo", "Gaste 2 Medo: causa uma Avaria "
    "além do dano.")]),

 ("grCarroca", "CARROÇA", 2, "Apoio", "GRALHA", "rede", "garra",
  {"perna": "mangueira"},
  "Longe", "Rede de carga",
  "Quatro pernas, um lanço de trinta metros e nenhuma arma de verdade.",
  "Prender · levantar · pôr onde mandaram",
  [("Rede", "Passiva", "Em um acerto, o alvo fica \\termo{Restrito} até "
    "alguém gastar uma ação cortando."),
   ("Suspende", "Ação de Medo", "Gaste 2 Medo: levanta um alvo "
    "\\termo{Restrito} do chão. Ele não age até ser solto.")]),

 ("grEnxame", "ENXAME DE GRALHAS", 3, "Bando", "GRALHA", "garra", "garra",
  {"perna": "mangueira"},
  "Corpo a corpo", "Muitos braços",
  "Cinco cascos leves montados com o que sobrou, pilotados por rádio de "
  "um caminhão, por uma pessoa só.",
  "Cercar · cansar · nunca atacar de frente",
  [("Cerco", "Passiva", "Se houver dois ou mais adversários perto do "
    "alvo, o dano do Enxame sobe um degrau."),
   ("Espalhar", "Ação de Medo", "Gaste 1 Medo: o Enxame se divide e "
    "ataca em duas frentes.")]),

 ("grMestreDeObras", "MESTRE DE OBRAS", 3, "Comandante", "GRALHA", "serra",
  "arpeu", {"ombro": "gaiolaom"},
  "Perto", "Serra e cabo",
  "Dono de galpão, chefe de turma e a única pessoa em cem quilômetros "
  "que sabe montar o que ele monta.",
  "Proteger a oficina · cobrar o que é devido · terminar o projeto",
  [("Improviso", "Ação", "Uma vez por cena, um adversário aliado ganha "
    "uma Peça nova até o fim da cena."),
   ("Tudo Que Tem", "Ação de Medo", "Gaste 2 Medo: dispara todas as armas "
    "de uma vez, uma rolagem cada.")]),

 ("grFrankenstein", "FRANKENSTEIN", 4, "Brutamontes", "GRALHA", "martelo",
  "serra", {"perna": "mangueira", "torso": "remendado"},
  "Corpo a corpo", "O que estiver instalado hoje",
  "Sete cascos de sete fábricas diferentes num esqueleto só. Nunca duas "
  "pessoas descreveram este colosso do mesmo jeito.",
  "Continuar existindo · incorporar · não ser desmontado",
  [("Peça de Todo Mundo", "Passiva", "No começo de cada cena, o Mestre "
    "escolhe uma Peça de qualquer fábrica: ele tem."),
   ("Cresce", "Passiva", "Cada vez que sofre uma Avaria, ganha "
    "\\textbf{+1} de ataque e \\textbf{+2} de dano, cumulativo."),
   ("Desmonta", "Ação de Medo", "Gaste 3 Medo: arranca uma Peça "
    "instalada de um colosso em Corpo a corpo e passa a usá-la.")]),

 ("grOficina", "A OFICINA", 4, "Apoio", "GRALHA", "arpeu", "garra",
  {"perna": "mangueira", "ombro": "gaiolaom"},
  "Longe", "Braços de bancada",
  "Não é um colosso: é um galpão com pernas. Seis braços, uma forja "
  "acesa e tudo que os outros precisam para continuar de pé.",
  "Manter os outros andando · não entrar na briga · recolher no fim",
  [("Bancada", "Ação", "Limpa 4 Estrutura de um adversário que alcance, "
    "ou desfaz uma Avaria dele."),
   ("Linha de Montagem", "Ação de Medo", "Gaste 3 Medo: dois adversários "
    "de Escalão 1 saem de dentro dela, prontos.")]),
]


# ----------------------------------------------------------------- SELO
COLOSSOS += [
 ("slPatrulha", "PATRULHA", 1, "Regular", "SELO", "punho", "escudo",
  {"tem_antena": True},
  "Perto", "Bastão e escudo",
  "Farda limpa, casco com o número pintado grande, e a certeza de que "
  "isto aqui é jurisdição dele.",
  "Identificar · deter · não matar se der",
  [("Parado Aí", "Ação", "Um alvo perde a próxima ação se não tiver "
    "documento, desculpa ou velocidade."),
   ("Reforço", "Ação de Medo", "Gaste 1 Medo: chega outra Patrulha.")]),

 ("slOlho", "OLHO", 1, "Atirador", "SELO", "fuzil", "arpeu",
  {"tem_antena": True},
  "Muito Longe", "Rifle de marcação",
  "Casco de observação. Não atira para matar: atira para avisar todo "
  "mundo onde você está.",
  "Ver · avisar · não ser visto",
  [("Marcado", "Passiva", "Em um acerto, o alvo fica \\termo{Travado} "
    "até o fim da cena: todos os ataques contra ele têm vantagem."),
   ("Rede", "Ação de Medo", "Gaste 1 Medo: todos os adversários da cena "
    "sabem exatamente onde cada personagem está.")]),

 ("slRonda", "RONDA", 2, "Regular", "SELO", "rede", "escudo",
  {"tem_antena": True},
  "Longe", "Lança-redes",
  "Casco de contenção urbana. Foi desenhado para prender colosso sem "
  "destruir quarteirão, e faz isso bem.",
  "Prender · conter · entregar vivo",
  [("Captura", "Passiva", "Em um acerto com a rede, o alvo fica "
    "\\termo{Restrito} e não pode ser movido por ninguém."),
   ("Cerco", "Ação de Medo", "Gaste 2 Medo: dois adversários aliados "
    "aparecem cercando um alvo \\termo{Restrito}.")]),

 ("slXerife", "XERIFE", 2, "Comandante", "SELO", "fuzil", "fuzil",
  {"cabeca": "antenado"},
  "Perto", "Par de revólveres",
  "A lei de uma cidade que não vê um juiz há quatro anos. Funciona.",
  "Manter a paz do jeito dele · cobrar o devido · ser obedecido",
  [("Dois Tiros", "Passiva", "Ataca dois alvos diferentes com a mesma "
    "ação."),
   ("Última Palavra", "Ação de Medo", "Gaste 2 Medo: um personagem que "
    "ia agir não age. Tudo que ele tinha a dizer, o Xerife já ouviu.")]),

 ("slTorre", "TORRE", 3, "Atirador", "SELO", "canhao", "escudo",
  {"tem_antena": True, "perna": "coluna"},
  "Muito Longe", "Canhão de sítio",
  "Um posto de observação que aprendeu a andar. Enxerga a cena inteira "
  "e acerta o que enxerga.",
  "Cobrir tudo · não deixar ninguém sair · não sair também",
  [("Vista de Cima", "Passiva", "Nada fica \\termo{Oculto} dele, e ele "
    "não sofre desvantagem por distância."),
   ("Fecha o Cerco", "Ação de Medo", "Gaste 2 Medo: ninguém sai da cena "
    "nesta rodada.")]),

 ("slDelegado", "DELEGADO", 3, "Comandante", "SELO", "rede", "fuzil",
  {"tem_antena": True},
  "Perto", "Algema de cabo",
  "Tem assinatura, carimbo e três décadas de arquivos. Sabe alguma "
  "coisa sobre cada pessoa na cena.",
  "Encerrar por escrito · não abrir exceção · ganhar o processo",
  [("Arquivo", "Ação", "O Mestre revela uma verdade constrangedora sobre "
    "um personagem. Ele marca 1 Estresse."),
   ("Mandado", "Ação de Medo", "Gaste 2 Medo: nomeia um alvo. Todo "
    "adversário na cena o ataca com vantagem até o fim da cena.")]),

 ("slOrbita", "ÓRBITA", 4, "Solo", "SELO", "canhao", "rede",
  {"tem_antena": True, "torso": "largo"},
  "Muito Longe", "Designador orbital",
  "Ligado direto à constelação de satélites do Selo. Não precisa ver "
  "você: precisa que você exista em algum registro.",
  "Localizar · designar · encerrar de longe",
  [("Do Alto", "Passiva", "Não pode ser surpreendido, e todo personagem "
    "que já apareceu em qualquer registro é encontrado por ele."),
   ("Designação", "Ação", "Marca um alvo. Todo ataque contra ele nesta "
    "cena acerta sem rolagem."),
   ("Queda", "Ação de Medo", "Gaste 4 Medo: alguma coisa cai da órbita "
    "no lugar designado. \\dado{6d10} em tudo lá, ignorando Blindagem.")]),

 ("slGuardaCivil", "GUARDA CIVIL", 4, "Bando", "SELO", "rede", "escudo",
  {"tem_antena": True},
  "Perto", "Linha de escudos",
  "Doze cascos idênticos, em linha, com número pintado nos dois ombros. "
  "Nenhum deles vai ceder primeiro.",
  "Segurar a linha · não abrir · esperar a ordem",
  [("Linha", "Passiva", "Ninguém passa por eles sem gastar uma ação "
    "inteira e uma rolagem Dificuldade 16."),
   ("Avança a Linha", "Ação de Medo", "Gaste 2 Medo: a linha inteira "
    "avança uma faixa de alcance, empurrando tudo à frente.")]),
]


# --------------------------------------------------------------- CARVÃO
COLOSSOS += [
 ("cvForaDaLei", "FORA DA LEI", 1, "Batedor", "CARVAO", "fuzil", "punho", {},
  "Perto", "Fuzil serrado",
  "Casco roubado, placa trocada e um talento genuíno para sumir em "
  "estrada aberta.",
  "Levar o que dá · não ser reconhecido · sair antes da conta",
  [("Placa Trocada", "Passiva", "Não pode ser identificado, marcado nem "
    "rastreado."),
   ("Emboscada", "Ação de Medo", "Gaste 2 Medo: dois Fora da Lei já "
    "estavam ali o tempo todo.")]),

 ("cvGancho", "GANCHO", 1, "Regular", "CARVAO", "arpeu", "garra", {},
  "Longe", "Garras de cabo",
  "Dois braços de guincho e nada mais. Feito para agarrar, não para "
  "vencer.",
  "Prender · arrastar · entregar vivo",
  [("Fisgada", "Passiva", "Em um acerto, o alvo fica \\termo{Restrito} "
    "até gastar uma ação."),
   ("Abordagem", "Ação de Medo", "Gaste 2 Medo: sobe num colosso "
    "\\termo{Restrito} e começa a abrir a cabine.")]),

 ("cvCorsario", "CORSÁRIO", 2, "Batedor", "CARVAO", "espada", "arpeu", {},
  "Perto", "Gancho e lâmina",
  "Vive de abordagem. Não afunda carga: afunda quem não quis entregar.",
  "Abordar · levar o casco inteiro · ter para quem vender",
  [("Abordagem", "Passiva", "Alvos que ele prendeu não conseguem se "
    "mover sem derrubá-lo primeiro."),
   ("Abre Essa Porta", "Ação de Medo", "Gaste 3 Medo: abre a cabine de "
    "um colosso \\termo{Restrito}. O que acontece depois é uma cena de "
    "gente.")]),

 ("cvSombra", "SOMBRA", 2, "Batedor", "CARVAO", "espada", "garra",
  {"cabeca": "capuz"},
  "Corpo a corpo", "Faca de casco",
  "Placa fria, casco mudo, nenhuma luz acesa. Você já o viu hoje e não "
  "lembra.",
  "Ver tudo · contar para quem paga · nunca entrar em combate",
  [("Placa Fria", "Passiva", "Está sempre \\termo{Oculto} até agir, e "
    "volta a ficar no fim da ação dele."),
   ("Já Sabíamos", "Ação de Medo", "Gaste 2 Medo: um plano dos jogadores "
    "já era conhecido. O Mestre diz qual.")]),

 ("cvEstopim", "ESTOPIM", 3, "Regular", "CARVAO", "garra", "garra",
  {"cabeca": "capuz"},
  "Muito Perto", "Cargas de fenda",
  "Trabalha com explosivo de demolição e uma calma que assusta mais que "
  "o explosivo.",
  "Abrir o que está fechado · não deixar rastro · receber",
  [("Carga", "Ação", "Planta uma carga em um alvo em Corpo a corpo. Ela "
    "estoura na próxima ação dele: \\dado{4d10} ignorando Blindagem."),
   ("Tudo Ao Mesmo Tempo", "Ação de Medo", "Gaste 3 Medo: todas as "
    "cargas plantadas na cena estouram agora.")]),

 ("cvCarrasco", "CARRASCO", 3, "Comandante", "CARVAO", "martelo", "garra",
  {"tem_capa": True, "cabeca": "crania"},
  "Corpo a corpo", "Machado de dois cabos",
  "Manto pesado, machado de desmanche e a função de encerrar o que os "
  "outros começaram.",
  "Terminar · ser lembrado · nunca correr atrás de ninguém",
  [("Presença", "Passiva", "Personagens que comecem a ação perto dele "
    "marcam 1 Estresse."),
   ("Corta", "Ação de Medo", "Gaste 3 Medo: o dano ignora Blindagem e "
    "escudo, e o alvo sofre uma Avaria.")]),

 ("cvCarvao", "CARVÃO", 4, "Solo", "CARVAO", "espada", "garra",
  {"cabeca": "capuz", "tem_capa": True},
  "Corpo a corpo", "Tudo que foi de outra pessoa",
  "Ninguém sabe se é uma pessoa, um cargo ou uma marca. Todas as três "
  "explicações já foram usadas em julgamento.",
  "Não ser encontrado · cobrar todas as dívidas · continuar sendo um boato",
  [("Não Existe", "Passiva", "Não pode ser identificado, gravado, "
    "fotografado nem lembrado por quem não estava na cena."),
   ("Peça de Todos", "Passiva", "Uma vez por cena, usa qualquer Peça de "
    "qualquer fábrica que um personagem tenha usado na cena."),
   ("A Conta", "Ação de Medo", "Gaste 4 Medo: um personagem descobre que "
    "deve alguma coisa a ele. Enquanto não pagar, rola com desvantagem "
    "contra ele.")]),

 ("cvMatilha", "MATILHA", 2, "Bando", "CARVAO", "garra", "garra",
  {"perna": "digitigrada"},
  "Corpo a corpo", "Garras e dentes",
  "Quatro cascos leves sem cabine, pilotados por rádio de um caminhão, "
  "por uma pessoa só.",
  "Cercar · cansar · nunca atacar de frente",
  [("Cerco", "Passiva", "Se houver dois ou mais adversários perto do "
    "alvo, o dano da Matilha sobe um degrau."),
   ("Espalhar", "Ação de Medo", "Gaste 1 Medo: a Matilha se divide e "
    "ataca em duas frentes.")]),
]


# ------------------------------------------------------------- OSSATURA
COLOSSOS += [
 ("osEnxerto", "ENXERTO", 1, "Regular", "OSSATURA", "garra", "punho", {},
  "Corpo a corpo", "Garra viva",
  "Um casco comum com uma peça que não é. Dá para ver a costura.",
  "Alimentar · continuar · obedecer enquanto der",
  [("Cicatriza", "Passiva", "Limpa 1 Estrutura no fim de cada ação dele."),
   ("Espasmo", "Reação", "Quando sofre dano, ataca de volta quem estiver "
    "em Corpo a corpo.")]),

 ("osColeira", "COLEIRA", 2, "Apoio", "OSSATURA", "rede", "garra", {},
  "Longe", "Cabresto de aço",
  "Não briga: segura. Foi feito para manter uma coisa maior obedecendo, "
  "e continua tentando.",
  "Segurar o rebanho · apontá-lo · não ser mordido",
  [("Rebanho", "Passiva", "Toda criatura ou Bando perto dele soma "
    "\\textbf{+2} de ataque."),
   ("Solta", "Ação de Medo", "Gaste 3 Medo: chega um Bando do Escalão "
    "dele, já na cena.")]),

 ("osCostela", "COSTELA", 2, "Regular", "OSSATURA", "garrao", "garra", {},
  "Corpo a corpo", "Braço grande demais",
  "Um braço de um tamanho que o resto do casco não comporta, e uma "
  "piloto que aceitou esse desenho sabendo o que custa.",
  "Chegar perto · fechar a mão · não ter que explicar",
  [("A Mão", "Passiva", "Em um acerto corpo a corpo, o alvo sofre uma "
    "Avaria além do dano."),
   ("Fecha", "Ação de Medo", "Gaste 3 Medo: um alvo \\termo{Restrito} em "
    "Corpo a corpo marca \\textbf{4 Estrutura}, sem rolagem.")]),

 ("osNinhada", "NINHADA", 3, "Bando", "OSSATURA", "garra", "garra", {},
  "Corpo a corpo", "Muitas bocas",
  "Não são colossos: são coisas do tamanho de um carro que saíram de "
  "dentro de um. Ninguém ali planejou isso.",
  "Comer · seguir o cheiro · crescer",
  [("Bando", "Passiva", "Dano em área acerta a Ninhada inteira e mata o "
    "dobro."),
   ("Cheiro", "Ação de Medo", "Gaste 1 Medo: encontram o alvo mais "
    "ferido da cena, onde quer que ele esteja.")]),

 ("osCarcaca", "CARCAÇA", 3, "Brutamontes", "OSSATURA", "garrao", "serra",
  {"torso": "carnudo"},
  "Corpo a corpo", "Serra e garra",
  "Um casco de sítio com carne de Funda enxertada por cima. Ninguém "
  "assume a autoria.",
  "Crescer · comer o que derrubou · não obedecer mais a ninguém",
  [("Come", "Ação", "Quando derruba qualquer coisa, limpa 4 Estrutura."),
   ("Cresce", "Passiva", "Cada Avaria que sofre dá \\textbf{+1} de "
    "ataque e \\textbf{+2} de dano, cumulativo.")]),

 ("osVirada", "A VIRADA", 4, "Solo", "OSSATURA", "garrao", "garrao",
  {"torso": "carnudo", "cabeca": "crania"},
  "Corpo a corpo", "O que sobrou dos braços",
  "Era um piloto. A papelada ainda diz que é. Quem viu de perto usa "
  "outra palavra e não gosta de repetir.",
  "Terminar de virar · encontrar quem assinou · não voltar",
  [("Não É Mais Máquina", "Passiva", "Efeitos que afetam colosso — "
    "trava, sabotagem, Avaria — não funcionam nela."),
   ("Abre", "Ação de Medo", "Gaste 4 Medo: ganha 8 Estrutura, e todo "
    "personagem que vê marca 2 Estresse."),
   ("Lembra de Você", "Passiva", "Contra o personagem que ela conhecia, "
    "tem \\textbf{+3} de ataque e não pode ser enganada.")]),

 ("osPastor", "PASTOR", 4, "Comandante", "OSSATURA", "rede", "garrao",
  {"torso": "carnudo"},
  "Longe", "Coleira longa",
  "O trabalho dele é manter vivas coisas que não deviam obedecer a "
  "ninguém, e apontá-las para o lado certo.",
  "Manter o rebanho em pé · apontá-lo · ser o último a sair",
  [("Rebanho Grande", "Passiva", "Toda Funda e todo Bando na cena soma "
    "\\textbf{+3} de ataque e não pode ser afugentado."),
   ("Larga Tudo", "Ação de Medo", "Gaste 4 Medo: chega uma Funda de "
    "Escalão 3 à escolha do Mestre.")]),

 ("osSemente", "SEMENTE", 1, "Lacaio", "OSSATURA", "garra", "punho", {},
  "Corpo a corpo", "Garras",
  "Cabe dentro de um homem. Já coube.",
  "Encontrar um casco · entrar · crescer",
  [("Entra", "Passiva", "Quando cai em Corpo a corpo de um colosso, o "
    "piloto marca 1 Estresse."),
   ("Nunca Sozinha", "Passiva", "Sementes aparecem em grupos de cinco.")]),
]


# ============================================================== FUNDAS
# (id, NOME, esc, papel, plano de corpo, params, alcance, ataque,
#  descrição, motivos, traços)

# Os pesados — linha de guarda, assinatura de fábrica e os Nomeados —
# ficam em dados/elite.py e entram aqui como colossos comuns, para o
# livro, as cartas e o Obsidian não precisarem de caso especial.
from .elite import ELITE as _ELITE             # noqa: E402

COLOSSOS += _ELITE

FUNDAS = [
 ("fdCria", "CRIA", 1, "Bando", "enxame", {"n": 9},
  "Corpo a corpo", "Dentes",
  "Do tamanho de um cachorro grande, em bando de vinte. Saem de onde a "
  "coisa grande passou.",
  "Comer · seguir o cheiro · crescer",
  [("Bando", "Passiva", "Dano em área acerta o bando inteiro e mata o "
    "dobro."),
   ("Cheiro de Sangue", "Ação de Medo", "Gaste 1 Medo: encontram o alvo "
    "mais ferido da cena, onde quer que esteja.")]),

 ("fdLacraia", "LACRAIA", 1, "Batedor", "rastejante", {"esc": 0.75},
  "Corpo a corpo", "Ferrão",
  "Seis metros de coisa baixa e rápida que atravessa galeria, duto e "
  "cano de esgoto como se fosse rua.",
  "Entrar · picar · sair pelo mesmo buraco",
  [("Por Dentro", "Passiva", "Atravessa qualquer vão maior que um "
    "homem, e sai do outro lado na mesma ação."),
   ("Ferrão", "Ação de Medo", "Gaste 1 Medo: o alvo marca 2 Estresse "
    "além do dano.")]),

 ("fdCarapaca", "CARAPAÇA", 1, "Brutamontes", "rastejante", {"esc": 0.95},
  "Corpo a corpo", "Investida",
  "Anda devagar, come pedra e não tem lado de trás. Já foi confundida "
  "com terreno.",
  "Atravessar · comer · não parar",
  [("Casca", "Passiva", "Reduz em um degrau todo dano vindo de Perto ou "
    "mais longe."),
   ("Rola", "Ação de Medo", "Gaste 2 Medo: atravessa a cena em linha "
    "reta. Tudo no caminho sofre o dano e fica \\termo{Restrito}.")]),

 ("fdCardume", "CARDUME", 2, "Bando", "enxame", {"n": 11, "esc": 0.9},
  "Perto", "Nuvem",
  "Milhares de coisas pequenas voando juntas. De longe parece fumaça "
  "com intenção.",
  "Cegar · entrar pelas frestas · não parar",
  [("Nuvem", "Passiva", "Quem estiver dentro do Cardume fica "
    "\\termo{Cego}."),
   ("Entra", "Ação de Medo", "Gaste 2 Medo: entra num colosso. Uma Peça "
    "instalada desliga a cada ação até o piloto marcar 2 Estresse.")]),

 ("fdLodo", "LODO", 2, "Brutamontes", "massa", {"esc": 0.8, "bocas": 2},
  "Muito Perto", "Massa",
  "Não tem forma fixa. Escorre, cobre e endurece. Já foi outra coisa.",
  "Cobrir · endurecer · digerir devagar",
  [("Sem Junta", "Passiva", "Armas de corte e perfuração causam metade "
    "do dano."),
   ("Cobre", "Ação de Medo", "Gaste 2 Medo: escorre por cima de um "
    "colosso. O alvo fica \\termo{Restrito} e o piloto marca 1 Estresse "
    "por ação.")]),

 ("fdAgulha", "AGULHA", 2, "Atirador", "torre", {"esc": 0.8},
  "Muito Longe", "Cuspe ácido",
  "Fica parada, alta e fina, e cospe. Ninguém sabe em que ela se apoia.",
  "Não se mexer · acertar de longe · não ser alcançada",
  [("Enraizada", "Passiva", "Não se move. \\textbf{+4} no Limiar Maior."),
   ("Cospe", "Ação de Medo", "Gaste 2 Medo: o dano ignora Blindagem e o "
    "alvo fica \\termo{Vulnerável}.")]),

 ("fdNadador", "NADADOR", 2, "Batedor", "nadadora", {"esc": 0.85},
  "Corpo a corpo", "Garras longas",
  "Dezoito metros de coisa lisa que se move na água como se a água não "
  "estivesse lá.",
  "Atacar por baixo · levar um · voltar ao fundo",
  [("Por Baixo", "Passiva", "Está sempre \\termo{Oculto} na água. Sair e "
    "voltar não custa ação."),
   ("Leva", "Ação de Medo", "Gaste 3 Medo: agarra um alvo e desce. Os "
    "dois saem da cena por uma cena inteira.")]),

 ("fdAsaSeca", "ASA-SECA", 2, "Batedor", "voadora", {"esc": 0.8},
  "Perto", "Garras de mergulho",
  "Envergadura de vinte metros e um corpo que cabe num carro. Mergulha "
  "de tão alto que chega antes do som.",
  "Mergulhar · levar · voltar a subir",
  [("Alto Demais", "Passiva", "Só pode ser atacada de Longe ou mais "
    "longe, a não ser que esteja mergulhando."),
   ("Rapina", "Ação de Medo", "Gaste 2 Medo: pega um personagem a pé e o "
    "leva para cima. Soltar é decisão dela.")]),

 ("fdBocarra", "BOCARRA", 3, "Brutamontes", "ereta", {"esc": 0.95},
  "Corpo a corpo", "Mordida",
  "Quatro andares de coisa que anda em duas pernas e não tem nenhum "
  "outro plano além de morder.",
  "Morder · engolir · continuar",
  [("Engole", "Passiva", "Quando derruba qualquer coisa, limpa 5 "
    "Estrutura."),
   ("Sacode", "Ação de Medo", "Gaste 2 Medo: um alvo \\termo{Restrito} "
    "sofre o dano dela duas vezes.")]),

 ("fdTorreVelha", "TORRE VELHA", 3, "Atirador", "torre", {"esc": 1.0},
  "Muito Longe", "Chuva de esporos",
  "Está lá há tanto tempo que construíram uma vila em volta antes de "
  "descobrirem que ela respirava.",
  "Não se mexer · espalhar · esperar",
  [("Parece Paisagem", "Passiva", "Até agir pela primeira vez, não conta "
    "como adversário e não pode ser atacada."),
   ("Esporos", "Ação de Medo", "Gaste 2 Medo: a cena inteira fica "
    "coberta. Todos marcam 1 Estresse por cena, menos quem tiver casco "
    "selado.")]),

 ("fdPorao", "PORÃO", 3, "Solo", "massa", {"esc": 1.0, "bocas": 4},
  "Perto", "Braços de dentro",
  "Ocupou o casco de um navio e não saiu mais. O navio ainda navega.",
  "Ficar onde está · pegar quem entra · crescer para dentro",
  [("Dentro", "Passiva", "Só pode ser atacado por quem estiver dentro do "
    "casco com ele."),
   ("O Navio Fecha", "Ação de Medo", "Gaste 3 Medo: uma saída deixa de "
    "existir."),
   ("Puxa", "Ação de Medo", "Gaste 2 Medo: um alvo em Perto vai para o "
    "ponto mais fundo do porão, sozinho.")]),

 ("fdVazante", "REFLUXO", 3, "Bando", "rastejante", {"esc": 1.0},
  "Corpo a corpo", "Onda de patas",
  "Não é uma: são trezentas, e elas atravessam a planície quando a água "
  "baixa.",
  "Atravessar · comer o que estiver no caminho · chegar do outro lado",
  [("Onda", "Passiva", "Ocupa todas as faixas de alcance até Perto ao "
    "mesmo tempo."),
   ("Passa Por Cima", "Ação de Medo", "Gaste 2 Medo: todos na cena "
    "sofrem o dano e ficam \\termo{Instáveis}.")]),

 ("fdMergulhadora", "MERGULHADORA", 3, "Regular", "nadadora", {"esc": 1.0},
  "Muito Perto", "Boca de fundo",
  "Quarenta metros. Sobe do escuro uma vez por dia, come o que estiver "
  "na superfície, e desce.",
  "Subir · comer · descer",
  [("Sobe", "Ação", "Aparece em qualquer ponto com água, sem aviso, e "
    "ataca ao chegar."),
   ("Desce", "Reação", "Quando sofre 3 Estrutura de um golpe só, "
    "desaparece e volta na cena seguinte, inteira.")]),

 ("fdBoca", "A BOCA", 4, "Solo", "colossal", {"esc": 1.0},
  "Muito Perto", "A boca",
  "Do tamanho de um quarteirão. Ninguém viu o corpo inteiro e voltou "
  "com uma descrição que batesse com a de outro.",
  "Comer · continuar · não ser impedida",
  [("Tamanho", "Passiva", "Ocupa todas as faixas de alcance até Perto e "
    "não pode ser \\termo{Restrita}, empurrada nem movida."),
   ("Engole", "Ação de Medo", "Gaste 3 Medo: um colosso em Muito Perto é "
    "engolido. Lá dentro é outro lugar."),
   ("Continua", "Passiva", "A Boca não persegue ninguém: ela vai para "
    "onde ia. O problema é que há uma cidade no caminho.")]),

 ("fdMonte", "O MONTE", 4, "Solo", "massa", {"esc": 1.3, "bocas": 5},
  "Perto", "Tudo que ela já comeu",
  "Três quilômetros de massa que absorveu duas vilas, uma refinaria e "
  "um comboio inteiro. Partes ainda funcionam.",
  "Absorver · crescer · não ter pressa",
  [("Absorve", "Passiva", "Quando qualquer coisa cai perto dela, ela "
    "ganha 4 Estrutura e uma Peça daquela coisa."),
   ("Lembranças", "Ação de Medo", "Gaste 3 Medo: uma máquina que o Monte "
    "comeu sai de dentro dele e ataca, como adversário de Escalão 2."),
   ("Sem Centro", "Passiva", "Não existe ponto fraco. Só existe menos "
    "monte.")]),

 ("fdCeuAberto", "CÉU ABERTO", 4, "Solo", "voadora", {"esc": 1.35},
  "Longe", "Sombra",
  "A envergadura tapa o sol de um vale inteiro. Quem viu de baixo "
  "descreve como uma nuvem que resolveu descer.",
  "Voar · escolher · descer uma vez",
  [("Alto", "Passiva", "Só pode ser atacada por quem voa ou por arma de "
    "Muito Longe."),
   ("Sombra", "Passiva", "Onde a sombra dela passa, todos ficam "
    "\\termo{Cegos} e marcam 1 Estresse."),
   ("Desce", "Ação de Medo", "Gaste 4 Medo: desce. \\dado{6d10} em tudo "
    "na cena, e a cena muda de forma.")]),

 ("fdEspinha", "ESPINHA", 4, "Brutamontes", "torre", {"esc": 1.3},
  "Muito Longe", "Lança de osso",
  "Cento e vinte metros de coisa fina que cresceu no meio da cidade em "
  "uma noite e agora dispara.",
  "Crescer · espalhar sementes · não cair",
  [("Não Tomba", "Passiva", "Não pode ser derrubada, empurrada nem "
    "movida por nada."),
   ("Semeia", "Ação de Medo", "Gaste 2 Medo: chega um Bando de Crias, "
    "em qualquer lugar da cena.")]),

 ("fdTravessia", "TRAVESSIA", 3, "Comandante", "ereta", {"esc": 1.1},
  "Perto", "Berro",
  "Anda na frente do resto e as outras seguem. Nenhum biólogo aceita "
  "chamar isso de liderança, e nenhum soldado aceita chamar de outra "
  "coisa.",
  "Atravessar · levar as outras · chegar ao mar",
  [("Segue", "Passiva", "Toda Funda na cena age quando ela age."),
   ("Berro", "Ação de Medo", "Gaste 2 Medo: todos na cena marcam 2 "
    "Estresse e ficam \\termo{Instáveis}.")]),

 ("fdCasco", "CASCO", 2, "Regular", "rastejante", {"esc": 0.85},
  "Corpo a corpo", "Pinça",
  "Carrega nas costas alguma coisa que já foi um prédio. Ninguém sabe "
  "por quê.",
  "Carregar · atravessar · não largar",
  [("Carga", "Passiva", "Reduz em um degrau todo dano vindo de cima ou "
    "de trás."),
   ("Larga", "Ação de Medo", "Gaste 2 Medo: solta o que carrega em cima "
    "de alguém. \\dado{4d10} e o alvo fica \\termo{Restrito}.")]),

 ("fdOlhoFundo", "OLHO-FUNDO", 3, "Apoio", "massa", {"esc": 0.9, "bocas": 3},
  "Longe", "Olhar",
  "Não ataca. Fica olhando, e as outras ficam melhores.",
  "Olhar · coordenar · nunca chegar perto",
  [("Enquanto Ele Olha", "Passiva", "Toda Funda na cena soma "
    "\\textbf{+3} de ataque e não pode ser surpreendida."),
   ("Vê Você", "Ação de Medo", "Gaste 1 Medo: um personagem marca 2 "
    "Estresse e perde qualquer \\termo{Oculto}.")]),

 ("fdRaiz", "RAIZ", 2, "Apoio", "torre", {"esc": 0.7},
  "Perto", "Tentáculo de fundo",
  "Só se vê a ponta. O resto está embaixo do chão, e o chão é a "
  "criatura.",
  "Prender · puxar para baixo · esperar",
  [("Embaixo", "Passiva", "Só pode ser atacada em Corpo a corpo e apenas "
    "pela ponta que estiver de fora."),
   ("Puxa", "Ação de Medo", "Gaste 2 Medo: um alvo fica \\termo{Restrito} "
    "e afunda até a cintura.")]),

 ("fdPele", "PELE", 1, "Apoio", "massa", {"esc": 0.55, "bocas": 1},
  "Corpo a corpo", "Adere",
  "Uma coisa fina do tamanho de um lençol que gruda em casco e não sai.",
  "Grudar · cobrir o visor · esperar a cabine abrir",
  [("Gruda", "Passiva", "Em um acerto, cola no alvo. Ele fica "
    "\\termo{Cego} até gastar uma ação arrancando."),
   ("Nunca Uma Só", "Passiva", "Peles aparecem em grupos de seis.")]),

 ("fdCoroa", "COROA", 4, "Comandante", "colossal", {"esc": 0.8},
  "Perto", "Braços de comando",
  "A maior de um bando. Não é a mais forte: é a que as outras escutam, "
  "e isso é pior.",
  "Manter o bando · escolher o caminho · chegar inteira",
  [("Bando Grande", "Passiva", "Toda Funda na cena soma \\textbf{+2} de "
    "ataque, de Evasão e de Limiares."),
   ("Chamado", "Ação de Medo", "Gaste 3 Medo: chegam duas Fundas de "
    "Escalão 2.")]),

 ("fdSemente", "SEMENTE-MÃE", 3, "Regular", "massa", {"esc": 0.75, "bocas": 2},
  "Muito Perto", "Parto",
  "Não se move e não se defende. Só produz, a cada poucos minutos, mais "
  "uma.",
  "Produzir · não ser interrompida · encher o lugar",
  [("Não Para", "Passiva", "No fim de cada cena, chega um Bando de "
    "Crias."),
   ("Última Ninhada", "Reação", "Quando cai, solta um Bando de Crias "
    "imediatamente.")]),

 ("fdCasa", "A CASA", 4, "Solo", "rastejante", {"esc": 1.4},
  "Perto", "Pinças de porto",
  "Do tamanho de um estaleiro. Há gente morando nas juntas dela há "
  "dois anos, e essa gente a defende.",
  "Andar · abrigar · não ser incomodada",
  [("Tem Gente Dentro", "Passiva", "Dano em área contra ela acerta "
    "civis. O Mestre não avisa duas vezes."),
   ("Juntas", "Passiva", "Só sofre dano cheio de quem estiver em Corpo a "
    "corpo, entre as placas."),
   ("Levanta", "Ação de Medo", "Gaste 3 Medo: levanta. Tudo que estava "
    "em cima dela cai, e a cena muda de altura.")]),

 ("fdEco", "ECO", 2, "Batedor", "voadora", {"esc": 0.6},
  "Perto", "Grito",
  "Cega, pequena e rápida. Enxerga por som, e por isso ataca sempre o "
  "que estiver fazendo mais barulho.",
  "Ouvir · chegar · calar",
  [("Por Som", "Passiva", "Ataca sempre quem usou arma pesada, Peça "
    "Ativa ou Núcleo na última ação, e com vantagem."),
   ("Grito", "Ação de Medo", "Gaste 1 Medo: todos em Perto ficam "
    "\\termo{Cegos} até a próxima ação deles.")]),
]


# ============================================== GENTE, VEÍCULO E OUTROS
# (id, NOME, esc, papel, desenho, alcance, ataque, descrição, motivos, traços)

GENTE = [
 ("gtSoldado", "SOLDADO", 1, "Lacaio", "gente",
  "Perto", "Fuzil de infantaria",
  "Gente a pé com um fuzil que não fura casco nenhum. Eles sabem disso.",
  "Cumprir a ordem · não morrer por engano · voltar",
  [("Não Fura Casco", "Passiva", "Contra colosso, o dano é metade — a "
    "não ser que estejam em Corpo a corpo com carga de fenda."),
   ("Pelotão", "Passiva", "Soldados aparecem em grupos de seis ou mais.")]),

 ("gtEquipeFenda", "EQUIPE DE FENDA", 2, "Regular", "gente",
  "Corpo a corpo", "Carga de fenda",
  "Quatro pessoas, uma mochila cada, e a paciência de esperar um "
  "colosso ficar parado tempo suficiente.",
  "Chegar perto · plantar · sair correndo",
  [("Antimáquina", "Passiva", "O dano deles contra colosso é cheio e "
    "ignora Blindagem."),
   ("Sobe", "Ação de Medo", "Gaste 2 Medo: sobem num colosso. Ele fica "
    "\\termo{Vulnerável} e eles atacam de dentro da guarda.")]),

 ("gtAtiradorDeElite", "ATIRADOR DE ELITE", 2, "Atirador", "gente",
  "Muito Longe", "Rifle antimaterial",
  "Uma pessoa, um rifle, e três horas deitada no mesmo lugar.",
  "Atirar primeiro · não ser encontrado · escolher o alvo",
  [("Antimáquina", "Passiva", "Dano cheio contra colosso."),
   ("Sem Fumaça", "Passiva", "Está \\termo{Oculto} até disparar, e volta "
    "a ficar se ninguém agir contra ele.")]),

 ("gtOficial", "OFICIAL", 2, "Comandante", "gente",
  "Perto", "Pistola e rádio",
  "Não atira bem. Não precisa: o rádio dele alcança mais que qualquer "
  "arma na cena.",
  "Manter o controle · relatar · não sujar a farda",
  [("Rádio", "Ação", "Dois adversários em qualquer lugar da cena agem "
    "imediatamente."),
   ("Chamar Fogo", "Ação de Medo", "Gaste 3 Medo: artilharia cai num "
    "lugar à escolha dele. \\dado{5d10} em tudo lá.")]),

 ("gtMultidao", "MULTIDÃO", 2, "Bando", "gente",
  "Corpo a corpo", "Muita gente",
  "Não é um adversário: é uma condição do terreno que resolveu ter "
  "opinião.",
  "Sair dali · ser ouvida · não ser atropelada",
  [("Gente", "Passiva", "Não pode ser atacada por colosso sem "
    "consequência. O Mestre anota quem tentou."),
   ("Onda", "Ação de Medo", "Gaste 1 Medo: a multidão se move. Tudo no "
    "caminho fica \\termo{Restrito} por uma ação.")]),

 ("gtPilotoAPe", "PILOTO A PÉ", 2, "Batedor", "gente",
  "Perto", "Pistola de cabine",
  "Saiu do casco vivo e agora está no meio de uma briga de máquinas com "
  "uma arma que cabe no bolso.",
  "Chegar num casco · não ser pisado · voltar para a doca",
  [("Pequeno Demais", "Passiva", "Colossos precisam gastar 1 Medo para "
    "se dar ao trabalho de atacá-lo."),
   ("Sobe", "Ação", "Sobe em um colosso adjacente. De cima, ele não "
    "alcança sem gastar uma ação se sacudindo.")]),

 ("gtBlindado", "BLINDADO", 1, "Regular", "veiculo",
  "Longe", "Canhão de torre",
  "Tanque de linha. Contra gente é o fim do mundo; contra colosso é um "
  "incômodo bem-armado.",
  "Cobrir a estrada · não avançar sozinho · aguentar",
  [("Blindagem Frontal", "Passiva", "Reduz em um degrau todo dano vindo "
    "de frente."),
   ("Coluna", "Passiva", "Blindados aparecem em grupos de três.")]),

 ("gtLancaFoguete", "LANÇA-FOGUETES", 2, "Atirador", "veiculo",
  "Muito Longe", "Salva de foguetes",
  "Caminhão com trilhos nas costas. Dispara tudo e vai embora, nessa "
  "ordem.",
  "Descarregar · sumir · recarregar em outro lugar",
  [("Antimáquina", "Passiva", "Dano cheio contra colosso."),
   ("E Sai", "Reação", "Depois de disparar, sai da cena. Volta na cena "
    "seguinte, recarregado.")]),

 ("gtHelicoptero", "HELICÓPTERO", 2, "Batedor", "veiculo",
  "Perto", "Metralha de porta",
  "Rápido, barulhento e frágil. Serve para ver, levar e incomodar.",
  "Ver · levar gente · não ser acertado",
  [("Voa", "Passiva", "Só pode ser atacado por quem voa ou por arma de "
    "Longe ou mais longe."),
   ("Evacua", "Ação", "Tira duas pessoas da cena, ou traz duas.")]),

 ("gtComboio", "COMBOIO", 3, "Bando", "veiculo",
  "Longe", "Tudo que estiver montado",
  "Doze veículos em fila, cada um com alguma coisa parafusada em cima. "
  "Juntos são um problema de verdade.",
  "Atravessar · entregar a carga · não parar",
  [("Fila", "Passiva", "Ocupa duas faixas de alcance ao mesmo tempo."),
   ("Dispersa", "Ação de Medo", "Gaste 2 Medo: o comboio se abre. Cada "
    "metade age separadamente a partir de agora.")]),

 ("gtTrem", "TREM BLINDADO", 3, "Brutamontes", "veiculo",
  "Muito Longe", "Bateria de vagão",
  "Uma fortaleza que anda em trilho. Só vai aonde o trilho vai, e é "
  "exatamente por isso que o trilho é o alvo.",
  "Chegar ao destino · não descarrilar · cobrir a linha",
  [("Trilho", "Passiva", "Só se move ao longo do trilho. Quebrar o "
    "trilho é uma ação com Dificuldade 16."),
   ("Salva de Vagão", "Ação de Medo", "Gaste 2 Medo: três alvos "
    "diferentes sofrem o dano dele.")]),

 ("gtDirigivel", "DIRIGÍVEL", 3, "Apoio", "veiculo",
  "Muito Longe", "Metralhas de gôndola",
  "Lento, enorme e cheio de gente que enxerga tudo. É um posto de "
  "comando que flutua.",
  "Ver tudo · coordenar · não ser furado",
  [("De Cima", "Passiva", "Todo adversário na cena soma \\textbf{+2} de "
    "ataque enquanto ele estiver no ar."),
   ("Desce Gente", "Ação de Medo", "Gaste 2 Medo: uma Equipe de Fenda "
    "desce de rapel em qualquer ponto da cena.")]),

 ("gtEngenheiro", "ENGENHEIRO", 1, "Apoio", "gente",
  "Corpo a corpo", "Maçarico",
  "Não briga. Conserta, abre e fecha coisas, e sabe onde é o ponto "
  "fraco de tudo que existe naquele lugar.",
  "Consertar · abrir passagem · não estar lá quando começar",
  [("Conserta", "Ação", "Limpa 3 Estrutura de um adversário que "
    "alcance."),
   ("Sabe Onde", "Ação de Medo", "Gaste 1 Medo: revela um ponto fraco da "
    "Localização. Uma coisa que estava fechada abre.")]),

 ("gtInterventor", "INTERVENTOR", 4, "Comandante", "gente",
  "Perto", "A autoridade",
  "Chegou com papel assinado e autoridade para reescrever o que estava "
  "combinado. Não trouxe arma nenhuma.",
  "Executar a ordem · não negociar · sair com a assinatura",
  [("Papel", "Passiva", "Enquanto ele estiver vivo e falando, nenhum "
    "adversário de força regular pode ser convencido a mudar de lado."),
   ("Revogado", "Ação de Medo", "Gaste 3 Medo: uma permissão, licença ou "
    "acordo que os personagens tinham deixa de valer, agora."),
   ("Escolta", "Passiva", "Nunca aparece sem quatro adversários de "
    "Escalão 3 junto.")]),
]


def todos():
    return COLOSSOS, FUNDAS, GENTE


def total():
    return len(COLOSSOS) + len(FUNDAS) + len(GENTE)


if __name__ == "__main__":
    from collections import Counter
    print("%d colossos + %d fundas + %d gente = %d adversários"
          % (len(COLOSSOS), len(FUNDAS), len(GENTE), total()))
    print("colossos por fábrica:", dict(Counter(c[4] for c in COLOSSOS)))
    todos_esc = ([c[2] for c in COLOSSOS] + [f[2] for f in FUNDAS]
                 + [g[2] for g in GENTE])
    print("por escalão:", dict(sorted(Counter(todos_esc).items())))
    todos_pap = ([c[3] for c in COLOSSOS] + [f[3] for f in FUNDAS]
                 + [g[3] for g in GENTE])
    print("por papel:  ", dict(Counter(todos_pap)))
    ids = [c[0] for c in COLOSSOS] + [f[0] for f in FUNDAS] + [g[0] for g in GENTE]
    assert len(ids) == len(set(ids)), "id repetido"
    print("ids únicos: ok")
