# -*- coding: utf-8 -*-
"""
Classes, chassis, ancestralidades e comunidades.

O piloto é simples de propósito: classe, subclasse, arma, traje, duas
Experiências. Toda a complexidade da ficha mora nas Peças da máquina.

Cada classe começa com licença numa fábrica. Licença de outra fábrica
custa uma escolha de nível, ou a campanha dá.
"""

# ========================================================== CHASSIS
# (nome, fábrica, porte, Estrutura, Evasão, LMaior, LSevero, Blindagem,
#  encaixes, deslocamento, núcleo)
# Limiares crescem +2 no Maior e +3 no Severo por nível acima do primeiro.

CHASSIS = [
 ("MULA", "BRASA", "Médio", 8, 10, 9, 16, 2, 4, 1,
  ("Empurrão", "Atravesse em linha reta até duas faixas de alcance. Tudo no "
   "caminho sofre o dano da sua arma e é jogado para o lado.")),
 ("BIGORNA", "BRASA", "Pesado", 10, 9, 11, 19, 3, 3, 1,
  ("Bater Até Parar", "Ataque corpo a corpo três vezes seguidas contra o "
   "mesmo alvo, com uma rolagem cada.")),
 ("ANDORINHA", "VESPERTINA", "Leve", 6, 13, 8, 14, 0, 5, 2,
  ("Passo Duplo", "Até o fim da cena, mover e atacar custam uma ação só.")),
 ("FLORETE", "VESPERTINA", "Médio", 7, 12, 9, 15, 1, 4, 2,
  ("Estocada", "Um ataque corpo a corpo que acerta sem rolagem e ignora "
   "toda a Blindagem.")),
 ("ARCADA", "CATEDRAL", "Pesado", 10, 10, 10, 18, 3, 3, 1,
  ("Abóbada", "Um domo de luz cobre a sua posição por uma cena: nada de "
   "fora acerta nada de dentro.")),
 ("GUARDA", "CATEDRAL", "Médio", 9, 11, 10, 17, 2, 4, 1,
  ("Ordem de Parada", "Todo adversário em até Perto perde a próxima ação, "
   "ou o Mestre gasta 1 Medo por cada um que não perder.")),
 ("VAZANTE", "ARCO", "Médio", 8, 11, 9, 16, 2, 4, 2,
  ("Enchente", "Um lugar alaga por uma cena. Tudo lá fica "
   "\\termo{Instável}; você não.")),
 ("QUILHA", "ARCO", "Pesado", 10, 10, 10, 19, 2, 4, 1,
  ("Lastro Solto", "Afunde o chão sob os seus pés. Tudo em Muito Perto "
   "fica \\termo{Restrito} até gastar uma ação subindo.")),
 ("REMENDO", "GRALHA", "Leve", 7, 12, 8, 15, 0, 6, 2,
  ("Troca Quente", "Instale ou troque duas Peças agora, no meio da cena, "
   "sem doca e sem ação.")),
 ("CARROÇA", "GRALHA", "Médio", 9, 10, 10, 17, 1, 6, 1,
  ("Descarga", "Solte o que estiver carregando: até três aliados ou uma "
   "tonelada de carga aparecem ao seu lado, prontos.")),
 ("RONDA", "SELO", "Médio", 8, 11, 9, 16, 2, 5, 2,
  ("Vista de Cima", "Por uma cena, você e todos os aliados que consigam "
   "te ouvir sabem onde está tudo na cena.")),
 ("TORRE", "SELO", "Pesado", 10, 10, 10, 18, 3, 4, 1,
  ("Perímetro Fechado", "Ninguém entra nem sai da cena sem passar por "
   "você. Dura até você sair do lugar.")),
 ("SOMBRA", "CARVAO", "Leve", 6, 13, 8, 14, 0, 5, 2,
  ("Nunca Estive Aqui", "Saia da cena e volte em qualquer ponto dela, em "
   "qualquer momento, inclusive no meio da ação de outro.")),
 ("GANCHO", "CARVAO", "Médio", 8, 11, 9, 16, 1, 5, 2,
  ("Abre Essa Porta", "Abra a cabine de um colosso \\termo{Restrito} ou "
   "\\termo{Inerte}. O que acontece depois é uma cena de gente.")),
 ("COSTELA", "OSSATURA", "Médio", 9, 11, 10, 17, 1, 5, 2,
  ("Abre", "Ganhe 6 Estrutura e \\termo{Garra Viva} até o fim da cena. "
   "Marque 3 Estresse.")),
 ("CARCAÇA", "OSSATURA", "Pesado", 11, 9, 11, 19, 2, 4, 1,
  ("Come", "Ataque um alvo \\termo{Restrito}, \\termo{Inerte} ou caído. "
   "Se acertar, limpe toda a Estrutura marcada.")),
]


# ========================================================== CLASSES

CLASSES = [
{
 "nome": "FERREIRO",
 "fabrica": "BRASA",
 "chassi": "MULA",
 "evasao": 10, "pv": 7,
 "chamada": "Você conhece essa máquina parafuso por parafuso, porque foi "
            "você que parafusou.",
 "itens": "Uma chave de aperto gasta no cabo, um caderno de peças e uma "
          "lata de graxa quase vazia.",
 "traco": ("Mão de Oficina",
   r"Você conserta qualquer coisa com o que tiver à mão. Fora de combate, "
   r"consertos não custam nada e não falham; em combate, uma vez por cena, "
   r"limpe \textbf{2 Estrutura} de qualquer colosso que você alcance."),
 "esperanca": ("Aguenta Mais Um Pouco",
   r"Gaste 3 Esperança: um colosso que cairia agora não cai. Ele fica de "
   r"pé até o fim da cena."),
 "subclasses": [
  {"nome": "MARTELO", "linha": "O que bate.",
   "f": r"Seus ataques corpo a corpo somam \textbf{+2 por Proficiência} "
        r"contra alvos \termo{Restritos}, \termo{Instáveis} ou parados.",
   "e": r"Quando você derruba um adversário, todo adversário em Muito "
        r"Perto fica \termo{Instável}. Isso encadeia.",
   "m": r"Uma vez por cena, um ataque seu ignora Blindagem, cobertura, "
        r"escudo e Véu de Luz."},
  {"nome": "BIGORNA", "linha": "O que aguenta.",
   "f": r"\textbf{+1 Blindagem}, e você não pode ser empurrado nem "
        r"derrubado por nada menor que um colosso.",
   "e": r"Quando um aliado em Perto sofreria dano, você pode tomá-lo no "
        r"lugar, com \textbf{um degrau a menos}.",
   "m": r"Enquanto você estiver de pé, nenhum aliado que esteja atrás de "
        r"você pode ser alvo de ataque de Longe ou mais longe."},
 ]},

{
 "nome": "ANDORINHA",
 "fabrica": "VESPERTINA",
 "chassi": "ANDORINHA",
 "evasao": 12, "pv": 5,
 "chamada": "A distância entre você e o problema é uma decisão sua, e "
            "você decide depressa.",
 "itens": "Óculos escuros de piloto, um mapa desenhado à mão de uma "
          "cidade que não existe mais, e o diploma.",
 "traco": ("Rasante",
   r"Sempre que você atravessa duas faixas de alcance ou mais numa ação, "
   r"fique \termo{Oculto} ao chegar, mesmo sem cobertura."),
 "esperanca": ("Passarinho",
   r"Gaste 3 Esperança: o próximo ataque feito contra você nesta cena "
   r"erra. Descreva por onde você passou."),
 "subclasses": [
  {"nome": "VENTO", "linha": "Estar em toda parte.",
   "f": r"\textbf{+1 Deslocamento}. Uma vez por cena, mude de posição "
        r"como reação, sem gastar ação.",
   "e": r"Você pode carregar um aliado em todos os seus deslocamentos, e "
        r"ele também chega \termo{Oculto}.",
   "m": r"Uma vez por cena, aja imediatamente depois de qualquer outra "
        r"pessoa, sem custo e sem o holofote sair de quem estava com ele."},
  {"nome": "CORTE", "linha": "Estar num lugar só, uma vez só.",
   "f": r"Ataques feitos saindo de \termo{Oculto} rolam o dano duas "
        r"vezes; fique com o maior.",
   "e": r"Quando você derruba um adversário, fique \termo{Oculto} "
        r"imediatamente.",
   "m": r"Contra um alvo que ainda não agiu nesta cena, o seu primeiro "
        r"ataque acerta sem rolagem e causa dano Severo."},
 ]},

{
 "nome": "BALUARTE",
 "fabrica": "CATEDRAL",
 "chassi": "ARCADA",
 "evasao": 9, "pv": 7,
 "chamada": "Você é a razão pela qual o resto tem para onde recuar.",
 "itens": "Um casaco de oficial furado no ombro esquerdo, um livro de "
          "protocolo e a chave da sua primeira cabine.",
 "traco": ("Linha",
   r"Enquanto houver um aliado atrás de você, você tem \textbf{+1 "
   r"Blindagem} e não pode ficar \termo{Instável}."),
 "esperanca": ("Em Nome de Quem",
   r"Gaste 3 Esperança: declare uma ordem em voz alta. Todo adversário "
   r"de Escalão inferior ao seu perde a próxima ação decidindo se "
   r"obedece."),
 "subclasses": [
  {"nome": "PORTÃO", "linha": "O que fecha.",
   "f": r"Adversários gastam uma ação inteira para passar por você. "
        r"Some \textbf{+2} em tudo que for impedir alguém de passar.",
   "e": r"Aliados no seu alcance ganham \textbf{+1} de Evasão e não "
        r"podem ser pegos de surpresa.",
   "m": r"Uma vez por sortida, declare uma linha fechada: nada a "
        r"atravessa por uma cena enquanto você estiver de pé."},
  {"nome": "ESTANDARTE", "linha": "O que chama.",
   "f": r"Uma vez por cena, um aliado que te ouça age imediatamente, "
        r"com vantagem.",
   "e": r"Aliados que te ouçam limpam 1 Estresse no começo de cada cena.",
   "m": r"Uma vez por sortida, todo aliado em campo age uma vez, na "
        r"ordem que você quiser."},
 ]},

{
 "nome": "MERGULHADOR",
 "fabrica": "ARCO",
 "chassi": "VAZANTE",
 "evasao": 11, "pv": 6,
 "chamada": "Você já esteve em lugares mais escuros que este.",
 "itens": "Tampões de ouvido que você nunca tira, uma corda de "
          "trinta metros e um frasco lacrado com alguma coisa dentro.",
 "traco": ("Fundo",
   r"Pressão, frio, vácuo e falta de ar não te afetam, dentro ou fora "
   r"do colosso. Você não marca Estresse por ambiente."),
 "esperanca": ("Escuta",
   r"Gaste 3 Esperança: pergunte ao Mestre onde está a coisa mais "
   r"perigosa em um quilômetro, e o que ela quer."),
 "subclasses": [
  {"nome": "QUILHA", "linha": "O peso da água.",
   "f": r"Seus ataques contra alvos submersos, presos ou sem apoio "
        r"somam \textbf{+1d8}, e você pode arrastar um alvo para baixo.",
   "e": r"Adversários gastam uma ação a mais para se afastar de você, "
        r"como se a água fosse mais pesada ali.",
   "m": r"Uma vez por sortida, o chão onde você está afunda. Tudo que "
        r"não for você vai junto."},
  {"nome": "SONAR", "linha": "O que responde lá embaixo.",
   "f": r"Você sabe o que existe em cada direção até Muito Longe, "
        r"através de parede, água e escuro.",
   "e": r"Fundas menores não te atacam sem um bom motivo. Algumas "
        r"obedecem por uma cena se você marcar 2 Estresse.",
   "m": r"Uma vez por campanha, chame uma coisa grande. Ela vem. O que "
        r"ela faz quando chega não é decisão sua."},
 ]},

{
 "nome": "REMENDÃO",
 "fabrica": "GRALHA",
 "chassi": "REMENDO",
 "evasao": 11, "pv": 6,
 "chamada": "Todo mundo tem um plano. Você tem uma caixa de ferramentas.",
 "itens": "Uma caixa de ferramentas que não é sua, um crachá de "
          "manutenção de uma fundição que fechou e fita de amarrar.",
 "traco": ("Puxadinho",
   r"\textbf{+1 encaixe} no seu chassi. Você pode instalar Peças de "
   r"qualquer fábrica em que tenha licença, em qualquer casco."),
 "esperanca": ("Tinha Isso Aqui",
   r"Gaste 3 Esperança: você tinha exatamente o item, a peça ou a "
   r"ferramenta de que a cena precisava. Diga qual, e de onde veio."),
 "subclasses": [
  {"nome": "FERRO-VELHO", "linha": "Nada se perde.",
   "f": r"Quando um colosso cai perto de você, arranque uma peça dele: "
        r"uma arma, uma Peça instalada, ou 3 Estrutura para você.",
   "e": r"Uma vez por cena, use uma Peça instalada de um colosso que "
        r"você esteja tocando, amigo ou não.",
   "m": r"Uma vez por sortida, monte na hora uma Peça que você não tem. "
        r"Funciona por uma cena e vira sucata."},
  {"nome": "ESTOPIM", "linha": "Nada fica inteiro.",
   "f": r"Suas cargas e sabotagens causam \textbf{+1d10} e ignoram "
        r"Blindagem.",
   "e": r"Quando uma Peça inimiga desliga por culpa sua, ela estoura: "
        r"\dado{3d10} em tudo em Muito Perto dela.",
   "m": r"Você pode plantar uma carga num colosso que ainda nem chegou "
        r"à cena, desde que tenha visto a doca dele."},
 ]},

{
 "nome": "SENTINELA",
 "fabrica": "SELO",
 "chassi": "RONDA",
 "evasao": 10, "pv": 7,
 "chamada": "Alguém tem que anotar o que aconteceu aqui. Vai ser você.",
 "itens": "Um apito de patrulha, um bloco de autuação e a lanterna mais "
          "cara que você já comprou.",
 "traco": ("Ronda",
   r"No começo de cada cena, escolha um lugar: você sabe tudo que entra "
   r"e sai dele até o fim da cena, mesmo sem estar lá."),
 "esperanca": ("Parado Aí",
   r"Gaste 3 Esperança: uma pessoa ou máquina que você consiga ver para "
   r"o que está fazendo e escuta você por uma cena."),
 "subclasses": [
  {"nome": "PATRULHA", "linha": "Estar onde o problema vai estar.",
   "f": r"Você pode mudar de posição como reação quando alguém entra no "
        r"lugar que você escolheu na Ronda.",
   "e": r"Aliados perto de você ganham \textbf{+1} de Evasão e não "
        r"podem ser surpreendidos.",
   "m": r"Uma vez por sortida, chegue a tempo: você estava lá o tempo "
        r"todo, e a coisa ruim não aconteceu."},
  {"nome": "TORRE", "linha": "Estar onde dá para ver tudo.",
   "f": r"Enquanto você não muda de lugar, os seus ataques de Longe e "
        r"Muito Longe têm vantagem.",
   "e": r"Marque um alvo por cena como reação: todo ataque aliado contra "
        r"ele soma \textbf{+2 por Proficiência}.",
   "m": r"Um alvo marcado por você não pode ficar \termo{Oculto}, mudar "
        r"de lugar sem ser visto, nem sair da cena."},
 ]},

{
 "nome": "CORSÁRIO",
 "fabrica": "CARVAO",
 "chassi": "GANCHO",
 "evasao": 11, "pv": 6,
 "chamada": "Não se afunda uma carga. Se afunda quem não quis entregar.",
 "itens": "Uma corda de abordagem com gancho de ferro batido, uma dívida "
          "escrita num pedaço de lona e três chaves que não são suas.",
 "traco": ("Abordagem",
   r"Quando você prende alguém com gancho, corda, arpéu ou garra, pode "
   r"arrastá-lo junto no mesmo movimento — e ele fica \termo{Restrito}."),
 "esperanca": ("Parte do Butim",
   r"Gaste 3 Esperança: cada aliado que te ouça limpa 1 Estresse, e "
   r"você ganha 1 Esperança de volta se algum deles usar isso na mesma "
   r"cena."),
 "subclasses": [
  {"nome": "GANCHO", "linha": "Chegar no casco do outro.",
   "f": r"Seus ganchos alcançam Longe e prendem dois alvos ao mesmo "
        r"tempo.",
   "e": r"Enquanto você segura um alvo preso, os ataques dele contra "
        r"qualquer um que não seja você têm desvantagem.",
   "m": r"Uma vez por sortida, abra a cabine de um colosso preso. O que "
        r"acontece lá dentro é uma cena de gente."},
  {"nome": "FUMAÇA", "linha": "Não estar onde procuram.",
   "f": r"Você não pode ser identificado, rastreado nem denunciado por "
        r"sistema nenhum.",
   "e": r"Uma vez por cena, você e um aliado somem e reaparecem em "
        r"qualquer ponto da cena.",
   "m": r"Uma vez por sortida, a cena inteira perde você de vista. "
        r"Ninguém sabe dizer quando foi que você saiu."},
 ]},

{
 "nome": "HERDEIRO",
 "fabrica": "OSSATURA",
 "chassi": "COSTELA",
 "evasao": 10, "pv": 6,
 "chamada": "Você desceu fundo demais uma vez. Alguma coisa subiu com você.",
 "itens": "Um cabresto de aço com quinze metros, um caderno com o nome de "
          "tudo que você já prendeu, e uma cicatriz no pescoço.",
 "traco": ("A Carne Lembra",
   r"Marque 1 Estresse para limpar 2 Estrutura do seu colosso, a "
   r"qualquer momento. O enxerto fecha o buraco antes de você pedir."),
 "esperanca": ("Palavra Boa",
   r"Gaste 3 Esperança: uma criatura que não seja personagem jogador "
   r"para de atacar e escuta você por uma cena."),
 "subclasses": [
  {"nome": "COLEIRA", "linha": "Segurar o que não devia andar solto.",
   "f": r"Você pode prender uma criatura ou colosso com uma ação: ele "
        r"fica \termo{Restrito} enquanto você não soltar nem atacar "
        r"outra coisa.",
   "e": r"Você prende dois alvos ao mesmo tempo, e prender deixou de "
        r"gastar a sua ação.",
   "m": r"Um alvo preso por você de Escalão inferior luta ao seu lado "
        r"até o fim da cena."},
  {"nome": "VIRADA", "linha": "Deixar de segurar.",
   "f": r"\textbf{Garra Viva} de graça, sem ocupar encaixe.",
   "e": r"Quando você marca Estresse por causa do enxerto, ganhe "
        r"\textbf{+1d6} na sua próxima rolagem.",
   "m": r"Quando o seu colosso cai, você não fica a pé: o enxerto "
        r"levanta com 6 Estrutura e obedece por uma cena."},
 ]},
]


# ================================================== ANCESTRALIDADES

ANCESTRALIDADES = [
 ("SERRANO",
  "Gente das cordilheiras de dentro, onde o ar é fino, a estrada é uma "
  "só e a neblina fecha às quatro da tarde.",
  "Serranos medem tudo em dias de caminhada e não confiam em pressa. "
  "Crescem subindo, o que dá um fôlego que gente de planície não tem e "
  "uma teimosia que gente de planície não entende. As vilas de serra "
  "foram as últimas a serem ocupadas em todas as guerras, não por "
  "coragem, mas por logística.",
  ("Fôlego Longo",
   r"Você não marca Estresse por esforço, altitude, calor ou falta de "
   r"sono. O Mestre precisa de um motivo melhor do que cansaço."),
  ("Pé de Pedra",
   r"Você não fica \termo{Instável} por terreno, e escala qualquer "
   r"superfície com uma rolagem de \termo{Força}, sem equipamento.")),

 ("VAZANTEIRO",
  "Nascido na planície que alaga seis meses por ano e seca nos outros "
  "seis, e que muda de forma entre uma coisa e outra.",
  "Vazanteiros aprendem a nadar antes de andar e a desmontar casa antes "
  "de aprender a ler. Não têm noção de propriedade fixa: onde a água "
  "passa, é de todo mundo. Isso os torna péssimos em cartório e "
  "excelentes em qualquer coisa que exija mudar de plano no meio.",
  ("Guelra Velha",
   r"Você respira debaixo d'água o tempo que quiser e enxerga na água "
   r"turva."),
  ("Barro",
   r"Uma vez por cena, marque 1 Estresse para escapar de qualquer "
   r"agarrão, algema, rede ou aperto — inclusive de um colosso.")),

 ("FUNDIDO",
  "Criado dentro das cidades-fundição, entre forno e turno, com o "
  "barulho da prensa marcando a hora.",
  "Fundidos nascem com o ouvido calibrado: sabem que uma máquina vai "
  "quebrar dois dias antes de ela quebrar. Crescem em vila de empresa, "
  "com escola de empresa e médico de empresa, e saem de lá com uma "
  "relação complicada com a palavra lealdade. Metade dos mecânicos do "
  "continente é fundida; a outra metade aprendeu com um.",
  ("Calo de Forja",
   r"Calor, faísca e metal quente não te machucam. Você pega a peça com "
   r"a mão."),
  ("Ouvido de Motor",
   r"Você sabe o que há de errado com qualquer máquina só de ouvir. Uma "
   r"vez por cena, o Mestre te conta um defeito de algo na cena.")),

 ("VENTO-ALTO",
  "De cima: das plataformas ancoradas, das torres de sinal e das rotas "
  "que ninguém olha do chão.",
  "Vento-altos passam a infância com um arnês preso na cintura e "
  "aprendem cedo que a queda não é o problema — o problema é o "
  "\\emph{susto} da queda, e esse dá para desligar. São contratados como "
  "instaladores, sinaleiros e carteiros de plataforma, e têm um "
  "vocabulário inteiro para tipos de vento.",
  ("Sem Fundo",
   r"Queda não é problema: você reduz qualquer dano de queda a zero e "
   r"cai de pé."),
  ("Olho de Longe",
   r"Você enxerga detalhe a distâncias absurdas. Ataques de Muito Longe "
   r"não sofrem desvantagem por distância.")),

 ("CINZEIRO",
  "Do cinturão de cinza, onde a guerra passou primeiro e nunca "
  "terminou de ir embora.",
  "Cinzeiros crescem sabendo o nome de três tipos de gás e o som de "
  "cinco tipos de artilharia. Têm um humor seco que gente de fora acha "
  "cruel e que entre eles é carinho. Ninguém de fora do cinturão "
  "entende por que eles não saem de lá; a resposta é sempre que "
  "alguém tem que ficar, e por enquanto é a vez deles.",
  ("Pulmão Sujo",
   r"Fumaça, gás, pó e ar ruim não te afetam, e você enxerga através "
   r"deles."),
  ("Já Vi Pior",
   r"Uma vez por sessão, quando o Mestre gasta Medo para piorar uma "
   r"cena, você ganha 1 Esperança.")),

 ("MARCADO",
  "Tocado por uma Funda antes de nascer. Ninguém combina isso, e "
  "ninguém sabe direito como acontece.",
  "Marcados têm alguma coisa levemente errada — o formato da pupila, a "
  "temperatura da pele, o fato de nunca terem tido uma infecção. São "
  "recrutados cedo por programas que negam existir e evitados por "
  "vizinhos que não sabem explicar por quê. A maioria leva uma vida "
  "comum e morre sem descobrir para que servia.",
  ("Sinal",
   r"Você sente Fundas a quilômetros e sabe de que tamanho. Elas "
   r"também sentem você."),
  ("Carne Errada",
   r"Uma vez por cena, marque 1 Estresse para ignorar completamente um "
   r"ferimento, um veneno ou uma condição que afete o seu corpo.")),

 ("NORTISTA",
  "Da frente fria, onde a linha de batalha não se mexe há dezoito anos "
  "e as duas trincheiras já trocaram de dono duas vezes.",
  "Nortistas têm a paciência de quem foi criado esperando: esperando "
  "degelo, esperando comboio, esperando ordem. São os melhores "
  "atiradores e os piores negociadores do continente, porque acham "
  "que quem fala demais está escondendo alguma coisa — e costumam "
  "estar certos.",
  ("Casca",
   r"Frio, fome e espera não te atingem. \textbf{+1} nos dois Limiares "
   r"do piloto."),
  ("Teimosia",
   r"Quando você falha em uma rolagem com Medo, ganhe 1 Esperança. Uma "
   r"vez por cena.")),

 ("APARELHADO",
  "Ligado a uma máquina desde criança — por programa, por acidente ou "
  "por escolha de outra pessoa.",
  "Aparelhados têm o enxerto de interface na nuca e a papelada que "
  "diz quem pagou por ele. São os melhores pilotos brutos que existem "
  "e a categoria com maior índice de abandono, porque descobrem cedo "
  "que a facilidade tem um preço que não está escrito em lugar "
  "nenhum. Há uma associação deles em quatro cidades. Nenhuma tem "
  "sede fixa.",
  ("Conexão Direta",
   r"Você opera o colosso sem cabine: pode pilotá-lo de fora, de "
   r"qualquer lugar da mesma cena."),
  ("Leitura Crua",
   r"Você lê o estado de qualquer colosso que veja: Estrutura, "
   r"Blindagem, Peças instaladas e o que está quebrado.")),

 ("CAMINHANTE",
  "Dos comboios que atravessam a linha carregando gente, peça e "
  "notícia, e que não param em lugar nenhum por mais de três dias.",
  "Caminhantes são o sistema nervoso do continente: se alguma coisa "
  "acontece num lugar, um comboio leva a notícia ao outro antes de "
  "qualquer rádio. Têm parentes em todo canto, dívidas em todo canto "
  "e uma etiqueta rígida sobre hospitalidade que forasteiros "
  "costumam violar sem perceber.",
  ("Estrada",
   r"Você nunca se perde e sempre sabe para onde ir. Viagens por terra "
   r"levam metade do tempo previsto."),
  ("Bagagem",
   r"Uma vez por sessão, você tinha exatamente o item mundano de que "
   r"se precisava. Estava no fundo do bornal.")),

 ("ILHÉU",
  "Do arquipélago: mergulho, sal, e uma língua que só se fala lá e "
  "que não tem palavra para fronteira.",
  "Ilhéus medem riqueza em profundidade alcançada e contam história "
  "cantando. Foram os primeiros a ver Funda de perto e a única "
  "cultura que tem nome próprio para cada uma das grandes. Trabalham "
  "como mergulhadores, pilotos de casco selado e — quando a coisa "
  "aperta — como guias para lugares de onde ninguém mais volta.",
  ("Sopro Guardado",
   r"Você aguenta cinco minutos sem respirar e nada tão rápido quanto "
   r"anda."),
  ("Corda e Nó",
   r"Você amarra, prende e solta qualquer coisa com uma ação. Nós seus "
   r"não cedem sem uma rolagem Dificuldade 18.")),
]


# ======================================================= COMUNIDADES

COMUNIDADES = [
 ("ACADEMIA",
  "Você veio de uma faculdade de pilotagem, com nota, fardamento e "
  "colegas que hoje voam do outro lado.",
  "As três academias do continente formam menos de quatrocentos "
  "pilotos por ano e decidem, na prática, quem comanda o quê pelos "
  "próximos trinta. Quem sai de lá carrega uma rede de contatos que "
  "vale mais que o diploma — e uma reputação que chega antes dele em "
  "qualquer sala.",
  r"Você conhece o manual. Uma vez por cena, some \textbf{+2} em "
  r"qualquer rolagem que dependa de procedimento, doutrina ou "
  r"protocolo, e o Mestre te conta qual era o procedimento correto."),

 ("FUNDIÇÃO",
  "Cidade de forno aceso, turno de doze horas e sindicato que já "
  "parou o continente duas vezes.",
  "Vila de fundição é um lugar onde todo mundo trabalha para a mesma "
  "empresa e todo mundo sabe disso. A solidariedade é real e a "
  "vigilância também. Quem sai de uma fundição sai sabendo fazer "
  "coisas com as mãos e sabendo exatamente quanto vale uma hora de "
  "trabalho de outra pessoa.",
  r"Peça é com você. Consertos custam metade, e você pode trabalhar "
  r"num colosso alheio como se fosse seu."),

 ("QUARTEL",
  "Filho de farda, criado em vila militar, mudando de base a cada "
  "dois anos e nunca terminando um ano letivo no mesmo lugar.",
  "Gente de quartel aprende hierarquia antes de aprender a ler e "
  "desenvolve uma facilidade assustadora para se adaptar a lugar "
  "novo. Também desenvolve, quase sempre, uma dificuldade igual de "
  "grande para confiar que alguém vai continuar por perto.",
  r"Você tem patente ou sabe imitar uma. Uma vez por sessão, uma "
  r"ordem sua é obedecida por tropa regular sem que ninguém peça "
  r"papel."),

 ("DOCA",
  "Porto, guindaste, contêiner e o barulho da água batendo no "
  "concreto às três da manhã.",
  "Doca é onde o mundo se encontra: a carga de todo mundo passa por "
  "ali, e com a carga passa a informação. Gente de doca fala quatro "
  "línguas mal e entende oito, negocia por instinto e tem uma noção "
  "muito própria de quando uma lei se aplica.",
  r"Você sabe o que entra e o que sai. Uma vez por sessão, pergunte "
  r"ao Mestre onde está uma carga, um navio ou uma pessoa que passou "
  r"por um porto."),

 ("SUCATA",
  "Você cresceu desmontando o que os outros abandonaram, num pátio "
  "sem dono e com regras que ninguém escreveu.",
  "Ferro-velho é uma economia inteira: tem hierarquia, tem território, "
  "tem acordo de não-agressão e tem gente que passou a vida sem sair "
  "de lá. Quem cresce na sucata sabe o preço de tudo e aprende cedo "
  "que a diferença entre lixo e tesouro é só quem está perguntando.",
  r"Você reconhece qualquer peça e sabe quanto ela vale. Uma vez por "
  r"sessão, encontre uma peça específica em qualquer monte de ferro "
  r"velho."),

 ("SOLAR",
  "Casa de oficiais, jantar com talher demais, retratos na parede e "
  "um sobrenome que abre porta antes de você falar.",
  "As famílias de solar controlam a oficialidade há tanto tempo que "
  "já não distinguem serviço público de patrimônio. Quem nasce ali "
  "recebe educação excelente, contatos excelentes e uma dívida de "
  "lealdade que nunca foi combinada e que vence sempre no pior "
  "momento possível.",
  r"Portas se abrem. Uma vez por sessão, você tem acesso a alguém "
  r"importante — e alguém importante passa a ter acesso a você."),

 ("ROÇA",
  "Terra ocupada, colheita requisitada, e o trator que a vizinhança "
  "converteu em colosso numa semana.",
  "Zona rural em guerra é a parte que ninguém filma: alimenta os dois "
  "lados, é revistada pelos dois lados e não é defendida por nenhum. "
  "Quem sai da roça sai sabendo trabalhar, sabendo esconder e "
  "sabendo, com precisão desconfortável, de quanta comida uma pessoa "
  "precisa por dia.",
  r"Você se vira sem nada. Fora de uma cidade, você e o seu grupo "
  r"nunca passam fome, nunca dormem ao relento e nunca são entregues "
  r"por vizinho."),

 ("CARAVANA",
  "Comboio de refugiados: gente que perdeu o lugar e aprendeu a "
  "carregá-lo.",
  "Uma caravana é uma cidade que anda. Tem conselho, tem escola, tem "
  "cemitério que fica para trás. Quem cresce em caravana tem uma "
  "memória absurda para rostos e uma relação estranha com o verbo "
  "voltar, que na língua deles é o mesmo que o verbo lembrar.",
  r"Você tem gente em todo canto. Uma vez por sessão, alguém no lugar "
  r"onde você está te reconhece e te deve alguma coisa."),
]


if __name__ == "__main__":
    from collections import Counter
    print("%d chassis, %d classes, %d subclasses"
          % (len(CHASSIS), len(CLASSES),
             sum(len(c["subclasses"]) for c in CLASSES)))
    print("chassis por porte:", dict(Counter(c[2] for c in CHASSIS)))
    print("classes por fábrica:", dict(Counter(c["fabrica"] for c in CLASSES)))
    print("%d ancestralidades, %d comunidades"
          % (len(ANCESTRALIDADES), len(COMUNIDADES)))
