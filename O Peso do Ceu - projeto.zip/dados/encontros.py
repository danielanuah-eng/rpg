# -*- coding: utf-8 -*-
"""
Padrões de encontro: quem aparece junto com quem.

O gerador antigo sorteava adversários por preço e Escalão e pronto — e
saía Funda do fundo do mar marchando ao lado de fuzileiro da Milícia,
que não quer dizer nada. Adversário não é ingrediente solto: vem em
formação, e a formação é que conta a história.

Cada padrão é uma receita: de onde os adversários podem sair, se todos
são da mesma casa, quem manda e o que enche a linha. O gerador monta
dentro dessas regras e o resultado sai com sentido.

  origens      "colosso" (máquina de fábrica), "gente" (sem máquina),
               "funda" (bicho)
  casa_unica   todos do mesmo fabricante
  eixo         quem entra primeiro e organiza: papel, "pesado",
               "assinatura" ou "nomeado"
  enche        papéis aceitos para o resto da linha
  escolta      se o eixo traz a escolta do dom dele
"""

PADROES = [
 ("exercito", "Exército", "🪖",
  "Fardados de uma casa só. Vem em ordem, obedece a alguém e recua "
  "quando mandam recuar.",
  dict(origens=["gente", "colosso"], casa_unica=True, eixo="Comandante",
       enche=["Lacaio", "Regular", "Apoio", "Atirador"],
       sem=["Solo"], escolta=False,
       nota="Se o Comandante cair, o resto testa moral: em Medo baixo, "
            "recuam.")),

 ("patrulha", "Patrulha", "🔦",
  "Meia dúzia de uma casa só, longe de casa e sem vontade de morrer "
  "por isso.",
  dict(origens=["gente", "colosso"], casa_unica=True, eixo="Regular",
       enche=["Lacaio", "Regular", "Batedor", "Atirador"],
       sem=["Solo", "Comandante"], escolta=False, teto=6,
       nota="Patrulha negocia. Comece pedindo documento, não rolando "
            "iniciativa.")),

 ("mechas_exercito", "Mechas e exército", "⚙️",
  "A casa mandou máquina pesada e mandou gente junto. A gente serve "
  "para a máquina não ser cercada.",
  dict(origens=["gente", "colosso"], casa_unica=True, eixo="pesado",
       enche=["Lacaio", "Regular", "Apoio", "Atirador", "Brutamontes"],
       sem=["Solo"], escolta=False,
       nota="O pesado segura a faixa da frente; a tropa cobre os "
            "flancos. Derrubar a tropa primeiro é a jogada certa.")),

 ("fundas", "Só Fundas", "🌊",
  "Bicho. Não marcha em formação, não recua e não quer nada que dê "
  "para negociar.",
  dict(origens=["funda"], casa_unica=False, eixo=None,
       enche=["Lacaio", "Regular", "Brutamontes", "Batedor", "Solo"],
       sem=["Comandante"], escolta=False,
       nota="Funda não tem Comandante. Se precisar de eixo, use uma "
            "Funda colossal e deixe o resto orbitar.")),

 ("corrompidos", "Mechas corrompidos", "🩸",
  "Uma máquina de fábrica no meio dos bichos — e obedecendo a ela. "
  "Para quando o vilão descobriu o que as Fundas fazem.",
  dict(origens=["funda", "colosso"], casa_unica=False,
       eixo="assinatura", enche=["Lacaio", "Regular", "Brutamontes",
                                 "Batedor"],
       so_funda_enche=True, sem=["Comandante"], escolta=False,
       nota="As Fundas cobrem a máquina e morrem por ela. Quem pilota "
            "aquilo sabe uma coisa que ninguém devia saber.")),

 ("chefe", "Chefe e escolta", "👑",
  "Um Nomeado com nome, cara e motivo, e a escolta que a casa dele "
  "manda junto.",
  dict(origens=["colosso", "gente"], casa_unica=True, eixo="nomeado",
       enche=["Lacaio", "Regular", "Apoio", "Atirador", "Brutamontes"],
       sem=["Solo"], escolta=True,
       nota="O chefe tem dom e segunda fase. Leia as duas coisas antes "
            "de começar, e guarde 2 Medo para a virada.")),

 ("duelo", "Duelo", "⚔️",
  "Um contra a mesa. Nada mais entra, e é isso que deixa a coisa "
  "perigosa.",
  dict(origens=["colosso"], casa_unica=True, eixo="nomeado",
       enche=[], sem=[], escolta=False, teto=1,
       nota="Sem tropa, o orçamento inteiro vai para o chefe. Deixe a "
            "segunda fase acontecer: é ela que é a briga.")),

 ("cerco", "Cerco de cidade", "🏚️",
  "Gente da rua no meio, tropa de um lado e uma máquina grande "
  "chegando. A briga tem testemunha.",
  dict(origens=["gente", "colosso"], casa_unica=True, eixo="pesado",
       enche=["Lacaio", "Regular", "Atirador"], sem=["Solo"],
       escolta=False,
       nota="Há gente que não vai sair a tempo. Toda ação em área "
            "cobra um preço que não está na ficha.")),

 ("bagunca", "Bagunça", "🎲",
  "Tudo misturado, sem explicação nenhuma. Use quando a cena já "
  "justificar — ou quando quiser inventar a justificativa depois.",
  dict(origens=["colosso", "gente", "funda"], casa_unica=False,
       eixo=None, enche=None, sem=[], escolta=False,
       nota="Era assim que o gerador fazia sempre. Agora é uma escolha, "
           "não um acidente.")),
]
