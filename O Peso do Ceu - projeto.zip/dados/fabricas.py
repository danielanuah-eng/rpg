# -*- coding: utf-8 -*-
"""
As oito fábricas — e é aqui que mora toda a customização do colosso.

O piloto tem classe, subclasse, arma e equipamento, e é isso. A máquina é
que cresce: cada fábrica vende PEÇAS, e é juntando Peças que se monta um
colosso que não parece com o de mais ninguém.

TIPOS DE PEÇA
  Fixa    ligada o tempo todo, sem custo nenhum.
  Ativa   custa Estresse do piloto. A máquina esquenta; quem sente é você.
  Tensa   de graça — mas só funciona enquanto o Mestre tiver Medo guardado.
          Quanto pior a situação, mais a sua máquina acorda.

ENCAIXES
  Cada chassi tem um número de encaixes. Uma Peça instalada ocupa um.
  Troca-se numa doca ou numa Parada Longa. As Peças são cartas: dá para
  deixar um conjunto preparado e trocar entre uma sortida e outra.

Cada peça: (nível, nome, tipo, custo, texto)
  custo   Estresse, para as Ativas; limiar de Medo, para as Tensas; 0 nas Fixas
"""

FABRICAS = {

# =====================================================================
"BRASA": {
 "nome": "Companhia Brasa e Filhos",
 "linha": "Fundição · chapa rebitada · a máquina que volta",
 "lema": "A gente não faz máquina bonita. A gente faz máquina que volta.",
 "cor": "brasaC",
 "proposta":
   "A Brasa é uma fundição de cidade operária que virou fabricante de "
   "colosso por acidente, quando a guerra chegou e ninguém mais tinha "
   "quem soubesse dobrar chapa daquela espessura. Ela nunca perdeu o "
   "jeito de fundição: os cascos saem com rebite aparente, solda visível, "
   "chaminé de escape e um manual de trinta páginas que qualquer mecânico "
   "de beira de estrada entende. Não há eletrônica que o piloto não "
   "consiga consertar com chave de fenda e teimosia.",
 "cultura":
   "Quem compra Brasa não compra desempenho, compra conserto. Uma Brasa "
   "quebrada volta a andar em seis horas com peça de caminhão. É o casco "
   "das milícias, das defesas civis, dos que não têm contrato com "
   "ninguém — e é, por isso mesmo, o casco mais numeroso de todas as "
   "frentes. Existe um ditado de doca que diz que toda guerra acaba "
   "sendo ganha por quem tinha a Brasa mais velha ainda de pé.",
 "estetica":
   "Chapa grossa parafusada por fora, chaminés de escape nos ombros, "
   "membros de mangueira sanfonada, pé largo de bota. Tinta industrial "
   "por cima de tinta industrial. Nunca houve uma Brasa sem fuligem.",
 "pecas": [
  (1, "Chapa Sobreposta", "Fixa", 0,
   r"\textbf{+1 Blindagem.} O casco ganha uma camada a mais de chapa "
   r"parafusada por fora, e um barulho característico quando anda."),
  (1, "Pé de Chumbo", "Fixa", 0,
   r"Você não pode ser empurrado, derrubado, puxado nem arrastado por "
   r"nada que pese menos que você. Em troca, o seu Deslocamento nunca "
   r"passa de uma faixa por ação."),
  (1, "Guincho de Doca", "Ativa", 1,
   r"Puxe até você qualquer coisa do tamanho de um colosso, ou vá até "
   r"ela. Fora de combate, isso levanta ponte caída, tira gente de "
   r"escombro e reboca máquina morta."),
  (2, "Solda de Campo", "Ativa", 1,
   r"Limpe \textbf{2 Estrutura} marcada — sua ou de um aliado em Muito "
   r"Perto. Fora de combate não custa nada e conserta o que precisar."),
  (2, "Fornalha Aberta", "Tensa", 4,
   r"O seu Setor fica quente. Todo adversário que começar a ação em "
   r"Muito Perto de você marca 1 Estresse."),
  (3, "Marreta de Fundição", "Ativa", 1,
   r"Um golpe corpo a corpo que rola o dano \textbf{duas vezes} — fique "
   r"com o maior — e joga o alvo uma faixa para longe."),
  (3, "Braço de Carga", "Fixa", 0,
   r"Você carrega o que quiser: um colosso inerte, um vagão, um pedaço "
   r"de parede. Nada disso atrapalha o seu movimento."),
  (4, "Purga de Vapor", "Ativa", 2,
   r"Encha um Setor de vapor. Todos ali ficam \termo{Ocultos} e "
   r"\termo{Cegos} até o fim da cena, você inclusive — a não ser que "
   r"tenha a \termo{Esfera de Leitura}."),
  (4, "Casco Teimoso", "Fixa", 0,
   r"A primeira vez em cada cena que você marcaria 3 Estrutura de um "
   r"golpe só, marque 1."),
  (5, "Motor de Teimosia", "Tensa", 6,
   r"Enquanto estiver ligada, você age \textbf{duas vezes} antes de "
   r"passar o holofote. Uma vez por cena."),
  (6, "Bigorna", "Fixa", 0,
   r"\textbf{+2 nos dois Limiares} e \textbf{+1 Estrutura}. O casco "
   r"ficou pesado demais para qualquer coisa que não seja andar em "
   r"frente."),
  (7, "Chaminé Dupla", "Ativa", 1,
   r"Limpe \textbf{2 Estresse}. O escape abre, a cabine esfria e todo "
   r"mundo num raio de quarteirão sabe onde você está."),
  (8, "Prensa", "Ativa", 2,
   r"Agarre um alvo em Corpo a corpo. Ele fica \termo{Restrito} e sofre "
   r"o dano da sua arma a cada ação enquanto você não soltar. Você "
   r"também não faz mais nada enquanto isso."),
  (9, "Placa de Sacrifício", "Tensa", 4,
   r"Quando um aliado em Perto sofreria dano, você pode tomá-lo no lugar "
   r"— e ele cai \textbf{um degrau} de Limiar no caminho."),
  (10, "A Última Brasa", "Ativa", 2,
   r"Uma vez por sortida: quando o seu colosso cairia, ele não cai. "
   r"Ele fica de pé com \textbf{4 Estrutura} até o fim da cena, e depois "
   r"disso nunca mais anda."),
 ]},

# =====================================================================
"VESPERTINA": {
 "nome": "Vespertina Mecânica Fina",
 "linha": "Academia · cintura estreita · chegar primeiro",
 "lema": "Quem te vê não te alcança. Quem te alcança não te viu.",
 "cor": "vespC",
 "proposta":
   "A Vespertina fabrica menos cascos em um ano do que a Brasa fabrica em "
   "uma semana, e cada um custa o que custa um quarteirão. São máquinas "
   "de cintura muito fina, patim polido, leque de aletas nas costas e uma "
   "ficha técnica que cabe numa folha — porque tudo que não era "
   "essencial foi tirado. A fábrica mantém contrato com as três "
   "academias de pilotagem do continente e escolhe a dedo quem pode "
   "comprar.",
 "cultura":
   "Pilotar Vespertina é uma declaração. Quem pilota foi treinado, tem "
   "nome, tem professor, e tem inimigos que sabem o nome dele. A fábrica "
   "manda um técnico junto com o casco e esse técnico responde à "
   "Vespertina, não ao piloto — o que já causou mais de um incidente "
   "diplomático. Um casco Vespertina abandonado no campo é recolhido pela "
   "própria fábrica antes de a poeira baixar.",
 "estetica":
   "Branco e cinza-pérola, cintura de vespa, perna digitígrada, leque de "
   "quatro aletas varridas para cima. Zero rebite aparente. Tudo que "
   "aparece, aparece de propósito.",
 "pecas": [
  (1, "Patim de Competição", "Fixa", 0,
   r"\textbf{+1 Deslocamento.} Em piso duro você atravessa duas faixas "
   r"de alcance com uma ação."),
  (1, "Passo de Lado", "Ativa", 1,
   r"Quando alguém declara um ataque contra você e antes de rolar, mude "
   r"de posição: o ataque erra, e você descreve por onde passou."),
  (2, "Lâmina de Serviço", "Fixa", 0,
   r"Seus ataques corpo a corpo somam \textbf{+2} ao dano e, num "
   r"Crítico, o alvo fica \termo{Vulnerável}."),
  (2, "Silêncio de Casco", "Fixa", 0,
   r"Você pode ficar \termo{Oculto} em qualquer lugar com fumaça, ruína, "
   r"água, multidão ou escuro — e continua Oculto depois de se mover."),
  (3, "Rasante", "Ativa", 1,
   r"Atravesse até três faixas de alcance em linha reta e ataque no fim. "
   r"Quem estiver no caminho rola \termo{Agilidade} ou é derrubado."),
  (3, "Leitura de Guarda", "Ativa", 1,
   r"Role \termo{Instinto} contra a Evasão de um alvo. Se acertar, todos "
   r"os seus ataques contra ele nesta cena têm vantagem."),
  (4, "Campo de Corte", "Tensa", 4,
   r"Enquanto ligada, os seus ataques ignoram \textbf{1 Blindagem} e "
   r"cobertura leve."),
  (4, "Aletas de Manobra", "Fixa", 0,
   r"Altura deixa de ser distância: você sobe, desce e atravessa vão "
   r"como se fosse chão plano."),
  (5, "Primeiro Corte", "Fixa", 0,
   r"Contra um alvo que ainda não agiu nesta cena, o seu primeiro ataque "
   r"acerta sem rolagem."),
  (6, "Eco Falso", "Ativa", 1,
   r"Deixe um eco seu onde estava. Até a sua próxima ação, quem quiser "
   r"te atacar precisa acertar qual dos dois é você (Dificuldade 15)."),
  (7, "Duas Lâminas", "Ativa", 2,
   r"Ataque dois alvos diferentes com uma rolagem só, comparada com as "
   r"duas Evasões."),
  (8, "Corte de Passagem", "Tensa", 6,
   r"Quando você atravessa o espaço de um adversário, ele sofre o dano "
   r"da sua arma corpo a corpo. Isso encadeia quantas vezes couber no "
   r"movimento."),
  (9, "Noite Portátil", "Ativa", 2,
   r"A cena escurece. Todos ficam \termo{Cegos} até o fim da cena, menos "
   r"você e quem você tocar antes de usar."),
  (9, "Sem Assinatura", "Fixa", 0,
   r"Trava, marcação, sonar e rastreio não funcionam em você. Precisa "
   r"ser olho."),
  (10, "O Que Não Estava Lá", "Ativa", 2,
   r"Uma vez por sortida: declare que você nunca esteve onde te "
   r"acertaram. O golpe não aconteceu, você está a uma faixa dali, "
   r"\termo{Oculto}, e é a sua vez."),
 ]},

# =====================================================================
"CATEDRAL": {
 "nome": "Fundição Catedral",
 "linha": "Estado · chapa cerimonial · ser visto e obedecido",
 "lema": "Metade do trabalho de um colosso é chegar. A outra metade é ser visto chegando.",
 "cor": "catC",
 "proposta":
   "A Catedral é a fábrica do Estado, e não esconde isso: os cascos dela "
   "têm brasão no peito, manto de tecido blindado, ombreira do tamanho de "
   "uma porta e um sistema de projeção de escudo que custa mais que o "
   "resto da máquina junta. Nada na Catedral é discreto, porque a "
   "discrição nunca foi o objetivo. Um colosso da Catedral é um "
   "argumento antes de ser uma arma.",
 "cultura":
   "Só quem tem patente pilota Catedral, e a patente vem com "
   "responsabilidade escrita: há um livro de protocolo do tamanho de uma "
   "bíblia sobre quando um casco da Catedral pode e não pode disparar. "
   "Pilotos da Catedral são julgados por tribunal próprio. Alguns acham "
   "isso proteção; outros já descobriram que não é.",
 "estetica":
   "Arco ogival na cabeça, ombreira em calota com espigões, faixas de "
   "chapa sobrepostas como degraus, manto. Cinza-pedra e osso, com um "
   "único acento quente.",
 "pecas": [
  (1, "Véu de Luz", "Ativa", 1,
   r"Reduza um dano que você ou um aliado em Perto acabou de sofrer em "
   r"\textbf{um degrau}. Três vezes por sortida."),
  (1, "Brasão", "Fixa", 0,
   r"Enquanto você estiver de pé e visível, todo aliado em Perto tem "
   r"\textbf{+1} de Evasão."),
  (2, "Voz de Comando", "Ativa", 1,
   r"Um aliado que você consiga ver age imediatamente, com vantagem."),
  (2, "Ombreira de Portão", "Fixa", 0,
   r"\textbf{+1 Blindagem} e \textbf{+1 Estrutura}. A ombreira cobre "
   r"meio corpo e é a primeira coisa que qualquer um acerta."),
  (3, "Ordem de Parada", "Tensa", 4,
   r"Adversários de Escalão inferior ao seu precisam gastar uma ação "
   r"decidindo se obedecem antes de poderem te atacar."),
  (3, "Estandarte", "Fixa", 0,
   r"Aliados em Perto não podem ser forçados a fugir, e não marcam "
   r"Estresse por medo, horror ou moral."),
  (4, "Abóbada", "Ativa", 2,
   r"Um domo de luz cobre o seu Setor por uma cena: nada de fora acerta "
   r"nada de dentro, e nada de dentro acerta nada de fora."),
  (5, "Formar", "Ativa", 1,
   r"Todo aliado em até Longe ganha \textbf{1 Blindagem} até o fim da "
   r"cena."),
  (6, "Peso da Lei", "Tensa", 4,
   r"Enquanto ligada, adversários gastam uma ação inteira para entrar no "
   r"seu Setor em vez de atravessar de graça."),
  (6, "Chapa de Estado", "Fixa", 0,
   r"\textbf{+3 no Limiar Maior.} Dano de Escalão inferior ao seu nunca "
   r"passa dele."),
  (7, "Julgamento", "Ativa", 2,
   r"Nomeie um alvo em voz alta. Todos os ataques aliados contra ele "
   r"somam \textbf{+2 por Proficiência}, e ele não pode ficar "
   r"\termo{Oculto} de você."),
  (8, "Segunda Abóbada", "Fixa", 0,
   r"O \termo{Véu de Luz} passa a ter seis cargas e pode ser usado como "
   r"reação por um aliado em até Longe."),
  (9, "Muralha de Um", "Tensa", 6,
   r"Enquanto ligada, nada atravessa a linha entre você e o que você "
   r"está protegendo. Nem tiro, nem máquina, nem argumento."),
  (9, "Toque de Recolher", "Ativa", 2,
   r"Encerre a cena de combate: todos os adversários de Escalão inferior "
   r"recuam, se rendem ou se escondem. Uma vez por sessão, e sempre "
   r"custa alguma coisa política."),
  (10, "A Catedral", "Ativa", 2,
   r"Uma vez por sortida: pelo resto da cena, você não pode ser movido, "
   r"não pode ser \termo{Restrito} e não sofre Avaria. Ao fim, o casco "
   r"precisa de uma doca de Estado para voltar a andar."),
 ]},

# =====================================================================
"ARCO": {
 "nome": "Estaleiros do Arco",
 "linha": "Naval · casco selado · a água é estrada",
 "lema": "Toda superfície é o teto de alguma coisa.",
 "cor": "arcoC",
 "proposta":
   "O Arco começou fazendo submarino e nunca aprendeu a fazer outra "
   "coisa. Os cascos dele são selados de fábrica: junta de borracha, "
   "solda contínua, zero fresta. Andam no fundo de rio, de canal e de "
   "fossa como quem anda em rua, e o preço disso é que são lentos em "
   "terra e não têm uma única abertura de ventilação — o calor sai por "
   "trocador, devagar, do jeito que sai num navio.",
 "cultura":
   "O Arco vende para porto, para guarda-costeira, para contrabandista e "
   "para quem trabalha em plataforma. É a única fábrica que treina o "
   "piloto a ficar parado: metade do manual é sobre esperar. Os pilotos "
   "do Arco têm fama de serem os mais difíceis de assustar do "
   "continente, e a explicação que eles dão é sempre a mesma — já "
   "estiveram em lugares mais escuros que este.",
 "estetica":
   "Casco liso e arredondado, sem frestas, cabeça em domo de vidro "
   "blindado, leme dorsal, bocais de propulsão no lugar de canos de "
   "escape. Verde-fundo e cinza-maré.",
 "pecas": [
  (1, "Casco Selado", "Fixa", 0,
   r"Água, pressão, vácuo, gás e fumaça não te afetam, em nenhuma "
   r"profundidade e por tempo nenhum."),
  (1, "Lastro", "Ativa", 1,
   r"Afunde ou suba sem gastar ação, e fique \termo{Oculto} de quem "
   r"estiver acima da linha d'água."),
  (2, "Jato de Pressão", "Ativa", 1,
   r"Um corte de água até Perto: \dado{2d10} e o alvo fica "
   r"\termo{Instável}. Fora de combate, corta chapa, abre porta e limpa "
   r"entulho."),
  (2, "Sonar", "Fixa", 0,
   r"Você sabe o que existe em cada direção até Muito Longe, mesmo sem "
   r"ver — e tudo que tiver ouvido também sabe que você está olhando."),
  (3, "Correnteza", "Ativa", 2,
   r"Puxe todos os alvos de uma faixa de alcance para outra à sua "
   r"escolha. Quem resistir rola \termo{Força} Dificuldade 15."),
  (3, "Bolsão de Ar", "Ativa", 1,
   r"Crie um bolsão no fundo. Todos ali podem abrir cabine, respirar e "
   r"fazer uma Parada Curta sem subir."),
  (4, "Agulha de Profundidade", "Fixa", 0,
   r"Suas armas não perdem alcance na água, e contra alvos submersos o "
   r"dano sobe \textbf{um degrau}."),
  (5, "Maré Vazante", "Ativa", 2,
   r"A água recua de um lugar e volta na sua próxima ação. Quem estava "
   r"lá fica \termo{Restrito} no lodo e sofre \dado{3d10} quando ela "
   r"volta."),
  (6, "Trocador de Fundo", "Tensa", 4,
   r"Enquanto ligada, você limpa \textbf{1 Estresse} no fim de cada cena "
   r"passada dentro d'água."),
  (6, "Casco Duplo", "Fixa", 0,
   r"\textbf{+2 Estrutura} e \textbf{+2 no Limiar Severo}."),
  (7, "Canto de Sonar", "Ativa", 1,
   r"Todo adversário em até Longe precisa vir na sua direção na próxima "
   r"ação dele, ou marcar 2 Estresse para resistir."),
  (8, "Rompe-Casco", "Fixa", 0,
   r"Quando você causa uma Avaria em alguém submerso, role a Avaria duas "
   r"vezes e fique com o pior resultado para ele."),
  (9, "Olho do Redemoinho", "Ativa", 2,
   r"Abra um funil de água. Tudo dentro fica \termo{Restrito} e sofre "
   r"\dado{2d10} por ação. Você anda lá dentro como se fosse chão."),
  (9, "Pressão Negativa", "Tensa", 6,
   r"Enquanto ligada, quem estiver em Muito Perto de você marca 1 "
   r"Estresse por ação. O casco deles range."),
  (10, "A Fossa", "Ativa", 2,
   r"Uma vez por sortida: leve um alvo com você para baixo. Vocês dois "
   r"saem da cena por uma cena inteira. Lá embaixo há vocês dois, a "
   r"pressão, e o que houver no fundo."),
 ]},

# =====================================================================
"GRALHA": {
 "nome": "Oficinas Gralha",
 "linha": "Modular · encaixe universal · nenhuma igual à outra",
 "lema": "Não existe uma Gralha igual a outra. Existe a sua.",
 "cor": "gralC",
 "proposta":
   "A Gralha não fabrica colosso: fabrica \\emph{encaixe}. O que sai da "
   "oficina é um esqueleto com pontos de fixação universais e um catálogo "
   "de trezentas páginas de coisas que cabem neles — inclusive coisas de "
   "outras fábricas, o que é ilegal em quatro países e praticado nos "
   "quatro. Um casco Gralha de dez anos não tem uma peça original, e a "
   "fábrica considera isso um elogio.",
 "cultura":
   "Quem pilota Gralha é quem mexe. A oficina vende direto para o "
   "piloto, sem intermediário, e mantém uma rede de galpões onde "
   "qualquer um pode alugar bancada por hora. É a fábrica dos "
   "mecânicos, dos convoios, dos independentes e de todo mundo que já "
   "foi despedido de outra fábrica. Também é a que mais mata piloto por "
   "peça mal instalada, e ninguém finge o contrário.",
 "estetica":
   "Assimetria deliberada: um ombro de gaiola tubular, outro de chapa "
   "de outra cor; membros de mangueira; adesivos de fábricas que não "
   "existem mais. A tinta nunca bate.",
 "pecas": [
  (1, "Encaixe Universal", "Fixa", 0,
   r"\textbf{+1 encaixe} no chassi. Você pode instalar Peças de qualquer "
   r"fábrica em que tenha licença, sem restrição de casco."),
  (1, "Gambiarra", "Ativa", 1,
   r"Conserte qualquer coisa por uma cena com o que estiver na mão. Em "
   r"combate, limpe \textbf{2 Estrutura} marcada."),
  (2, "Bolso Furado", "Fixa", 0,
   r"Uma vez por sessão, declare que você tinha a peça, a ferramenta ou "
   r"a carga pequena de que precisava. Você tinha."),
  (2, "Troca Quente", "Ativa", 2,
   r"Troque duas Peças instaladas por outras que você tenha no baú, "
   r"agora, no meio da cena, sem doca."),
  (3, "Ferro-Velho", "Tensa", 4,
   r"Quando um colosso cai em Perto ou mais perto, arranque uma peça: "
   r"uma arma, uma Peça instalada dele, ou 2 Estrutura para você."),
  (3, "Mão Torta", "Fixa", 0,
   r"Você pode usar qualquer arma de colosso que encontrar, sem "
   r"instalar e sem licença. Ela quebra no fim da cena."),
  (4, "Reator Remendado", "Ativa", 1,
   r"Limpe \textbf{3 Estresse}. Role \dado{1d6}: com 1, marque também "
   r"1 Estrutura. O remendo cobra."),
  (5, "Chassi Aberto", "Fixa", 0,
   r"\textbf{+2 encaixes}, \textbf{--1 Blindagem}. Não há chapa "
   r"sobrando: tudo que cabe, cabe porque alguma coisa saiu."),
  (5, "Areia no Motor", "Ativa", 1,
   r"Role \termo{Conhecimento} contra a Evasão de um alvo. Se acertar, "
   r"uma Peça instalada dele desliga até o fim da cena."),
  (6, "Peça de Outro", "Ativa", 1,
   r"Uma vez por cena, use uma Peça instalada de um colosso que você "
   r"esteja tocando — aliado ou não."),
  (7, "Oficina Ambulante", "Fixa", 0,
   r"Você faz Parada Longa de máquina em qualquer lugar, para qualquer "
   r"um, sem doca e sem material."),
  (8, "Tudo Que Tem", "Ativa", 2,
   r"Dispare ou use todas as armas e Peças Ativas instaladas de uma vez. "
   r"Depois disso, marque 3 Estresse e uma Peça à sua escolha desliga "
   r"até a próxima Parada."),
  (9, "Segundo Casco", "Fixa", 0,
   r"Você tem outro colosso guardado num galpão, montado com as Peças "
   r"que sobraram. Trocar entre os dois é uma Parada Longa."),
  (9, "Serviço Completo", "Tensa", 6,
   r"Enquanto ligada, toda Peça Ativa sua custa \textbf{1 Estresse a "
   r"menos}, até o mínimo de zero."),
  (10, "A Gralha", "Ativa", 2,
   r"Uma vez por sortida: monte, agora, na frente de todo mundo, uma "
   r"Peça que você não tem. Ela funciona por uma cena e depois vira "
   r"sucata. O Mestre escolhe qual Peça de que fábrica — e nunca é "
   r"exatamente a que você queria."),
 ]},

# =====================================================================
"SELO": {
 "nome": "Selo Civil",
 "linha": "Guarda · sensor e algema · entregar vivo",
 "lema": "Não é sobre vencer. É sobre entregar vivo e com papel assinado.",
 "cor": "seloC",
 "proposta":
   "O Selo Civil nasceu como fornecedor de guarda portuária e virou a "
   "maior fabricante de \\emph{sensor} do continente. Os cascos dele "
   "atiram pior que todos os outros e enxergam melhor que todos os "
   "outros juntos: antena de órbita, esfera de leitura, escuta passiva, "
   "holofote de apreensão, arpéu de algema. A doutrina da casa é "
   "explícita — um colosso do Selo que precisou disparar já tinha "
   "errado antes.",
 "cultura":
   "O Selo vende para polícia, para alfândega, para resgate e para "
   "empresa de segurança, e mantém uma rede de satélites de baixa "
   "órbita que aluga por assinatura. Metade dos pilotos do Selo nunca "
   "esteve numa guerra; a outra metade esteve em todas e resolveu "
   "mudar de trabalho. É a única fábrica que imprime o número de série "
   "do casco em letra grande nos dois ombros, de propósito.",
 "estetica":
   "Chapa lisa e uniforme, faixa refletiva, torre de antenas na cabeça, "
   "ombreira quadrada com número pintado grande. Branco sujo e "
   "amarelo-sinal.",
 "pecas": [
  (1, "Capacete de Órbita", "Fixa", 0,
   r"O seu capacete conversa com os satélites do Selo. Você enxerga a "
   r"cena de cima: \textbf{+2} em rolagens para perceber, localizar e "
   r"orientar, e uma vez por cena o Mestre te diz onde está uma coisa "
   r"que você está procurando."),
  (1, "Holofote de Apreensão", "Ativa", 1,
   r"Ninguém fica \termo{Oculto} onde a sua luz bate, e quem estava "
   r"Oculto fica \termo{Vulnerável} até a próxima ação dele."),
  (2, "Arpéu de Algema", "Ativa", 1,
   r"Prenda um alvo em até Longe. Ele fica \termo{Restrito} até gastar "
   r"uma ação e rolar \termo{Força} Dificuldade 15."),
  (2, "Escuta Passiva", "Fixa", 0,
   r"Você sabe quantas coisas existem em cada direção e de que tamanho "
   r"elas são, mesmo através de parede. Não sabe quem são."),
  (3, "Cassetete", "Fixa", 0,
   r"Você pode declarar qualquer ataque seu como \textbf{não letal} sem "
   r"perder dano. Um alvo derrubado assim fica \termo{Inerte} em vez "
   r"de destruído, e dá para levá-lo embora."),
  (3, "Registro", "Fixa", 0,
   r"Tudo que os seus sensores pegam fica gravado, com hora e lugar. "
   r"Uma vez por cena, o Mestre responde com a verdade a uma pergunta "
   r"sobre algo que você olhou."),
  (4, "Perímetro", "Ativa", 2,
   r"Feche um lugar. Ninguém entra nem sai sem gastar uma ação inteira "
   r"e passar por você. Dura até você sair de lá."),
  (5, "Tiro de Aviso", "Ativa", 1,
   r"Um ataque que, se fosse acertar, não causa dano: o alvo fica "
   r"\termo{Instável} e não pode atacar você até a próxima ação dele, a "
   r"não ser que o Mestre gaste 1 Medo."),
  (5, "Mandado", "Tensa", 4,
   r"Nomeie um alvo. Enquanto ligada, os seus ataques contra ele têm "
   r"vantagem e os ataques dele contra qualquer outra pessoa têm "
   r"desvantagem."),
  (6, "Triangulação", "Ativa", 1,
   r"Marque um alvo pelo satélite. Você sabe onde ele está pelo resto "
   r"da sessão, em qualquer lugar do mapa, e ele não consegue se "
   r"esconder de você numa cena."),
  (7, "Ordem Pública", "Fixa", 0,
   r"Enquanto você estiver de pé e visível, o Mestre paga \textbf{+1 "
   r"Medo} para fazer um adversário agir fora da vez dele."),
  (8, "Reboque", "Ativa", 1,
   r"Engate um colosso \termo{Inerte} ou \termo{Restrito} e arraste-o "
   r"com você, inclusive para fora da cena."),
  (9, "Olho de Órbita", "Tensa", 4,
   r"Enquanto ligada, todo aliado que você consiga falar soma "
   r"\textbf{+1} em ataques e não pode ser pego de surpresa."),
  (9, "Apreensão", "Ativa", 2,
   r"Um alvo \termo{Restrito} de Escalão igual ou inferior ao seu sai "
   r"da cena: está preso, desarmado e é problema seu agora."),
  (10, "O Selo", "Ativa", 2,
   r"Uma vez por sortida: anule uma ação de adversário que já "
   r"aconteceu. Ela não aconteceu. O Mestre ganha 2 Medo e escolhe "
   r"quem fica devendo esse favor a você."),
 ]},

# =====================================================================
"CARVAO": {
 "nome": "Carvão",
 "linha": "Mercado preto · placa trocada · o parafuso que ninguém checa",
 "lema": "Toda máquina tem um parafuso que ninguém checa. Eu checo.",
 "cor": "carvC",
 "proposta":
   "Carvão não é uma fábrica: é um nome que várias oficinas usam quando "
   "precisam assinar alguma coisa. O que sai com o selo do Carvão é "
   "sempre peça de outra fábrica com o número lixado, remontada por "
   "alguém muito bom e vendida por alguém muito pior. A qualidade varia "
   "de excepcional a homicida dentro do mesmo lote, e o catálogo circula "
   "em papel, de mão em mão, sem endereço.",
 "cultura":
   "Quem compra Carvão compra o que não devia existir: carga de fenda, "
   "placa fria, sistema de identificação falso, chave-mestra de cabine "
   "alheia. Também compra silêncio — é o único fornecedor que garante "
   "que a venda não ficou registrada em lugar nenhum. O preço nunca é "
   "dinheiro sozinho. Sempre tem um favor junto, e o favor vence.",
 "estetica":
   "Chapa faltando de propósito, capuz de lona sobre a cabine, ganchos "
   "e lâminas parafusadas por fora, tinta fosca preta por cima de "
   "qualquer cor original. Nenhum número em lugar nenhum.",
 "pecas": [
  (1, "Placa Fria", "Fixa", 0,
   r"Sensor, trava, sonar e rastreio não te pegam. Registro nenhum "
   r"sabe que este casco existe."),
  (1, "Carga de Fenda", "Ativa", 1,
   r"Plante uma carga em um alvo em Corpo a corpo. Ela estoura na sua "
   r"próxima ação: \dado{4d10}, ignorando Blindagem. Duas por sortida."),
  (2, "Chave-Mestra", "Ativa", 1,
   r"Abra qualquer coisa fechada: porta, comporta, cofre, cabine de "
   r"colosso \termo{Inerte}. Leva uma ação e faz barulho."),
  (2, "Gancho Sujo", "Fixa", 0,
   r"Seus ataques contra alvos \termo{Vulneráveis}, \termo{Restritos} "
   r"ou distraídos somam \textbf{+2 por Proficiência} ao dano."),
  (3, "Rombo", "Ativa", 1,
   r"Abra um buraco em qualquer parede, casco, piso ou comporta em "
   r"Muito Perto. Não importa do que seja feito."),
  (3, "Mercado", "Fixa", 0,
   r"Você conhece alguém em qualquer cidade. Uma vez por sessão, "
   r"consiga um item, uma informação ou uma saída — e fique devendo."),
  (4, "Fumaça de Bordo", "Ativa", 1,
   r"Encha o lugar de fumaça. Todos ficam \termo{Cegos}; você não."),
  (5, "Boca de Lobo", "Ativa", 2,
   r"Prepare uma armadilha num lugar. O primeiro adversário que entrar "
   r"nele sofre \dado{4d10} e fica \termo{Restrito}."),
  (5, "Ninguém Viu", "Tensa", 4,
   r"Enquanto ligada, você fica \termo{Oculto} de novo sempre que "
   r"termina uma ação, mesmo tendo atacado."),
  (6, "Retrato Roubado", "Ativa", 1,
   r"Copie a silhueta e a assinatura de um colosso que você já viu. "
   r"Quem não te viu fazer isso te trata como aquele colosso."),
  (7, "Serviço Completo", "Fixa", 0,
   r"Suas cargas e sabotagens causam \textbf{uma Avaria} além do dano."),
  (8, "Saída pelos Fundos", "Ativa", 2,
   r"Você e todos os aliados em Perto saem da cena agora e reaparecem "
   r"em qualquer borda dela. Ninguém consegue dizer como."),
  (9, "A Conta", "Tensa", 6,
   r"Enquanto ligada, uma vez por cena, um adversário de Escalão "
   r"inferior ao seu descobre que te deve alguma coisa e passa a agir "
   r"do seu lado até o fim da cena."),
  (9, "Sem Número", "Fixa", 0,
   r"Você não pode ser identificado, denunciado, processado nem "
   r"reconhecido por nenhum sistema. Só por gente que te viu o rosto."),
  (10, "Já Era Seu", "Ativa", 2,
   r"Uma vez por sortida: declare que uma peça, uma porta, um veículo "
   r"ou uma arma da cena era sua o tempo todo. Era. O Mestre diz quem "
   r"vai vir cobrar, e quando."),
 ]},

# =====================================================================
"OSSATURA": {
 "nome": "Ossatura",
 "linha": "Enxerto · carne de Funda · a carne lembra",
 "lema": "Puseram carne de Funda dentro do casco. A carne lembra.",
 "cor": "ossC",
 "proposta":
   "Ossatura é o nome que se deu ao programa de enxerto depois que ele "
   "deixou de ser segredo. A ideia é simples e é péssima: tecido de "
   "Funda, colhido fresco, integrado ao casco. Uma peça de Ossatura "
   "cicatriza sozinha, cresce, aprende e responde ao piloto antes de "
   "ele mandar. Funciona melhor do que qualquer coisa que as outras "
   "sete fábricas já venderam. Também cobra, e cobra do piloto.",
 "cultura":
   "Não existe uma Ossatura oficial. Existem três laboratórios de "
   "Estado que negam tudo, dois cartéis que não negam nada e uma "
   "quantidade crescente de pilotos com uma cicatriz no pescoço. "
   "Quem instala Ossatura entra numa conta que não fecha: a peça "
   "melhora, o piloto piora, e o dia em que os dois se encontram no "
   "meio tem nome próprio nas docas — chamam de \\emph{a virada}.",
 "estetica":
   "Carapaça nervurada no lugar da chapa, ombreira de calota viva com "
   "espinhos, braço-garra desproporcional, nenhum visor — olhos. "
   "Osso, âmbar e uma cor de carne que ninguém escolheu.",
 "pecas": [
  (1, "Enxerto", "Fixa", 0,
   r"\textbf{+2 Estrutura.} No fim de cada sortida, marque 1 Estresse: "
   r"o enxerto não dorme."),
  (1, "Garra Viva", "Fixa", 0,
   r"Um ataque corpo a corpo que não ocupa arma nenhuma: \dado{d10} por "
   r"Proficiência, \textbf{+3}. Em um acerto, o alvo fica "
   r"\termo{Restrito}."),
  (2, "Cicatriza", "Ativa", 1,
   r"Quando você marcaria Estrutura, marque uma a menos. O casco se "
   r"fecha sozinho, e você sente."),
  (2, "Cheiro de Sangue", "Fixa", 0,
   r"Você sempre sabe onde está a coisa mais ferida da cena, e seus "
   r"ataques contra ela têm vantagem."),
  (3, "Berro", "Ativa", 1,
   r"Todo adversário em até Perto marca 1 Estresse e fica "
   r"\termo{Instável}. Aliados que não sabiam do enxerto passam a "
   r"saber."),
  (3, "Pele Errada", "Fixa", 0,
   r"Fogo, ácido, frio, pressão e veneno não causam dano a você. Marque "
   r"1 Estresse na primeira vez que isso acontecer em cada cena."),
  (4, "Segunda Boca", "Ativa", 1,
   r"Ataque um alvo \termo{Restrito} ou \termo{Inerte}. Se acertar, "
   r"limpe \textbf{3 Estrutura} sua. Você não escolhe se quer engolir."),
  (5, "Muda", "Ativa", 2,
   r"Limpe todas as Avarias e \textbf{4 Estrutura}. Marque 2 Estresse e "
   r"fique \termo{Vulnerável} até a sua próxima ação. O casco está "
   r"molhado."),
  (6, "Braços Demais", "Fixa", 0,
   r"Você tem dois braços a mais. Eles não usam arma: usam "
   r"\termo{Garra Viva}. Enquanto estiverem abertos, marque 1 Estresse "
   r"por cena."),
  (6, "Ninhada", "Ativa", 2,
   r"Solte três crias do tamanho de um carro. Cada uma tem 3 Estrutura, "
   r"Evasão 13, ataca por \dado{2d6} e obedece até morrer."),
  (7, "Raiz", "Ativa", 1,
   r"Crave o casco no chão, na parede ou no casco de outro. Você fica "
   r"\termo{Restrito}, não pode ser movido por nada e todo dano que "
   r"sofrer cai \textbf{um degrau}. Soltar é de graça."),
  (7, "Sangue Alto", "Tensa", 4,
   r"Enquanto ligada, os seus ataques somam \textbf{+1d10} de dano. "
   r"A máquina gosta quando a coisa está feia."),
  (8, "Casulo", "Ativa", 2,
   r"Feche o casco por uma cena. Nada entra. Ao abrir, limpe todo o "
   r"Estresse e toda a Estrutura — e role na tabela de \termo{Virada}."),
  (9, "O Que Estava Dentro", "Tensa", 6,
   r"Quando o seu colosso cairia, ele não cai: ele abre. Ganhe 6 "
   r"Estrutura e \termo{Garra Viva} até o fim da cena. Marque 3 "
   r"Estresse. Quem vir isso vai lembrar."),
  (10, "Funda Menor", "Ativa", 2,
   r"Uma vez por campanha: pare de pilotar e comece a ser. Você vira um "
   r"adversário Solo de Escalão 4, jogado pelo seu jogador, por uma "
   r"cena. Depois dela, a mesa decide junto se ainda há alguém lá "
   r"dentro."),
 ]},
}

ORDEM = ["BRASA", "VESPERTINA", "CATEDRAL", "ARCO",
         "GRALHA", "SELO", "CARVAO", "OSSATURA"]

# As Peças pesadas dos Escalões altos vivem em dados/sistemas.py e são
# costuradas aqui, para que fábrica nenhuma precise saber que existem
# dois arquivos.
from .sistemas import PESADAS as _PESADAS       # noqa: E402

for _k, _ps in _PESADAS.items():
    FABRICAS[_k]["pecas"] = list(FABRICAS[_k]["pecas"]) + list(_ps)


def todas_pecas():
    saida = []
    for k in ORDEM:
        for p in FABRICAS[k]["pecas"]:
            saida.append((k,) + p)
    return saida


if __name__ == "__main__":
    from collections import Counter
    t = todas_pecas()
    print("%d peças em %d fábricas" % (len(t), len(ORDEM)))
    for k in ORDEM:
        ps = FABRICAS[k]["pecas"]
        tipos = Counter(p[2] for p in ps)
        print("  %-11s %2d peças  níveis %-28s %s"
              % (k, len(ps), str([p[0] for p in ps]), dict(tipos)))
