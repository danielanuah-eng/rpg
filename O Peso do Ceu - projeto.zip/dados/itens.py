# -*- coding: utf-8 -*-
"""
O que se carrega: armas de piloto, trajes, itens mecânicos e as coisas
que ninguém sabe explicar.

ANTIMÁQUINA é a etiqueta que importa. Uma pessoa atacando um colosso
rola com desvantagem e causa metade do dano — a não ser que a arma seja
Antimáquina, e aí o dano é cheio.
"""

# (nome, traço, alcance, dado, bônus, mãos, etiquetas, texto)
ARMAS_PILOTO = [
 ("Pistola de Cabine", "Finesse", "Perto", "d6", 1, 1, "",
  "Cabe no bolso do macacão. Ninguém revista piloto."),
 ("Revólver Pesado", "Finesse", "Perto", "d8", 1, 1, "",
  "Em um Crítico, o alvo fica \\termo{Vulnerável}."),
 ("Carabina Curta", "Agilidade", "Longe", "d8", 0, 2, "",
  "Sem desvantagem por distância até Longe."),
 ("Rifle de Ferrolho", "Finesse", "Muito Longe", "d10", 1, 2, "",
  "Se você não se mexeu, a rolagem tem vantagem. Um tiro por cena."),
 ("Rifle Antimaterial", "Finesse", "Muito Longe", "d10", 2, 2, "Antimáquina",
  "Pesa dezoito quilos. Você não corre com ele."),
 ("Escopeta Serrada", "Agilidade", "Muito Perto", "d10", 2, 2, "",
  "Acerta até dois alvos adjacentes com uma rolagem."),
 ("Metralhadora Leve", "Força", "Longe", "d6", 2, 2, "",
  "Acerta todos em uma linha. Você fica \\termo{Instável} ao disparar."),
 ("Faca de Cabine", "Finesse", "Corpo a corpo", "d8", 1, 1, "",
  "Em um Crítico, o alvo não consegue gritar nesta cena."),
 ("Bastão de Patrulha", "Força", "Corpo a corpo", "d8", 2, 1, "",
  "Você pode declarar o dano como não letal sem perder nada."),
 ("Machadinha", "Força", "Corpo a corpo", "d10", 1, 1, "",
  "Arromba porta, cadeado e escotilha sem rolagem."),
 ("Chave de Aperto", "Força", "Corpo a corpo", "d8", 0, 1, "",
  "Também é ferramenta: \\textbf{+2} em consertos improvisados."),
 ("Lança-Cabos", "Agilidade", "Longe", "d6", 0, 1, "",
  "Em um acerto, o alvo fica \\termo{Restrito}, ou você sobe até ele."),
 ("Espingarda de Sinal", "Instinto", "Longe", "d6", 0, 1, "",
  "O tiro é visto a quilômetros. Quem você quer que venha, vem."),
 ("Carga de Fenda", "Conhecimento", "Corpo a corpo", "d12", 4, 2, "Antimáquina",
  "Feita para casco, não para gente. Plantar leva uma ação inteira. "
  "Uma por sortida."),
 ("Lança de Fenda", "Força", "Corpo a corpo", "d10", 3, 2, "Antimáquina",
  "Uma haste de dois metros com uma carga na ponta. Um uso, e depois é "
  "uma haste de dois metros."),
 ("Granada de Concussão", "Agilidade", "Perto", "d8", 0, 1, "",
  "Acerta todos no lugar. Quem for atingido fica \\termo{Instável}. "
  "Duas por sortida."),
 ("Soqueira de Doca", "Força", "Corpo a corpo", "d6", 2, 1, "",
  "Você não pode ser desarmado. Dano não letal por padrão."),
 ("Punho Nu", "Força", "Corpo a corpo", "d4", 1, 0, "",
  "Sempre disponível. Dano não letal por padrão."),
]

# (nome, blindagem, LMaior, LSevero, texto)
TRAJES = [
 ("Macacão de Voo", 1, 5, 10,
  "O que todo mundo usa. Leve, quente, sem promessa nenhuma."),
 ("Colete de Estilhaço", 2, 6, 12,
  "Pesado no ombro. Desvantagem em corridas longas."),
 ("Traje de Pressão", 2, 6, 11,
  "Água, vácuo e ar podre não te atingem. Demora uma cena para vestir."),
 ("Casaco de Patrulha", 1, 6, 11,
  "Some \\textbf{+1} em \\termo{Presença} com gente uniformizada."),
 ("Placa de Doca", 3, 7, 13,
  "Improvisada com chapa de colosso. Você não corre, você anda."),
 ("Traje Selado do Arco", 2, 7, 12,
  "Feito para fundo. Você não marca Estresse por ambiente nenhum."),
 ("Nada", 0, 4, 9,
  "É uma opção. Costuma ser uma opção ruim."),
]


# ============================================ ITENS MECÂNICOS
# (nome, fábrica de origem ou "—", usos, texto)
MECANICOS = [
 ("Kit de Solda Rápida", "BRASA", "3 usos",
  "Uma ação: limpe 2 Estrutura de qualquer colosso que você alcance, de "
  "dentro ou de fora dele."),
 ("Cilindro de Argônio", "BRASA", "1 uso",
  "Uma ação: apague qualquer incêndio, ou faça uma cena inteira parar de "
  "queimar por uma cena."),
 ("Macaco de Doca", "BRASA", "—",
  "Levanta um colosso caído em uma ação, sem rolagem. Pesa o que pesa um "
  "carro pequeno."),
 ("Talha de Corrente", "BRASA", "—",
  "\\textbf{+3} em qualquer rolagem de \\termo{Força} para levantar, "
  "puxar ou segurar alguma coisa pesada."),
 ("Célula Reserva", "VESPERTINA", "2 usos",
  "Uma reação: use uma Peça Ativa sem marcar Estresse."),
 ("Lâmina de Reposição", "VESPERTINA", "—",
  "Uma arma corpo a corpo de colosso que cabe numa mochila. Serve uma "
  "cena e depois entorta."),
 ("Ampola de Calma", "VESPERTINA", "3 usos",
  "Uma ação: alguém limpa 3 Estresse. Não funciona duas vezes na mesma "
  "pessoa na mesma sessão."),
 ("Selo de Abóbada", "CATEDRAL", "1 uso",
  "Uma reação: um golpe que ia acertar você ou um aliado em Perto "
  "simplesmente não acerta."),
 ("Brasão Emprestado", "CATEDRAL", "—",
  "Enquanto você estiver com ele à mostra, tropa regular de Estado "
  "assume que você tem autoridade. Até alguém checar."),
 ("Fumígeno de Linha", "CATEDRAL", "4 usos",
  "Uma ação: um lugar fica cheio de fumaça por uma cena."),
 ("Boia de Sonar", "ARCO", "—",
  "Largue na água: pelo resto da sessão, você sabe o que passa por "
  "aquele ponto."),
 ("Ampola de Ar", "ARCO", "2 usos",
  "Dez minutos de ar respirável para uma pessoa, em qualquer lugar."),
 ("Casco de Emergência", "ARCO", "1 uso",
  "Sela um colosso furado por uma cena. Funciona debaixo d'água."),
 ("Caixa de Encaixe", "GRALHA", "—",
  "Uma ação numa Parada: troque uma Peça instalada por outra que você "
  "tenha, em qualquer lugar."),
 ("Adaptador Universal", "GRALHA", "—",
  "Você pode instalar uma Peça de uma fábrica em que \\emph{não} tem "
  "licença. Ela falha com 1 em \\dado{1d6} toda vez que for usada."),
 ("Fita de Doca", "GRALHA", "—",
  "Conserta qualquer coisa por uma cena. Uma coisa por cena. Todo mundo "
  "sabe que não devia funcionar."),
 ("Marcador Orbital", "SELO", "2 usos",
  "Uma ação: marque um alvo. Todo ataque contra ele nesta cena soma "
  "\\textbf{+2 por Proficiência}."),
 ("Algema de Casco", "SELO", "—",
  "Prende um colosso \\termo{Inerte}. Só abre com a chave, ou com uma "
  "rolagem de \\termo{Força} Dificuldade 18."),
 ("Gravador de Cabine", "SELO", "—",
  "Grava tudo que se disse e se fez dentro do casco. Já condenou mais "
  "gente do que qualquer testemunha."),
 ("Placa Falsa", "CARVAO", "—",
  "Seu colosso passa a ser outro colosso, em qualquer registro. Vale até "
  "alguém olhar com atenção."),
 ("Pó de Fenda", "CARVAO", "2 usos",
  "Corta qualquer metal com uma ação e sem barulho. Abre casco, cofre e "
  "comporta."),
 ("Chave Dupla", "CARVAO", "—",
  "Abre a cabine de qualquer colosso das fábricas comuns. Não abre "
  "Catedral, e a Catedral sabe disso."),
 ("Frasco de Enxerto", "OSSATURA", "1 uso",
  "Uma ação: limpe 5 Estrutura de um colosso. O piloto marca 2 Estresse "
  "e sonha com isso a semana inteira."),
 ("Osso de Funda", "OSSATURA", "—",
  "Uma arma corpo a corpo de colosso: \\dado{d10} por Proficiência, "
  "\\textbf{+4}. Fica mais afiada quando o piloto marca Estresse."),
 ("Reparo de Campo", "—", "3 usos",
  "Uma ação numa Parada Curta: limpe 3 Estrutura, ou desfaça uma Avaria."),
 ("Rádio de Campanha", "—", "—",
  "Fala com qualquer um na mesma cena, e com quem estiver fora dela se "
  "houver antena de pé."),
 ("Binóculo de Cota", "—", "—",
  "\\textbf{+2} em rolagens para observar de longe, e você identifica "
  "fábrica e modelo de qualquer colosso que veja."),
 ("Lanterna de Doca", "—", "—",
  "Alcança Longe e queima por dezoito horas. Também serve de sinal."),
]


# ==================================== ITENS ESTRANHOS (os "mágicos")
# (nome, raridade, texto)
ESTRANHOS = [
 ("Bússola de Funda", "Incomum",
  "A agulha aponta para a Funda mais próxima, sempre, e gira mais "
  "depressa quanto mais perto. Nunca aponta para o norte."),
 ("Vidro de Maré", "Incomum",
  "Olhando através dele, você vê o lugar como ele estava há uma hora. "
  "Uma vez por cena, isso responde a uma pergunta."),
 ("Prego do Estaleiro", "Incomum",
  "Enquanto estiver cravado num casco, aquele casco não cai — ele "
  "\\emph{atrasa}. Uma vez por sortida, adie a queda por uma cena."),
 ("Dente Que Cresce", "Incomum",
  "Uma faca que fica um pouco maior toda vez que corta alguma coisa "
  "viva. Já foi uma faca de cozinha."),
 ("Carta Sem Remetente", "Incomum",
  "Chega toda manhã, endereçada a você, com uma frase verdadeira sobre "
  "o dia que vem. Nunca a mais útil."),
 ("Rádio da Frequência Vazia", "Raro",
  "Sintonizado numa faixa em que ninguém transmite. Uma vez por sessão, "
  "alguém responde e diz uma coisa que ajuda."),
 ("Casaco do Piloto Morto", "Raro",
  "\\textbf{+1} de Evasão do piloto. Quem o vestiu antes de você "
  "aparece nos seus sonhos e é educado."),
 ("Olho Guardado", "Raro",
  "Um olho de Funda num pote. Enquanto estiver aberto no seu colete, "
  "nada \\termo{Oculto} consegue se esconder de você. Ele pisca."),
 ("Chave de Porta Nenhuma", "Raro",
  "Abre uma porta por sessão. Qualquer porta, em qualquer lugar do "
  "mundo. Do outro lado é sempre o mesmo corredor."),
 ("Medalha de Ninguém", "Raro",
  "Uma vez por sessão, alguém de farda decide que você é da casa dele. "
  "Você não escolhe quem, nem que casa."),
 ("Caderno do Engenheiro", "Raro",
  "Tem o desenho de uma Peça que não existe. Uma vez por campanha, ela "
  "passa a existir, montada por você, e o caderno perde aquela página."),
 ("Areia da Fossa", "Raro",
  "Um saquinho. Jogada no chão, aquele lugar fica escuro como fundo de "
  "mar por uma cena. Você enxerga lá dentro; mais ninguém."),
 ("Coração de Reator", "Muito raro",
  "Cabe na mão e está sempre morno. Uma vez por sortida, todas as suas "
  "Peças Ativas custam zero Estresse por uma cena."),
 ("Placa do Primeiro Casco", "Muito raro",
  "A placa de identificação do colosso número um, de nenhuma fábrica. "
  "Enquanto estiver instalada, o seu colosso não pode ser destruído por "
  "outro colosso — só por Funda, por queda ou por decisão sua."),
 ("Semente Dormindo", "Muito raro",
  "Uma coisa viva, pequena, num vidro lacrado. Quem a carrega sonha com "
  "água. Quebrando o vidro, ela cresce, e a mesa decide junto o que "
  "isso significa — uma vez."),
 ("O Manual", "Muito raro",
  "Trezentas páginas de instruções para uma máquina que ninguém "
  "reconhece. Uma vez por sessão, leia uma página: você sabe fazer uma "
  "coisa que não sabia."),
]


if __name__ == "__main__":
    print("%d armas de piloto, %d trajes" % (len(ARMAS_PILOTO), len(TRAJES)))
    print("%d itens mecânicos, %d itens estranhos"
          % (len(MECANICOS), len(ESTRANHOS)))
    print("total de itens: %d" % (len(ARMAS_PILOTO) + len(TRAJES)
                                  + len(MECANICOS) + len(ESTRANHOS)))
