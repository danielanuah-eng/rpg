# -*- coding: utf-8 -*-
"""
Os pesados: linha de guarda, assinatura de fábrica e os Nomeados.

Faltava no elenco a máquina que o Mestre joga na mesa quando quer que a
sortida vire outra coisa. São três degraus:

  LINHA PESADA   um por fábrica, Escalão 3, Brutamontes. Genérico de
                 propósito: é o casco grande que aparece de novo e de
                 novo, e a mesa aprende a temer o modelo.
  ASSINATURA     um por fábrica, Escalão 4, Comandante. Carrega a
                 tecnologia da casa levada ao limite — o campo de
                 força da Catedral, o satélite do Selo, o enxerto da
                 Ossatura.
  OS NOMEADOS    doze cascos únicos com piloto dentro. São vilões, têm
                 nome, cara e motivo, e cada um é um Solo.

O formato é o mesmo dos outros colossos, para entrar no livro, nas
cartas e no Obsidian sem nenhum tratamento especial. O dicionário
`extras` carrega o que a arte precisa (pose, asas) e o tipo de dano do
ataque principal.
"""

# (id, NOME, esc, papel, fábrica, arma_dir, arma_esq, extras,
#  alcance, nome_ataque, descrição, motivos, [(traço, tipo, texto)])

LINHA_PESADA = [
 ("elBrasaMuralha", "MURALHA", 3, "Brutamontes", "BRASA",
  "martelo", "escudo", dict(pose="guarda", tipo="Físico"),
  "Corpo a corpo", "Martelo de pátio",
  "Chapa por cima de chapa até virar parede. A Brasa vende como "
  "\\emph{defesa civil} e todo mundo sabe para que serve.",
  "Segurar a linha · não recuar · voltar inteiro",
  [("Parede", "Passiva",
    "Aliados atrás dele contam com cobertura. Enquanto estiver de pé, "
    "ninguém passa da faixa dele sem gastar uma ação."),
   ("Chapa Contra Luz", "Passiva",
    "\\termo{Blindagem de Energia 2}. Laser contra Muralha é desperdício "
    "de carga, e a Brasa imprime isso no folheto."),
   ("Fornalha", "Ação de Medo",
    "Gaste 2 Medo: todo mundo em Muito Perto sofre o dano dele em "
    "\\termo{Energia} e fica \\termo{Instável}.")]),

 ("elVespGavião", "GAVIÃO", 3, "Brutamontes", "VESPERTINA",
  "lamina_dupla", "punho", dict(pose="avanco", tipo="Físico"),
  "Muito Perto", "Par de lâminas",
  "O casco pesado da Vespertina, que na Vespertina quer dizer "
  "\\emph{alcança você duas vezes antes de você decidir*}.",
  "Chegar primeiro · terminar rápido · não ser tocado",
  [("Dois Tempos", "Passiva",
    "Ataca duas vezes por ação, com a segunda em desvantagem."),
   ("Véu de Luz", "Passiva",
    "\\termo{Blindagem de Energia 1}, e ataques de Energia de Longe "
    "contra ele têm desvantagem."),
   ("Passo", "Reação",
    "Quando virar alvo, muda uma faixa antes da rolagem. Se sair do "
    "alcance, o ataque não acontece.")]),

 ("elCatBastiao", "BASTIÃO", 3, "Brutamontes", "CATEDRAL",
  "lanca" if False else "espada", "escudo",
  dict(pose="guarda", tipo="Físico"),
  "Corpo a corpo", "Espada de ordenança",
  "Casco de ordem pública que a Catedral empresta a quem promete "
  "devolver. Ninguém devolve.",
  "Cumprir a ordem · proteger a fileira · não errar",
  [("Vitral", "Ação",
    "Levanta um campo de força de 10 pontos na faixa dele, barrando "
    "\\termo{Físico} e \\termo{Energia} nos dois sentidos."),
   ("Manto de Ferro", "Passiva",
    "\\termo{Blindagem de Energia 2}; aliados em Muito Perto ganham 1."),
   ("Parada", "Ação de Medo",
    "Gaste 2 Medo: até três alvos em Perto perdem a próxima ação.")]),

 ("elArcoQuebraMar", "QUEBRA-MAR", 3, "Brutamontes", "ARCO",
  "canhao", "escudo", dict(pose="ordena", tipo="Físico"),
  "Longe", "Bateria de casco",
  "Feito para ficar em pé onde a água bate. Fica em pé onde qualquer "
  "coisa bate.",
  "Não sair do lugar · aguentar a maré · cobrir o porto",
  [("Lastro", "Passiva",
    "Não pode ser empurrado nem derrubado. Ataques de Longe dele somam "
    "\\textbf{+2}."),
   ("Casco Sifão", "Passiva",
    "Dano de \\termo{Energia} contra ele cai 3, e ele limpa 1 Estresse "
    "cada vez que isso acontece."),
   ("Enchente", "Ação de Medo",
    "Gaste 2 Medo: a faixa dele e a vizinha alagam. Todos lá ficam "
    "\\termo{Instáveis} e perdem 1 Deslocamento.")]),

 ("elGralCarcara", "CARCARÁ", 3, "Brutamontes", "GRALHA",
  "serra", "garra", dict(pose="espreita", tipo="Físico"),
  "Corpo a corpo", "Serra de desmanche",
  "Montado com peça de seis fábricas e nenhuma licença. Anda torto e "
  "corta reto.",
  "Recolher · desmontar · crescer",
  [("Ninhada", "Ação",
    "Solta três drones de sucata: cada um ataca com \\textbf{+4} e "
    "causa \\dado{1d10} \\termo{Físico} por Proficiência."),
   ("Gaiola", "Passiva",
    "\\termo{Blindagem de Energia 2}, que cai 1 cada vez que ele sofre "
    "dano \\termo{Físico}."),
   ("Cata Peça", "Reação",
    "Quando um colosso cai em Perto, ele ganha \\textbf{+3 Estrutura} e "
    "uma arma daquele colosso.")]),

 ("elSeloAduana", "ADUANA", 3, "Brutamontes", "SELO",
  "fuzil", "drone", dict(pose="tiro", tipo="Físico"),
  "Longe", "Fuzil de cerco",
  "O casco de bloqueio do Selo. Não persegue: fecha, e espera você "
  "cansar.",
  "Fechar o cerco · registrar tudo · entregar vivo",
  [("Malha", "Ação",
    "Dois drones de visão sobem: ninguém fica \\termo{Oculto} na faixa "
    "dele nem na vizinha, e aliados que atacarem o alvo marcado somam "
    "\\textbf{+2}."),
   ("Cerco", "Ação de Medo",
    "Gaste 2 Medo: quatro minas de choque em duas faixas. Quem pisa "
    "sofre \\dado{2d10} \\termo{Energia} por Proficiência e fica "
    "\\termo{Restrito}."),
   ("Registro", "Passiva",
    "Quem ele marcou não sai da cena sem que a mesa saiba onde foi.")]),

 ("elCarvBrecha", "BRECHA", 3, "Brutamontes", "CARVAO",
  "garra", "arpeu", dict(pose="espreita", tipo="Físico"),
  "Muito Perto", "Garra de fenda",
  "Grande para o padrão do Carvão, que é dizer que finalmente dá para "
  "ver de longe. Ninguém vê.",
  "Entrar · levar · não ter estado ali",
  [("Manta Fria", "Passiva",
    "\\termo{Blindagem de Energia 1}, e não aparece em sensor, drone ou "
    "satélite: achar exige olho e uma ação."),
   ("Corta-Linha", "Ação",
    "Desliga uma Peça de um alvo em Muito Perto até a próxima Parada "
    "Longa, e derruba todo campo de força dele."),
   ("Mina Fantasma", "Ação de Medo",
    "Gaste 1 Medo: duas minas invisíveis. \\dado{3d10} \\termo{Físico} "
    "por Proficiência e o alvo fica \\termo{Vulnerável}.")]),

 ("elOssMatriz", "MATRIZ", 3, "Brutamontes", "OSSATURA",
  "garra", "garra", dict(pose="avanco", tipo="Físico"),
  "Corpo a corpo", "Braço de enxerto",
  "Cresceu mais do que o projeto previa. O projeto previa pouco.",
  "Comer · dividir · continuar",
  [("Enxerto Vivo", "Passiva",
    "Dano de \\termo{Energia} cai 4, e ele recupera 1 Estrutura cada "
    "vez que isso acontece."),
   ("Cria de Bolso", "Ação",
    "Solta dois filhotes: \\textbf{+5} de ataque, \\dado{1d10} "
    "\\termo{Físico} por Proficiência, e ganham +1 de dano a cada "
    "acerto."),
   ("Fecha", "Passiva",
    "Toda vez que um aliado dele cai, ele limpa 3 Estrutura.")]),
]


ASSINATURA = [
 ("asBrasaAltoForno", "ALTO-FORNO", 4, "Comandante", "BRASA",
  "martelo", "canhao", dict(pose="ordena", tipo="Energia",
                            mochila="turbina"),
  "Perto", "Jato de fornalha",
  "A Brasa abriu o casco e deixou a fundição à mostra. Anda devagar e "
  "chega igual.",
  "Queimar o que atrapalha · abrir caminho · não parar",
  [("Fornalha Aberta", "Ação",
    "Todo mundo em Muito Perto sofre \\dado{3d10} \\termo{Energia} por "
    "Proficiência e fica \\termo{Instável}."),
   ("Semeadora", "Ação de Medo",
    "Gaste 2 Medo: três minas em uma faixa até Perto. \\dado{2d10} "
    "\\termo{Físico} por Proficiência e \\termo{Instável}."),
   ("A Última Brasa", "Passiva",
    "Com 6 ou mais de Medo na mesa, ao chegar a zero de Estrutura ele "
    "fica de pé com 1 até o fim da cena, e some \\dado{+2d10} em todo "
    "ataque.")]),

 ("asVespAurora", "PRIMEIRA LUZ", 4, "Comandante", "VESPERTINA",
  "espada", "lamina_dupla", dict(pose="voo", tipo="Energia", asas=True),
  "Muito Perto", "Lâmina em ressonância",
  "O casco que a Vespertina mostra em feira e não vende. Voa alto, e "
  "de cima decide.",
  "Provar que é possível · chegar antes · não descer",
  [("Asa de Fim de Tarde", "Passiva",
    "Voa: ignora terreno, atravessa duas faixas sem ação, e corpo a "
    "corpo contra ele tem desvantagem. Em troca, Longe contra ele tem "
    "vantagem."),
   ("Ressonância", "Passiva",
    "O ataque dele é \\termo{Energia} e ignora \\termo{Blindagem} "
    "comum."),
   ("Mergulho", "Ação de Medo",
    "Gaste 2 Medo: desce de qualquer faixa até um alvo e ataca com "
    "\\dado{+3d10}. O alvo fica \\termo{Vulnerável}.")]),

 ("asCatConcilio", "CONCÍLIO", 4, "Comandante", "CATEDRAL",
  "espada", "escudo", dict(pose="guarda", tipo="Energia",
                           mochila="capa"),
  "Longe", "Lança de campanário",
  "Não é um casco de guerra: é um casco de sentença. Quando aparece, "
  "a decisão já foi tomada em outro lugar.",
  "Executar a ordem · manter a forma · não explicar",
  [("Abóbada", "Passiva",
    "Com 4 ou mais de Medo, todo ataque vindo de fora da faixa dele "
    "muda de alvo para ele."),
   ("Lança de Campanário", "Ação",
    "Uma vez por cena: linha reta até Muito Longe, \\dado{5d10} "
    "\\termo{Energia} por Proficiência, ignorando cobertura e campo de "
    "força."),
   ("Ordem de Parada", "Ação de Medo",
    "Gaste 2 Medo: até três alvos em Perto perdem a próxima ação.")]),

 ("asArcoFossaViva", "FOSSA VIVA", 4, "Comandante", "ARCO",
  "canhao", "arpeu", dict(pose="ordena", tipo="Físico",
                          mochila="discos"),
  "Muito Longe", "Bateria de fundo",
  "Passa mais tempo embaixo do que em cima. Quando sobe, já escolheu "
  "onde.",
  "Chegar por baixo · cercar · não ser visto subindo",
  [("Fossa", "Passiva",
    "Com 4 ou mais de Medo, some da cena e reaparece em qualquer faixa "
    "uma vez por rodada, sem gastar ação."),
   ("Casco Sifão", "Passiva",
    "\\termo{Energia} contra ele cai 3 e ele limpa 1 Estresse."),
   ("Maré", "Ação de Medo",
    "Gaste 3 Medo: duas faixas alagam e todo mundo lá fica "
    "\\termo{Restrito} até gastar uma ação.")]),

 ("asGralOficinaGrande", "OFICINA GRANDE", 4, "Comandante", "GRALHA",
  "serra", "drone", dict(pose="ordena", tipo="Físico",
                         mochila="antena"),
  "Perto", "Braço de desmanche",
  "Uma doca que aprendeu a andar. Constrói no meio da briga, e é por "
  "isso que a briga não acaba.",
  "Montar · remendar · nunca jogar fora",
  [("Ninhada Contínua", "Passiva",
    "No começo de cada rodada, um drone novo. Cada um: \\textbf{+4}, "
    "\\dado{1d10} \\termo{Físico} por Proficiência."),
   ("Frankenstein", "Passiva",
    "Com 4 ou mais de Medo, cada colosso que cai na cena dá a ele "
    "\\textbf{+2 Estrutura} e uma arma."),
   ("Campo Remendado", "Ação",
    "Campo de força de 6 pontos nele e num aliado. Cada absorção, "
    "role \\dado{1d6}: com 1, cai.")]),

 ("asSeloOrbita", "APOGEU", 4, "Comandante", "SELO",
  "fuzil", "drone", dict(pose="tiro", tipo="Energia",
                         mochila="canhoes"),
  "Muito Longe", "Chamada de órbita",
  "O casco que fala com o céu. Não precisa ganhar a briga: precisa "
  "durar até a contagem fechar.",
  "Marcar · esperar · encerrar",
  [("Chamada de Órbita", "Ação",
    "Marca um alvo em qualquer faixa e abre uma \\termo{Contagem de 3}. "
    "Ao fechar: \\dado{6d10} \\termo{Energia} por Proficiência no alvo, "
    "metade na faixa."),
   ("Cúpula", "Ação de Medo",
    "Gaste 2 Medo: campo de força de 15 pontos na faixa dele, de fora "
    "para dentro."),
   ("Olho de Cima", "Passiva",
    "Com 6 ou mais de Medo, uma vez por rodada anula um ataque contra "
    "ele ou um aliado em qualquer faixa.")]),

 ("asCarvMercado", "MERCADO", 4, "Comandante", "CARVAO",
  "lamina_dupla", "arpeu", dict(pose="espreita", tipo="Físico"),
  "Muito Perto", "Par de fendas",
  "Ninguém sabe de quem é. Já foi de quatro exércitos e ainda tem a "
  "tinta dos quatro por baixo.",
  "Cobrar · não dever · sumir com o troco",
  [("Frequência Vazia", "Passiva",
    "Com 4 ou mais de Medo, toda arma de \\termo{Energia} na cena falha "
    "com 1--2 em \\dado{1d6}. Inclusive as dele."),
   ("Sombra Longa", "Ação",
    "Fica \\termo{Oculto} mesmo à vista. Sair do Oculto para atacar dá "
    "\\dado{+3d10}."),
   ("Corta-Linha", "Ação de Medo",
    "Gaste 2 Medo: desliga uma Peça de um alvo e derruba o campo de "
    "força dele.")]),

 ("asOssAnel", "O ANEL", 4, "Comandante", "OSSATURA",
  "garra", "garra", dict(pose="avanco", tipo="Energia",
                         mochila="espinhos"),
  "Perto", "Anel de dentes",
  "Não foi construído. Foi encontrado, e alguém decidiu pilotar.",
  "Continuar · não ser entendido · voltar para a água",
  [("Campo de Carne", "Passiva",
    "Com 4 ou mais de Medo, campo de força orgânico de 8 pontos que "
    "recompõe 3 por rodada, contra os dois tipos."),
   ("A Virada", "Ação",
    "Uma vez por sortida: uma \\termo{Funda} ou um colosso de Ossatura "
    "na cena passa a lutar do lado dele."),
   ("Enxerto Vivo", "Passiva",
    "\\termo{Energia} contra ele cai 4 e devolve 1 Estrutura.")]),
]


NOMEADOS = [
 ("noVespEstiletePreto", "ESTILETE PRETO", 4, "Solo", "VESPERTINA",
  "espada", "lamina_dupla", dict(pose="voo", tipo="Energia", asas=True),
  "Muito Perto", "Três cortes",
  "Pilotado por \\textbf{Ivo Rennó}, que foi instrutor da Vespertina "
  "até a casa descobrir o que ele ensinava. Voa mais baixo do que "
  "deveria, de propósito.",
  "Provar que a casa errou · não ser alcançado · terminar em três",
  [("Três Cortes", "Passiva",
    "Ataca três vezes por ação, a segunda em desvantagem e a terceira "
    "só se a segunda acertar."),
   ("Asa Baixa", "Passiva",
    "Voa. Corpo a corpo contra ele tem desvantagem; Longe contra ele "
    "\\emph{não} tem vantagem, porque ele voa rente."),
   ("Sem Testemunha", "Ação de Medo",
    "Gaste 2 Medo: sai do alcance de todo mundo e reaparece em Muito "
    "Perto de quem ele escolher, com \\dado{+3d10}.")]),

 ("noCatLegadoPreto", "TRIBUNAL", 4, "Solo", "CATEDRAL",
  "espada", "escudo", dict(pose="guarda", tipo="Energia",
                           mochila="capa"),
  "Perto", "Sentença",
  "Pilotado pela \\textbf{Juíza Abelardo}, que herdou o casco do pai e "
  "a certeza da mãe. Nunca ataca primeiro, e nunca perde a segunda "
  "troca.",
  "Ter razão · não abrir exceção · devolver o casco inteiro",
  [("Abóbada", "Passiva",
    "Com 4 ou mais de Medo, todo ataque de fora da faixa dela muda de "
    "alvo para ela."),
   ("Sentença", "Reação",
    "Quando alguém erra um ataque contra ela, ela ataca de volta sem "
    "gastar ação, com \\dado{+2d10}."),
   ("Campanário", "Ação",
    "Uma vez por cena: linha reta até Muito Longe, \\dado{5d10} "
    "\\termo{Energia} por Proficiência, ignorando cobertura e campo.")]),

 ("noBrasaCapatazVelho", "CAPATAZ VELHO", 4, "Solo", "BRASA",
  "martelo", "escudo", dict(pose="avanco", tipo="Físico"),
  "Corpo a corpo", "Malho de doca",
  "Pilotado por \\textbf{Dona Isaura}, sessenta e um anos, trinta deles "
  "na fundição. Não aprendeu a pilotar: aprendeu a bater.",
  "Não entregar a doca · proteger os meninos · morrer depois",
  [("Não Cai", "Passiva",
    "Quando chegaria a zero de Estrutura, fica com 1 e continua. Uma "
    "vez por cena, e o Mestre avisa a mesa que foi usado."),
   ("Malho", "Passiva",
    "Todo acerto dela empurra o alvo uma faixa e o deixa "
    "\\termo{Instável}."),
   ("Grito de Pátio", "Ação de Medo",
    "Gaste 2 Medo: todo aliado dela na cena limpa 2 Estrutura e ataca "
    "agora, fora da vez.")]),

 ("noSeloXerifeDoCeu", "XERIFE DO CÉU", 4, "Solo", "SELO",
  "fuzil", "drone", dict(pose="tiro", tipo="Energia",
                         mochila="canhoes", asas=True),
  "Muito Longe", "Tiro marcado",
  "Pilotado pelo \\textbf{Delegado Anastácio}, que assina cada disparo "
  "com o próprio nome e arquiva. Tem a papelada em dia de tudo que "
  "matou.",
  "Cumprir o mandado · registrar · levar de volta",
  [("Mandado", "Passiva",
    "Escolhe um alvo no começo da cena. Contra aquele alvo, ele nunca "
    "erra com Esperança: erro com Esperança vira acerto pela metade."),
   ("Olho de Cima", "Passiva",
    "Com 6 ou mais de Medo, uma vez por rodada anula um ataque contra "
    "ele ou um aliado em qualquer faixa."),
   ("Encerramento", "Ação de Medo",
    "Gaste 3 Medo: \\dado{6d10} \\termo{Energia} por Proficiência no "
    "alvo do Mandado, onde quer que ele esteja.")]),

 ("noGralMestraDeObras", "MESTRA DE OBRAS", 4, "Solo", "GRALHA",
  "serra", "drone", dict(pose="ordena", tipo="Físico",
                         mochila="antena"),
  "Perto", "Braço de guindaste",
  "Pilotado por \\textbf{Nair Quebra-Galho}, que montou o próprio casco "
  "com peça roubada de sete fábricas e cobra caro para montar o seu.",
  "Terminar a obra · cobrar depois · não explicar o desenho",
  [("Frankenstein", "Passiva",
    "Com 4 ou mais de Medo, cada colosso que cai na cena dá a ela "
    "\\textbf{+2 Estrutura} e uma arma."),
   ("Ninhada Contínua", "Passiva",
    "Um drone novo por rodada: \\textbf{+4}, \\dado{1d10} "
    "\\termo{Físico} por Proficiência."),
   ("Reforma", "Ação",
    "Troca uma Peça dela por outra agora, no meio da cena, sem doca e "
    "sem Parada.")]),

 ("noCarvSemRemetente", "SEM REMETENTE", 4, "Solo", "CARVAO",
  "lamina_dupla", "arpeu", dict(pose="espreita", tipo="Físico"),
  "Muito Perto", "Duas fendas",
  "Ninguém sabe quem pilota. A voz no rádio é sempre outra, e sempre "
  "sabe o seu nome.",
  "Cobrar a dívida antiga · não ser identificado · sumir",
  [("Não Está Aqui", "Passiva",
    "Não aparece em sensor, drone, satélite nem campo. Para virar alvo, "
    "alguém precisa gastar uma ação olhando."),
   ("Frequência Vazia", "Passiva",
    "Com 4 ou mais de Medo, toda arma de \\termo{Energia} na cena falha "
    "com 1--2 em \\dado{1d6}."),
   ("Conta Antiga", "Ação de Medo",
    "Gaste 2 Medo: escolhe um piloto e diz em voz alta uma coisa "
    "verdadeira que ele escondia. O jogador confirma ou marca 3 "
    "Estresse.")]),

 ("noOssPrimeiraCria", "PRIMEIRA CRIA", 4, "Solo", "OSSATURA",
  "garra", "garra", dict(pose="avanco", tipo="Físico",
                         mochila="espinhos"),
  "Corpo a corpo", "Boca de casco",
  "Pilotado por \\textbf{ninguém}. A cabine está lá, e está vazia, e o "
  "casco obedece a alguma coisa.",
  "Voltar para a água · levar junto · lembrar",
  [("Sem Piloto", "Passiva",
    "Não pode ser convencido, ameaçado nem subornado. Abrir a cabine "
    "não faz nada."),
   ("Campo de Carne", "Passiva",
    "Com 4 ou mais de Medo, campo de força de 8 pontos que recompõe 3 "
    "por rodada, contra os dois tipos."),
   ("Reconhece", "Ação de Medo",
    "Gaste 2 Medo: escolhe um piloto. Até o fim da cena, só ataca "
    "aquele, e soma \\dado{+2d10} contra ele.")]),

 ("noArcoTimoneiro", "TIMONEIRO", 4, "Solo", "ARCO",
  "canhao", "escudo", dict(pose="ordena", tipo="Físico",
                           mochila="discos"),
  "Muito Longe", "Salva de fundo",
  "Pilotado pelo \\textbf{Comodoro Bulhões}, que perdeu uma frota "
  "inteira num dia e desde então não deixa nada subir à superfície sem "
  "ordem dele.",
  "Não repetir aquele dia · manter a formação · afundar o resto",
  [("Fossa", "Passiva",
    "Com 4 ou mais de Medo, some e reaparece em qualquer faixa uma vez "
    "por rodada, sem ação."),
   ("Formação", "Passiva",
    "Todo aliado dele na cena soma \\textbf{+2} em ataques de Longe ou "
    "mais."),
   ("Salva", "Ação de Medo",
    "Gaste 3 Medo: escolhe duas faixas. Tudo nelas sofre o dano dele "
    "em \\termo{Físico}.")]),

 ("noVespMenina", "A MENINA DA FEIRA", 3, "Solo", "VESPERTINA",
  "espada", "punho", dict(pose="parado", tipo="Energia"),
  "Muito Perto", "Florete",
  "Pilotado por \\textbf{Ciça}, catorze anos, campeã de simulador em "
  "três feiras seguidas. A Vespertina achou graça e deu o casco. Ela "
  "não achou graça nenhuma.",
  "Ganhar de verdade · ser levada a sério · voltar para casa",
  [("Simulador", "Passiva",
    "Uma vez por cena, ela repete uma rolagem sua e fica com o melhor "
    "resultado. Ela treinou exatamente essa cena."),
   ("Não Machuca", "Passiva",
    "Quando derruba um colosso, o piloto sai vivo e ileso. Ela faz "
    "questão, e isso já custou caro a ela."),
   ("Desarme", "Ação",
    "Em vez de dano: o alvo perde a arma da mão até gastar uma ação "
    "pegando de volta.")]),

 ("noBrasaFilho", "O FILHO", 3, "Solo", "BRASA",
  "martelo", "punho", dict(pose="guarda", tipo="Físico"),
  "Corpo a corpo", "Malho herdado",
  "Pilotado por \\textbf{Zé da Brasa}, que herdou a fundição, o casco "
  "e a dívida. Só quer entregar o pedido e ir dormir.",
  "Pagar a dívida · não perder a doca · dormir uma noite",
  [("Aguenta", "Passiva",
    "Reduz em 3 todo dano \\termo{Físico}. Ele já apanhou desse jeito a "
    "vida inteira."),
   ("Só Quero Ir Embora", "Passiva",
    "Se alguém oferecer a ele uma saída que pague a dívida, ele "
    "aceita. Vale como cena, não como rolagem."),
   ("Última Batida", "Ação de Medo",
    "Gaste 2 Medo: um ataque com \\dado{+4d10}. Depois disso ele fica "
    "\\termo{Vulnerável} até o fim da cena.")]),

 ("noCatCavaleiro", "O CAVALEIRO DE FORA", 3, "Solo", "CATEDRAL",
  "espada", "escudo", dict(pose="parado", tipo="Físico"),
  "Perto", "Espada de foro",
  "Pilotado por \\textbf{Sr. Veiga}, que não é da Catedral, não tem "
  "licença e pilota melhor do que qualquer um que tem.",
  "Ser reconhecido · não pedir licença · ganhar limpo",
  [("Sem Licença", "Passiva",
    "Usa Peças de qualquer fábrica. Cada vez que usa uma, role "
    "\\dado{1d6}: com 1, ela trava até a próxima Parada."),
   ("Foro", "Passiva",
    "Contra um único alvo por cena, os ataques dele nunca sofrem "
    "desvantagem."),
   ("Convite", "Ação",
    "Desafia um piloto para uma troca só. Se o jogador aceitar, os dois "
    "atacam simultaneamente e ninguém mais pode interferir.")]),

 ("noSeloAgenteVazio", "AGENTE VAZIO", 3, "Solo", "SELO",
  "fuzil", "arpeu", dict(pose="tiro", tipo="Energia"),
  "Longe", "Tiro de protocolo",
  "Pilotado por \\textbf{alguém do Selo}. O crachá está em branco de "
  "propósito, e a papelada diz que esta sortida não aconteceu.",
  "Cumprir sem registro · não deixar testemunha · sumir do arquivo",
  [("Sem Registro", "Passiva",
    "Nada que ele faz gera Contagem, prova ou consequência oficial. O "
    "Mestre nunca gasta Medo para ele aparecer: ele já estava lá."),
   ("Protocolo", "Passiva",
    "O primeiro ataque dele em cada cena acerta sem rolagem."),
   ("Apagar", "Ação de Medo",
    "Gaste 2 Medo: um drone, uma boia, uma mina ou um campo de força na "
    "cena deixa de existir, e ninguém lembra que existiu.")]),
]

ELITE = LINHA_PESADA + ASSINATURA + NOMEADOS
