# -*- coding: utf-8 -*-
"""
O que transforma um Nomeado em chefe de verdade.

Um Solo com números altos não é chefe: é uma parede que demora. Chefe é
o que **muda a briga no meio dela**. Duas coisas dão isso:

  O DOM     a marca da casa levada ao limite — invisibilidade, satélite,
            muralha, enxame. É o que o grupo aprende a contornar. Cada
            fábrica tem o seu, e todo chefe daquela casa o carrega.

  A VIRADA  a segunda fase. Quando a Estrutura cai pela metade, a
            máquina deixa de fazer o que vinha fazendo e passa a fazer
            outra coisa. Não é mais dano: é outro problema.

A virada é de graça e acontece na hora, no meio do turno se for
preciso. O Mestre narra e a mesa sente. Os doze Nomeados têm virada; os
oito de Assinatura têm só o dom, porque são linha de fábrica e não
personagem.
"""

# ==================================================================== DOM
# (id, nome, uma linha, o que faz na mesa)
DOM = {
 "muralha": ("Muralha", "BRASA",
   "Chapa por cima de chapa, e o pátio inteiro atrás dela.",
   "\\termo{Blindagem 2} extra e aliados na mesma faixa contam com "
   "cobertura. Enquanto estiver de pé, passar pela faixa dele custa uma "
   "ação a mais."),
 "passo": ("Passo", "VESPERTINA",
   "Chega antes de você decidir, e sai antes de você responder.",
   "Uma vez por rodada, de graça: muda uma faixa. Se isso o tirar do "
   "alcance de um ataque já anunciado, o ataque não acontece."),
 "campo": ("Campo", "CATEDRAL",
   "A luz para antes de encostar.",
   "Campo de força com pontos iguais ao Escalão × 3. Enquanto tiver "
   "ponto, todo dano — \\termo{Físico} ou \\termo{Energia} — tira do "
   "campo primeiro. Volta a 1 ponto no começo de cada rodada."),
 "rede": ("Rede", "ARCO",
   "Ele não procura você. Ele já sabe onde você está.",
   "Todo alvo que ele atacar fica \\termo{Marcado} até o fim da cena. "
   "Contra alvo Marcado, ele e os aliados dele rolam com vantagem, e "
   "não existe cobertura."),
 "enxame": ("Enxame", "GRALHA",
   "Sempre tem mais. A oficina não fecha.",
   "No começo de cada rodada, de graça: dois Lacaios de sucata entram "
   "na faixa dele. Se ele cair, eles caem junto."),
 "orbita": ("Órbita", "SELO",
   "O problema não está na sua frente. Está em cima.",
   "Uma vez por cena, gaste 1 Medo para marcar uma faixa. No fim da "
   "rodada seguinte, todo mundo ainda naquela faixa sofre "
   "\\dado{4d10} de \\termo{Energia}. Todo mundo vê a marca no chão."),
 "sumico": ("Sumiço", "CARVAO",
   "Some no meio da frase.",
   "Fora de turno, ele não pode ser alvo: ataques contra ele erram "
   "automaticamente. Ele reaparece ao atacar e fica visível até o fim "
   "do turno seguinte. Quem acertá-lo enquanto visível o mantém "
   "visível por mais uma rodada."),
 "enxerto": ("Enxerto", "OSSATURA",
   "O que cai perto dele não fica caído.",
   "Quando qualquer máquina cair na faixa dele — inimiga ou não —, ele "
   "limpa 3 de Estrutura e ganha um traço da máquina caída até o fim "
   "da cena."),
}

# qual casa carrega qual dom
DOM_DA_CASA = {
 "BRASA": "muralha", "VESPERTINA": "passo", "CATEDRAL": "campo",
 "ARCO": "rede", "GRALHA": "enxame", "SELO": "orbita",
 "CARVAO": "sumico", "OSSATURA": "enxerto",
}


# ================================================================= VIRADA
# id do Nomeado -> (nome da fase, o que o Mestre diz, o que muda)
VIRADA = {
 "noVespEstiletePreto": ("SEM CHÃO",
   "Ele larga a carenagem da asa no meio do pátio e sobe. Pela primeira "
   "vez ele voa na altura certa.",
   "Perde toda a Blindagem. Ganha um quarto corte e passa a atacar de "
   "\\termo{Longe} sem penalidade. Corpo a corpo contra ele deixa de "
   "ser possível: quem quiser alcançá-lo precisa derrubá-lo primeiro."),

 "noCatLegadoPreto": ("SENTENÇA PROFERIDA",
   "O campo vira para dentro. Ele para de defender a si e passa a "
   "cercar uma pessoa só.",
   "No começo de cada rodada ele nomeia um piloto. Contra o nomeado, "
   "rola com vantagem e ignora Blindagem. Contra todo o resto, é imune "
   "a \\termo{Físico}. O nomeado muda toda rodada; não pode repetir "
   "enquanto houver outro de pé."),

 "noBrasaCapatazVelho": ("TURNO DOBRADO",
   "A fornalha abre e ele não fecha mais. O velho trabalha dobrado "
   "porque é o que ele sabe fazer.",
   "Para de se mover — de vez. No fim de cada rodada, todo mundo em "
   "\\termo{Perto} ou menos sofre \\dado{3d10} de \\termo{Energia}. "
   "Em troca ganha \\termo{Blindagem 4} e ataca duas vezes por ação."),

 "noSeloXerifeDoCeu": ("MANDADO",
   "Ele levanta o punho e o céu responde antes dele terminar o gesto.",
   "Todo mundo fica \\termo{Marcado}, e fica. No fim de cada rodada, "
   "uma faixa escolhida por ele leva \\dado{4d10} de \\termo{Energia}. "
   "Ele não ataca mais com a arma: só aponta."),

 "noGralMestraDeObras": ("CANTEIRO",
   "Ela crava o braço no chão e começa a construir no meio da briga, "
   "como se a briga fosse o andaime.",
   "No começo de cada rodada ela levanta uma parede: uma faixa à "
   "escolha dela passa a dar cobertura total a quem estiver atrás. "
   "Entram três Lacaios de sucata por rodada em vez de dois, e ela "
   "limpa 2 de Estrutura por parede levantada."),

 "noCarvSemRemetente": ("ENDEREÇO ERRADO",
   "Ele some. Não recua, não corre: some — e o silêncio dura tempo "
   "demais para ser acidente.",
   "Deixa de poder ser alvo até atacar, e o Sumiço dele não expira mais "
   "sozinho. Quando reaparece, reaparece em \\termo{Muito Perto} de "
   "quem tiver menos Estrutura, com \\dado{+3d10}. Só fica visível na "
   "rodada em que atacar."),

 "noOssPrimeiraCria": ("SEGUNDA BOCA",
   "A carcaça abre onde não havia abertura. O que estava dentro dela "
   "estava vivo o tempo todo.",
   "Ganha um segundo ataque de \\termo{Corpo a corpo} que não usa ação. "
   "Cada vez que ela derruba alguém — ou come uma máquina caída —, "
   "limpa 6 de Estrutura em vez de 3 e ganha \\termo{Blindagem 1} "
   "cumulativa."),

 "noArcoTimoneiro": ("ÁGUA POR CIMA",
   "Ele vira o casco e a doca vira porto. A água sobe sem pedir "
   "licença a ninguém.",
   "O campo inteiro passa a ser água. Mudar de faixa exige uma rolagem "
   "de Ágil; quem falhar fica \\termo{Preso}. Ele ataca de baixo, sem "
   "linha de visão, e ninguém tem cobertura contra isso."),

 "noVespMenina": ("A FEIRA INTEIRA",
   "A feira não corre. A feira fecha em volta dela, e você percebe de "
   "quem é aquela praça.",
   "Ganha cobertura em qualquer faixa e não pode ser alvo de "
   "\\termo{Longe} ou mais. Toda vez que um ataque contra ela errar, o "
   "Mestre ganha 1 Medo. Ela ataca duas vezes por ação enquanto "
   "estiver em \\termo{Muito Perto}."),

 "noBrasaFilho": ("O NOME DO PAI",
   "Ele para de lutar como quem aprendeu e passa a lutar como quem "
   "viu. É pior.",
   "Dobra o dano e perde 3 de Evasão. Não usa mais reação nenhuma e "
   "não recua: se puder alcançar alguém, alcança. Quando cair, o malho "
   "fica de pé no chão — e é um item."),

 "noCatCavaleiro": ("FORO ÍNTIMO",
   "Ele tira a peitoral e joga fora. Diz o nome dele inteiro, que "
   "ninguém tinha ouvido até agora.",
   "Perde toda a Blindagem e o Campo. Ganha \\dado{+3d10} no ataque e "
   "acerta automaticamente contra quem já o tenha atingido nesta cena. "
   "É um duelo agora, e ele vai levar até o fim."),

 "noSeloAgenteVazio": ("PROTOCOLO FINAL",
   "O casco abre em sete partes e nenhuma delas tem piloto dentro. "
   "Nunca teve.",
   "Deixa de ser um alvo e vira sete: cada parte tem 4 de Estrutura e "
   "ataca de \\termo{Longe} com \\dado{2d10}. Enquanto sobrar uma "
   "parte, as outras voltam no começo da rodada. Derrubar as sete na "
   "mesma rodada é a única forma de acabar."),
}


# ============================================================== AJUDANTES
# O chefe não entra sozinho. Isto é o que o gerador põe do lado dele.
ESCOLTA = {
 "muralha": ("Linha de pátio",
   "Dois Regulares da casa à frente dele e um Apoio atrás. Eles não "
   "atacam: seguram faixa."),
 "passo": ("Par de lâminas",
   "Dois Perseguidores da casa, que entram na rodada seguinte à dele."),
 "campo": ("Corte",
   "Um Comandante da casa e dois Apoios. O Comandante fala; os Apoios "
   "mantêm o campo de pé."),
 "rede": ("Olho",
   "Um Atirador de Longe e dois drones de visão. Os drones não "
   "atacam: marcam."),
 "enxame": ("Turma",
   "Quatro Lacaios de sucata e um Mecânico, que levanta um Lacaio "
   "caído por rodada."),
 "orbita": ("Pauta",
   "Dois Atiradores do Selo, em faixas diferentes, que não se movem."),
 "sumico": ("Ninguém",
   "Nenhum. O chefe entra sozinho — e é por isso que assusta."),
 "enxerto": ("Ninhada",
   "Três Fundas pequenas do mesmo plano, que a máquina come se "
   "precisar."),
}


def dom_de(fabrica):
    """O dom da casa, ou None para quem não é colosso de fábrica."""
    return DOM_DA_CASA.get(fabrica)


def ficha_de_chefe(ident, fabrica):
    """O que o gerador precisa saber para tratar alguém como chefe."""
    d = dom_de(fabrica)
    return {
        "dom": d,
        "dom_nome": DOM[d][0] if d else None,
        "dom_texto": DOM[d][3] if d else None,
        "escolta": ESCOLTA[d][0] if d else None,
        "escolta_texto": ESCOLTA[d][1] if d else None,
        "virada": VIRADA.get(ident),
    }
